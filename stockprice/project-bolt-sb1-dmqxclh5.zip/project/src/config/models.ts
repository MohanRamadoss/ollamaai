import { AIModel } from '../types/models';

export const AI_MODELS: AIModel[] = [
  {
    id: 'gemini-pro-code',
    name: 'Gemini Pro Code',
    provider: 'gemini',
    features: ['Code Generation', 'Code Analysis'],
    maxTokens: 8192,
    supportsStreaming: true,
    priority: 1
  },
  {
    id: 'gemini-1.5-flash',
    name: 'Gemini 1.5 Flash',
    provider: 'gemini',
    features: ['Fast Generation', 'Code Completion'],
    maxTokens: 4096,
    supportsStreaming: true,
    priority: 2
  },
  {
    id: 'gpt-4',
    name: 'GPT-4',
    provider: 'openai',
    features: ['Advanced Reasoning', 'Complex Tasks'],
    maxTokens: 8192,
    supportsStreaming: true,
    priority: 1
  },
  {
    id: 'gpt-4-turbo',
    name: 'GPT-4 Turbo',
    provider: 'openai',
    features: ['Fast Processing', 'Latest Knowledge'],
    maxTokens: 4096,
    supportsStreaming: true,
    priority: 2
  }
];