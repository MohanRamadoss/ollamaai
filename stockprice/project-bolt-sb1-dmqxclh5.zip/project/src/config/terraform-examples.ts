import { CloudProvider } from './terraform';

interface TerraformExample {
  title: string;
  description: string;
  requirements: string;
  provider: CloudProvider;
  resourceType: string;
}

export const TERRAFORM_EXAMPLES: TerraformExample[] = [
  // AWS Examples
  {
    title: 'Production EKS Cluster',
    description: 'Create a production-grade EKS cluster with multiple node groups',
    provider: 'aws',
    resourceType: 'aws_eks_cluster',
    requirements: `Create a production-grade EKS cluster with the following requirements:
- 3 node groups across different availability zones
- Node groups should use t3.large instances with auto-scaling (min: 2, max: 10)
- Enable cluster autoscaler and metrics server
- Configure RBAC with least privilege access
- Enable control plane logging
- Set up cluster encryption using KMS
- Configure network policies using Calico
- Implement proper tagging for cost allocation
- Set up private networking with VPC endpoints
- Enable container insights monitoring
- Configure cluster backup and disaster recovery`
  },
  {
    title: 'Secure RDS Database',
    description: 'Set up a highly available RDS instance with security controls',
    provider: 'aws',
    resourceType: 'aws_db_instance',
    requirements: `Create a secure RDS database with:
- Multi-AZ deployment for high availability
- Automated backups with 30-day retention
- Encryption at rest using KMS
- Enhanced monitoring enabled
- Performance insights enabled
- Parameter groups optimized for production
- Subnet groups across 3 AZs
- Security group with restricted access
- Automated minor version upgrades
- Maintenance window during off-peak hours
- Tags for cost allocation and management`
  },
  // Azure Examples
  {
    title: 'AKS Production Cluster',
    description: 'Deploy an enterprise-grade AKS cluster',
    provider: 'azure',
    resourceType: 'azurerm_kubernetes_cluster',
    requirements: `Set up an AKS cluster with:
- Enable Azure CNI networking
- Configure multiple node pools (system and user)
- Enable Azure Monitor for containers
- Set up pod security policies
- Configure Azure AD integration
- Enable network policies
- Implement auto-scaling with spot instances
- Set up private cluster with private endpoints
- Enable container insights
- Configure backup for etcd
- Implement proper RBAC
- Set up Azure Policy for Kubernetes`
  },
  {
    title: 'Azure SQL Database',
    description: 'Create a highly available Azure SQL Database',
    provider: 'azure',
    resourceType: 'azurerm_sql_database',
    requirements: `Deploy Azure SQL Database with:
- Business Critical service tier
- Geo-replication enabled
- Automatic tuning enabled
- Advanced threat protection
- Transparent data encryption
- Private endpoint connectivity
- Automated backups with long-term retention
- Elastic pool configuration
- Performance alerts and monitoring
- Auditing enabled
- Tags for resource organization`
  },
  // GCP Examples
  {
    title: 'GKE Autopilot Cluster',
    description: 'Set up a fully managed GKE Autopilot cluster',
    provider: 'gcp',
    resourceType: 'google_container_cluster',
    requirements: `Create a GKE Autopilot cluster with:
- Enable Workload Identity
- Configure Cloud Armor security policies
- Set up Binary Authorization
- Enable Container-Optimized OS
- Configure VPC-native networking
- Set up Cloud Monitoring and Logging
- Enable Release Channels
- Configure Backup for GKE
- Set up Private cluster
- Enable Network Policy
- Configure master authorized networks
- Implement proper IAM roles`
  },
  {
    title: 'Cloud SQL Instance',
    description: 'Deploy a highly available Cloud SQL instance',
    provider: 'gcp',
    resourceType: 'google_sql_database_instance',
    requirements: `Set up Cloud SQL with:
- High availability configuration
- Automated backups with point-in-time recovery
- Enable Cloud SQL insights
- Configure maintenance window
- Set up private IP connectivity
- Enable SSL/TLS enforcement
- Configure automated storage increases
- Set up monitoring and alerts
- Enable database flags for security
- Configure backup retention policies
- Implement proper IAM roles
- Set up proper networking`
  }
];