import { Shield, Server, Network, Database, Box, HardDrive, Cloud } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export const TERRAFORM_RESOURCE_TYPES = {
  aws: {
    compute: [
      { value: 'aws_instance', label: 'EC2 Instance' },
      { value: 'aws_eks_cluster', label: 'EKS Cluster' },
      { value: 'aws_eks_node_group', label: 'EKS Node Group' },
      { value: 'aws_eks_fargate_profile', label: 'EKS Fargate Profile' },
      { value: 'aws_launch_template', label: 'Launch Template' },
      { value: 'aws_autoscaling_group', label: 'Auto Scaling Group' },
      { value: 'aws_lambda_function', label: 'Lambda Function' }
    ],
    containers: [
      { value: 'aws_eks_cluster', label: 'EKS Cluster' },
      { value: 'aws_eks_node_group', label: 'EKS Node Group' },
      { value: 'aws_eks_fargate_profile', label: 'EKS Fargate Profile' },
      { value: 'aws_ecr_repository', label: 'ECR Repository' },
      { value: 'aws_ecs_cluster', label: 'ECS Cluster' },
      { value: 'aws_ecs_service', label: 'ECS Service' },
      { value: 'aws_ecs_task_definition', label: 'ECS Task Definition' }
    ],
    networking: [
      { value: 'aws_vpc', label: 'VPC' },
      { value: 'aws_subnet', label: 'Subnet' },
      { value: 'aws_security_group', label: 'Security Group' },
      { value: 'aws_route_table', label: 'Route Table' },
      { value: 'aws_internet_gateway', label: 'Internet Gateway' },
      { value: 'aws_nat_gateway', label: 'NAT Gateway' },
      { value: 'aws_vpc_endpoint', label: 'VPC Endpoint' }
    ],
    storage: [
      { value: 'aws_s3_bucket', label: 'S3 Bucket' },
      { value: 'aws_ebs_volume', label: 'EBS Volume' },
      { value: 'aws_efs_file_system', label: 'EFS File System' }
    ],
    database: [
      { value: 'aws_db_instance', label: 'RDS Instance' },
      { value: 'aws_dynamodb_table', label: 'DynamoDB Table' },
      { value: 'aws_elasticache_cluster', label: 'ElastiCache Cluster' }
    ],
    security: [
      { value: 'aws_iam_role', label: 'IAM Role' },
      { value: 'aws_iam_policy', label: 'IAM Policy' },
      { value: 'aws_kms_key', label: 'KMS Key' },
      { value: 'aws_secretsmanager_secret', label: 'Secrets Manager Secret' }
    ]
  },
  azure: {
    compute: [
      { value: 'azurerm_virtual_machine', label: 'Virtual Machine' },
      { value: 'azurerm_kubernetes_cluster', label: 'AKS Cluster' },
      { value: 'azurerm_kubernetes_cluster_node_pool', label: 'AKS Node Pool' },
      { value: 'azurerm_container_group', label: 'Container Instance' },
      { value: 'azurerm_function_app', label: 'Function App' }
    ],
    containers: [
      { value: 'azurerm_kubernetes_cluster', label: 'AKS Cluster' },
      { value: 'azurerm_kubernetes_cluster_node_pool', label: 'AKS Node Pool' },
      { value: 'azurerm_container_registry', label: 'Container Registry' },
      { value: 'azurerm_container_group', label: 'Container Instance' },
      { value: 'azurerm_kubernetes_cluster_identity', label: 'AKS Identity' }
    ],
    networking: [
      { value: 'azurerm_virtual_network', label: 'Virtual Network' },
      { value: 'azurerm_subnet', label: 'Subnet' },
      { value: 'azurerm_network_security_group', label: 'Network Security Group' },
      { value: 'azurerm_public_ip', label: 'Public IP' },
      { value: 'azurerm_application_gateway', label: 'Application Gateway' }
    ],
    storage: [
      { value: 'azurerm_storage_account', label: 'Storage Account' },
      { value: 'azurerm_managed_disk', label: 'Managed Disk' },
      { value: 'azurerm_storage_container', label: 'Storage Container' }
    ],
    database: [
      { value: 'azurerm_postgresql_server', label: 'PostgreSQL Server' },
      { value: 'azurerm_mysql_server', label: 'MySQL Server' },
      { value: 'azurerm_sql_server', label: 'SQL Server' }
    ],
    security: [
      { value: 'azurerm_key_vault', label: 'Key Vault' },
      { value: 'azurerm_role_assignment', label: 'Role Assignment' },
      { value: 'azurerm_user_assigned_identity', label: 'Managed Identity' }
    ]
  },
  gcp: {
    compute: [
      { value: 'google_compute_instance', label: 'Compute Instance' },
      { value: 'google_container_cluster', label: 'GKE Cluster' },
      { value: 'google_container_node_pool', label: 'GKE Node Pool' },
      { value: 'google_cloud_run_service', label: 'Cloud Run Service' }
    ],
    containers: [
      { value: 'google_container_cluster', label: 'GKE Cluster' },
      { value: 'google_container_node_pool', label: 'GKE Node Pool' },
      { value: 'google_container_registry', label: 'Container Registry' },
      { value: 'google_artifact_registry_repository', label: 'Artifact Registry' },
      { value: 'google_container_cluster_auth', label: 'GKE Auth' }
    ],
    networking: [
      { value: 'google_compute_network', label: 'VPC Network' },
      { value: 'google_compute_subnetwork', label: 'Subnet' },
      { value: 'google_compute_firewall', label: 'Firewall Rule' },
      { value: 'google_compute_router', label: 'Cloud Router' }
    ],
    storage: [
      { value: 'google_storage_bucket', label: 'Cloud Storage Bucket' },
      { value: 'google_compute_disk', label: 'Persistent Disk' },
      { value: 'google_filestore_instance', label: 'Filestore Instance' }
    ],
    database: [
      { value: 'google_sql_database_instance', label: 'Cloud SQL Instance' },
      { value: 'google_spanner_instance', label: 'Spanner Instance' },
      { value: 'google_bigtable_instance', label: 'Bigtable Instance' }
    ],
    security: [
      { value: 'google_service_account', label: 'Service Account' },
      { value: 'google_kms_key_ring', label: 'KMS Key Ring' },
      { value: 'google_kms_crypto_key', label: 'KMS Crypto Key' }
    ]
  }
} as const;

export type CloudProvider = keyof typeof TERRAFORM_RESOURCE_TYPES;
export type ResourceCategory = keyof typeof TERRAFORM_RESOURCE_TYPES.aws;
export type ResourceType = { value: string; label: string };

export const CATEGORY_ICONS: Record<ResourceCategory, LucideIcon> = {
  compute: Server,
  containers: Box,
  networking: Network,
  storage: HardDrive,
  database: Database,
  security: Shield
};

export const PROVIDER_ICONS: Record<CloudProvider, LucideIcon> = {
  aws: Cloud,
  azure: Cloud,
  gcp: Cloud
};