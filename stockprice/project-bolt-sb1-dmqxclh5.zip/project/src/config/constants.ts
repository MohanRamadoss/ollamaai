export const FILE_EXTENSIONS = {
  // Programming Languages
  javascript: 'js',
  typescript: 'ts',
  python: 'py',
  java: 'java',
  cpp: 'cpp',
  go: 'go',
  ruby: 'rb',
  php: 'php',
  csharp: 'cs',
  rust: 'rs',
  swift: 'swift',
  kotlin: 'kt',

  // Configuration Management
  yaml: 'yml',
  ansible: 'yml',
  shell: 'sh',
  powershell: 'ps1',
  terraform: 'tf',
  cloudformation: 'yaml',
  kubernetes: 'yaml',
  docker: 'Dockerfile',

  // Other
  json: 'json',
  sql: 'sql',
  markdown: 'md'
} as const;

export const ACCEPTED_FILE_EXTENSIONS = [
  // Programming Languages
  '.js', '.ts', '.py', '.java', '.cpp', '.go', '.rb', '.php', '.cs', '.rs', '.swift', '.kt',
  
  // Configuration Management
  '.yml', '.yaml', '.sh', '.ps1', '.tf', 
  'Dockerfile', // Special case for Dockerfiles
  
  // Other
  '.json', '.sql', '.md'
];