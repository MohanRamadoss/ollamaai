import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Code2, 
  LogOut,
  Wand2,
  ArrowLeftRight,
  Search,
  Cloud,
  GitBranch,
  Database,
  Bot,
  Sparkles,
  FileCode
} from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { Avatar } from './Avatar';

export function Header() {
  const location = useLocation();
  const { user, signOut } = useAuth();

  const navItems = [
    { path: '/generate', label: 'Generate', icon: <Wand2 className="w-4 h-4" /> },
    { path: '/convert', label: 'Convert', icon: <ArrowLeftRight className="w-4 h-4" /> },
    { path: '/analyze', label: 'Analyze', icon: <Search className="w-4 h-4" /> },
    { path: '/cloud', label: 'Cloud', icon: <Cloud className="w-4 h-4" /> },
    { path: '/cicd', label: 'CI/CD', icon: <GitBranch className="w-4 h-4" /> },
    { path: '/sql', label: 'SQL', icon: <Database className="w-4 h-4" /> },
    { path: '/agent', label: 'Agent', icon: <Bot className="w-4 h-4" /> },
    { path: '/prompts', label: 'Prompts', icon: <Sparkles className="w-4 h-4" /> },
    { path: '/terraform-rag', label: 'Terraform RAG', icon: <FileCode className="w-4 h-4" /> }
  ];

  return (
    <header className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            {/* Logo */}
            <Link to="/" className="flex items-center">
              <Code2 className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">VisaCodeCraft</span>
            </Link>
            
            {/* Navigation */}
            <nav className="ml-8 flex space-x-1">
              {navItems.map((item) => (
                <Link 
                  key={item.path}
                  to={item.path}
                  className={`inline-flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                    location.pathname === item.path 
                      ? 'text-indigo-600 bg-indigo-50' 
                      : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {item.icon}
                  <span className="ml-2">{item.label}</span>
                </Link>
              ))}
            </nav>
          </div>

          {/* User Profile & Sign Out */}
          <div className="flex items-center">
            {user && (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-3">
                  <Avatar name={user.name} size="sm" />
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-gray-900">{user.name}</span>
                    <span className="text-xs text-gray-500">{user.email}</span>
                  </div>
                </div>
                <button
                  onClick={signOut}
                  className="inline-flex items-center px-3 py-2 border border-gray-200 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 hover:text-gray-900 transition-colors"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}