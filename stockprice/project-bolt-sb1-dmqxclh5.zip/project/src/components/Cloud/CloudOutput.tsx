import React from 'react';
import { CodeEditor } from '../CodeEditor';
import type { CloudProvider, ResourceType } from '../../types/cloud';

interface CloudOutputProps {
  code: string;
  isGenerating: boolean;
  provider: CloudProvider;
  resourceType: ResourceType;
}

const getLanguage = (provider: CloudProvider, resourceType: ResourceType): string => {
  switch (resourceType) {
    case 'terraform':
      return 'hcl';
    case 'cloudformation':
      return 'yaml';
    case 'azurearm':
      return 'json';
    case 'gcpdeployment':
      return 'yaml';
    case 'kubernetes':
      return 'yaml';
    case 'serverless':
      return 'yaml';
    default:
      return 'yaml';
  }
};

export function CloudOutput({ code, isGenerating, provider, resourceType }: CloudOutputProps) {
  return (
    <div className="space-y-4">
      <CodeEditor
        value={code}
        onChange={() => {}}
        language={getLanguage(provider, resourceType)}
        readOnly
        isGenerating={isGenerating}
      />
    </div>
  );
}