import React from 'react';
import { Cloud, Server, Database, HardDrive, Network } from 'lucide-react';
import type { CloudProvider, ResourceType } from '../../types/cloud';

const CLOUD_PROVIDERS: Record<CloudProvider, { name: string; icon: JSX.Element }> = {
  aws: { name: 'AWS', icon: <Cloud className="w-5 h-5" /> },
  azure: { name: 'Azure', icon: <Cloud className="w-5 h-5" /> },
  gcp: { name: 'Google Cloud', icon: <Cloud className="w-5 h-5" /> }
};

const RESOURCE_TYPES: Record<ResourceType, { name: string; icon: JSX.Element }> = {
  terraform: { name: 'Terraform', icon: <Server className="w-5 h-5" /> },
  cloudformation: { name: 'CloudFormation', icon: <Server className="w-5 h-5" /> },
  azurearm: { name: 'Azure ARM', icon: <Server className="w-5 h-5" /> },
  gcpdeployment: { name: 'GCP Deployment', icon: <Server className="w-5 h-5" /> },
  kubernetes: { name: 'Kubernetes', icon: <Server className="w-5 h-5" /> },
  serverless: { name: 'Serverless', icon: <Server className="w-5 h-5" /> },
  database: { name: 'Database', icon: <Database className="w-5 h-5" /> },
  storage: { name: 'Storage', icon: <HardDrive className="w-5 h-5" /> },
  networking: { name: 'Networking', icon: <Network className="w-5 h-5" /> }
};

interface CloudControlProps {
  provider: string;
  resourceType: string;
  onProviderChange: (provider: CloudProvider) => void;
  onResourceTypeChange: (type: ResourceType) => void;
}

export function CloudControl({
  provider,
  resourceType,
  onProviderChange,
  onResourceTypeChange
}: CloudControlProps) {
  return (
    <div className="space-y-6">
      {/* Cloud Provider Selection */}
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-700">Cloud Provider</label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Object.entries(CLOUD_PROVIDERS).map(([key, value]) => (
            <button
              key={key}
              onClick={() => onProviderChange(key as CloudProvider)}
              className={`flex items-center space-x-3 p-4 rounded-lg border transition-colors ${
                provider === key
                  ? 'border-indigo-500 bg-indigo-50'
                  : 'border-gray-200 hover:border-indigo-300'
              }`}
            >
              <div className={`${provider === key ? 'text-indigo-500' : 'text-gray-400'}`}>
                {value.icon}
              </div>
              <span className="font-medium">{value.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Resource Type Selection */}
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-700">Resource Type</label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Object.entries(RESOURCE_TYPES).map(([key, value]) => (
            <button
              key={key}
              onClick={() => onResourceTypeChange(key as ResourceType)}
              className={`flex items-center space-x-3 p-4 rounded-lg border transition-colors ${
                resourceType === key
                  ? 'border-indigo-500 bg-indigo-50'
                  : 'border-gray-200 hover:border-indigo-300'
              }`}
            >
              <div className={`${resourceType === key ? 'text-indigo-500' : 'text-gray-400'}`}>
                {value.icon}
              </div>
              <span className="font-medium">{value.name}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}