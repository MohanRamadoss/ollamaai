import React from 'react';
import { AlertCircle } from 'lucide-react';

interface TokenCounterProps {
  code: string;
  maxTokens: number;
}

export function TokenCounter({ code, maxTokens }: TokenCounterProps) {
  // Simple estimation: ~1 token per 4 characters
  const estimatedTokens = Math.ceil(code.length / 4);
  const tokenPercentage = (estimatedTokens / maxTokens) * 100;
  
  return (
    <div className="flex items-center space-x-2 text-sm">
      <div className="flex-1">
        <div className="flex justify-between mb-1">
          <span className="text-gray-700">Tokens Used</span>
          <span className="text-gray-700">
            {estimatedTokens.toLocaleString()} / {maxTokens.toLocaleString()}
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-1.5">
          <div
            className={`h-1.5 rounded-full transition-all duration-300 ${
              tokenPercentage > 90 ? 'bg-red-500' : 'bg-indigo-600'
            }`}
            style={{ width: `${Math.min(tokenPercentage, 100)}%` }}
          />
        </div>
      </div>
      {tokenPercentage > 90 && (
        <AlertCircle className="w-4 h-4 text-red-500" />
      )}
    </div>
  );
}