import React from 'react';
import { Code2, TestTube2, Bug, Zap, RefreshCw, FileText, CheckCircle2, Paintbrush } from 'lucide-react';

export const ANALYSIS_ACTIONS = [
  { id: 'analyze', name: 'Analyze Code', icon: <Code2 className="w-5 h-5" />, description: 'General code analysis and recommendations' },
  { id: 'test', name: 'Generate Tests', icon: <TestTube2 className="w-5 h-5" />, description: 'Create unit tests for your code' },
  { id: 'debug', name: 'Debug Assistant', icon: <Bug className="w-5 h-5" />, description: 'Find and fix potential bugs' },
  { id: 'optimize', name: 'Optimize', icon: <Zap className="w-5 h-5" />, description: 'Improve code performance' },
  { id: 'refactor', name: 'Refactor', icon: <RefreshCw className="w-5 h-5" />, description: 'Restructure and improve code quality' },
  { id: 'document', name: 'Document', icon: <FileText className="w-5 h-5" />, description: 'Generate documentation' },
  { id: 'best-practices', name: 'Best Practices', icon: <CheckCircle2 className="w-5 h-5" />, description: 'Check against best practices' },
  { id: 'style-check', name: 'Style Check', icon: <Paintbrush className="w-5 h-5" />, description: 'Verify code style and formatting' }
];

interface ActionSelectProps {
  selectedAction: string;
  onChange: (action: string) => void;
}

export function ActionSelect({ selectedAction, onChange }: ActionSelectProps) {
  return (
    <div className="space-y-4">
      <label className="block text-sm font-medium text-gray-700">Analysis Type</label>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {ANALYSIS_ACTIONS.map((action) => (
          <button
            key={action.id}
            onClick={() => onChange(action.id)}
            className={`flex items-start space-x-3 p-4 rounded-lg border transition-colors ${
              selectedAction === action.id
                ? 'border-indigo-500 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-300'
            }`}
          >
            <div className={`${selectedAction === action.id ? 'text-indigo-500' : 'text-gray-400'}`}>
              {action.icon}
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-medium text-gray-900">{action.name}</h3>
              <p className="mt-1 text-xs text-gray-500">{action.description}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}