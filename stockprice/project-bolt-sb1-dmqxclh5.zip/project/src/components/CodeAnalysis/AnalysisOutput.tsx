import React from 'react';
import { AlertCircle, CheckCircle, Info } from 'lucide-react';

interface AnalysisResult {
  type: 'error' | 'warning' | 'info' | 'success';
  message: string;
  line?: number;
  suggestion?: string;
}

interface AnalysisOutputProps {
  results: AnalysisResult[];
  isAnalyzing: boolean;
  progress: number;
}

const typeIcons = {
  error: <AlertCircle className="w-5 h-5 text-red-500" />,
  warning: <AlertCircle className="w-5 h-5 text-yellow-500" />,
  info: <Info className="w-5 h-5 text-blue-500" />,
  success: <CheckCircle className="w-5 h-5 text-green-500" />
};

const typeColors = {
  error: 'bg-red-50 border-red-200',
  warning: 'bg-yellow-50 border-yellow-200',
  info: 'bg-blue-50 border-blue-200',
  success: 'bg-green-50 border-green-200'
};

export function AnalysisOutput({ results, isAnalyzing, progress }: AnalysisOutputProps) {
  if (isAnalyzing) {
    return (
      <div className="space-y-4">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          <div className="h-4 bg-gray-200 rounded w-5/6"></div>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div 
            className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    );
  }

  if (!results.length) {
    return (
      <div className="text-center py-8 text-gray-500">
        No analysis results yet. Submit your code to begin analysis.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {results.map((result, index) => (
        <div
          key={index}
          className={`p-4 rounded-lg border ${typeColors[result.type]}`}
        >
          <div className="flex items-start space-x-3">
            {typeIcons[result.type]}
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-gray-900">
                  {result.message}
                </p>
                {result.line && (
                  <span className="text-xs text-gray-500">Line {result.line}</span>
                )}
              </div>
              {result.suggestion && (
                <p className="mt-1 text-sm text-gray-600">{result.suggestion}</p>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}