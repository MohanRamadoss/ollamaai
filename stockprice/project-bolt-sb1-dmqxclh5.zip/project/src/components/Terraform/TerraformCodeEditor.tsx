import React, { Suspense } from 'react';
import { Download, Copy, Check, Code2 } from 'lucide-react';
import CodeMirror from '@uiw/react-codemirror';
import { vscodeDark } from '@uiw/codemirror-theme-vscode';
import { StreamLanguage } from '@codemirror/language';
import { FILE_EXTENSIONS } from '../../config/constants';

interface TerraformCodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  readOnly?: boolean;
  isGenerating?: boolean;
  progress?: number;
  showValidation?: boolean;
}

// Basic HCL syntax definition
const hcl = {
  name: 'hcl',
  token: function(stream: any, state: any) {
    if (stream.eatSpace()) return null;

    // Comments
    if (stream.match('#') || stream.match('//')) {
      stream.skipToEnd();
      return 'comment';
    }

    // Block start
    if (stream.match('{')) {
      state.braceDepth++;
      return 'bracket';
    }

    // Block end
    if (stream.match('}')) {
      state.braceDepth--;
      return 'bracket';
    }

    // Strings
    if (stream.match(/"(?:[^"\\]|\\.)*"/)) return 'string';
    if (stream.match(/'(?:[^'\\]|\\.)*'/)) return 'string';

    // Keywords
    if (stream.match(/\b(resource|data|provider|variable|output|locals|module|terraform)\b/))
      return 'keyword';

    // Numbers
    if (stream.match(/\b\d+(\.\d+)?\b/)) return 'number';

    // Identifiers
    if (stream.match(/\b[A-Za-z][A-Za-z0-9_-]*\b/)) return 'variable';

    stream.next();
    return null;
  },
  startState: function() {
    return { braceDepth: 0 };
  },
};

export function TerraformCodeEditor({
  value,
  onChange,
  readOnly = false,
  isGenerating = false,
  progress = 0,
  showValidation = true,
}: TerraformCodeEditorProps) {
  const [copied, setCopied] = React.useState(false);
  const [downloading, setDownloading] = React.useState(false);
  const [validationResults, setValidationResults] = React.useState<string[]>([]);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const blob = new Blob([value], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `main.${FILE_EXTENSIONS.hcl}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } finally {
      setDownloading(false);
    }
  };

  // Simple validation for Terraform syntax
  const validateCode = (code: string) => {
    const results: string[] = [];
    
    // Check for required blocks
    if (!code.includes('provider')) {
      results.push('Warning: No provider block found');
    }
    if (!code.includes('terraform {')) {
      results.push('Warning: No terraform block found');
    }
    
    // Check for common security issues
    if (code.includes('*')) {
      results.push('Security: Avoid using wildcard permissions');
    }
    if (code.includes('0.0.0.0/0')) {
      results.push('Security: Unrestricted network access detected');
    }
    
    // Check for best practices
    if (!code.includes('tags')) {
      results.push('Best Practice: Consider adding resource tags');
    }
    if (code.includes('default = true')) {
      results.push('Best Practice: Avoid using default VPCs/subnets');
    }

    setValidationResults(results);
  };

  React.useEffect(() => {
    if (showValidation && value) {
      validateCode(value);
    }
  }, [value, showValidation]);

  return (
    <div className="space-y-2">
      {/* Progress Bar */}
      {isGenerating && (
        <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
          <div 
            className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}

      {/* Code Editor */}
      <div className="relative">
        <div className="h-[500px] border border-gray-200 rounded-lg overflow-hidden">
          <Suspense fallback={<div className="p-4 text-gray-500">Loading editor...</div>}>
            <CodeMirror
              value={value}
              height="100%"
              theme={vscodeDark}
              extensions={[StreamLanguage.define(hcl)]}
              onChange={(value) => {
                onChange(value);
                if (showValidation) {
                  validateCode(value);
                }
              }}
              editable={!readOnly}
              basicSetup={{
                lineNumbers: true,
                highlightActiveLineGutter: true,
                highlightSpecialChars: true,
                history: true,
                foldGutter: true,
                drawSelection: true,
                dropCursor: true,
                allowMultipleSelections: true,
                indentOnInput: true,
                syntaxHighlighting: true,
                bracketMatching: true,
                closeBrackets: true,
                autocompletion: true,
                rectangularSelection: true,
                crosshairCursor: true,
                highlightActiveLine: true,
                highlightSelectionMatches: true,
                closeBracketsKeymap: true,
                defaultKeymap: true,
                searchKeymap: true,
                historyKeymap: true,
                foldKeymap: true,
                completionKeymap: true,
                lintKeymap: true,
              }}
            />
          </Suspense>
        </div>

        {/* Action Buttons */}
        <div className="absolute top-2 right-2 flex space-x-2">
          <button
            onClick={handleCopy}
            className="p-2 rounded-md bg-gray-800 text-white hover:bg-gray-700 transition-colors"
            title="Copy code"
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
          </button>
          <button
            onClick={handleDownload}
            disabled={!value || downloading}
            className={`p-2 rounded-md bg-gray-800 text-white transition-colors ${
              value && !downloading ? 'hover:bg-gray-700' : 'opacity-50 cursor-not-allowed'
            }`}
            title="Download code"
          >
            <Download size={16} className={downloading ? 'animate-bounce' : ''} />
          </button>
        </div>
      </div>

      {/* Validation Results */}
      {showValidation && validationResults.length > 0 && (
        <div className="mt-4 space-y-2">
          <h3 className="text-sm font-medium text-gray-700">Validation Results</h3>
          <div className="space-y-1">
            {validationResults.map((result, index) => (
              <div
                key={index}
                className={`p-2 rounded-md text-sm ${
                  result.startsWith('Security')
                    ? 'bg-red-50 text-red-700'
                    : result.startsWith('Warning')
                    ? 'bg-yellow-50 text-yellow-700'
                    : 'bg-blue-50 text-blue-700'
                }`}
              >
                {result}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}