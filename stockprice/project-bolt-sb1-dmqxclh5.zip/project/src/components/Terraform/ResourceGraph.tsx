import React from 'react';
import { ArrowRight, Database, Server, Network, Shield } from 'lucide-react';

interface Resource {
  id: string;
  type: string;
  name: string;
  dependencies: string[];
}

interface ResourceGraphProps {
  resources: Resource[];
}

export function ResourceGraph({ resources }: ResourceGraphProps) {
  const getResourceIcon = (type: string) => {
    if (type.includes('database')) return <Database className="w-5 h-5" />;
    if (type.includes('instance') || type.includes('compute')) return <Server className="w-5 h-5" />;
    if (type.includes('vpc') || type.includes('network')) return <Network className="w-5 h-5" />;
    return <Shield className="w-5 h-5" />;
  };

  return (
    <div className="p-4 bg-white rounded-lg shadow">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Resource Dependencies</h3>
      <div className="space-y-4">
        {resources.map((resource) => (
          <div key={resource.id} className="relative">
            <div className="flex items-center space-x-4">
              {getResourceIcon(resource.type)}
              <div className="flex-1">
                <div className="font-medium text-gray-900">{resource.name}</div>
                <div className="text-sm text-gray-500">{resource.type}</div>
              </div>
            </div>
            {resource.dependencies.length > 0 && (
              <div className="ml-6 mt-2 space-y-2">
                {resource.dependencies.map((dep) => (
                  <div key={dep} className="flex items-center text-sm text-gray-600">
                    <ArrowRight className="w-4 h-4 mr-2" />
                    {dep}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}