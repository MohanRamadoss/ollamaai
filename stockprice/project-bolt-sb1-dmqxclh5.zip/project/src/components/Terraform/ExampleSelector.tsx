import React from 'react';
import { Lightbulb } from 'lucide-react';
import { TERRAFORM_EXAMPLES } from '../../config/terraform-examples';
import type { CloudProvider } from '../../config/terraform';

interface ExampleSelectorProps {
  provider: CloudProvider;
  resourceType: string;
  onSelect: (requirements: string) => void;
}

export function ExampleSelector({ provider, resourceType, onSelect }: ExampleSelectorProps) {
  const filteredExamples = TERRAFORM_EXAMPLES.filter(
    example => example.provider === provider && example.resourceType === resourceType
  );

  if (filteredExamples.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
        <Lightbulb className="w-4 h-4" />
        <span>Example Requirements</span>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredExamples.map((example, index) => (
          <button
            key={index}
            onClick={() => onSelect(example.requirements)}
            className="text-left p-4 rounded-lg border border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-colors"
          >
            <h3 className="font-medium text-gray-900">{example.title}</h3>
            <p className="mt-1 text-sm text-gray-500">{example.description}</p>
          </button>
        ))}
      </div>
    </div>
  );
}