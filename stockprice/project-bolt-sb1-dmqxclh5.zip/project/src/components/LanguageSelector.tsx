import React from 'react';
import { PROGRAMMING_LANGUAGES } from '../config/languages';
import { ProgrammingLanguage } from '../types/models';

interface LanguageSelectorProps {
  value: string;
  onChange: (language: string) => void;
  label?: string;
}

export function LanguageSelector({ value, onChange, label = 'Programming Language' }: LanguageSelectorProps) {
  // Group languages by category
  const groupedLanguages = Object.values(PROGRAMMING_LANGUAGES).reduce((acc, lang) => {
    const category = lang.category || 'programming';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(lang);
    return acc;
  }, {} as Record<string, ProgrammingLanguage[]>);

  return (
    <div className="space-y-4">
      <label className="block text-sm font-medium text-gray-700">{label}</label>
      
      {/* Programming Languages Section */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-500">Programming Languages</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {groupedLanguages.programming?.map((language) => (
            <LanguageCard
              key={language.id}
              language={language}
              isSelected={value === language.id}
              onClick={() => onChange(language.id)}
            />
          ))}
        </div>
      </div>

      {/* Configuration Management Section */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-500">Configuration Management</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {groupedLanguages.config?.map((language) => (
            <LanguageCard
              key={language.id}
              language={language}
              isSelected={value === language.id}
              onClick={() => onChange(language.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

interface LanguageCardProps {
  language: ProgrammingLanguage;
  isSelected: boolean;
  onClick: () => void;
}

function LanguageCard({ language, isSelected, onClick }: LanguageCardProps) {
  return (
    <div
      className={`p-4 border rounded-lg cursor-pointer transition-colors ${
        isSelected
          ? 'border-indigo-500 bg-indigo-50'
          : 'border-gray-200 hover:border-indigo-300'
      }`}
      onClick={onClick}
    >
      <div className="flex items-center space-x-2">
        <span className="text-2xl">{language.icon}</span>
        <div>
          <p className="font-medium text-gray-900">{language.name}</p>
          <p className="text-xs text-gray-500">.{language.extension}</p>
        </div>
      </div>
      <div className="mt-2">
        <div className="flex flex-wrap gap-1">
          {language.features.slice(0, 2).map((feature, index) => (
            <span
              key={index}
              className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800"
            >
              {feature}
            </span>
          ))}
          {language.features.length > 2 && (
            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
              +{language.features.length - 2}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}