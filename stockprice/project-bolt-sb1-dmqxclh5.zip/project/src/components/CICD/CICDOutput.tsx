import React from 'react';
import { CodeEditor } from '../CodeEditor';
import type { Platform, PipelineType } from '../../types/cicd';

interface CICDOutputProps {
  code: string;
  isGenerating: boolean;
  platform: Platform;
  pipelineType: PipelineType;
}

const getLanguage = (platform: Platform): string => {
  switch (platform) {
    case 'github':
    case 'gitlab':
      return 'yaml';
    case 'azure-devops':
      return 'yaml';
    case 'jenkins':
      return 'groovy';
    default:
      return 'yaml';
  }
};

export function CICDOutput({ code, isGenerating, platform, pipelineType }: CICDOutputProps) {
  return (
    <div className="space-y-4">
      <CodeEditor
        value={code}
        onChange={() => {}}
        language={getLanguage(platform)}
        readOnly
        isGenerating={isGenerating}
      />
    </div>
  );
}