import React, { Suspense } from 'react';
import { Download, Copy, Check } from 'lucide-react';
import CodeMirror from '@uiw/react-codemirror';
import { vscodeDark } from '@uiw/codemirror-theme-vscode';
import { sql } from '@codemirror/lang-sql';
import { FILE_EXTENSIONS } from '../../config/constants';

interface SQLCodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  readOnly?: boolean;
  isGenerating?: boolean;
  progress?: number;
}

export function SQLCodeEditor({ 
  value, 
  onChange, 
  readOnly = false,
  isGenerating = false,
  progress = 0 
}: SQLCodeEditorProps) {
  const [copied, setCopied] = React.useState(false);
  const [downloading, setDownloading] = React.useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const blob = new Blob([value], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `query.${FILE_EXTENSIONS.sql}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-2">
      {/* Progress Bar */}
      {isGenerating && (
        <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
          <div 
            className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}

      {/* Code Editor */}
      <div className="relative">
        <div className="h-[500px] border border-gray-200 rounded-lg overflow-hidden">
          <Suspense fallback={<div className="p-4 text-gray-500">Loading editor...</div>}>
            <CodeMirror
              value={value}
              height="100%"
              theme={vscodeDark}
              extensions={[sql()]}
              onChange={onChange}
              editable={!readOnly}
              basicSetup={{
                lineNumbers: true,
                highlightActiveLineGutter: true,
                highlightSpecialChars: true,
                history: true,
                foldGutter: true,
                drawSelection: true,
                dropCursor: true,
                allowMultipleSelections: true,
                indentOnInput: true,
                syntaxHighlighting: true,
                bracketMatching: true,
                closeBrackets: true,
                autocompletion: true,
                rectangularSelection: true,
                crosshairCursor: true,
                highlightActiveLine: true,
                highlightSelectionMatches: true,
                closeBracketsKeymap: true,
                defaultKeymap: true,
                searchKeymap: true,
                historyKeymap: true,
                foldKeymap: true,
                completionKeymap: true,
                lintKeymap: true,
              }}
            />
          </Suspense>
        </div>

        {/* Action Buttons */}
        <div className="absolute top-2 right-2 flex space-x-2">
          <button
            onClick={handleCopy}
            className="p-2 rounded-md bg-gray-800 text-white hover:bg-gray-700 transition-colors"
            title="Copy code"
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
          </button>
          <button
            onClick={handleDownload}
            disabled={!value || downloading}
            className={`p-2 rounded-md bg-gray-800 text-white transition-colors ${
              value && !downloading ? 'hover:bg-gray-700' : 'opacity-50 cursor-not-allowed'
            }`}
            title="Download code"
          >
            <Download size={16} className={downloading ? 'animate-bounce' : ''} />
          </button>
        </div>
      </div>
    </div>
  );
}