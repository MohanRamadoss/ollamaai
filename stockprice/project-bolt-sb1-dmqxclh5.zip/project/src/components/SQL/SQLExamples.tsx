import React from 'react';
import { Lightbulb } from 'lucide-react';
import type { SQLDialect } from '../../types/sql';

interface SQLExample {
  title: string;
  description: string;
  schema?: string;
  dialects: SQLDialect[];
}

const SQL_EXAMPLES: SQLExample[] = [
  {
    title: 'Complex Join Query',
    description: 'Find all customers who made purchases over $1000 in the last month, including their order details and product information',
    schema: `
CREATE TABLE customers (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(255)
);

CREATE TABLE orders (
  id SERIAL PRIMARY KEY,
  customer_id INTEGER REFERENCES customers(id),
  order_date TIMESTAMP,
  total_amount DECIMAL(10,2)
);

CREATE TABLE order_items (
  id SERIAL PRIMARY KEY,
  order_id INTEGER REFERENCES orders(id),
  product_id INTEGER REFERENCES products(id),
  quantity INTEGER,
  price DECIMAL(10,2)
);

CREATE TABLE products (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  price DECIMAL(10,2)
);`,
    dialects: ['postgresql', 'mysql', 'mssql', 'oracle']
  },
  {
    title: 'Aggregation with Window Functions',
    description: 'Calculate monthly sales totals and running averages for each product category',
    dialects: ['postgresql', 'mysql', 'mssql', 'oracle']
  },
  {
    title: 'Hierarchical Data Query',
    description: 'Retrieve an organization chart showing employee hierarchies with multiple levels',
    dialects: ['postgresql', 'oracle', 'mssql']
  }
];

interface SQLExamplesProps {
  onSelectExample: (example: SQLExample) => void;
  currentDialect: SQLDialect;
}

export function SQLExamples({ onSelectExample, currentDialect }: SQLExamplesProps) {
  const filteredExamples = SQL_EXAMPLES.filter(example => 
    example.dialects.includes(currentDialect)
  );

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-medium text-gray-700 flex items-center gap-2">
        <Lightbulb className="w-4 h-4" />
        Example Queries
      </h3>
      
      <div className="space-y-3">
        {filteredExamples.map((example, index) => (
          <button
            key={index}
            onClick={() => onSelectExample(example)}
            className="w-full text-left p-4 rounded-lg border border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-colors"
          >
            <h4 className="font-medium text-gray-900">{example.title}</h4>
            <p className="mt-1 text-sm text-gray-500">{example.description}</p>
          </button>
        ))}
      </div>
    </div>
  );
}