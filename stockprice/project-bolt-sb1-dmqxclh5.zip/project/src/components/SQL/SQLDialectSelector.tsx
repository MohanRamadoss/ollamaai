import React from 'react';
import { Database } from 'lucide-react';
import type { SQLDialect } from '../../types/sql';

const SQL_DIALECTS: Record<SQLDialect, { name: string; icon: JSX.Element }> = {
  postgresql: { name: 'PostgreSQL', icon: <Database className="w-5 h-5" /> },
  mysql: { name: 'MySQL', icon: <Database className="w-5 h-5" /> },
  sqlite: { name: 'SQLite', icon: <Database className="w-5 h-5" /> },
  mssql: { name: 'SQL Server', icon: <Database className="w-5 h-5" /> },
  oracle: { name: 'Oracle', icon: <Database className="w-5 h-5" /> }
};

interface SQLDialectSelectorProps {
  selected: SQLDialect;
  onChange: (dialect: SQLDialect) => void;
}

export function SQLDialectSelector({ selected, onChange }: SQLDialectSelectorProps) {
  return (
    <div className="space-y-4">
      <label className="block text-sm font-medium text-gray-700">SQL Dialect</label>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {Object.entries(SQL_DIALECTS).map(([key, value]) => (
          <button
            key={key}
            onClick={() => onChange(key as SQLDialect)}
            className={`flex items-center space-x-3 p-4 rounded-lg border transition-colors ${
              selected === key
                ? 'border-indigo-500 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-300'
            }`}
          >
            <div className={`${selected === key ? 'text-indigo-500' : 'text-gray-400'}`}>
              {value.icon}
            </div>
            <span className="font-medium">{value.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}