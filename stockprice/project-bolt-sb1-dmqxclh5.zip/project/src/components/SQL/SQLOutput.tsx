import React from 'react';
import { CodeEditor } from '../CodeEditor';

interface SQLOutputProps {
  query: string;
  explanation?: string;
}

export function SQLOutput({ query, explanation }: SQLOutputProps) {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium text-gray-900 mb-4">Generated Query</h3>
        <CodeEditor
          value={query}
          onChange={() => {}}
          language="sql"
          readOnly
        />
      </div>
      
      {explanation && (
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="text-sm font-medium text-gray-900 mb-2">Query Explanation</h3>
          <p className="text-sm text-gray-600 whitespace-pre-wrap">{explanation}</p>
        </div>
      )}
    </div>
  );
}