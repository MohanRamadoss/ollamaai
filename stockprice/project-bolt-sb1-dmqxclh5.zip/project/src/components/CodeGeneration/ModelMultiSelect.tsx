import React from 'react';
import { AI_MODELS } from '../../config/models';
import type { AIModel } from '../../types/models';

interface ModelMultiSelectProps {
  selectedModels: string[];
  onChange: (models: string[]) => void;
}

export function ModelMultiSelect({ selectedModels, onChange }: ModelMultiSelectProps) {
  const handleModelChange = (modelId: string) => {
    const newSelection = selectedModels.includes(modelId)
      ? selectedModels.filter(id => id !== modelId)
      : [...selectedModels, modelId];
    onChange(newSelection);
  };

  return (
    <div className="space-y-4">
      <label className="block text-sm font-medium text-gray-700">AI Models</label>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {AI_MODELS.map((model: AIModel) => (
          <div
            key={model.id}
            className={`p-4 border rounded-lg cursor-pointer transition-colors ${
              selectedModels.includes(model.id)
                ? 'border-indigo-500 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-300'
            }`}
            onClick={() => handleModelChange(model.id)}
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-gray-900">{model.name}</h3>
                <p className="text-sm text-gray-500">{model.provider}</p>
              </div>
              <input
                type="checkbox"
                checked={selectedModels.includes(model.id)}
                onChange={() => handleModelChange(model.id)}
                className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
              />
            </div>
            <div className="mt-2">
              <div className="flex flex-wrap gap-2">
                {model.features.map((feature, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-indigo-100 text-indigo-800"
                  >
                    {feature}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}