import React, { Suspense } from 'react';
import { Download, Copy, Check, Code2 } from 'lucide-react';
import CodeMirror from '@uiw/react-codemirror';
import { vscodeDark } from '@uiw/codemirror-theme-vscode';
import { javascript } from '@codemirror/lang-javascript';
import { python } from '@codemirror/lang-python';
import { yaml } from '@codemirror/lang-yaml';
import { json } from '@codemirror/lang-json';
import { FILE_EXTENSIONS } from '../../config/constants';
import { TokenCounter } from '../TokenCounter';

interface CodeOutputProps {
  code: string;
  language: string;
  isGenerating: boolean;
  progress: number;
  maxTokens: number;
}

const getLanguageExtension = (language: string) => {
  switch (language) {
    case 'javascript':
    case 'typescript':
      return javascript();
    case 'python':
      return python();
    case 'yaml':
    case 'yml':
      return yaml();
    case 'json':
      return json();
    default:
      return javascript();
  }
};

export function CodeOutput({ code, language, isGenerating, progress, maxTokens }: CodeOutputProps) {
  const [copied, setCopied] = React.useState(false);
  const [downloading, setDownloading] = React.useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const extension = FILE_EXTENSIONS[language as keyof typeof FILE_EXTENSIONS] || 'txt';
      const blob = new Blob([code], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `generated-code.${extension}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-medium text-gray-900">Generated Code</h2>
        <TokenCounter code={code} maxTokens={maxTokens} />
      </div>

      {/* Progress Bar */}
      {isGenerating && (
        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-sm text-gray-500">
            <span>Generating code...</span>
            <span>{progress}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}

      <div className="relative bg-gray-900 rounded-lg overflow-hidden">
        {/* Code Editor */}
        <Suspense fallback={<div className="p-4 text-gray-400">Loading editor...</div>}>
          <CodeMirror
            value={code}
            height="500px"
            theme={vscodeDark}
            extensions={[getLanguageExtension(language)]}
            editable={false}
            basicSetup={{
              lineNumbers: true,
              highlightActiveLineGutter: true,
              highlightSpecialChars: true,
              history: true,
              foldGutter: true,
              drawSelection: true,
              dropCursor: true,
              allowMultipleSelections: true,
              indentOnInput: true,
              syntaxHighlighting: true,
              bracketMatching: true,
              closeBrackets: true,
              autocompletion: true,
              rectangularSelection: true,
              crosshairCursor: true,
              highlightActiveLine: true,
              highlightSelectionMatches: true,
              closeBracketsKeymap: true,
              defaultKeymap: true,
              searchKeymap: true,
              historyKeymap: true,
              foldKeymap: true,
              completionKeymap: true,
              lintKeymap: true,
            }}
          />
        </Suspense>

        {/* Action Buttons */}
        <div className="absolute top-2 right-2 flex space-x-2">
          <button
            onClick={handleCopy}
            className="p-2 rounded-md bg-gray-800 text-white hover:bg-gray-700 transition-colors"
            title="Copy code"
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
          </button>
          <button
            onClick={handleDownload}
            disabled={!code || downloading}
            className={`p-2 rounded-md bg-gray-800 text-white transition-colors ${
              code && !downloading ? 'hover:bg-gray-700' : 'opacity-50 cursor-not-allowed'
            }`}
            title="Download code"
          >
            <Download size={16} className={downloading ? 'animate-bounce' : ''} />
          </button>
        </div>
      </div>

      {/* Model Progress Indicators */}
      {isGenerating && (
        <div className="mt-4 space-y-2">
          <div className="text-sm font-medium text-gray-700">Model Progress</div>
          <div className="space-y-3">
            {['GPT-4', 'Gemini Pro'].map((model, index) => (
              <div key={model} className="space-y-1">
                <div className="flex justify-between text-xs text-gray-600">
                  <span>{model}</span>
                  <span>{Math.min(progress + (index * 10), 100)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-1.5">
                  <div 
                    className="bg-indigo-600 h-1.5 rounded-full transition-all duration-500"
                    style={{ 
                      width: `${Math.min(progress + (index * 10), 100)}%`,
                      opacity: 0.7 + (index * 0.3)
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}