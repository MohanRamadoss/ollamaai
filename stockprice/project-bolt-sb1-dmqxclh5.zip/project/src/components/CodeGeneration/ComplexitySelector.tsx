import React from 'react';
import { Brain, Sparkles, Zap } from 'lucide-react';
import type { ComplexityLevel } from '../../types/models';

interface ComplexitySelectorProps {
  value: ComplexityLevel;
  onChange: (value: ComplexityLevel) => void;
}

const complexityGuides = {
  basic: {
    icon: <Zap className="w-5 h-5" />,
    description: 'Simple, straightforward implementations with basic functionality',
    examples: ['Basic CRUD operations', 'Simple form validation', 'Static layouts']
  },
  intermediate: {
    icon: <Sparkles className="w-5 h-5" />,
    description: 'More sophisticated features with error handling and best practices',
    examples: ['Authentication flows', 'Data visualization', 'API integration']
  },
  advanced: {
    icon: <Brain className="w-5 h-5" />,
    description: 'Complex systems with advanced patterns and optimizations',
    examples: ['Real-time features', 'Complex state management', 'Performance optimization']
  }
};

export function ComplexitySelector({ value, onChange }: ComplexitySelectorProps) {
  return (
    <div className="space-y-4">
      <label className="block text-sm font-medium text-gray-700">Complexity Level</label>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {(Object.keys(complexityGuides) as Array<keyof typeof complexityGuides>).map((level) => (
          <label
            key={level}
            className={`relative flex flex-col p-4 cursor-pointer rounded-lg border ${
              value === level
                ? 'border-indigo-500 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-200'
            }`}
          >
            <input
              type="radio"
              name="complexity"
              value={level}
              checked={value === level}
              onChange={(e) => onChange(e.target.value as ComplexityLevel)}
              className="sr-only"
            />
            <div className="flex items-center mb-2">
              {complexityGuides[level].icon}
              <span className="ml-2 font-medium capitalize">{level}</span>
            </div>
            <p className="text-sm text-gray-600">{complexityGuides[level].description}</p>
            <div className="mt-2">
              <ul className="text-xs text-gray-500 list-disc list-inside">
                {complexityGuides[level].examples.map((example, index) => (
                  <li key={index}>{example}</li>
                ))}
              </ul>
            </div>
          </label>
        ))}
      </div>
    </div>
  );
}