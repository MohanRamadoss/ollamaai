import { Language } from '../../types/models';

export class LanguageDetector {
  static detect(code: string): string | null {
    // Simple detection based on file extensions and syntax patterns
    const patterns = {
      // Programming Languages
      python: /\b(def|import|from|class)\b|\.py$/i,
      javascript: /\b(const|let|var|function)\b|\.js$/i,
      typescript: /\b(interface|type|export)\b|\.ts$/i,
      java: /\b(public|class|void|private)\b|\.java$/i,
      go: /\b(func|package|import)\b|\.go$/i,
      rust: /\b(fn|let|mut|impl)\b|\.rs$/i,
      cpp: /\b(include|namespace|class|template)\b|\.cpp$/i,
      csharp: /\b(using|namespace|class|public)\b|\.cs$/i,
      php: /\b(function|class|namespace|use)\b|\.php$/i,
      ruby: /\b(def|class|require|module)\b|\.rb$/i,
      swift: /\b(func|class|struct|import)\b|\.swift$/i,
      kotlin: /\b(fun|class|val|var)\b|\.kt$/i,

      // Configuration and Infrastructure Languages
      ansible: /\b(tasks:|hosts:|vars:|become:|playbook|roles:|ansible_|gather_facts:)\b|\.ya?ml$/i,
      shell: /\b(export|source|echo|read|while|for|case|if|then|else|fi)\b|\.sh$/i,
      powershell: /\b(Get-|Set-|New-|Remove-|function|param\s*\(|Write-Host|\$PSScriptRoot)\b|\.ps1$/i,
      cloudformation: /\b(AWSTemplateFormatVersion|Resources|Properties|Type: ['"]AWS::)\b|\.(?:ya?ml|json|template)$/i,
      terraform: /\b(resource|provider|variable|output|module|data)\s+"[^"]+"\s+"[^"]+"|\.tf$/i,
      kubernetes: /\b(apiVersion:|kind:|metadata:|spec:|containers:|volumeMounts:)\b|\.ya?ml$/i,
      docker: /\b(FROM|RUN|CMD|ENTRYPOINT|WORKDIR|COPY|ADD|ENV|EXPOSE|VOLUME)\b|Dockerfile$/i,
      nginx: /\b(server|location|proxy_pass|upstream|listen|server_name)\b|\.conf$/i
    };

    // Check for shebang first
    if (code.startsWith('#!')) {
      if (code.includes('/bin/bash') || code.includes('/bin/sh')) {
        return 'shell';
      }
      if (code.includes('powershell') || code.includes('pwsh')) {
        return 'powershell';
      }
    }

    // Check each pattern
    for (const [lang, pattern] of Object.entries(patterns)) {
      if (pattern.test(code)) {
        return lang;
      }
    }

    // Additional checks for YAML-based formats
    if (/\.ya?ml$/i.test(code)) {
      // CloudFormation specific check
      if (code.includes('AWSTemplateFormatVersion') || code.includes('Resources:')) {
        return 'cloudformation';
      }
      // Ansible specific check
      if (code.includes('hosts:') || code.includes('tasks:')) {
        return 'ansible';
      }
      // Kubernetes specific check
      if (code.includes('apiVersion:') || code.includes('kind:')) {
        return 'kubernetes';
      }
    }

    return null;
  }

  static getFileExtension(language: string): string {
    const extensions: Record<string, string> = {
      // Programming Languages
      python: 'py',
      javascript: 'js',
      typescript: 'ts',
      java: 'java',
      go: 'go',
      rust: 'rs',
      cpp: 'cpp',
      csharp: 'cs',
      php: 'php',
      ruby: 'rb',
      swift: 'swift',
      kotlin: 'kt',

      // Configuration and Infrastructure Languages
      ansible: 'yml',
      shell: 'sh',
      powershell: 'ps1',
      cloudformation: 'yaml',
      terraform: 'tf',
      kubernetes: 'yaml',
      docker: 'Dockerfile',
      nginx: 'conf'
    };

    return extensions[language] || '';
  }

  static getLanguageIcon(language: string): string {
    const icons: Record<string, string> = {
      // Programming Languages
      python: '🐍',
      javascript: '📜',
      typescript: '💪',
      java: '☕',
      go: '🐹',
      rust: '🦀',
      cpp: '⚡',
      csharp: '🎯',
      php: '🐘',
      ruby: '💎',
      swift: '🎯',
      kotlin: '🎯',

      // Configuration and Infrastructure Languages
      ansible: '🔧',
      shell: '🐚',
      powershell: '⚡',
      cloudformation: '☁️',
      terraform: '🌍',
      kubernetes: '🎮',
      docker: '🐳',
      nginx: '🌐'
    };

    return icons[language] || '📄';
  }
}