import React from 'react';
import { ArrowRight } from 'lucide-react';
import { LanguageSelector } from '../LanguageSelector';

interface LanguageConverterProps {
  sourceLanguage: string;
  targetLanguage: string;
  onSourceChange: (language: string) => void;
  onTargetChange: (language: string) => void;
}

export function LanguageConverter({
  sourceLanguage,
  targetLanguage,
  onSourceChange,
  onTargetChange,
}: LanguageConverterProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
      <LanguageSelector 
        value={sourceLanguage}
        onChange={onSourceChange}
        label="Source Language"
      />
      <div className="flex justify-center">
        <ArrowRight className="w-6 h-6 text-gray-400" />
      </div>
      <LanguageSelector 
        value={targetLanguage}
        onChange={onTargetChange}
        label="Target Language"
      />
    </div>
  );
}