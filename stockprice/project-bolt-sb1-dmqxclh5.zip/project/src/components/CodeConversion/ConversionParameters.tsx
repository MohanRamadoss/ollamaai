import React from 'react';
import { UseFormRegister } from 'react-hook-form';

interface ConversionParametersProps {
  register: UseFormRegister<any>;
  watch: (name: string) => any;
}

export function ConversionParameters({ register, watch }: ConversionParametersProps) {
  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">
          Temperature ({watch('temperature')})
        </label>
        <input
          type="range"
          {...register('temperature', { valueAsNumber: true })}
          min="0"
          max="1"
          step="0.1"
          className="w-full"
        />
        <p className="mt-1 text-sm text-gray-500">
          Controls creativity in the conversion process
        </p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Top P ({watch('topP')})
        </label>
        <input
          type="range"
          {...register('topP', { valueAsNumber: true })}
          min="0"
          max="1"
          step="0.1"
          className="w-full"
        />
        <p className="mt-1 text-sm text-gray-500">
          Controls diversity in the conversion
        </p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Top K ({watch('topK')})
        </label>
        <input
          type="range"
          {...register('topK', { valueAsNumber: true })}
          min="1"
          max="100"
          className="w-full"
        />
        <p className="mt-1 text-sm text-gray-500">
          Limits token consideration during conversion
        </p>
      </div>
    </div>
  );
}