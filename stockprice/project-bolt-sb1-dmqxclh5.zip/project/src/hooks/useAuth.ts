import { create } from 'zustand';
import type { User } from '../types/models';

type AuthState = {
  user: User | null;
  isInitialized: boolean;
  signIn: (credentials: { email: string; password: string }) => Promise<void>;
  signOut: () => void;
};

// Hardcoded admin credentials for demo
const ADMIN_USER: User = {
  id: '1',
  email: 'admin@visacodecraft.com',
  name: 'Admin User',
};

const ADMIN_PASSWORD = 'admin123';

export const useAuth = create<AuthState>((set) => ({
  user: null,
  isInitialized: true,

  signIn: async ({ email, password }) => {
    // Trim whitespace and normalize email
    const normalizedEmail = email.trim().toLowerCase();
    
    if (normalizedEmail === ADMIN_USER.email && password === ADMIN_PASSWORD) {
      set({ user: ADMIN_USER });
    } else {
      throw new Error('Invalid email or password');
    }
  },

  signOut: () => {
    set({ user: null });
  },
}));