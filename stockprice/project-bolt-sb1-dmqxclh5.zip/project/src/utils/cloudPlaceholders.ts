import type { CloudProvider, ResourceType } from '../types/cloud';

const placeholders = {
  aws: {
    terraform: 'Example: Create a production-grade VPC with 3 AZs...',
    cloudformation: 'Example: Set up an ECS cluster with auto-scaling...',
    kubernetes: 'Example: Deploy an EKS cluster with managed node groups...',
    serverless: 'Example: Create a serverless API with Lambda functions and API Gateway...',
    database: 'Example: Set up an Aurora PostgreSQL cluster with read replicas...',
    storage: 'Example: Configure S3 buckets with lifecycle policies...',
    networking: 'Example: Design a Transit Gateway setup with VPC peering...'
  },
  azure: {
    terraform: 'Example: Set up a hub-spoke network architecture...',
    azurearm: 'Example: Deploy an AKS cluster with VMSS...',
    kubernetes: 'Example: Create an AKS cluster with Azure CNI...',
    serverless: 'Example: Create Azure Functions with API Management...',
    database: 'Example: Set up Azure SQL Database with geo-replication...',
    storage: 'Example: Configure Azure Blob Storage with lifecycle management...',
    networking: 'Example: Design a Virtual Network with ExpressRoute...'
  },
  gcp: {
    terraform: 'Example: Design a GCP landing zone...',
    gcpdeployment: 'Example: Set up a Cloud Run service...',
    kubernetes: 'Example: Deploy a GKE cluster with Autopilot...',
    serverless: 'Example: Create Cloud Functions with API Gateway...',
    database: 'Example: Set up Cloud SQL with read replicas...',
    storage: 'Example: Configure Cloud Storage with lifecycle policies...',
    networking: 'Example: Design VPC with Cloud Interconnect...'
  }
};

export function getPlaceholder(provider: CloudProvider, resourceType: ResourceType): string {
  return placeholders[provider]?.[resourceType as keyof typeof placeholders[typeof provider]] || 
    'Describe your infrastructure requirements...';
}