export type CloudProvider = 'aws' | 'azure' | 'gcp';

export type ResourceType = 
  | 'terraform'
  | 'cloudformation'
  | 'azurearm'
  | 'gcpdeployment'
  | 'kubernetes'
  | 'serverless'
  | 'database'
  | 'storage'
  | 'networking';