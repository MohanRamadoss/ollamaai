export type Platform = 'github' | 'gitlab' | 'azure-devops' | 'jenkins';

export type PipelineType = 'build' | 'test' | 'deploy' | 'monitor';