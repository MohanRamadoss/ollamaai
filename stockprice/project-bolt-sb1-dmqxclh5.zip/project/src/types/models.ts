export type AIModel = {
  id: string;
  name: string;
  provider: 'openai' | 'gemini';
  features: string[];
  maxTokens: number;
  supportsStreaming: boolean;
  priority: number;
};

export type ProgrammingLanguage = {
  id: string;
  name: string;
  features: string[];
  extension: string;
  icon: string;
  category?: 'config' | 'programming';
};

export type ComplexityLevel = 'basic' | 'intermediate' | 'advanced';

export type GenerationRequest = {
  modelIds: string[];
  sourceLanguage: string;
  targetLanguage?: string;
  prompt: string;
  complexity: ComplexityLevel;
  temperature: number;
  topP: number;
  topK: number;
  maxTokens: number;
};

export type User = {
  id: string;
  email: string;
  name: string;
  avatar_url?: string;
};