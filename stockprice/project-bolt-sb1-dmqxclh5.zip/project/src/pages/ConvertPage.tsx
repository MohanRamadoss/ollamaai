import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  ArrowLeftRight, 
  Code2, 
  FileCode, 
  Loader2, 
  Settings2, 
  CheckCircle2, 
  Upload,
  Sparkles,
  Brain,
  Zap,
  AlertTriangle
} from 'lucide-react';
import { ModelMultiSelect } from '../components/CodeGeneration/ModelMultiSelect';
import { ComplexitySelector } from '../components/CodeGeneration/ComplexitySelector';
import { ConversionProgress } from '../components/CodeConversion/ConversionProgress';
import { LanguageConverter } from '../components/CodeConversion/LanguageConverter';
import { ConversionParameters } from '../components/CodeConversion/ConversionParameters';
import { FileAttachment } from '../components/CodeConversion/FileAttachment';
import { CodeOutput } from '../components/CodeGeneration/CodeOutput';
import { CodeEditor } from '../components/CodeEditor';
import { TokenCounter } from '../components/TokenCounter';
import type { ComplexityLevel } from '../types/models';
import { convertCode } from '../lib/api/convert';

const convertSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  sourceLanguage: z.string().min(1, 'Select a source language'),
  targetLanguage: z.string().min(1, 'Select a target language'),
  complexity: z.enum(['basic', 'intermediate', 'advanced']),
  temperature: z.number().min(0).max(1),
  topP: z.number().min(0).max(1),
  topK: z.number().min(1).max(100),
  maxTokens: z.number().min(1).max(8192),
});

type ConvertForm = z.infer<typeof convertSchema>;

export function ConvertPage() {
  const [sourceCode, setSourceCode] = useState('');
  const [convertedCode, setConvertedCode] = useState('');
  const [isConverting, setIsConverting] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<ConvertForm>({
    resolver: zodResolver(convertSchema),
    defaultValues: {
      temperature: 0.7,
      topP: 0.9,
      topK: 50,
      maxTokens: 2048,
      complexity: 'intermediate' as ComplexityLevel,
      sourceLanguage: 'javascript',
      targetLanguage: 'python',
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedModels = watch('modelIds');
  const sourceLanguage = watch('sourceLanguage');
  const targetLanguage = watch('targetLanguage');
  const maxTokens = watch('maxTokens');

  const handleFileSelect = (content: string) => {
    setSourceCode(content);
  };

  const onSubmit = async (data: ConvertForm) => {
    if (!sourceCode.trim()) {
      return;
    }

    setIsConverting(true);
    setProgress(0);
    
    try {
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      const result = await convertCode({
        ...data,
        prompt: sourceCode,
      });

      setConvertedCode(result);
      setProgress(100);
    } catch (error) {
      console.error('Conversion failed:', error);
    } finally {
      setIsConverting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <ArrowLeftRight className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Convert Code</h1>
              <p className="mt-1 text-sm text-gray-500">
                Transform code between different programming languages while maintaining functionality
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Code2 className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Smart Conversion</div>
                <div className="text-xs text-gray-500">Language-aware</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Best Practices</div>
                <div className="text-xs text-gray-500">Idiomatic code</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Brain className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Context Aware</div>
                <div className="text-xs text-gray-500">Maintains logic</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Zap className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Fast & Accurate</div>
                <div className="text-xs text-gray-500">Quick conversion</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Conversion Settings</h2>
            </div>

            <div className="space-y-8">
              <ModelMultiSelect 
                selectedModels={selectedModels} 
                onChange={(models) => setValue('modelIds', models)} 
              />

              <LanguageConverter
                sourceLanguage={sourceLanguage}
                targetLanguage={targetLanguage}
                onSourceChange={(language) => setValue('sourceLanguage', language)}
                onTargetChange={(language) => setValue('targetLanguage', language)}
              />

              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-4">
                  <FileCode className="w-5 h-5 text-indigo-600" />
                  <h3 className="text-sm font-medium text-gray-900">Conversion Parameters</h3>
                </div>

                <ConversionParameters register={register} watch={watch} />
              </div>
            </div>
          </div>

          {/* File Upload Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Upload className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Source Code</h2>
            </div>

            <div className="space-y-6">
              <FileAttachment onFileSelect={handleFileSelect} />

              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium text-gray-700">Code Editor</h3>
                <TokenCounter code={sourceCode} maxTokens={maxTokens} />
              </div>

              <CodeEditor
                value={sourceCode}
                onChange={setSourceCode}
                language={sourceLanguage}
              />

              {!sourceCode.trim() && (
                <div className="flex items-center gap-2 text-sm text-amber-600">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Please enter or upload source code to convert</span>
                </div>
              )}
            </div>
          </div>

          {/* Output Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <CheckCircle2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Converted Code</h2>
            </div>

            <ConversionProgress isConverting={isConverting} progress={progress} />
            
            <CodeOutput
              code={convertedCode}
              language={targetLanguage}
              isGenerating={isConverting}
              progress={progress}
              maxTokens={maxTokens}
            />
          </div>

          {/* Convert Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isConverting || !sourceCode.trim()}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isConverting ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Converting...
                </>
              ) : (
                <>
                  <ArrowLeftRight className="w-5 h-5 mr-2" />
                  Convert Code
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}