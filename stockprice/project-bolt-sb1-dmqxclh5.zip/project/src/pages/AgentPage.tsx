import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Bot, AlertCircle, Loader2 } from 'lucide-react';
import { ModelMultiSelect } from '../components/CodeGeneration/ModelMultiSelect';
import { LanguageSelector } from '../components/LanguageSelector';
import { ComplexitySelector } from '../components/CodeGeneration/ComplexitySelector';
import { TokenCounter } from '../components/TokenCounter';
import { FileAttachment } from '../components/CodeConversion/FileAttachment';
import { CodeEditor } from '../components/CodeEditor';
import { LanguageDetector } from '../components/Agent/LanguageDetector';
import { AgentOutput } from '../components/Agent/AgentOutput';
import type { ComplexityLevel } from '../types/models';

const agentSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  language: z.string().min(1, 'Select a programming language'),
  complexity: z.enum(['basic', 'intermediate', 'advanced']),
  temperature: z.number().min(0).max(1),
  topP: z.number().min(0).max(1),
  topK: z.number().min(1).max(100),
  maxTokens: z.number().min(1).max(8192),
});

type AgentForm = z.infer<typeof agentSchema>;

export function AgentPage() {
  const [sourceCode, setSourceCode] = useState('');
  const [detectedLanguage, setDetectedLanguage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<Array<{ code: string; model: string }>>([]);
  const [error, setError] = useState<string | null>(null);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<AgentForm>({
    resolver: zodResolver(agentSchema),
    defaultValues: {
      temperature: 0.7,
      topP: 0.9,
      topK: 50,
      maxTokens: 2048,
      complexity: 'intermediate' as ComplexityLevel,
      language: 'javascript',
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedModels = watch('modelIds');
  const selectedLanguage = watch('language');
  const selectedComplexity = watch('complexity');
  const maxTokens = watch('maxTokens');

  useEffect(() => {
    if (sourceCode) {
      const language = LanguageDetector.detect(sourceCode);
      setDetectedLanguage(language);
      if (language) {
        setValue('language', language);
      }
    }
  }, [sourceCode, setValue]);

  const handleFileSelect = (content: string) => {
    setSourceCode(content);
  };

  const onSubmit = async (data: AgentForm) => {
    if (!sourceCode.trim()) {
      return;
    }

    setIsGenerating(true);
    setProgress(0);
    setError(null);
    setResults([]);
    
    try {
      // Simulate progress for each model
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      // TODO: Implement actual agent-based code generation
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setResults([
        { code: '// Generated code from Model 1', model: 'GPT-4' },
        { code: '// Generated code from Model 2', model: 'Gemini Pro' }
      ]);
      
      setProgress(100);
    } catch (error) {
      console.error('Generation failed:', error);
      setError('Failed to generate code. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Bot className="w-8 h-8 text-indigo-600" />
            AI Agent Generation
          </h1>
          <p className="mt-2 text-sm text-gray-500">
            Generate code using multiple AI models with automatic language detection
          </p>
        </div>

        {error && (
          <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white rounded-lg shadow-sm p-6 space-y-6">
            <ModelMultiSelect 
              selectedModels={selectedModels} 
              onChange={(models) => setValue('modelIds', models)} 
            />

            <LanguageSelector 
              value={selectedLanguage}
              onChange={(language) => setValue('language', language)}
            />

            <ComplexitySelector
              value={selectedComplexity}
              onChange={(complexity) => setValue('complexity', complexity as ComplexityLevel)}
            />

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Temperature ({watch('temperature')})
                </label>
                <input
                  type="range"
                  {...register('temperature', { valueAsNumber: true })}
                  min="0"
                  max="1"
                  step="0.1"
                  className="w-full"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Controls creativity in the generation process
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Top P ({watch('topP')})
                </label>
                <input
                  type="range"
                  {...register('topP', { valueAsNumber: true })}
                  min="0"
                  max="1"
                  step="0.1"
                  className="w-full"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Controls diversity in the output
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Top K ({watch('topK')})
                </label>
                <input
                  type="range"
                  {...register('topK', { valueAsNumber: true })}
                  min="1"
                  max="100"
                  className="w-full"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Limits token consideration during generation
                </p>
              </div>
            </div>
          </div>

          {/* File Upload Section */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <FileAttachment onFileSelect={handleFileSelect} />
          </div>

          {/* Code Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Source Code Section */}
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-medium text-gray-900">Source Code</h2>
                  <div className="flex items-center gap-4">
                    {detectedLanguage && (
                      <span className="text-sm text-gray-500">
                        Detected: {detectedLanguage}
                      </span>
                    )}
                    <TokenCounter code={sourceCode} maxTokens={maxTokens} />
                  </div>
                </div>
                
                <CodeEditor
                  value={sourceCode}
                  onChange={setSourceCode}
                  language={selectedLanguage}
                />
              </div>
            </div>

            {/* Results Section */}
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-medium text-gray-900">Generated Results</h2>
                  {results.length > 0 && (
                    <TokenCounter 
                      code={results.map(r => r.code).join('\n')} 
                      maxTokens={maxTokens} 
                    />
                  )}
                </div>

                <AgentOutput
                  results={results}
                  isGenerating={isGenerating}
                  progress={progress}
                  language={selectedLanguage}
                />
              </div>
            </div>
          </div>

          {/* Generate Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isGenerating || !sourceCode.trim()}
              className="px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Generating...
                </span>
              ) : (
                'Generate Code'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}