import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  FileCode, 
  Code2, 
  Loader2, 
  Settings2, 
  CheckCircle2, 
  Brain,
  AlertTriangle,
  Shield,
  Server,
  Network,
  Database,
  Cloud
} from 'lucide-react';
import { ResourceTypeSelector } from '../components/Terraform/ResourceTypeSelector';
import { PolicyFeatures } from '../components/Terraform/PolicyFeatures';
import { ExampleSelector } from '../components/Terraform/ExampleSelector';
import { TerraformCodeEditor } from '../components/Terraform/TerraformCodeEditor';
import { SentinelPolicyEditor } from '../components/Terraform/SentinelPolicyEditor';
import { ResourceGraph } from '../components/Terraform/ResourceGraph';
import type { CloudProvider } from '../config/terraform';

const terraformSchema = z.object({
  provider: z.enum(['aws', 'azure', 'gcp']),
  resourceType: z.string().min(1, 'Resource type is required'),
  requirements: z.string().min(10, 'Requirements must be at least 10 characters'),
  features: z.object({
    sentinelPolicy: z.boolean(),
    terraformAnalyzer: z.boolean(),
  }),
});

type TerraformForm = z.infer<typeof terraformSchema>;

export function TerraformRAGPage() {
  const [generatedCode, setGeneratedCode] = useState('');
  const [sentinelPolicy, setSentinelPolicy] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<TerraformForm>({
    resolver: zodResolver(terraformSchema),
    defaultValues: {
      provider: 'aws',
      resourceType: 'aws_eks_cluster',
      features: {
        sentinelPolicy: true,
        terraformAnalyzer: true,
      },
    },
  });

  const selectedProvider = watch('provider') as CloudProvider;
  const selectedResourceType = watch('resourceType');
  const selectedFeatures = watch('features');

  const onSubmit = async (data: TerraformForm) => {
    setIsGenerating(true);
    setProgress(0);
    
    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      // TODO: Implement actual code generation
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setGeneratedCode(`# Generated Terraform code for ${data.provider} ${data.resourceType}
resource "${data.resourceType}" "example" {
  # Configuration will be generated here
}`);

      if (data.features.sentinelPolicy) {
        setSentinelPolicy(`# Generated Sentinel policy
import "tfplan"

${data.resourceType}_policy = func() {
  return true
}

main = rule {
  ${data.resourceType}_policy()
}`);
      }

      setProgress(100);
    } catch (error) {
      console.error('Generation failed:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <FileCode className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Terraform RAG</h1>
              <p className="mt-1 text-sm text-gray-500">
                Generate production-ready Terraform code and Sentinel policies using AI with RAG
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Brain className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">RAG-Enhanced</div>
                <div className="text-xs text-gray-500">Context-aware</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Shield className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Secure</div>
                <div className="text-xs text-gray-500">Best practices</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Server className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Production</div>
                <div className="text-xs text-gray-500">Enterprise-ready</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Network className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Compliant</div>
                <div className="text-xs text-gray-500">Policy-driven</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Infrastructure Settings</h2>
            </div>

            <div className="space-y-8">
              <ResourceTypeSelector
                provider={selectedProvider}
                selectedType={selectedResourceType}
                onChange={(type) => setValue('resourceType', type)}
                onProviderChange={(provider) => setValue('provider', provider)}
              />

              <PolicyFeatures
                features={selectedFeatures}
                onFeaturesChange={(features) => setValue('features', features)}
              />

              <ExampleSelector
                provider={selectedProvider}
                resourceType={selectedResourceType}
                onSelect={(requirements) => setValue('requirements', requirements)}
              />

              <div>
                <label className="block text-sm font-medium text-gray-700">Requirements</label>
                <textarea
                  {...register('requirements')}
                  rows={6}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="Describe your infrastructure requirements..."
                />
                {errors.requirements && (
                  <p className="mt-2 text-sm text-red-600 flex items-center gap-1">
                    <AlertTriangle className="w-4 h-4" />
                    {errors.requirements.message}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Generated Code Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Terraform Code */}
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center gap-3 mb-6">
                  <Code2 className="w-5 h-5 text-indigo-600" />
                  <h2 className="text-lg font-medium text-gray-900">Generated Terraform</h2>
                </div>
                <TerraformCodeEditor
                  value={generatedCode}
                  onChange={setGeneratedCode}
                  readOnly
                  isGenerating={isGenerating}
                  progress={progress}
                  showValidation
                />
              </div>
            </div>

            {/* Sentinel Policy */}
            {selectedFeatures.sentinelPolicy && (
              <div className="space-y-6">
                <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                  <div className="flex items-center gap-3 mb-6">
                    <Shield className="w-5 h-5 text-indigo-600" />
                    <h2 className="text-lg font-medium text-gray-900">Generated Policy</h2>
                  </div>
                  <SentinelPolicyEditor
                    value={sentinelPolicy}
                    onChange={setSentinelPolicy}
                    readOnly
                    isGenerating={isGenerating}
                    progress={progress}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Resource Graph */}
          {generatedCode && (
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="flex items-center gap-3 mb-6">
                <Network className="w-5 h-5 text-indigo-600" />
                <h2 className="text-lg font-medium text-gray-900">Resource Graph</h2>
              </div>
              <ResourceGraph
                resources={[
                  {
                    id: '1',
                    type: selectedResourceType,
                    name: 'example',
                    dependencies: [],
                  },
                ]}
              />
            </div>
          )}

          {/* Generate Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isGenerating}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <FileCode className="w-5 h-5 mr-2" />
                  Generate Infrastructure
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}