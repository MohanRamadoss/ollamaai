import React, { useState } from 'react';
import { AlertCircle, Loader2, Database } from 'lucide-react';
import { SQLDialectSelector } from '../components/SQL/SQLDialectSelector';
import { SQLSchemaInput } from '../components/SQL/SQLSchemaInput';
import { SQLOutput } from '../components/SQL/SQLOutput';
import { SQLExamples } from '../components/SQL/SQLExamples';
import { SQLFileUpload } from '../components/SQL/SQLFileUpload';
import { Switch } from '../components/ui/switch';
import type { SQLDialect, SQLGenerationResult, OptimizationFeatures } from '../types/sql';

export function SQLPage() {
  const [description, setDescription] = useState('');
  const [schema, setSchema] = useState('');
  const [sqlFile, setSqlFile] = useState('');
  const [dialect, setDialect] = useState<SQLDialect>('postgresql');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<SQLGenerationResult | null>(null);
  const [optimizations, setOptimizations] = useState<OptimizationFeatures>({
    indexDesign: false,
    queryTuning: false,
    partitioning: false,
    replication: false,
  });

  const handleGenerate = async () => {
    if (!description.trim() && !sqlFile.trim()) {
      setError('Please provide a description or upload a SQL file.');
      return;
    }
    
    setLoading(true);
    setError(null);
    setResult(null);
    
    try {
      // TODO: Implement actual SQL generation
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setResult({
        query: '-- Generated SQL query will appear here\nSELECT * FROM table;',
        explanation: 'Query explanation will appear here.',
        optimizations: {
          indexRecommendations: ['Example index recommendation']
        }
      });
    } catch (err) {
      console.error('Generation error:', err);
      setError('Failed to generate SQL query. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleExampleSelect = (example: any) => {
    setDescription(example.description);
    if (example.schema) {
      setSchema(example.schema);
    }
  };

  const handleFileSelect = (content: string) => {
    setSqlFile(content);
    // Try to extract schema from the SQL file
    const schemaMatch = content.match(/CREATE TABLE[^;]+;/gi);
    if (schemaMatch) {
      setSchema(schemaMatch.join('\n\n'));
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Database className="w-8 h-8 text-indigo-600" />
            SQL Generation
          </h1>
          <p className="mt-2 text-sm text-gray-500">
            Generate optimized SQL queries using AI
          </p>
        </div>

        {error && (
          <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-lg shadow-sm p-6 space-y-6">
              <SQLDialectSelector 
                selected={dialect} 
                onChange={setDialect} 
              />

              <SQLFileUpload onFileSelect={handleFileSelect} />

              <SQLSchemaInput 
                value={schema}
                onChange={setSchema}
              />

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Describe the SQL query you need
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Example: Find all customers who made purchases over $1000 in the last month"
                  className="w-full h-32 px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                />
              </div>

              <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700">Optimization Features</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <label className="text-sm text-gray-600">Index Design</label>
                    <Switch
                      checked={optimizations.indexDesign}
                      onCheckedChange={(checked) =>
                        setOptimizations(prev => ({ ...prev, indexDesign: checked }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm text-gray-600">Query Tuning</label>
                    <Switch
                      checked={optimizations.queryTuning}
                      onCheckedChange={(checked) =>
                        setOptimizations(prev => ({ ...prev, queryTuning: checked }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm text-gray-600">Partitioning</label>
                    <Switch
                      checked={optimizations.partitioning}
                      onCheckedChange={(checked) =>
                        setOptimizations(prev => ({ ...prev, partitioning: checked }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm text-gray-600">Replication</label>
                    <Switch
                      checked={optimizations.replication}
                      onCheckedChange={(checked) =>
                        setOptimizations(prev => ({ ...prev, replication: checked }))
                      }
                    />
                  </div>
                </div>
              </div>

              <button
                onClick={handleGenerate}
                disabled={loading || (!description.trim() && !sqlFile.trim())}
                className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading && <Loader2 className="w-5 h-5 animate-spin" />}
                {loading ? 'Generating...' : 'Generate SQL Query'}
              </button>
            </div>

            {result && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <SQLOutput 
                  query={result.query}
                  explanation={result.explanation}
                />
                {result.optimizations && (
                  <div className="mt-6 space-y-4">
                    <h3 className="text-lg font-medium">Optimization Recommendations</h3>
                    {result.optimizations.indexRecommendations && (
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium text-gray-700">Recommended Indexes</h4>
                        <ul className="list-disc pl-5 space-y-1">
                          {result.optimizations.indexRecommendations.map((idx, i) => (
                            <li key={i} className="text-sm text-gray-600">{idx}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
          
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <SQLExamples 
                onSelectExample={handleExampleSelect}
                currentDialect={dialect}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}