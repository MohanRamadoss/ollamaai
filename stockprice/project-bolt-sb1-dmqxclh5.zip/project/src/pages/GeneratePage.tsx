import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Wand2, 
  Code2, 
  Sparkles, 
  Zap, 
  Brain, 
  FileCode, 
  Loader2,
  CheckCircle2,
  AlertTriangle,
  Settings2
} from 'lucide-react';
import { ModelMultiSelect } from '../components/CodeGeneration/ModelMultiSelect';
import { LanguageSelector } from '../components/LanguageSelector';
import { ComplexitySelector } from '../components/CodeGeneration/ComplexitySelector';
import { GenerationProgress } from '../components/CodeGeneration/GenerationProgress';
import { CodeOutput } from '../components/CodeGeneration/CodeOutput';
import type { ComplexityLevel } from '../types/models';

const generateSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  language: z.string().min(1, 'Select a programming language'),
  complexity: z.enum(['basic', 'intermediate', 'advanced']),
  prompt: z.string().min(10, 'Prompt must be at least 10 characters'),
  temperature: z.number().min(0).max(1),
  topP: z.number().min(0).max(1),
  topK: z.number().min(1).max(100),
  maxTokens: z.number().min(1).max(8192),
});

type GenerateForm = z.infer<typeof generateSchema>;

export function GeneratePage() {
  const [generatedCode, setGeneratedCode] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<GenerateForm>({
    resolver: zodResolver(generateSchema),
    defaultValues: {
      temperature: 0.7,
      topP: 0.9,
      topK: 50,
      maxTokens: 2048,
      complexity: 'intermediate' as ComplexityLevel,
      language: 'javascript',
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedModels = watch('modelIds');
  const selectedLanguage = watch('language');
  const selectedComplexity = watch('complexity');
  const maxTokens = watch('maxTokens');

  const onSubmit = async (data: GenerateForm) => {
    setIsGenerating(true);
    setProgress(0);
    try {
      // Simulate progress
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            return 100;
          }
          return prev + 10;
        });
      }, 500);

      // API call would go here
      await new Promise(resolve => setTimeout(resolve, 3000));
      setGeneratedCode('// Generated code will appear here');
    } catch (error) {
      console.error('Generation failed:', error);
    } finally {
      setIsGenerating(false);
      setProgress(100);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Wand2 className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Generate Code</h1>
              <p className="mt-1 text-sm text-gray-500">
                Transform your ideas into production-ready code using advanced AI models
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Code2 className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Smart Generation</div>
                <div className="text-xs text-gray-500">Multiple AI models</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Best Practices</div>
                <div className="text-xs text-gray-500">Industry standards</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Brain className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Context Aware</div>
                <div className="text-xs text-gray-500">Intelligent suggestions</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Zap className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Fast & Efficient</div>
                <div className="text-xs text-gray-500">Quick generation</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Generation Settings</h2>
            </div>

            <div className="space-y-8">
              <ModelMultiSelect 
                selectedModels={selectedModels} 
                onChange={(models) => setValue('modelIds', models)} 
              />

              <LanguageSelector 
                value={selectedLanguage}
                onChange={(language) => setValue('language', language)}
              />

              <ComplexitySelector
                value={selectedComplexity}
                onChange={(complexity) => setValue('complexity', complexity as ComplexityLevel)}
              />

              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-4">
                  <FileCode className="w-5 h-5 text-indigo-600" />
                  <h3 className="text-sm font-medium text-gray-900">Generation Parameters</h3>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Temperature ({watch('temperature')})
                    </label>
                    <input
                      type="range"
                      {...register('temperature', { valueAsNumber: true })}
                      min="0"
                      max="1"
                      step="0.1"
                      className="w-full mt-2"
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      Controls creativity in the generation process
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Top P ({watch('topP')})
                    </label>
                    <input
                      type="range"
                      {...register('topP', { valueAsNumber: true })}
                      min="0"
                      max="1"
                      step="0.1"
                      className="w-full mt-2"
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      Controls diversity in the output
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Top K ({watch('topK')})
                    </label>
                    <input
                      type="range"
                      {...register('topK', { valueAsNumber: true })}
                      min="1"
                      max="100"
                      className="w-full mt-2"
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      Limits token consideration during generation
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Prompt Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Brain className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Code Requirements</h2>
            </div>

            <div>
              <textarea
                {...register('prompt')}
                rows={6}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder="Describe the code you want to generate in detail..."
              />
              {errors.prompt && (
                <p className="mt-2 text-sm text-red-600 flex items-center gap-1">
                  <AlertTriangle className="w-4 h-4" />
                  {errors.prompt.message}
                </p>
              )}
            </div>
          </div>

          {/* Generate Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isGenerating}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Wand2 className="w-5 h-5 mr-2" />
                  Generate Code
                </>
              )}
            </button>
          </div>
        </form>

        {/* Progress Section */}
        <GenerationProgress isGenerating={isGenerating} progress={progress} />

        {/* Output Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-3 mb-6">
            <CheckCircle2 className="w-5 h-5 text-indigo-600" />
            <h2 className="text-lg font-medium text-gray-900">Generated Code</h2>
          </div>

          <CodeOutput
            code={generatedCode}
            language={selectedLanguage}
            isGenerating={isGenerating}
            progress={progress}
            maxTokens={maxTokens}
          />
        </div>
      </div>
    </div>
  );
}