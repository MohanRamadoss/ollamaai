import type { GenerationRequest } from '../../types/models';

// Default parameters for code generation and conversion
export const DEFAULT_PARAMETERS: Partial<GenerationRequest> = {
  temperature: 0.7,
  topP: 0.9,
  topK: 40,
  maxTokens: 2048,
};

// Parameter constraints
export const PARAMETER_CONSTRAINTS = {
  temperature: {
    min: 0,
    max: 1,
    step: 0.1,
    default: 0.7,
    description: 'Controls randomness in the output. Higher values make the output more creative but less predictable.',
  },
  topP: {
    min: 0,
    max: 1,
    step: 0.1,
    default: 0.9,
    description: 'Controls diversity via nucleus sampling. Lower values make the output more focused.',
  },
  topK: {
    min: 1,
    max: 100,
    step: 1,
    default: 40,
    description: 'Limits the number of tokens considered for each step of text generation.',
  },
  maxTokens: {
    min: 1,
    max: 8192,
    step: 1,
    default: 2048,
    description: 'Maximum length of the generated code in tokens.',
  },
};