import { generateWithOpenAI } from '../ai/openai';
import { generateWithGemini } from '../ai/gemini';
import type { GenerationRequest } from '../../types/models';

export async function analyzeCode(request: GenerationRequest & { action: string }): Promise<string> {
  const {
    modelIds,
    sourceLanguage,
    prompt: sourceCode,
    temperature,
    topP,
    topK,
    maxTokens,
    action,
  } = request;

  const params = {
    temperature,
    topP,
    topK,
    maxTokens,
  };

  const actionPrompts = {
    analyze: `Analyze the following ${sourceLanguage} code and provide insights on:
- Code quality
- Potential issues
- Security concerns
- Performance implications
- Maintainability
`,
    test: `Generate comprehensive unit tests for the following ${sourceLanguage} code:
- Include test cases for edge cases
- Cover main functionality
- Add error cases
- Ensure good test coverage
`,
    debug: `Analyze the following ${sourceLanguage} code for potential bugs and issues:
- Identify logical errors
- Find edge cases
- Spot potential runtime errors
- Suggest fixes
`,
    optimize: `Analyze the following ${sourceLanguage} code for performance optimization:
- Identify performance bottlenecks
- Suggest optimizations
- Consider time and space complexity
- Recommend better algorithms or data structures
`,
    refactor: `Suggest refactoring improvements for the following ${sourceLanguage} code:
- Improve code structure
- Enhance readability
- Apply design patterns
- Remove code smells
`,
    document: `Generate comprehensive documentation for the following ${sourceLanguage} code:
- Function/method documentation
- Parameter descriptions
- Return value explanations
- Usage examples
`,
    'best-practices': `Check the following ${sourceLanguage} code against best practices:
- Code organization
- Error handling
- Resource management
- Design principles
`,
    'style-check': `Review the following ${sourceLanguage} code for style issues:
- Formatting
- Naming conventions
- Code organization
- Consistency
`
  };

  const enhancedPrompt = `${actionPrompts[action as keyof typeof actionPrompts]}

Code to analyze:
${sourceCode}

Please provide a detailed analysis with specific line numbers where applicable.`;

  const results = await Promise.all(
    modelIds.map(async (modelId) => {
      try {
        if (modelId.startsWith('gpt')) {
          return await generateWithOpenAI(enhancedPrompt, modelId, params);
        } else if (modelId.startsWith('gemini')) {
          return await generateWithGemini(enhancedPrompt, modelId, params);
        }
        return null;
      } catch (error) {
        console.error(`Error with model ${modelId}:`, error);
        return null;
      }
    })
  );

  const validResults = results.filter((result): result is string => result !== null);
  
  if (validResults.length === 0) {
    throw new Error('Code analysis failed with all selected models');
  }

  return validResults.reduce((best, current) => 
    current.length > best.length ? current : best
  );
}