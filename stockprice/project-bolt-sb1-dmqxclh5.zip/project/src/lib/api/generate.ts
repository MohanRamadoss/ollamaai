import { generateWithOpenAI } from '../ai/openai';
import { generateWithGemini } from '../ai/gemini';
import type { GenerationRequest } from '../../types/models';

export async function generateCode(request: GenerationRequest): Promise<string> {
  const {
    modelIds,
    prompt,
    temperature,
    topP,
    topK,
    maxTokens,
    sourceLanguage,
  } = request;

  // Common parameters for both models
  const params = {
    temperature,
    topP,
    topK,
    maxTokens,
  };

  // Enhanced prompt with language context
  const enhancedPrompt = `Generate ${sourceLanguage} code for the following request:

${prompt}

Requirements:
- Use ${sourceLanguage} best practices and conventions
- Include error handling
- Add comments for complex logic
- Follow clean code principles
- Consider edge cases

Please provide only the code without explanations.`;

  // Generate code with each selected model
  const results = await Promise.all(
    modelIds.map(async (modelId) => {
      try {
        if (modelId.startsWith('gpt')) {
          return await generateWithOpenAI(enhancedPrompt, modelId, params);
        } else if (modelId.startsWith('gemini')) {
          return await generateWithGemini(enhancedPrompt, modelId, params);
        }
        return null;
      } catch (error) {
        console.error(`Error with model ${modelId}:`, error);
        return null;
      }
    })
  );

  // Filter out null results and combine the responses
  const validResults = results.filter((result): result is string => result !== null);
  
  if (validResults.length === 0) {
    throw new Error('Code generation failed with all selected models');
  }

  // Return the most comprehensive result
  return validResults.reduce((longest, current) => 
    current.length > longest.length ? current : longest
  );
}