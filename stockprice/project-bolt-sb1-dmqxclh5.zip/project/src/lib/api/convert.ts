import { generateWithOpenAI } from '../ai/openai';
import { generateWithGemini } from '../ai/gemini';
import type { GenerationRequest } from '../../types/models';

export async function convertCode(request: GenerationRequest): Promise<string> {
  const {
    modelIds,
    sourceLanguage,
    targetLanguage,
    prompt: sourceCode,
    temperature,
    topP,
    topK,
    maxTokens,
  } = request;

  if (!targetLanguage) {
    throw new Error('Target language is required for code conversion');
  }

  // Common parameters for both models
  const params = {
    temperature,
    topP,
    topK,
    maxTokens,
  };

  // Enhanced prompt for code conversion
  const enhancedPrompt = `Convert the following ${sourceLanguage} code to ${targetLanguage}:

${sourceCode}

Requirements:
- Maintain the same functionality
- Use ${targetLanguage} idioms and best practices
- Preserve comments and documentation
- Handle language-specific differences appropriately
- Ensure proper error handling
- Optimize for ${targetLanguage} performance

Please provide only the converted code without explanations.`;

  // Convert code with each selected model
  const results = await Promise.all(
    modelIds.map(async (modelId) => {
      try {
        if (modelId.startsWith('gpt')) {
          return await generateWithOpenAI(enhancedPrompt, modelId, params);
        } else if (modelId.startsWith('gemini')) {
          return await generateWithGemini(enhancedPrompt, modelId, params);
        }
        return null;
      } catch (error) {
        console.error(`Error with model ${modelId}:`, error);
        return null;
      }
    })
  );

  // Filter out null results and combine the responses
  const validResults = results.filter((result): result is string => result !== null);
  
  if (validResults.length === 0) {
    throw new Error('Code conversion failed with all selected models');
  }

  // Compare results and return the most comprehensive one
  return validResults.reduce((best, current) => {
    // Prefer longer results as they're likely more complete
    if (current.length > best.length * 1.5) return current;
    // If lengths are similar, prefer the one with more comments
    const bestComments = (best.match(/\/\//g) || []).length + (best.match(/\/\*|\*\//g) || []).length;
    const currentComments = (current.match(/\/\//g) || []).length + (current.match(/\/\*|\*\//g) || []).length;
    return currentComments > bestComments ? current : best;
  });
}