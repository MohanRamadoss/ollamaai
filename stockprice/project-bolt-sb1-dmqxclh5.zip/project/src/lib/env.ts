interface Env {
  OPENAI_API_KEY: string;
  GOOGLE_AI_API_KEY: string;
}

export const env: Env = {
  OPENAI_API_KEY: import.meta.env.VITE_OPENAI_API_KEY || '',
  GOOGLE_AI_API_KEY: import.meta.env.VITE_GOOGLE_AI_API_KEY || '',
};