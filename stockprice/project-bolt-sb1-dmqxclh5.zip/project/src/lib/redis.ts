import Redis from 'ioredis';

const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  password: process.env.REDIS_PASSWORD,
});

export async function cacheResponse(key: string, data: any, ttl = 3600) {
  await redis.set(key, JSON.stringify(data), 'EX', ttl);
}

export async function getCachedResponse(key: string) {
  const data = await redis.get(key);
  return data ? JSON.parse(data) : null;
}

export async function clearCache(pattern: string) {
  const keys = await redis.keys(pattern);
  if (keys.length) {
    await redis.del(...keys);
  }
}