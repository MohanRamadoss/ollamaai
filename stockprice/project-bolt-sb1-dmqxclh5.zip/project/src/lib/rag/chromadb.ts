import { ChromaClient, Collection, OpenAIEmbeddingFunction } from 'chromadb';
import { env } from '../env';

export class ChromaDBClient {
  private client: ChromaClient;
  private collection: Collection | null = null;
  private embeddingFunction: OpenAIEmbeddingFunction;

  constructor() {
    this.client = new ChromaClient();
    this.embeddingFunction = new OpenAIEmbeddingFunction({
      openai_api_key: env.OPENAI_API_KEY,
    });
  }

  async initialize() {
    try {
      this.collection = await this.client.getOrCreateCollection({
        name: 'terraform_registry',
        embeddingFunction: this.embeddingFunction,
      });
    } catch (error) {
      console.error('Error initializing ChromaDB:', error);
      throw error;
    }
  }

  async addDocuments(documents: {
    id: string;
    content: string;
    metadata: Record<string, any>;
  }[]) {
    if (!this.collection) {
      await this.initialize();
    }

    try {
      await this.collection!.add({
        ids: documents.map(doc => doc.id),
        documents: documents.map(doc => doc.content),
        metadatas: documents.map(doc => doc.metadata),
      });
    } catch (error) {
      console.error('Error adding documents to ChromaDB:', error);
      throw error;
    }
  }

  async query(query: string, provider?: string, resourceType?: string, n = 5) {
    if (!this.collection) {
      await this.initialize();
    }

    try {
      const filter = {
        ...(provider && { provider }),
        ...(resourceType && { resourceType }),
      };

      const results = await this.collection!.query({
        queryTexts: [query],
        nResults: n,
        ...(Object.keys(filter).length > 0 && { filter }),
      });

      return results;
    } catch (error) {
      console.error('Error querying ChromaDB:', error);
      throw error;
    }
  }
}