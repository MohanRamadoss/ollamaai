import cheerio from 'cheerio';
import fetch from 'node-fetch';

interface RegistryContent {
  title: string;
  description: string;
  code: string;
  source: string;
  lastUpdated: string;
  provider: string;
  resourceType: string;
}

export class TerraformRegistryScraper {
  private baseUrl = 'https://registry.terraform.io';

  async scrapeProvider(provider: string): Promise<RegistryContent[]> {
    const results: RegistryContent[] = [];
    const providerUrl = `${this.baseUrl}/providers/hashicorp/${provider}/latest/docs`;

    try {
      const response = await fetch(providerUrl);
      const html = await response.text();
      const $ = cheerio.load(html);

      // Extract resource documentation
      $('.docs-content').each((_, element) => {
        const title = $(element).find('h1').first().text().trim();
        const description = $(element).find('p').first().text().trim();
        const code = $(element).find('pre code').first().text().trim();
        const lastUpdated = new Date().toISOString().split('T')[0]; // Use current date as fallback

        if (title && code) {
          results.push({
            title,
            description,
            code,
            source: providerUrl,
            lastUpdated,
            provider,
            resourceType: title.toLowerCase().replace(/\s+/g, '_'),
          });
        }
      });
    } catch (error) {
      console.error(`Error scraping provider ${provider}:`, error);
    }

    return results;
  }

  async scrapeResourceType(provider: string, resourceType: string): Promise<RegistryContent[]> {
    const results: RegistryContent[] = [];
    const resourceUrl = `${this.baseUrl}/providers/hashicorp/${provider}/latest/docs/resources/${resourceType}`;

    try {
      const response = await fetch(resourceUrl);
      const html = await response.text();
      const $ = cheerio.load(html);

      const title = $('h1').first().text().trim();
      const description = $('.docs-content p').first().text().trim();
      const code = $('.docs-content pre code').first().text().trim();
      const lastUpdated = new Date().toISOString().split('T')[0];

      if (title && code) {
        results.push({
          title,
          description,
          code,
          source: resourceUrl,
          lastUpdated,
          provider,
          resourceType,
        });
      }
    } catch (error) {
      console.error(`Error scraping resource ${resourceType}:`, error);
    }

    return results;
  }
}