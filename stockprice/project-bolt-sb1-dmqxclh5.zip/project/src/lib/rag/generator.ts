import { generateWithOpenAI } from '../ai/openai';
import { generateWithGemini } from '../ai/gemini';
import { ChromaDBClient } from './chromadb';

export class TerraformGenerator {
  private chromaDB: ChromaDBClient;

  constructor() {
    this.chromaDB = new ChromaDBClient();
  }

  async generateCode(query: string, provider: string, resourceType: string) {
    // Get relevant context from ChromaDB
    const results = await this.chromaDB.query(query, provider, resourceType);
    
    // Combine retrieved documents into context
    const context = results.documents?.[0]?.join('\n\n') || '';

    // Create enhanced prompt with context
    const prompt = `Generate Terraform code for ${provider} ${resourceType} based on the following requirements:

${query}

Here is relevant documentation and examples:

${context}

Please generate production-ready Terraform code that:
1. Follows best practices
2. Includes proper error handling
3. Uses appropriate data types
4. Includes helpful comments
5. Implements proper tagging
6. Considers security implications

Generate only the code without explanations.`;

    try {
      // Try with GPT-4 first
      const gptResult = await generateWithOpenAI(prompt, 'gpt-4', {
        temperature: 0.7,
        maxTokens: 2048,
      });

      if (gptResult) {
        return gptResult;
      }

      // Fallback to Gemini
      const geminiResult = await generateWithGemini(prompt, 'gemini-pro-code', {
        temperature: 0.7,
        maxTokens: 2048,
      });

      return geminiResult;
    } catch (error) {
      console.error('Error generating Terraform code:', error);
      throw error;
    }
  }
}