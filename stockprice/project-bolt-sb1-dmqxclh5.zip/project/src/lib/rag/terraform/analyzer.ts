interface AnalysisResult {
  securityIssues: string[];
  bestPractices: string[];
  costOptimizations: string[];
  compliance: {
    standard: string;
    issues: string[];
  }[];
}

export class TerraformAnalyzer {
  analyzeSecurity(code: string): string[] {
    const issues: string[] = [];
    
    // Check for common security misconfigurations
    if (code.includes('0.0.0.0/0')) {
      issues.push('Unrestricted network access detected');
    }
    if (code.includes('"*"') || code.includes('["*"]')) {
      issues.push('Wildcard permissions detected');
    }
    if (!code.includes('encryption')) {
      issues.push('Consider enabling encryption for sensitive resources');
    }
    if (!code.includes('monitoring')) {
      issues.push('Consider enabling monitoring and logging');
    }
    
    return issues;
  }

  analyzeBestPractices(code: string): string[] {
    const practices: string[] = [];
    
    // Check for Terraform best practices
    if (!code.includes('terraform {')) {
      practices.push('Add terraform block to specify required providers');
    }
    if (!code.includes('version')) {
      practices.push('Specify provider versions for stability');
    }
    if (!code.includes('tags')) {
      practices.push('Add resource tags for better organization');
    }
    if (!code.includes('workspace')) {
      practices.push('Consider using workspaces for environment separation');
    }
    
    return practices;
  }

  analyzeCost(code: string): string[] {
    const optimizations: string[] = [];
    
    // Check for potential cost optimizations
    if (code.includes('instance_type') && !code.includes('t3.')) {
      optimizations.push('Consider using t3 instance types for better cost efficiency');
    }
    if (code.includes('retention')) {
      optimizations.push('Review retention periods for cost optimization');
    }
    if (code.includes('auto_scaling')) {
      optimizations.push('Verify auto-scaling thresholds for optimal resource usage');
    }
    
    return optimizations;
  }

  analyzeCompliance(code: string): { standard: string; issues: string[] }[] {
    return [
      {
        standard: 'CIS Benchmarks',
        issues: this.analyzeCISCompliance(code),
      },
      {
        standard: 'HIPAA',
        issues: this.analyzeHIPAACompliance(code),
      },
      {
        standard: 'SOC 2',
        issues: this.analyzeSOC2Compliance(code),
      },
    ];
  }

  private analyzeCISCompliance(code: string): string[] {
    const issues: string[] = [];
    if (!code.includes('log')) {
      issues.push('Enable logging for compliance with CIS requirements');
    }
    if (!code.includes('encryption')) {
      issues.push('Enable encryption at rest for compliance');
    }
    return issues;
  }

  private analyzeHIPAACompliance(code: string): string[] {
    const issues: string[] = [];
    if (!code.includes('backup')) {
      issues.push('Configure backup policies for HIPAA compliance');
    }
    if (!code.includes('private_subnet')) {
      issues.push('Use private subnets for PHI data');
    }
    return issues;
  }

  private analyzeSOC2Compliance(code: string): string[] {
    const issues: string[] = [];
    if (!code.includes('monitoring')) {
      issues.push('Enable monitoring for SOC 2 compliance');
    }
    if (!code.includes('audit')) {
      issues.push('Configure audit logging for compliance');
    }
    return issues;
  }

  analyze(code: string): AnalysisResult {
    return {
      securityIssues: this.analyzeSecurity(code),
      bestPractices: this.analyzeBestPractices(code),
      costOptimizations: this.analyzeCost(code),
      compliance: this.analyzeCompliance(code),
    };
  }
}