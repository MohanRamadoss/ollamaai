import { ComplexityLevel } from '../types/models';

export type PromptTemplate = {
  id: string;
  name: string;
  description: string;
  template: string;
  complexity: ComplexityLevel;
  category: string;
  variables: {
    name: string;
    description: string;
    required: boolean;
    defaultValue?: string;
  }[];
};

export const PROMPT_TEMPLATES: PromptTemplate[] = [
  // Basic Templates
  {
    id: 'basic-crud',
    name: 'Basic CRUD Operations',
    description: 'Generate simple CRUD operations for a data model',
    complexity: 'basic',
    category: 'operations',
    template: `Create a basic {entityName} management system with the following requirements:

1. Data Model:
{modelFields}

2. Required Operations:
- Create new {entityName}
- Read {entityName} by ID and list all
- Update existing {entityName}
- Delete {entityName}

Technical Requirements:
- Use {framework} framework
- Implement basic error handling
- Add input validation
- Follow RESTful conventions`,
    variables: [
      { name: 'entityName', description: 'Name of the entity (e.g., User, Product)', required: true },
      { name: 'modelFields', description: 'List of model fields and their types', required: true },
      { name: 'framework', description: 'Framework to use', required: true, defaultValue: 'React' }
    ]
  },
  {
    id: 'basic-form',
    name: 'Form with Validation',
    description: 'Create a form with basic validation',
    complexity: 'basic',
    category: 'ui',
    template: `Create a form for {formPurpose} with the following fields:

{formFields}

Validation Requirements:
{validationRules}

UI Requirements:
- Show validation errors
- Disable submit button when invalid
- Clear form after successful submission
- Show loading state during submission

Use {framework} with {validationLibrary} for form handling.`,
    variables: [
      { name: 'formPurpose', description: 'Purpose of the form', required: true },
      { name: 'formFields', description: 'List of form fields', required: true },
      { name: 'validationRules', description: 'Validation rules for fields', required: true },
      { name: 'framework', description: 'Framework to use', required: true, defaultValue: 'React' },
      { name: 'validationLibrary', description: 'Validation library', required: true, defaultValue: 'zod' }
    ]
  },

  // Intermediate Templates
  {
    id: 'intermediate-auth',
    name: 'Authentication System',
    description: 'Implement a complete authentication system',
    complexity: 'intermediate',
    category: 'security',
    template: `Create an authentication system with the following features:

Authentication Methods:
{authMethods}

Required Features:
- User registration and login
- Password reset flow
- Session management
- Protected routes
- Remember me functionality

Security Requirements:
- Secure password storage
- Rate limiting
- CSRF protection
- XSS prevention

Technical Stack:
- Frontend: {frontendStack}
- Backend: {backendStack}
- Database: {database}

Additional Requirements:
{additionalRequirements}`,
    variables: [
      { name: 'authMethods', description: 'Authentication methods to implement', required: true },
      { name: 'frontendStack', description: 'Frontend technology stack', required: true },
      { name: 'backendStack', description: 'Backend technology stack', required: true },
      { name: 'database', description: 'Database to use', required: true },
      { name: 'additionalRequirements', description: 'Additional requirements', required: false }
    ]
  },

  // Advanced Templates
  {
    id: 'advanced-realtime',
    name: 'Real-time System',
    description: 'Build a real-time data processing system',
    complexity: 'advanced',
    category: 'system',
    template: `Create a real-time {systemType} system with the following capabilities:

Core Features:
{coreFeatures}

Real-time Requirements:
- WebSocket/SSE implementation
- Real-time data synchronization
- Conflict resolution
- Offline support
- Event sourcing

Performance Requirements:
- Maximum latency: {maxLatency}
- Concurrent users: {concurrentUsers}
- Data consistency model: {consistencyModel}

Architecture:
- Frontend: {frontendTech}
- Backend: {backendTech}
- Message Queue: {messageQueue}
- Database: {database}

Additional Considerations:
- Error handling and recovery
- Monitoring and logging
- Performance optimization
- Scalability strategy
- Security measures

{additionalRequirements}`,
    variables: [
      { name: 'systemType', description: 'Type of real-time system', required: true },
      { name: 'coreFeatures', description: 'Core features of the system', required: true },
      { name: 'maxLatency', description: 'Maximum acceptable latency', required: true },
      { name: 'concurrentUsers', description: 'Number of concurrent users', required: true },
      { name: 'consistencyModel', description: 'Data consistency model', required: true },
      { name: 'frontendTech', description: 'Frontend technology', required: true },
      { name: 'backendTech', description: 'Backend technology', required: true },
      { name: 'messageQueue', description: 'Message queue system', required: true },
      { name: 'database', description: 'Database system', required: true },
      { name: 'additionalRequirements', description: 'Additional requirements', required: false }
    ]
  }
];