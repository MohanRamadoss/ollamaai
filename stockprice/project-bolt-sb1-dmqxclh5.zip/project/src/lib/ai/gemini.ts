import { GoogleGenerativeAI } from '@google/generative-ai';
import { env } from '../env';

const genAI = new GoogleGenerativeAI(env.GOOGLE_AI_API_KEY);

export async function generateWithGemini(prompt: string, model: string, params: any) {
  const modelInstance = genAI.getGenerativeModel({ model });

  const result = await modelInstance.generateContent({
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    generationConfig: {
      temperature: params.temperature,
      topK: params.topK,
      topP: params.topP,
      maxOutputTokens: params.maxTokens,
    },
  });

  const response = await result.response;
  return response.text();
}