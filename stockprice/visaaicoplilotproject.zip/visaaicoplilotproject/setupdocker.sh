# 1. Uninstall old versions
sudo apt-get remove docker docker-engine docker.io containerd runc

# 2. Set up repository
sudo apt-get update
sudo apt-get install -y \
    apt-transport-https \
    ca-certificates \
    curl \
    gnupg \
    lsb-release

# Add Docker's official GPG key
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

# Set up stable repository
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# 3. Install Docker Engine
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# 4. Add user to docker group
sudo usermod -aG docker $USER

# 5. Test installation
docker --version
docker compose version

# 6. Enable and start Docker
sudo systemctl enable docker
sudo systemctl start docker

# 7. Verify installation
docker run hello-world



# 1. Update system
sudo apt update
sudo apt upgrade -y

# 2. Install Apache
sudo apt install apache2 -y

# 4. Create virtual host configuration
sudo nano /etc/apache2/sites-available/aicodecraft.conf

<VirtualHost *:80>
    ServerName aicodecraft.mohan.sg
    DocumentRoot /var/www/aicodecraft
    
    <Directory /var/www/aicodecraft>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
        
        Header set Access-Control-Allow-Origin "*"
        Header set Access-Control-Allow-Methods "GET, POST, OPTIONS"
        Header set Access-Control-Allow-Headers "Content-Type"
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/error.log
    CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>


# 5. Enable modules and site
sudo a2enmod headers
sudo a2enmod rewrite
sudo a2ensite aicodecraft.conf
sudo systemctl restart apache2

# 6. Test Apache
sudo systemctl status apache2
curl -I http://localhost
