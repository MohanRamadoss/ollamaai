import asyncio
import aiohttp
import json
import logging
import os
import subprocess
import time
import platform
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Any, Optional, Coroutine
import psutil
import requests
from jinja2 import Template
import socket
import xml.etree.ElementTree as ET
import re
import shlex
from pathlib import Path # Import Path from pathlib

@dataclass
class Config:
    """Application configuration"""
    LOG_DIR: str = str(Path(os.path.dirname(os.path.abspath(__file__))) / "docker_monitor/logs")
    COMMAND_TIMEOUT: int = 300
    API_RETRIES: int = 3
    CACHE_DURATION: int = 3600
    MODEL_CONFIG: Dict[str, Dict] = None
    OLLAMA_BASE_URL: Optional[str] = os.getenv("OLLAMA_API_URL", None)
    OLLAMA_ENDPOINTS: Dict[str, str] = field(default_factory=lambda: {
        "generate": "/api/generate",
        "status": "/api/status",
        "models": "/api/models"
    })
    OLLAMA_HEADERS: Dict[str, str] = field(default_factory=lambda: {
        "Content-Type": "application/json",
        "Accept": "application/json"
    })
    OLLAMA_RETRY_CONFIG: Dict[str, int] = field(default_factory=lambda: {
        "max_attempts": 3,
        "min_delay": 1,
        "max_delay": 10
    })
    OLLAMA_RATE_LIMIT: Dict[str, int] = field(default_factory=lambda: {
        "calls": 10,
        "period": 60
    })
    OLLAMA_TIMEOUT: int = 30
    SYSTEM_CHECKS_TIMEOUT: int = 30
    HEALTH_CHECK_PARALLEL: bool = True
    COMMAND_WHITELIST: List[str] = field(default_factory=lambda: [])
    def __post_init__(self):
        """Initialize model configurations and command whitelist"""
        if not self.OLLAMA_BASE_URL:
            raise ValueError("Ollama base url cannot be empty, provide OLLAMA_API_URL or set in config.yaml")
        if not self.MODEL_CONFIG:
             self.MODEL_CONFIG = {
                'quick_check': {
                    'name': 'mistral-small:latest',
                    'temperature': 0.5,
                     'timeout': 120
                },
                'technical': {
                    'name': 'mistral-small:latest',
                    'temperature': 0.6,
                    'timeout': 120
                },
                 'code': {
                    'name': 'granite-code:20b',
                    'temperature': 0.2,
                    'timeout': 120
                 },
                'security': {
                    'name': 'mistral:latest',
                    'temperature': 0.3,
                    'timeout': 180
                },
                 'reasoning': {
                    'name': 'mistral:latest',
                    'temperature': 0.6,
                    'timeout': 180
                 }
            }
        if not all(self.MODEL_CONFIG.values()):
            raise ValueError("Invalid Configuration, Please check model values")
        if not self.COMMAND_WHITELIST:
             self.COMMAND_WHITELIST = ['systemctl', 'ss', 'ifconfig', 'grep', 'uptime', 'date', 'cat',
                                      'httpd', 'apachectl', 'rpm',  'journalctl', 'docker', 'lsblk', 'fdisk',
                                        'dpkg-query', 'apt', 'apt-get', 'aa-status', 'ufw','journalctl', 'docker', 'lsblk', 'fdisk', 'docker']
    @classmethod
    def from_xml(cls, xml_file):
        """Load configuration from XML file."""
        tree = ET.parse(xml_file)
        root = tree.getroot()
        config_data = {}

        # Map XML tags to attributes
        config_data['OLLAMA_BASE_URL'] = root.find('ollama_api').text.strip() if root.find('ollama_api') is not None else os.getenv("OLLAMA_API_URL", None)
        config_data['LOG_DIR'] = root.find('log_dir').text.strip()  if root.find('log_dir') is not None else str(Path(os.path.dirname(os.path.abspath(__file__))) / "docker_monitor/logs")
        config_data['API_RETRIES'] = int(root.find('api_retries').text.strip()) if root.find('api_retries') is not None else 3
        config_data['CACHE_DURATION'] = int(root.find('cache_timeout').text.strip())  if root.find('cache_timeout') is not None else 3600
        
        # Read model configs
        models_config = {}
        for model_type in root.find('models'):
            models_config[model_type.tag] = {
                'name': model_type.find('name').text.strip(),
                'temperature': float(model_type.find('temperature').text.strip()),
                'timeout': int(model_type.find('timeout').text.strip())
            }
        config_data['MODEL_CONFIG'] = models_config

         # Read Command whitelist
        command_whitelist = [cmd.text.strip() for cmd in root.find('command_whitelist')]
        config_data['COMMAND_WHITELIST'] = command_whitelist
       
        return cls(**config_data)


@dataclass
class ContainerMetrics:
    """Store container metrics"""
    timestamp: str
    hostname: str
    os_version: str
    docker_version: str
    container_count: int
    running_containers: int
    cpu_usage: float
    memory_usage: float
    image_metrics: List[Dict[str, Any]]
    configuration_issues: List[str]
    log_issues: List[str]
    instance_metadata: Dict[str, Any]

def sanitize_error_message(error: str) -> str:
    """Sanitize error messages before logging or display"""
    if not error:
        return "An unknown error occurred."

    # Remove file paths, IP addresses, and other potentially sensitive information
    sanitized_error = re.sub(r'(/[\w\d\/\.\-]+)', '[FILE PATH]', error)
    sanitized_error = re.sub(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', '[IP ADDRESS]', sanitized_error)
    sanitized_error = re.sub(r'(\b\w+@[\w\d\.\-]+\b)', '[EMAIL ADDRESS]', error)

    return sanitized_error

class EnhancedPromptGenerator:
    """Advanced prompt generation for patch analysis"""

    def __init__(self):
        self.system_messages = {
            'analysis': "You are an expert system administrator with extensive experience in docker container management and security analysis.",
            'playbook': "You are an expert DevOps engineer specializing in docker automation and Ansible playbook development.",
             'reasoning': "You are an expert systems analyst specializing in docker container security.",
              'security': "You are an expert security analyst specializing in container security and hardening.",
            'quick_check': "You are an expert system administrator with extensive experience in docker container management.",
            'technical': "You are an expert systems analyst specializing in infrastructure optimization."
        }

    def create_analysis_prompt(self, metrics: ContainerMetrics) -> List[Dict]:
        """Create system analysis prompt."""
        prompt = f"""
            As a system administrator, analyze these Docker metrics:

            System Information:
            - Hostname: {metrics.hostname}
            - OS Version: {metrics.os_version}
            - Docker Version: {metrics.docker_version}

            Resource Usage:
            - CPU Usage: {metrics.cpu_usage:.2f}%
            - Memory Usage: {metrics.memory_usage:.2f}GB
            - Running Containers: {metrics.running_containers}
            - Total Containers: {metrics.container_count}

            Image Metrics:
            {json.dumps(metrics.image_metrics, indent=2)}

            Configuration Issues:
            {json.dumps(metrics.configuration_issues, indent=2)}

            Log Issues:
            {json.dumps(metrics.log_issues, indent=2)}

            AWS Instance Metadata:
            {json.dumps(metrics.instance_metadata, indent=2)}

            Provide a detailed analysis including:
            1. Docker daemon health assessment
            2. Resource usage analysis
            3. Image and container status evaluation
            4. Configuration issues evaluation
            5. Log analysis
            6. Security recommendations for Docker
            7. Performance optimization suggestions
            8. Maintenance tasks needed

            Format the response in a structured markdown document with clear sections and actionable recommendations.
        """
        return [
            {"role": "system", "content": self.system_messages['analysis']},
            {"role": "user", "content": prompt}
        ]

    def create_recommendation_prompt(self, metrics: ContainerMetrics) -> List[Dict]:
        """Create instance recommendation prompt."""
        prompt = f"""
        Based on the following Docker metrics, provide a recommendation for the best EC2 instance type, including suggestions for CPU, memory, and storage configurations:

            System Information:
            - Hostname: {metrics.hostname}
            - OS Version: {metrics.os_version}
             - Docker Version: {metrics.docker_version}

            Resource Usage:
            - CPU Usage: {metrics.cpu_usage:.2f}%
            - Memory Usage: {metrics.memory_usage:.2f}GB
             - Running Containers: {metrics.running_containers}
            - Total Containers: {metrics.container_count}


            Image Metrics:
            {json.dumps(metrics.image_metrics, indent=2)}

            Configuration Issues:
            {json.dumps(metrics.configuration_issues, indent=2)}

            Log Issues:
            {json.dumps(metrics.log_issues, indent=2)}

            AWS Instance Metadata:
            {json.dumps(metrics.instance_metadata, indent=2)}

            Consider the current resource usage, application workload, and future scalability.

            Provide the best EC2 instance type with a rationale and suggestions for system tuning.

            Format the response as a structured markdown document with clear sections and actionable recommendations.
        """
        return [
            {"role": "system", "content": self.system_messages['reasoning']},
            {"role": "user", "content": prompt}
        ]

    def create_tuning_playbook_prompt(self, metrics: ContainerMetrics) -> List[Dict]:
        """Create system tuning playbook prompt."""
        prompt = f"""
            Based on the following Docker metrics, generate an Ansible playbook for system tuning:

            System Information:
            - Hostname: {metrics.hostname}
            - OS Version: {metrics.os_version}
             - Docker Version: {metrics.docker_version}

            Resource Usage:
            - CPU Usage: {metrics.cpu_usage:.2f}%
            - Memory Usage: {metrics.memory_usage:.2f}GB
             - Running Containers: {metrics.running_containers}
            - Total Containers: {metrics.container_count}


            Image Metrics:
            {json.dumps(metrics.image_metrics, indent=2)}

            Configuration Issues:
            {json.dumps(metrics.configuration_issues, indent=2)}

            Log Issues:
            {json.dumps(metrics.log_issues, indent=2)}

            AWS Instance Metadata:
            {json.dumps(metrics.instance_metadata, indent=2)}

            Include tasks to:
            1. Optimize Docker daemon configuration.
            2. Optimize resource allocation of Docker
            3. Ensure image security.
            4. Configure proper logging.
            5. Ensure stability of docker.

            The playbook must be well-structured, use clear task names, and include proper indentation.
            Use Ubuntu-specific modules and best practices.
            Always handle errors with a rollback when possible.

            Format the response as a structured markdown document with clear sections and actionable recommendations.
        """
        return [
             {"role": "system", "content": self.system_messages['playbook']},
             {"role": "user", "content": prompt}
        ]

    def create_security_prompt(self, metrics: ContainerMetrics) -> List[Dict]:
        """Create security scan prompt."""
        prompt = f"""
            As a security expert, perform a security review and recommend best practices based on the following Docker metrics:

            System Information:
            - Hostname: {metrics.hostname}
            - OS Version: {metrics.os_version}
             - Docker Version: {metrics.docker_version}

            Resource Usage:
            - CPU Usage: {metrics.cpu_usage:.2f}%
            - Memory Usage: {metrics.memory_usage:.2f}GB
            - Running Containers: {metrics.running_containers}
             - Total Containers: {metrics.container_count}

            Image Metrics:
            {json.dumps(metrics.image_metrics, indent=2)}

            Configuration Issues:
            {json.dumps(metrics.configuration_issues, indent=2)}

            Log Issues:
            {json.dumps(metrics.log_issues, indent=2)}

            AWS Instance Metadata:
            {json.dumps(metrics.instance_metadata, indent=2)}
            
            Provide a security review including:
            1. Docker daemon best practices
            2. Image security analysis and recommendations
            3. Container security analysis and recommendations
            4. Configuration recommendation
            5. Logging recommendations
            6. Security hardening steps to be taken.

            Format the response as a structured markdown document with clear sections and actionable recommendations.
        """
        return [
            {"role": "system", "content": self.system_messages['security']},
            {"role": "user", "content": prompt}
        ]
    def create_validation_commands_prompt(self, metrics: ContainerMetrics) -> List[Dict]:
       """Generate validation commands based on system metrics context"""
       prompt = f"""
        Generate specific validation commands for a Ubuntu system running Docker with metrics as follows:

            System Information:
            - Hostname: {metrics.hostname}
            - OS Version: {metrics.os_version}
            - Docker Version: {metrics.docker_version}

            Resource Usage:
            - CPU Usage: {metrics.cpu_usage:.2f}%
            - Memory Usage: {metrics.memory_usage:.2f}GB
            - Running Containers: {metrics.running_containers}
            - Total Containers: {metrics.container_count}

            Image Metrics:
            {json.dumps(metrics.image_metrics, indent=2)}

            Configuration Issues:
            {json.dumps(metrics.configuration_issues, indent=2)}

            Log Issues:
            {json.dumps(metrics.log_issues, indent=2)}

        Provide:
        1. Docker Daemon Status commands
        2. Container Status Commands
        3. Image Status Commands
        4. Resource usage commands
        5. Security Check Commands
        6. Log Review Commands

        Format the response as a markdown list with command descriptions
        """
       return [
             {"role": "system", "content": "You are an expert Ubuntu system administrator with extensive experience in docker container management."},
            {"role": "user", "content": prompt}
       ]

class DockerMonitor:
    def __init__(self, config: Config = None):
        """Initialize monitoring system."""
        if not config:
             config_file = "config.xml"
             if os.path.exists(config_file):
                self.config = Config.from_xml(config_file)
             else:
                self.config = Config()
        else:
            self.config = config

        self.log_dir = Path(os.path.dirname(os.path.abspath(__file__))) / "docker_monitor/logs"
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.setup_logging()
        self.prompt_generator = EnhancedPromptGenerator()
        self.ollama_api = f"{self.config.OLLAMA_BASE_URL}/api/generate"
        self.instance_metadata = self.get_instance_metadata()

        self.ansible_playbook_template = Template("""
        ---
        - name: Docker Tuning Playbook
          hosts: all
          become: true
          gather_facts: yes
          tasks:
             {{ tasks }}
          handlers:
             - name: Restart Docker
               service:
                 name: docker
                 state: restarted
        """)
    def setup_logging(self):
        """Setup logging configuration."""
        log_file = self.log_dir / "monitor.log"
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        logging.info(f"Docker Monitor Initialized. Log file: {log_file}")
    def _validate_command_input(self, command: List[str]) -> bool:
         """Validate the command before execution."""
         return command and command[0] in self.config.COMMAND_WHITELIST

    def run_command(self, command: str) -> Dict[str, Any]:
        """Run a shell command with error handling."""
        if not self._validate_command_input(shlex.split(command)):
            logging.error(f"Invalid command input: {command}")
            return {'success': False, 'output': '', 'error': "Invalid command input"}
        try:
            safe_command = [shlex.quote(arg) for arg in shlex.split(command)]
            result = subprocess.run(safe_command, shell=False, capture_output=True, text=True, check=True, timeout=self.config.COMMAND_TIMEOUT)
            return {"success": True, "output": result.stdout, "error": None}
        except subprocess.TimeoutExpired:
            logging.error(f"Command '{command}' timed out")
            return {'success': False, 'output': '', 'error': "Command timed out"}
        except subprocess.CalledProcessError as e:
            logging.error(f"Command '{command}' failed: {e.stderr}")
            return {"success": False, "output": e.stderr, "error": e}
        except Exception as e:
             logging.exception(f"An unexpected error occurred during command execution: {e}")
             return {'success': False, 'output': str(e), 'error': e}

    def get_instance_metadata(self) -> Dict[str, Any]:
        """Get instance metadata from AWS or fallback to hostname."""
        metadata_url = "http://169.254.169.254/latest/dynamic/instance-identity/document"
        try:
            response = requests.get(metadata_url, timeout=5)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logging.warning(f"Not an AWS Instance: {e}, Falling back to hostname")
            return {"instance_id": socket.gethostname()} # Fallback to hostname

    def get_container_metrics(self) -> ContainerMetrics:
        """Collect Docker metrics."""
        try:
            # System info
            uname = platform.uname()
            hostname = uname.node

            # Get OS version for Ubuntu
            try:
                with open('/etc/os-release') as f:
                    os_info = dict(line.strip().split('=', 1) for line in f if '=' in line)
                os_version = os_info.get('VERSION_ID', '').strip('"')
            except:
                os_version = "Ubuntu (version unknown)"

            # Docker version
            docker_version_cmd = self.run_command("docker version --format '{{.Server.Version}}'")
            docker_version = docker_version_cmd["output"].strip() if docker_version_cmd["success"] else "Unknown"

            # Container Counts
            # Use Docker's formatting options instead of piping to wc
            container_count_cmd = self.run_command("docker ps -a --format '{{.ID}}'")
            if container_count_cmd["success"]:
               container_count = len([line for line in container_count_cmd["output"].splitlines() if line.strip()]) - 1
            else:
                container_count = 0

            running_container_cmd = self.run_command("docker ps --format '{{.ID}}'")
            if running_container_cmd["success"]:
               running_containers = len([line for line in running_container_cmd["output"].splitlines() if line.strip()]) - 1
            else:
               running_containers = 0
            
            # Resource usage
            cpu_usage = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            memory_usage = memory.used / (1024**3)

            # Image metrics
            image_metrics = self.get_image_metrics()

            # Configuration issues
            configuration_issues = self.check_configuration()

            # Log issues
            log_issues = self.check_logs()
           
            return ContainerMetrics(
                timestamp=datetime.now().isoformat(),
                hostname=hostname,
                os_version=os_version,
                docker_version=docker_version,
                container_count=container_count,
                running_containers = running_containers,
                cpu_usage=cpu_usage,
                memory_usage=memory_usage,
                image_metrics=image_metrics,
                configuration_issues=configuration_issues,
                log_issues=log_issues,
                instance_metadata=self.instance_metadata
            )
        except Exception as e:
            logging.error(f"Error collecting container metrics: {e}")
            raise

    def get_image_metrics(self) -> List[Dict[str, Any]]:
        """Get Docker image metrics."""
        try:
            images_cmd = self.run_command('docker images --format "{{json .}}"')
            if not images_cmd["success"]:
                 logging.error(f"Error getting Docker images: {images_cmd['output']}")
                 return []

            images_data = []
            for line in images_cmd["output"].splitlines():
                 if not line:  # Skip empty lines
                      continue
                 try:
                     image_json = json.loads(line)
                     images_data.append({
                        'repository': image_json.get('Repository', 'N/A'),
                        'tag': image_json.get('Tag', 'N/A'),
                        'image_id': image_json.get('ID', 'N/A'),
                        'created_at': image_json.get('CreatedAt', 'N/A'),
                        'size': image_json.get('Size', 'N/A')
                     })
                 except json.JSONDecodeError:
                     logging.warning(f"Skipping invalid JSON line : {line}")
                     continue # skip this line
            return images_data
        except Exception as e:
            logging.error(f"Error parsing image JSON: {e}")
            return []

    def check_configuration(self) -> List[str]:
        """Check Docker daemon configuration."""
        issues = []
        config_file = "/etc/docker/daemon.json"
        if os.path.exists(config_file):
           try:
            with open(config_file, 'r') as f:
                config_data = json.load(f)
            
            if not config_data.get("log-driver", ""):
              issues.append("No log driver configured in daemon.json")
            elif config_data.get("log-driver") == "json-file":
              logging.warning("json-file is not recommend as log driver")
              issues.append("Use 'json-file' driver with caution, potential for disk filling.")
            
           except json.JSONDecodeError as e:
              issues.append(f"Invalid JSON format in {config_file}: {e}")
           except Exception as e:
              issues.append(f"Error reading config file {config_file}: {e}")
        else:
            issues.append("Docker daemon configuration file not found")
        return issues

    def check_logs(self) -> List[str]:
        """Check Docker daemon logs for errors."""
        log_issues = []
        try:
            log_cmd = self.run_command("sudo journalctl -u docker -n 200 --no-pager")
            if log_cmd["success"]:
               log_output = log_cmd["output"]
               if "error" in log_output.lower() or "fail" in log_output.lower():
                 log_issues.append(log_output)
            else:
               log_issues.append(f"Could not check logs due to error : {log_cmd['output']}")
        except Exception as e:
            log_issues.append(f"Error checking Docker logs: {e}")
        return log_issues


    async def _make_api_call(self, prompt_messages: List[Dict], model_type: str) -> str:
        """Enhanced model interaction with better error handling"""
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }

        # Define the model type mapping
        model_type_mapping = {
           'quick_check': 'quick_check',
            'technical': 'technical',
            'playbook': 'code',
            'security': 'security',
            'reasoning': 'reasoning'
        }

        # Get the correct model type from mapping
        mapped_type = model_type_mapping.get(model_type, model_type)
        
        if mapped_type not in self.config.MODEL_CONFIG:
            error_msg = f"Invalid model type: {model_type} (mapped to {mapped_type})"
            logging.error(error_msg)
            return f"Error: {error_msg}"

        model_name = self.config.MODEL_CONFIG[mapped_type]['name']
        temperature = self.config.MODEL_CONFIG[mapped_type]['temperature']

        for attempt in range(self.config.API_RETRIES):
            try:
                timeout = aiohttp.ClientTimeout(total=self.config.MODEL_CONFIG[mapped_type]['timeout'])
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    # Prepare the request payload according to Ollama API format
                    payload = {
                        "model": model_name,
                        "prompt": prompt_messages[1]['content'],
                         "system": prompt_messages[0]['content'],  # Include system message
                        "stream": False,
                        "options": {
                            "temperature": temperature
                        }
                    }

                    async with session.post(
                        f"{self.config.OLLAMA_BASE_URL}/api/generate",
                        json=payload,
                        headers=headers
                    ) as response:
                        if response.status == 200:
                            result = await response.json()
                            response_text = result.get('response', '')
                            if response_text:
                                return response_text
                            else:
                                logging.warning(f"Empty response from model on attempt {attempt + 1}")
                        else:
                            error_text = await response.text()
                            logging.error(f"API call failed with status {response.status}: {error_text}")
                            
                    if attempt < self.config.API_RETRIES - 1:
                        delay = 2 ** attempt
                        logging.info(f"Retrying in {delay} seconds...")
                        await asyncio.sleep(delay)
            
            except Exception as e:
                logging.error(f"API call error on attempt {attempt + 1}: {str(e)}")
                if attempt == self.config.API_RETRIES - 1:
                    return f"Error calling model: {str(e)}"

        return "Failed to get response after all retries. Using fallback analysis."
    
    async def get_validation_commands(self, metrics: ContainerMetrics) -> str:
        """Get dynamically generated validation commands"""
        try:
            prompt_messages = self.prompt_generator.create_validation_commands_prompt(metrics)
            commands = await self._make_api_call(prompt_messages, 'technical')
            
            if commands.startswith('Error') or not commands:
                # Fallback validation commands
                return """
                ## Docker Daemon Status:
                - `sudo systemctl status docker` : Check docker service status
                - `docker info` : Check docker information and status
                
                ## Container Status:
                - `docker ps`: List running containers
                - `docker ps -a` : List all containers
                - `docker container inspect <container_id or name>`: Inspect container details
                
                 ## Image Status
                - `docker images`: List local images
                - `docker inspect <image_id or name>`: Inspect image details

                ## Resource usage:
                - `top -bn1` : Check cpu and memory utilization
                - `free -m` : Check memory utilization
                 - `df -h`: Check disk usage

                ## Security Checks:
                 - `sudo ausearch -m user_avc`:  Check selinux audit logs for docker
                
                ## Log Review
                - `sudo journalctl -u docker -n 200 --no-pager`: Review docker logs
                - `sudo cat /var/log/messages | grep docker`: Check for docker logs
"""
            
            return commands

        except Exception as e:
            logging.error(f"Error generating validation commands: {str(e)}")
            return "Error generating validation commands. Please check logs for details."

    async def generate_playbook_tasks(self, metrics: ContainerMetrics) -> str:
         """Generate Ansible tasks based on AI analysis."""
         tuning_playbook_prompt = self.prompt_generator.create_tuning_playbook_prompt(metrics)
         tuning_playbook_text = await self._make_api_call(tuning_playbook_prompt, 'code')
         return tuning_playbook_text

    async def analyze_metrics(self, metrics: ContainerMetrics) -> Dict[str, Any]:
        """Use AI to analyze system metrics."""
        analysis_prompt = self.prompt_generator.create_analysis_prompt(metrics)
        recommendation_prompt = self.prompt_generator.create_recommendation_prompt(metrics)
        security_prompt = self.prompt_generator.create_security_prompt(metrics)

        analysis_text = await self._make_api_call(analysis_prompt, 'quick_check')
        recommendation_text = await self._make_api_call(recommendation_prompt, 'technical')
        security_text = await self._make_api_call(security_prompt, 'security')

        # Generate Ansible tasks and assemble the playbook
        tasks = await self.generate_playbook_tasks(metrics)
        rendered_playbook = self.ansible_playbook_template.render(tasks=tasks)
        # Get validation commands
        validation_commands = await self.get_validation_commands(metrics)

        return {
            'timestamp': metrics.timestamp,
            'analysis': analysis_text,
            'recommendation': recommendation_text,
            'security_analysis': security_text,
            'tuning_playbook': rendered_playbook,
            'validation_commands': validation_commands,
            'metrics': metrics.__dict__
        }
    
    def format_report(self, metrics: ContainerMetrics, analysis: Dict[str, Any]) -> str:
        """Format detailed system monitoring report as a string using Jinja2."""
        report_template = Template("""
            # Docker Monitoring Report

            **Executive Summary:**
            - Timestamp: {{ metrics.timestamp }}
            - Hostname: {{ metrics.hostname }}
            - OS Version: {{ metrics.os_version }}
            - Docker Version: {{ metrics.docker_version }}
            
            **Resource Usage:**
            - CPU Usage: {{ metrics.cpu_usage|round(2) }}%
            - Memory Usage: {{ metrics.memory_usage|round(2) }} GB
            - Total Containers: {{ metrics.container_count }}
            - Running Containers: {{ metrics.running_containers }}
            
            **Image Metrics:**
            {% for image in metrics.image_metrics %}
                - Repository: {{ image.repository }}, Tag: {{ image.tag }}, ID: {{ image.image_id }}, Created At: {{ image.created_at }}, Size: {{ image.size }}
            {% endfor %}
            
            **Configuration Issues:**
            {% for issue in metrics.configuration_issues %}
                - {{ issue }}
            {% endfor %}
            
            **Log Issues:**
            {% for issue in metrics.log_issues %}
                - {{ issue }}
            {% endfor %}

            {% if metrics.instance_metadata %}
            **AWS Instance Metadata:**
            {{ metrics.instance_metadata | tojson(indent=2) }}
             {% endif %}

            **System Analysis:**
            {{ analysis.analysis }}

            **Instance Recommendations:**
            {{ analysis.recommendation }}

            **Security Analysis:**
            {{ analysis.security_analysis }}
            
            **Validation Commands:**
            {{ validation_commands }}
           """)
        
        return report_template.render(
                metrics=metrics,
                analysis=analysis
            )

    def print_report(self, metrics: ContainerMetrics, analysis: Dict[str, Any]) -> None:
         """Print detailed system monitoring report."""
         print(self.format_report(metrics, analysis))

    async def monitor(self, interval: int = 300):
        """Run continuous monitoring."""
        print("\nDocker Monitoring System")
        print("=" * 50)
        print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Log Directory: {self.log_dir}")
        print("=" * 50)

        try:
            while True:
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                metrics = self.get_container_metrics()
                analysis = await self.analyze_metrics(metrics)
                self.print_report(metrics, analysis)

                 # Save to log file
                playbook_file = self.log_dir / f'tuning_playbook_{timestamp}.yml'
                with open(playbook_file, 'w') as f:
                     f.write(analysis['tuning_playbook'])
                formatted_report = self.format_report(metrics, analysis)
                formatted_report += f"\nSystem Tuning Playbook saved to: {playbook_file}\n"

                # Save metrics as JSON
                metrics_file = self.log_dir / f'metrics_{timestamp}.json'
                with open(metrics_file, 'w') as f:
                    json.dump(analysis, f, indent=2)
                formatted_report += f"Metrics saved to: {metrics_file}\n"

                # Save full report
                report_file = self.log_dir / f'report_{timestamp}.txt'
                with open(report_file, 'w') as f:
                    f.write(formatted_report)
                print(f"Full Report saved to: {report_file}\n")
                time.sleep(interval)

        except KeyboardInterrupt:
            print("\nMonitoring stopped by user")
        except Exception as e:
            print(f"\nError: {e}")
            logging.error(f"Monitoring failed: {e}")

async def main():
    monitor = DockerMonitor()
    await monitor.monitor()

if __name__ == "__main__":
    asyncio.run(main())