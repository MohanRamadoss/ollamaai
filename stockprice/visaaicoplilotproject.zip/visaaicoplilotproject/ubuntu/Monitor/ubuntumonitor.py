#!/usr/bin/env python3
import asyncio
import aiohttp
import json
import logging
import os
import subprocess
import time
import platform
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Any, Optional
import psutil
import requests
import re
from jinja2 import Template
from pathlib import Path
import xml.etree.ElementTree as ET
from dotenv import load_dotenv
import sys
import socket

load_dotenv()

@dataclass
class UbuntuMonitorConfig:
    """Enhanced configuration management for Ubuntu Monitor"""
    LOG_DIR: str = str(Path.home() / "ubuntu_monitor")
    COMMAND_TIMEOUT: int = 300
    API_RETRIES: int = 5
    CACHE_DURATION: int = 3600
    MODEL_CONFIG: Dict[str, Dict] = field(default_factory=dict)
    OLLAMA_BASE_URL: Optional[str] = os.getenv("OLLAMA_API_URL", None)
    OLLAMA_ENDPOINTS: Dict[str, str] = field(default_factory=lambda: {
        "generate": "/api/generate",
        "status": "/api/status",
        "models": "/api/models"
    })
    OLLAMA_HEADERS: Dict[str, str] = field(default_factory=lambda: {
        "Content-Type": "application/json",
        "Accept": "application/json"
    })
    OLLAMA_RETRY_CONFIG: Dict[str, int] = field(default_factory=lambda: {
        "max_attempts": 5,
        "min_delay": 1,
        "max_delay": 10
    })
    OLLAMA_RATE_LIMIT: Dict[str, int] = field(default_factory=lambda: {
        "calls": 10,
        "period": 60
    })
    METADATA_URL: str = ""
    DEFAULT_INTERVAL: int = 300
    COMMAND_WHITELIST: List[str] = field(default_factory=lambda: [
        "systemctl", "ss", "ifconfig", "grep", "uptime", "apt", "date", "cat",
        "apache2", "nginx", "dpkg-query", "apt-get", "aa-status", "ufw",
        "lsblk", "fdisk", "ip", "who", "journalctl"
    ])
    MAX_HISTORY_ITEMS: int = 100
    
    def __post_init__(self):
      if not self.OLLAMA_BASE_URL:
            raise ValueError("Ollama base url cannot be empty, provide OLLAMA_API_URL or set in config.xml")
      if not all(self.MODEL_CONFIG.values()):
            raise ValueError("Invalid Configuration, Please check model values")


@dataclass
class SystemMetrics:
    """Store system metrics"""
    timestamp: str
    hostname: str
    os_version: str
    kernel_version: str
    uptime: str
    cpu_usage: float
    memory_used: float
    memory_total: float
    swap_used: float
    swap_total: float
    disk_usage: Dict[str, Any]
    updates_pending: int
    security_updates: int
    network_metrics: Dict[str, Any]
    top_processes: List[Dict[str, Any]]
    service_status: Dict[str, str]
    load_average: Dict[str, float]
    instance_metadata: Dict[str, Any]
    open_ports: List[str]
    syslog_errors: List[str]


class UbuntuMonitor:
    def __init__(self, config_file: str = "config.xml"):
        """Initialize monitoring system with configuration."""
        self.config = self._load_config_from_xml(config_file)
        self.command_cache = {}
        self.log_dir = Path(self.config.LOG_DIR)
        self.logs_dir = self.log_dir / "logs"  # Add this line
        self.logs_dir.mkdir(parents=True, exist_ok=True)  # Create logs subdirectory

        self._setup_logging()  # Corrected method call here
        self.ansible_playbook_template = Template("""
        ---
        - name: System Tuning Playbook
          hosts: all
          become: true
          gather_facts: yes
          tasks:
             {{ tasks }}
          handlers:
             - name: Restart services
               service:
                 name: "{{ item }}"
                 state: restarted
               loop:
                - ssh
                - cron
                - systemd-journald
                - rsyslog
                - NetworkManager
                - apparmor
                - unattended-upgrades
        """)
        self.instance_metadata = self.get_instance_metadata()
        self.validate_config()
    
    def _load_config_from_xml(self, config_file: str) -> UbuntuMonitorConfig:
            """Load configuration from XML file."""
            try:
                tree = ET.parse(config_file)
                root = tree.getroot()

                config_data = {
                    "LOG_DIR": str(Path.home() / "ubuntu_monitor"),
                    "API_RETRIES": int(root.find("api_retries").text),
                    "CACHE_DURATION": int(root.find("cache_timeout").text),
                    "OLLAMA_BASE_URL": root.find("ollama_api").text,
                    "MAX_HISTORY_ITEMS": int(root.find("max_history_items").text),
                    "METADATA_URL": root.find("metadata_url").text,
                    "DEFAULT_INTERVAL": int(root.find("default_interval").text),
                }

                model_config = {}
                for model_type in root.find("models"):
                    if model_type.tag not in ["quick_check", "technical", "code", "reasoning", "commands"]:
                       continue  # Skip if not a model type we are interested in
                    model_config[model_type.tag] = {
                          'name': model_type.find("name").text,
                          'temperature': float(model_type.find("temperature").text),
                          'timeout': int(model_type.find("timeout").text),
                                }
                    config_data["MODEL_CONFIG"] = model_config
                
                command_whitelist = root.find("command_whitelist")
                if command_whitelist is not None:
                  config_data['COMMAND_WHITELIST'] = [command.text for command in command_whitelist]
                return UbuntuMonitorConfig(**config_data)
            except Exception as e:
                logging.error(f"Error loading configuration from {config_file}: {e}")
                raise
    
    def _setup_logging(self):
        """Configure logging."""
        log_file = self.logs_dir / "ubuntu_monitor.log"  # Use self.logs_dir here
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    async def __aenter__(self):
        """Async context manager entry."""
        self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc_value, traceback):
        """Async context manager exit."""
        await self.session.close()

    def run_command(self, command: List[str], capture_all: bool = False) -> Dict[str, Any]:
        """Enhanced command execution with caching and timeout"""
        cmd_str = ' '.join(command)
        if cmd_str in self.command_cache:
            cached_result = self.command_cache[cmd_str]
            if (datetime.now() - cached_result['timestamp']).seconds < self.config.CACHE_DURATION:
                return cached_result['result']

        try:
             # Add common system commands to whitelist check
            base_commands = ['cat', 'ls', 'df', 'lsblk', 'ip', 'who', 'uptime', 'ufw', 'aa-status']
            cmd_base = command[0].split('/')[-1]  # Handle full paths
            
            if cmd_base not in self.config.COMMAND_WHITELIST + base_commands:
                logging.warning(f"Command '{cmd_base}' not in whitelist")
                return {'success': False, 'output': '', 'error': 'Command not allowed'}
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=self.config.COMMAND_TIMEOUT
            )
            output = result.stdout.strip()
            error = result.stderr.strip()
            
            result_dict = {
                'success': result.returncode == 0,
                'output': output if capture_all else output,
                'error': error
            }
            
            self.command_cache[cmd_str] = {
                'result': result_dict,
                'timestamp': datetime.now()
            }
            return result_dict
        except subprocess.TimeoutExpired:
            logging.error(f"Command '{cmd_str}' timed out")
            return {'success': False, 'output': '', 'error': 'Command timed out'}
        except Exception as e:
            logging.error(f"Command '{cmd_str}' failed with error: {e}")
            return {'success': False, 'output': '', 'error': str(e)}

    def get_network_metrics(self) -> Dict[str, Any]:
        """Get network metrics using ip command."""
        interfaces = {}
        try:
            # Get network statistics using ip -s link
            cmd = self.run_command(['ip', '-s', 'link'])
            if not cmd["success"]:
                logging.error(f"Error getting network metrics: {cmd['output']}")
                return {}

            current_interface = None
            lines = cmd["output"].split('\n')
            
            for i, line in enumerate(lines):
                # Interface line starts with index number
                if line[0].isdigit():
                    parts = line.split(':')
                    if len(parts) >= 2:
                        current_interface = parts[1].strip()
                        if not current_interface.startswith(('lo', 'docker')):  # Skip loopback and docker
                            interfaces[current_interface] = {"tx_bytes": 0, "rx_bytes": 0}
                # RX/TX lines contain the statistics
                elif current_interface and current_interface in interfaces:
                    if "RX:" in line and i + 1 < len(lines):
                        # RX bytes are typically the first field in statistics
                        try:
                            rx_bytes = int(lines[i + 1].split()[0])
                            interfaces[current_interface]["rx_bytes"] = rx_bytes
                        except (IndexError, ValueError):
                            continue
                    elif "TX:" in line and i + 1 < len(lines):
                        try:
                            tx_bytes = int(lines[i + 1].split()[0])
                            interfaces[current_interface]["tx_bytes"] = tx_bytes
                        except (IndexError, ValueError):
                            continue

            return interfaces
        except Exception as e:
            logging.error(f"Error processing network metrics: {e}")
            return {}

    def get_top_processes(self, count: int = 5) -> List[Dict[str, Any]]:
        """Get top CPU and memory-consuming processes."""
        try:
            processes = []
            for process in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
                processes.append(process.info)

            # Sort by CPU usage
            cpu_sorted = sorted(processes, key=lambda p: p['cpu_percent'], reverse=True)[:count]
            # Sort by Memory usage
            mem_sorted = sorted(processes, key=lambda p: p['memory_percent'], reverse=True)[:count]

            # Merge results if needed
            merged_processes = {}
            for p in cpu_sorted:
                merged_processes[p['pid']] = p
                merged_processes[p['pid']]['source'] = 'cpu'

            for p in mem_sorted:
                if p['pid'] not in merged_processes:
                    merged_processes[p['pid']] = p
                    merged_processes[p['pid']]['source'] = 'memory'
                else:
                    merged_processes[p['pid']]['source'] += ',memory'

            return list(merged_processes.values())
        except Exception as e:
            logging.error(f"Error getting top processes: {e}")
            return []

    def check_critical_services(self) -> Dict[str, str]:
        """Check status of critical services."""
        critical_services = ['ssh', 'apache2', 'nginx', 'mysql', 'ufw']
        service_status = {}

        for service in critical_services:
            cmd = self.run_command(['systemctl', 'is-active', service])
            service_status[service] = cmd["output"].strip() if cmd["success"] else "unknown"

        return service_status

    def get_load_average(self) -> Dict[str, float]:
        """Get load average information."""
        load = os.getloadavg()
        return {
            '1min': load[0],
            '5min': load[1],
            '15min': load[2]
        }

    def get_instance_metadata(self) -> Dict[str, Any]:
        """Get instance metadata from AWS using IMDSv2 or fallback to hostname"""
        try:
            # Get token first
            token_url = self.config.METADATA_URL.replace("document","token")
            token_headers = {"X-aws-ec2-metadata-token-ttl-seconds": "21600"}
            token_response = requests.put(token_url, headers=token_headers, timeout=2)
            token = token_response.text

            # Get metadata with token
            metadata_headers = {"X-aws-ec2-metadata-token": token}
            response = requests.get(self.config.METADATA_URL, headers=metadata_headers, timeout=5)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logging.warning(f"Not an AWS instance or cannot get metadata, falling back to hostname: {e}")
            return {"instance_id": socket.gethostname()} # Fallback to hostname

    def get_open_ports(self) -> List[str]:
        """Scan open ports using ss command."""
        cmd = self.run_command(['sudo', 'ss', '-antp'])
        if not cmd["success"]:
            logging.error(f"Error getting open ports: {cmd['output']}")
            return []

        ports = []
        for line in cmd["output"].splitlines():
            if "LISTEN" in line:
                parts = line.split()
                try:
                    local_address = parts[4]
                    match = re.search(r':(\d+)', local_address)
                    if match:
                        port = match.group(1)
                        ports.append(port)

                except (IndexError, ValueError):
                    continue  # Skip if line is not well formatted
        return ports

    def get_syslog_errors(self) -> List[str]:
        """Grep /var/log/syslog for errors."""
        cmd = self.run_command(['grep', '-E', 'error|fail|critical', '/var/log/syslog'])
        if not cmd["success"]:
            logging.error(f"Error getting syslog errors: {cmd['output']}")
            return []

        errors = [line.strip() for line in cmd["output"].splitlines() if line.strip()][:5]  # Limit to last 5
        return errors

    def get_system_metrics(self) -> SystemMetrics:
        """Collect system metrics."""
        try:
            # System info
            uname = platform.uname()
            hostname = uname.node
            kernel = uname.release

            # Get OS version for Ubuntu
            try:
                with open('/etc/os-release') as f:
                    os_info = dict(line.strip().split('=', 1) for line in f if '=' in line)
                os_version = os_info.get('VERSION_ID', '').strip('"')
            except:
                os_version = "Ubuntu (version unknown)"

            # Get uptime
            uptime_cmd = self.run_command(['uptime', '-p'], capture_all=True)  # Add capture_all=True
            uptime = uptime_cmd["output"].strip() if uptime_cmd["success"] else "Unknown"

            # Resource usage
            cpu_usage = psutil.cpu_percent()
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()

            # Disk Usage
            disk = psutil.disk_usage('/')
            disk_metrics = {
                'total': disk.total / (1024 ** 3),
                'used': disk.used / (1024 ** 3),
                'free': disk.free / (1024 ** 3),
                'percent': disk.percent
            }

            # Update information
            updates = self.check_updates()

            # Additional metrics
            network_metrics = self.get_network_metrics()
            top_processes = self.get_top_processes()
            service_status = self.check_critical_services()
            load_average = self.get_load_average()
            open_ports = self.get_open_ports()
            syslog_errors = self.get_syslog_errors()

            return SystemMetrics(
                timestamp=datetime.now().isoformat(),
                hostname=hostname,
                os_version=os_version,
                kernel_version=kernel,
                uptime=uptime,
                cpu_usage=cpu_usage,
                memory_used=memory.used / (1024 ** 3),
                memory_total=memory.total / (1024 ** 3),
                swap_used=swap.used / (1024 ** 3),
                swap_total=swap.total / (1024 ** 3),
                disk_usage=disk_metrics,
                updates_pending=updates['total'],
                security_updates=updates['security'],
                network_metrics=network_metrics,
                top_processes=top_processes,
                service_status=service_status,
                load_average=load_average,
                instance_metadata=self.instance_metadata,
                open_ports=open_ports,
                syslog_errors=syslog_errors
            )

        except Exception as e:
            logging.error(f"Error collecting metrics: {e}")
            raise

    def check_updates(self) -> Dict[str, int]:
        """Check for system updates using apt."""
        try:
            # Update package list
            self.run_command(["sudo", "apt-get", "update", "-qq"])

            # Check for updates using apt list
            upgrade_cmd = self.run_command(["apt", "list", "--upgradable"])

            updates = {
                'total': 0,
                'security': 0
            }

            # Count total updates
            if upgrade_cmd["success"]:
               lines = upgrade_cmd["output"].split('\n')
               updates['total'] = len([l for l in lines if '/' in l])
               updates['security'] = len([l for l in lines if '-security' in l])

            return updates

        except Exception as e:
            logging.error(f"Error checking updates: {e}")
            return {'total': 0, 'security': 0}

    async def _make_api_call(self, prompt: str, model_type: str) -> str:
        """Enhanced model interaction with better error handling"""
        logging.info(f"Starting _make_api_call for model type: {model_type}")
        
        # Updated model mapping to match config.xml
        model_type_mapping = {
            'quick_check': 'quick_check',
            'technical': 'technical',
            'code': 'code',
             'reasoning': 'reasoning',
            'analysis': 'quick_check',
            'recommendation': 'quick_check',
            'playbook': 'code',
            'terraform': 'code',
             'commands': 'commands'
        }
        
        mapped_type = model_type_mapping.get(model_type)
        if not mapped_type or mapped_type not in self.config.MODEL_CONFIG:
            raise ValueError(f"Invalid model type: {model_type}")
        
        model_config = self.config.MODEL_CONFIG[mapped_type]
        model_name = model_config['name']
        
        for attempt in range(self.config.API_RETRIES):
            try:
                timeout = aiohttp.ClientTimeout(total=model_config['timeout'])
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    request_data = {
                        "model": model_name,
                        "prompt": prompt,
                        "stream": False,
                        "temperature": model_config['temperature']
                    }
                    
                    async with session.post(
                        f"{self.config.OLLAMA_BASE_URL}/api/generate",
                        json=request_data,
                        headers=self.config.OLLAMA_HEADERS
                    ) as response:
                        if response.status == 200:
                            result = await response.json()
                            if result and 'response' in result:
                                return result['response']
                            logging.error(f"Invalid response format: {result}")
                        else:
                            error_text = await response.text()
                            logging.error(f"API call failed with status {response.status}: {error_text}")
                    
                if attempt < self.config.API_RETRIES - 1:
                    delay = min(2 ** attempt, 10)
                    logging.info(f"Retrying in {delay} seconds...")
                    await asyncio.sleep(delay)
                    
            except Exception as e:
                logging.error(f"API call error on attempt {attempt + 1}: {str(e)}")
                
        return "Failed to get valid response after all retries"

    def create_analysis_prompt(self, metrics: SystemMetrics) -> str:
        """Create system analysis prompt."""
        return f"""
        As a system administrator, analyze these Ubuntu server metrics:

        System Information:
        - Hostname: {metrics.hostname}
        - OS Version: {metrics.os_version}
        - Kernel: {metrics.kernel_version}
        - Uptime: {metrics.uptime}

        Resource Usage:
        - CPU Usage: {metrics.cpu_usage:.2f}%
        - Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB
        - Swap: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB
        - Disk Usage: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB ({metrics.disk_usage['percent']}%)

        Load Average:
        - 1 minute: {metrics.load_average['1min']:.2f}
        - 5 minutes: {metrics.load_average['5min']:.2f}
        - 15 minutes: {metrics.load_average['15min']:.2f}

        Network Metrics:
        {json.dumps(metrics.network_metrics, indent=2)}

        Top Processes:
        {json.dumps(metrics.top_processes, indent=2)}

        Service Status:
        {json.dumps(metrics.service_status, indent=2)}

        Updates:
        - Total Updates Pending: {metrics.updates_pending}
        - Security Updates: {metrics.security_updates}

        Open Ports:
        {metrics.open_ports}

        Syslog Errors:
        {metrics.syslog_errors}

        AWS Instance Metadata:
        {json.dumps(metrics.instance_metadata, indent=2)}

        Provide a detailed analysis including:
        1. System health assessment
        2. Resource usage analysis
        3. Network performance analysis
        4. Process and service status evaluation
        5. Security recommendations, including which open ports should be closed
        6. Performance optimization suggestions
        7. Maintenance tasks needed
        8. Analysis of any syslog errors

        Format the response in markdown with clear sections and bullet points.
        """

    def create_recommendation_prompt(self, metrics: SystemMetrics) -> str:
        """Create instance recommendation prompt."""
        return f"""
        Based on the following Ubuntu server metrics, provide a recommendation for the best EC2 instance type, including suggestions for CPU, memory, and storage configurations:

        System Information:
        - Hostname: {metrics.hostname}
        - OS Version: {metrics.os_version}
        - Kernel: {metrics.kernel_version}
        - Uptime: {metrics.uptime}

        Resource Usage:
        - CPU Usage: {metrics.cpu_usage:.2f}%
        - Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB
        - Swap: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB
        - Disk Usage: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB ({metrics.disk_usage['percent']}%)

        Load Average:
        - 1 minute: {metrics.load_average['1min']:.2f}
        - 5 minutes: {metrics.load_average['5min']:.2f}
        - 15 minutes: {metrics.load_average['15min']:.2f}

        Top Processes:
        {json.dumps(metrics.top_processes, indent=2)}

        AWS Instance Metadata:
        {json.dumps(metrics.instance_metadata, indent=2)}

        Updates:
        - Total Updates Pending: {metrics.updates_pending}
        - Security Updates: {metrics.security_updates}

        Consider the current resource usage, application workload, and future scalability.

        Provide the best EC2 instance type with a rationale and suggestions for system tuning.
        """

    def create_tuning_playbook_prompt(self, metrics: SystemMetrics, ports_to_close: List[str]) -> str:
            """Create system tuning playbook prompt."""
            ports_str = ", ".join(ports_to_close)
            return f"""
            Based on the following Ubuntu server metrics, generate an Ansible playbook for system tuning:

            System Information:
            - Hostname: {metrics.hostname}
            - OS Version: {metrics.os_version}
            - Kernel: {metrics.kernel_version}
            - Uptime: {metrics.uptime}

            Resource Usage:
            - CPU Usage: {metrics.cpu_usage:.2f}%
            - Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB
            - Swap: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB
            - Disk Usage: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB ({metrics.disk_usage['percent']}%)

            Load Average:
            - 1 minute: {metrics.load_average['1min']:.2f}
            - 5 minutes: {metrics.load_average['5min']:.2f}
            - 15 minutes: {metrics.load_average['15min']:.2f}

            Top Processes:
            {json.dumps(metrics.top_processes, indent=2)}

            Updates:
            - Total Updates Pending: {metrics.updates_pending}
            - Security Updates: {metrics.security_updates}

            Open Ports:
            {metrics.open_ports}

            Syslog Errors:
            {metrics.syslog_errors}

            AWS Instance Metadata:
            {json.dumps(metrics.instance_metadata, indent=2)}

            Include tasks to:
            1. Optimize CPU usage.
            2. Adjust memory settings.
            3. Improve disk performance.
            4. Configure networking.
            5. Ensure service stability.
            6. Stop the following ports: {ports_str}, using the most appropriate method.

            The playbook must be well-structured, use clear task names, and include proper indentation.
            Use Ubuntu-specific modules and best practices.
            Always handle errors with a rollback when possible.
            """
    
    def create_terraform_prompt(self, metrics: SystemMetrics, new_instance_type: str) -> str:
        """Create Terraform code for instance upgrade/downgrade prompt."""
        return f"""
        Based on the current Ubuntu server metrics and the new instance type '{new_instance_type}', generate the Terraform code to upgrade or downgrade the EC2 instance:

        System Information:
        - Hostname: {metrics.hostname}
        - OS Version: {metrics.os_version}
        - Kernel: {metrics.kernel_version}
        - Uptime: {metrics.uptime}

        Resource Usage:
        - CPU Usage: {metrics.cpu_usage:.2f}%
        - Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB
        - Swap: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB
        - Disk Usage: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB ({metrics.disk_usage['percent']}%)

        Top Processes:
        {json.dumps(metrics.top_processes, indent=2)}

        AWS Instance Metadata:
        {json.dumps(metrics.instance_metadata, indent=2)}

        Updates:
        - Total Updates Pending: {metrics.updates_pending}
        - Security Updates: {metrics.security_updates}

        The Terraform code must:
        1. Define the new instance type.
        2. Include necessary attributes for the instance.
        3. Handle dependencies for the instance.
        4. Provide clear comments for each resource.
        """

    async def analyze_metrics(self, metrics: SystemMetrics) -> Dict[str, Any]:
        """Use AI to analyze system metrics."""
        logging.info("Starting analyze_metrics")
        analysis_prompt = self.create_analysis_prompt(metrics)
        recommendation_prompt = self.create_recommendation_prompt(metrics)
        logging.info("Creating analysis and recommendation tasks")
        analysis_task = self._make_api_call(analysis_prompt, 'analysis')
        recommendation_task = self._make_api_call(recommendation_prompt, 'recommendation')
        logging.info("Gathering analysis and recommendation results")
        analysis_text, recommendation_text = await asyncio.gather(analysis_task, recommendation_task)

        tasks = await self.generate_playbook_tasks(metrics, analysis_text)
        rendered_playbook = self.ansible_playbook_template.render(tasks=tasks)

        return {
            'timestamp': metrics.timestamp,
            'analysis': analysis_text,
            'recommendation': recommendation_text,
            'tuning_playbook': rendered_playbook,
            'metrics': metrics.__dict__
        }
    
    async def generate_playbook_tasks(self, metrics: SystemMetrics, analysis: str) -> str:
        """Generate Ansible tasks based on AI analysis."""

        ports_to_close = []
        # parse analysis to determine which ports to close
        lines = analysis.split('\n')
        for line in lines:
            if 'close port' in line.lower() and "port" in line.lower():
                match = re.search(r'\bport\s+(\d+)\b', line, re.IGNORECASE)
                if match:
                    ports_to_close.append(match.group(1))

        tuning_playbook_prompt = self.create_tuning_playbook_prompt(metrics, ports_to_close)
        tuning_playbook_text = await self._make_api_call(tuning_playbook_prompt, 'commands')
        return tuning_playbook_text

    async def generate_terraform_code(self, metrics: SystemMetrics, new_instance_type: str) -> str:
        """Generate Terraform code for instance changes."""
        terraform_prompt = self.create_terraform_prompt(metrics, new_instance_type)
        terraform_code = await self._make_api_call(terraform_prompt, 'terraform')
        return terraform_code
    
    def format_report(self, metrics: SystemMetrics, analysis: Dict[str, Any]) -> str:
        """Format report with enhanced AI analysis section."""
        report = []
        report.append(self.format_banner("Ubuntu System Analysis Report"))
        report.append(f"Generated: {metrics.timestamp}")
        report.append("=" * 80)

       # Hardware Configuration Section
        report.append("\n## Hardware Configuration")
        cpu_info = self.get_cpu_info()
        disk_info = self.get_disk_info()
        nic_info = self.get_network_interfaces()
        
        report.append("\n### CPU Information")
        report.append(f"- Physical CPUs: {cpu_info['physical_cpus']}")
        report.append(f"- CPU Cores: {cpu_info['cpu_cores']}")
        report.append(f"- CPU Model: {cpu_info['cpu_model']}")
        report.append(f"- CPU Architecture: {cpu_info['architecture']}")

        report.append("\n### Storage Configuration")
        report.append("Disk Layout:")
        for disk in disk_info:
            report.append(f"- Device: {disk['device']}")
            report.append(f"  - Size: {disk['size']}")
            report.append(f"  - Model: {disk['model']}")
       
        report.append("\n### Network Configuration")
        report.append("Network Interfaces:")
        for nic in nic_info:
            report.append(f"- Interface: {nic['name']}")
            report.append(f"  - State: {nic['state']}")
            report.append(f"  - MAC Address: {nic['mac']}")
            report.append(f"  - IP Address: {nic.get('ip', 'None')}")
            report.append(f"  - Speed: {nic.get('speed','Unknown')}")
        
        # System Performance Section
        report.append("\n## System Performance")
        report.append("\n### Resource Utilization")
        report.append(f"- CPU Usage: {metrics.cpu_usage:.2f}%")
        report.append(f"- Memory Usage: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB ({(metrics.memory_used/metrics.memory_total)*100:.1f}%)")
        report.append(f"- Swap Usage: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB")
        report.append("Load Average:")
        report.append(f"- 1 minute: {metrics.load_average['1min']:.2f}")
        report.append(f"- 5 minutes: {metrics.load_average['5min']:.2f}")
        report.append(f"- 15 minutes: {metrics.load_average['15min']:.2f}")

        # Process Analysis
        report.append("\n### Top Processes")
        report.append("| PID | Name | CPU% | Memory% | Type |")
        report.append("|-----|------|------|---------|------|")
        for proc in metrics.top_processes:
            report.append(f"| {proc['pid']} | {proc['name']} | {proc['cpu_percent']:.1f} | {proc['memory_percent']:.1f} | {proc['source']} |")

        # System Health Section
        report.append("\n## System Health")
        health_checks = self.perform_health_checks()
        
        report.append("\n### Service Status")
        for service, status in metrics.service_status.items():
            report.append(f"- {service}: {status}")

        report.append("\n### Security Status")
        report.append(f"- AppArmor Status: {health_checks['apparmor_status']}")
        report.append(f"- Firewall Status: Active ({len(metrics.open_ports)} open ports)")
        report.append(f"- Updates Pending: {metrics.updates_pending} (Security: {metrics.security_updates})")

        # Error Analysis
        if metrics.syslog_errors:
            report.append("\n### System Errors")
            report.append("Recent Critical Events:")
            for error in metrics.syslog_errors[:5]:  # Show only last 5 errors
                report.append(f"- {error}")

        # Monitoring commands
        report.append(self.format_monitoring_commands_section())
        
        # AI Analysis Section with better formatting
        if 'analysis' in analysis:
            report.append(self.format_banner("AI ANALYSIS AND RECOMMENDATIONS"))
            
            # Split analysis into sections and format them
            analysis_text = analysis['analysis']
            sections = analysis_text.split('\n\n')
            
            for section in sections:
                if section.strip():
                    # Handle markdown headers
                    if section.startswith('#'):
                        report.append(section)
                    else:
                        # Add section header if it contains a recognized section title
                        section_lower = section.lower()
                        if any(title in section_lower for title in [
                            'system health', 'resource usage', 'network performance',
                            'process', 'security', 'performance', 'maintenance',
                            'analysis'
                        ]):
                            report.append(f"\n{section}")
                        else:
                            report.append(section)

        # Infrastructure Recommendations
        if 'recommendation' in analysis:
            report.append(self.format_banner("INFRASTRUCTURE RECOMMENDATIONS"))
            report.append(analysis['recommendation'])
            
        report.append(self.check_single_points_of_failure())
        
        return '\n'.join(report)

    # 2. Add new methods to gather detailed system information

    def get_cpu_info(self) -> Dict[str, Any]:
        """Get detailed CPU information."""
        cpu_info = {
            'physical_cpus': 0,
            'cpu_cores': 0,
            'cpu_model': '',
            'architecture': platform.machine()
        }
        
        try:
            # Get CPU information from /proc/cpuinfo
            cmd = self.run_command(['cat', '/proc/cpuinfo'])
            if cmd['success']:
                content = cmd['output']
                cpu_info['physical_cpus'] = len(re.findall(r'physical id\s+:\s+\d+', content))
                cpu_info['cpu_cores'] = len(re.findall(r'processor\s+:\s+\d+', content))
                
                # Get CPU model
                model_match = re.search(r'model name\s+:\s+(.+)', content)
                if model_match:
                    cpu_info['cpu_model'] = model_match.group(1)
        except Exception as e:
            logging.error(f"Error getting CPU info: {e}")
        
        return cpu_info

    def get_disk_info(self) -> List[Dict[str, Any]]:
         """Get detailed disk information with improved error handling"""
         disks = []
         try:
             # First try using lsblk with different format
             cmd = self.run_command(['lsblk', '--json', '--output', 'NAME,SIZE,TYPE,MOUNTPOINT'])
             if cmd['success']:
                 try:
                     disk_data = json.loads(cmd['output'])
                     for device in disk_data.get('blockdevices', []):
                         if device['type'] == 'disk' and not device['name'].startswith(('loop', 'sr')):
                             disk_info = {
                                 'device': f"/dev/{device['name']}",
                                 'size': device['size'],
                                 'model': 'Unknown',
                                 'mount_point': device.get('mountpoint', '')
                             }
                             disks.append(disk_info)
                 except json.JSONDecodeError:
                     logging.error("Failed to parse lsblk JSON output")
             
             # If no disks found, try alternative method
             if not disks:
                 cmd = self.run_command(['fdisk', '-l'])
                 if cmd['success']:
                     for line in cmd['output'].split('\n'):
                         if line.startswith('Disk /dev/') and not any(x in line for x in ['loop', 'sr']):
                             device = line.split()[1].rstrip(':')
                             size = line.split('bytes')[0].split(',')[-1].strip()
                             disks.append({
                                 'device': device,
                                 'size': size,
                                 'model': 'Unknown',
                                 'mount_point': ''
                             })
             
             return disks
             
         except Exception as e:
            logging.error(f"Error getting disk info: {e}")
            return []

    def get_nic_info(self) -> List[Dict[str, Any]]:
        """Get detailed network interface information."""
        nics = []
        try:
            # Get network interface information using ip command
             cmd = self.run_command(['ip', 'addr', 'show'])
             if cmd['success']:
                current_nic = None
                for line in cmd['output'].splitlines():
                    if ': ' in line:
                        parts = line.split(': ')
                        if len(parts) >= 2:
                            iface = parts[1].split('@')[0]
                            if iface not in ('lo', 'docker0'):
                                current_nic = {
                                    'name': iface,
                                    'mac_address': 'N/A',
                                    'ip_address': 'N/A',
                                    'speed': self._get_interface_speed(iface),
                                    'state': 'unknown'
                                }
                                nics.append(current_nic)
                    elif current_nic and 'link/ether' in line:
                        current_nic['mac_address'] = line.split()[1]
                    elif current_nic and 'inet ' in line:
                         current_nic['ip_address'] = line.split()[1].split('/')[0]
                            
        except Exception as e:
            logging.error(f"Error getting NIC info: {e}")
        
        return nics
    
    def get_network_interfaces(self) -> List[Dict[str, str]]:
        """Get list of physical network interfaces with detailed information."""
        interfaces = []
        try:
            # Try ip command first
            cmd = self.run_command(['ip', '-br', 'link', 'show'])
            if cmd['success']:
                for line in cmd['output'].split('\n'):
                    if line and not any(x in line.lower() for x in ['lo:', 'virtual', 'docker', 'veth']):
                        parts = line.split()
                        if len(parts) >= 2:
                            interface = {
                                'name': parts[0],
                                'state': parts[1],
                                'mac': parts[2] if len(parts) > 2 else 'Unknown',
                                'ip': 'None',
                                'speed': 'Unknown'
                            }
                            
                            # Get IP address
                            ip_cmd = self.run_command(['ip', '-br', 'addr', 'show', interface['name']])
                            if ip_cmd['success']:
                                ip_parts = ip_cmd['output'].strip().split()
                                if len(ip_parts) > 2:
                                    interface['ip'] = ip_parts[2].split('/')[0]
                            
                            # Get speed if available
                            try:
                                with open(f"/sys/class/net/{interface['name']}/speed", 'r') as f:
                                    speed = f.read().strip()
                                    interface['speed'] = f"{speed}Mbps" if speed.isdigit() else 'Unknown'
                            except Exception:
                                pass
                                
                            interfaces.append(interface)
        
        
        except Exception as e:
            logging.error(f"Error getting network interfaces: {e}")
            return []
        
        # If no interfaces found or command failed, try fallback method
        if not interfaces:
            cmd = self.run_command(['ls', '/sys/class/net/'])
            if cmd['success']:
                for iface in cmd['output'].split():
                    if not any(x in iface.lower() for x in ['lo', 'docker', 'veth']):
                        interface = {
                            'name': iface,
                            'state': 'unknown',
                            'mac': 'Unknown',
                            'ip': 'None',
                            'speed': 'Unknown'
                        }
                        
                        # Try to get MAC address
                        try:
                            with open(f"/sys/class/net/{iface}/address", 'r') as f:
                                mac = f.read().strip()
                                if mac:
                                    interface['mac'] = mac
                        except Exception:
                            pass
                            
                        # Try to get operational state
                        try:
                            with open(f"/sys/class/net/{iface}/operstate", 'r') as f:
                                interface['state'] = f.read().strip()
                        except Exception:
                            pass
                            
                        interfaces.append(interface)

        return interfaces


    def _format_size(self, size_bytes: int) -> str:
        """Format size in bytes to human readable format."""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size_bytes < 1024:
                return f"{size_bytes:.1f}{unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f}PB"

    def _get_interface_speed(self, interface: str) -> str:
        """Get network interface speed."""
        try:
            with open(f"/sys/class/net/{interface}/speed", 'r') as f:
                speed = int(f.read().strip())
                return f"{speed}Mbps"
        except:
            return "N/A"

    def _validate_apparmor(self) -> bool:
        """Validate if AppArmor is enabled"""
        result = self.run_command(['aa-status'])
        return result['success'] and 'apparmor module is loaded' in result['output']

    def _validate_firewall(self) -> bool:
          """Validate if the firewall is active"""
          status = self.check_firewall_status()
          return status['is_running']
      
    def _validate_ssh_config(self) -> bool:
        """Validate SSH configuration for key parameters."""
        try:
            cmd = self.run_command(['sshd', '-T'])
            if not cmd['success']:
                return False
                
            config = {}
            for line in cmd['output'].splitlines():
                parts = line.strip().split(None, 1)
                if len(parts) == 2:
                    config[parts[0]] = parts[1]
                    
            # Check required settings
            required_settings = {
                "permitrootlogin": ["no", "without-password", "prohibit-password"],  # Accept multiple secure options
                "passwordauthentication": "no",
                "pubkeyauthentication": "yes"
            }
            
            for key, expected_value in required_settings.items():
                if config.get(key) not in expected_value if isinstance(expected_value, list) else config.get(key) != expected_value:
                    logging.warning(f"SSH config validation failed for {key}. Current: {config.get(key)} Expected:{expected_value}")
                    return False
            return True
            
        except Exception as e:
            logging.error(f"Error validating SSH config: {e}")
            return False

    def _validate_updates(self) -> bool:
        """Validate if updates are current"""
        updates = self.check_updates()
        return updates['total'] == 0 and updates['security'] == 0

    def _validate_disk_space(self) -> bool:
        """Validate if disk space is sufficient"""
        disk = psutil.disk_usage('/')
        return disk.percent < 90

    def perform_validation_checks(self) -> Dict[str, bool]:
        """Perform validation checks on system configuration"""
        return {
            'apparmor_enabled': self._validate_apparmor(),
            'firewall_active': self._validate_firewall(),
            'ssh_secure': self._validate_ssh_config(),
            'updates_current': self._validate_updates(),
            'disk_space_sufficient': self._validate_disk_space()
        }
    
    def perform_health_checks(self) -> Dict[str, Any]:
        """Perform comprehensive system health checks"""
        return {
            'apparmor_status': self.check_apparmor_status(),
            'firewall_status': self.check_firewall_status(),
            'service_status': self.check_critical_services(),
            'system_load': self.get_load_average(),
            'update_status': self.check_updates(),
            'disk_health': self.check_disk_health(),
            'network_health': self.check_network_health()
        }
    
    def check_apparmor_status(self) -> str:
        """Check AppArmor status"""
        result = self.run_command(['aa-status'])
        if result['success']:
             return result['output']
        return f"Error checking AppArmor status: {result.get('error', 'Unknown error')}"
    
    def check_firewall_status(self) -> Dict[str, Any]:
        """Enhanced ufw status check with detailed information"""
        status = {
            'is_running': False,
            'is_enabled': False,
            'ssh_allowed': False,
            'zones': [],
            'detailed_status': '',
            'error': None
        }
    
        try:
            # Check if ufw is installed
            result = self.run_command(['dpkg', '-s', 'ufw'])
            if not result['success']:
                 status['error'] = "ufw is not installed"
                 return status
    
            # Check if ufw is running
            run_result = self.run_command(['systemctl', 'is-active', 'ufw'])
            status['is_running'] = run_result['success'] and run_result['output'].strip() == 'active'
            
            # Check if ufw is enabled
            enable_result = self.run_command(['systemctl', 'is-enabled', 'ufw'])
            status['is_enabled'] = enable_result['success'] and enable_result['output'].strip() == 'enabled'

            if status['is_running']:
                # Get detailed status
                detailed = self.run_command(['ufw', 'status', 'verbose'])
                status['detailed_status'] = detailed['output']
    
                 # Check if SSH is allowed
                ssh_check = self.run_command(['ufw', 'status'])
                status['ssh_allowed'] = '22' in ssh_check['output']
    

                # Get zones (not applicable for ufw, setting empty array)
                status['zones'] = []

        except Exception as e:
             status['error'] = str(e)

        return status

    def check_disk_health(self) -> Dict[str, Any]:
        """Check disk health status"""
        result = self.run_command(['df', '-h'])  # Use df instead of smartctl as it doesn't require additional packages
        return {
            'status': result['success'],
            'details': result['output']
        }

    def check_network_health(self) -> Dict[str, Any]:
         """Check network health status"""
         ping_result = self.run_command(['ping', '-c', '4', '8.8.8.8'])
         return {
             'connectivity': ping_result['success'],
             'latency': self._parse_ping_latency(ping_result['output']) if ping_result['success'] else None
         }

    def _parse_ping_latency(self, ping_output: str) -> Optional[float]:
         """Parse ping output to get average latency."""
         try:
              match = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)/[\d.]+/[\d.]+", ping_output)
              if match:
                return float(match.group(1))
              return None
         except Exception as e:
            logging.error(f"Error parsing ping latency: {e}")
            return None
    
    def print_report(self, metrics: SystemMetrics, analysis: Dict[str, Any]) -> None:
        """Print detailed system monitoring report."""
        print(self.format_report(metrics, analysis))
    
    def check_single_points_of_failure(self) -> str:
        """Check if server has single NIC or single disk."""
        results = []
        results.append("\nSINGLE POINT OF FAILURE CHECK")
        results.append("-" * 50)
        
        # Check Network Interfaces
        try:
            # Get only physical NICs (excluding virtual interfaces)
            cmd = self.run_command(['ip', 'link', 'show'])
            if cmd['success']:
                nics = []
                for line in cmd['output'].split('\n'):
                    if ': ' in line and not any(x in line.lower() for x in ['lo:', 'virtual', 'docker', 'veth']):
                        nic_name = line.split(':')[1].strip()
                        nics.append(nic_name)
                
                results.append(f"Network Interfaces Found: {len(nics)}")
                for nic in nics:
                    results.append(f"  - {nic}")
                
                if len(nics) == 1:
                    results.append("\n**WARNING**: System has only one network interface!")
                    results.append("Recommendation: Add a second NIC for network redundancy")
        except Exception as e:
            results.append(f"Error checking NICs: {e}")

        results.append("")  # Empty line for spacing
    
        # Check Physical Disks
        try:
            # Get only physical disks (excluding virtual/loop devices)
            cmd = self.run_command(['lsblk', '-d', '-n', '-o', 'NAME,SIZE,TYPE,MOUNTPOINT'])
            if cmd['success']:
                physical_disks = [line for line in cmd['output'].split('\n') 
                                if line.strip() and 'disk' in line 
                                and not any(x in line for x in ['loop', 'sr'])]
                
                results.append(f"Physical Disks Found: {len(physical_disks)}")
                for disk in physical_disks:
                    results.append(f"  - {disk.strip()}")
                
                if len(physical_disks) == 1:
                    results.append("\n**WARNING**: System has only one physical disk!")
                    results.append("Recommendation: Add additional disk(s) and configure RAID for redundancy")

                # Check root device redundancy
                root_cmd = self.run_command(['df', '-h', '/'])
                if root_cmd['success']:
                    root_device = root_cmd['output'].split('\n')[1].split()[0]
                    if not any(x in root_device for x in ['/dev/md', '/dev/mapper']):
                        results.append("\nWARNING: Root filesystem is not on RAID or LVM!")
                        results.append("Recommendation: Consider migrating root to RAID1 or LVM mirror")
        except Exception as e:
            results.append(f"Error checking disks: {e}")

        return '\n'.join(results)

    def validate_config(self):
        """Validate configuration settings."""
        if not self.config.OLLAMA_BASE_URL:
            raise ValueError("OLLAMA_API_URL environment variable is not set")
            
        # Test Ollama API connection
        try:
            # Check root endpoint instead of /api/status
            response = requests.get(self.config.OLLAMA_BASE_URL)
            logging.info(f"Ollama API Response: Status Code: {response.status_code}, Text: {response.text}")
            if response.status_code != 200 :
                raise ValueError("Ollama service is not responding correctly")
            
        except requests.exceptions.RequestException as e:
            raise ValueError(f"Cannot connect to Ollama API: {e}")
        except Exception as e:
            raise ValueError(f"Error validating Ollama configuration: {e}")
    
    def get_detailed_uptime(self) -> Dict[str, Any]:
        """Get detailed uptime information."""
        uptime_info = {
            'uptime_pretty': '',
            'uptime_seconds': 0,
            'last_boot': '',
            'last_reboot': '',
            'users': 0,
            'load_averages': {}
        }
        
        try:
            # Get uptime in pretty format
            cmd = self.run_command(['uptime', '-p'], capture_all=True)
            if cmd['success']:
                uptime_info['uptime_pretty'] = cmd['output'].strip()

            # Get last boot time
            cmd = self.run_command(['who', '-b'], capture_all=True)
            if cmd['success']:
                uptime_info['last_boot'] = cmd['output'].strip()

            # Get uptime in seconds
            with open('/proc/uptime') as f:
                uptime_seconds = float(f.readline().split()[0])
                uptime_info['uptime_seconds'] = uptime_seconds

            # Get last reboot info
            cmd = self.run_command(['last', 'reboot', '-n', '1'], capture_all=True)
            if cmd['success']:
                uptime_info['last_reboot'] = cmd['output'].splitlines()[0] if cmd['output'] else ''

            # Get number of users
            cmd = self.run_command(['who'], capture_all=True)
            if cmd['success']:
                uptime_info['users'] = len(cmd['output'].splitlines())

            return uptime_info

        except Exception as e:
            logging.error(f"Error getting detailed uptime: {e}")
            return uptime_info

    def format_uptime_section(self) -> str:
        """Format uptime information for the report."""
        uptime_info = self.get_detailed_uptime()
        
        lines = [
            "\nUPTIME INFORMATION",
            "-" * 50,
            f"System Uptime: {uptime_info['uptime_pretty']}",
            f"Last Boot: {uptime_info['last_boot']}",
            f"Last Reboot: {uptime_info['last_reboot']}",
            f"Active Users: {uptime_info['users']}",
            f"Uptime in Seconds: {uptime_info['uptime_seconds']:.0f}"
        ]
        
        return '\n'.join(lines)
    
    def format_banner(self, text: str, width: int = 50) -> str:
        """Create a neat banner for sections."""
        return f"\n{'='*width}\n{text.center(width)}\n{'='*width}\n"
    
    async def monitor(self):
        """Run monitoring once and exit."""
        try:
            # Ensure directories exist
            self.log_dir.mkdir(parents=True, exist_ok=True)
            self.logs_dir.mkdir(parents=True, exist_ok=True)

            print("\n" + "="*50)
            print("Ubuntu Server Monitoring System")
            print("="*50)
            print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"Log Directory: {self.logs_dir}")  # Updated to show full path
            print("="*50 + "\n")
            
            available_models = await self.check_available_models()
            print(f"Available Ollama models: {available_models}\n")

            metrics = self.get_system_metrics()
            analysis = await self.analyze_metrics(metrics)
            health_checks = self.perform_health_checks()
            validation_checks = self.perform_validation_checks()

            # Include health and validation checks in the report
            analysis['health_checks'] = health_checks
            analysis['validation_checks'] = validation_checks
            
            # Generate timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # Save detailed system analysis
            metrics_file = self.logs_dir / f'metrics_{timestamp}.json'
            metrics_file.write_text(json.dumps(analysis, indent=2))

            # Print the report
            self.print_report(metrics, analysis)

            # Save full report
            report_file = self.logs_dir / f'report_{timestamp}.txt'
            report_content = self.format_report(metrics, analysis)
            report_file.write_text(report_content)
            print(f"\nFull Report saved to: {report_file}")

            # Save Ansible playbook
            playbook_file = self.logs_dir / f'tuning_playbook_{timestamp}.yml'
            playbook_file.write_text(analysis['tuning_playbook'])
            print(f"System Tuning Playbook saved to: {playbook_file}")

            # Generate and save Terraform code
            new_instance_type = self._extract_instance_type(analysis['recommendation'])
            if new_instance_type:
                terraform_code = await self.generate_terraform_code(metrics, new_instance_type)
                terraform_file = self.logs_dir / f'terraform_{timestamp}.tf'
                terraform_file.write_text(terraform_code)
                print(f"Terraform code saved to: {terraform_file}\n")

        except Exception as e:
            logging.error(f"Monitoring failed: {e}")
            print(f"\nError: {str(e)}")

    def _extract_instance_type(self, recommendation: str) -> str:
        """Extract recommended instance type from AI analysis."""
        # Look for common instance type patterns
        patterns = [
            r't[0-9][a-z]?\.(nano|micro|small|medium|large|xlarge)',
            r'[cmr][0-9][a-z]?\.(nano|micro|small|medium|large|xlarge)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, recommendation.lower())
            if match:
                return match.group(0)
                
        return "t3.micro"  # Default fallback if no instance type found
    
    async def check_available_models(self) -> List[str]:
        """Check which models are available in Ollama."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self.config.OLLAMA_BASE_URL}/api/tags") as response:
                    if response.status == 200:
                        data = await response.json()
                        return [model['name'] for model in data.get('models', [])]
                    else:
                        logging.error(f"Failed to get models, status: {response.status}")
                        return []
        except Exception as e:
            logging.error(f"Error checking available models: {e}")
            return []
    
    def get_monitoring_commands(self) -> Dict[str, List[str]]:
        """Get list of monitoring commands used for system metrics collection."""
        return {
            'CPU Info': [
                'cat /proc/cpuinfo',
                'mpstat',
                'lscpu'
            ],
            'Memory Info': [
                'free -m',
                'vmstat',
                'cat /proc/meminfo'
            ],
            'Disk Info': [
                'df -h',
                'lsblk --json --output NAME,SIZE,TYPE,MOUNTPOINT',
                'iostat',
                'fdisk -l'
            ],
            'Network Info': [
                'ip -br link show',
                'ip -s link',
                'netstat -i',
                'ss -antp'
            ],
            'Process Info': [
                'top -b -n 1',
                'ps aux',
                'pstree'
            ],
            'System Load': [
                'uptime',
                'w',
                'who'
            ],
            'Service Status': [
                'systemctl status ssh',
                'systemctl status apache2',
                 'systemctl status nginx',
                'systemctl status mysql',
                'systemctl status ufw'
            ],
             'Security Info': [
                'aa-status',
                'ufw status verbose'
            ],
            'System Updates': [
                'apt update -qq',
                'apt list --upgradable'
            ]
        }

    def format_monitoring_commands_section(self) -> str:
        """Format monitoring commands section for the report."""
        commands = self.get_monitoring_commands()
        
        lines = [
            "\n## System Monitoring Commands",
            "The following commands were used to gather system metrics:\n"
        ]
        
        for category, cmd_list in commands.items():
            lines.append(f"### {category}")
            for cmd in cmd_list:
                lines.append(f"```bash\n{cmd}\n```")
            lines.append("")  # Empty line between categories
        
        return '\n'.join(lines)
    

async def main():
    try:
        monitor = UbuntuMonitor()
        await monitor.monitor()
    except Exception as e:
        print(f"Error: {str(e)}")
    finally:
        # Ensure clean exit
        print("\nMonitoring completed.")
        sys.exit(0)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nMonitoring stopped by user.")
        sys.exit(0)