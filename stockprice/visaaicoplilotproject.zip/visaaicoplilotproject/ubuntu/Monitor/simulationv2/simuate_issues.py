#!/usr/bin/env python3
import argparse
import subprocess
import time
import os
import sys
import logging
import psutil
from pathlib import Path

logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class UbuntuResourceStressSimulator:
    def __init__(self):
        self._check_ubuntu_version()
        self.stress_installed = self._check_stress_installed()
        self.total_memory = psutil.virtual_memory().total / (1024 * 1024 * 1024)  # GB
        self.cpu_count = psutil.cpu_count()
        
    def _check_ubuntu_version(self):
        """Verify this is running on Ubuntu 22.04"""
        try:
            with open('/etc/os-release', 'r') as f:
                content = f.read()
                if 'Ubuntu' not in content or '22.04' not in content:
                    logger.warning("This script is optimized for Ubuntu 22.04")
        except Exception as e:
            logger.warning(f"Could not verify Ubuntu version: {e}")

    def _check_stress_installed(self):
        """Check if stress-ng is installed"""
        try:
            subprocess.run(['which', 'stress-ng'], check=True, capture_output=True)
            return True
        except subprocess.CalledProcessError:
            logger.warning("stress-ng not installed. Installing...")
            try:
                subprocess.run(['sudo', 'apt-get', 'update'], check=True)
                subprocess.run(['sudo', 'apt-get', 'install', '-y', 'stress-ng'], check=True)
                return True
            except subprocess.CalledProcessError:
                logger.error("Failed to install stress-ng")
                return False

    def simulate_combined_stress(self, cpu_load=80, memory_percent=80, duration=300):
        """Simulate combined CPU and memory stress"""
        if not self.stress_installed:
            return False
            
        try:
            logger.info(f"Simulating combined CPU ({cpu_load}%) and Memory ({memory_percent}%) "
                       f"stress for {duration} seconds...")
            
            # Calculate CPU workers based on desired load
            cpu_workers = max(1, int((self.cpu_count * cpu_load) / 100))
            
            # Calculate memory to use
            memory_mb = int((self.total_memory * 1024 * memory_percent) / 100)
            
            cmd = [
                'stress-ng',
                '--cpu', str(cpu_workers),
                '--cpu-load', str(cpu_load),
                '--vm', '2',
                '--vm-bytes', f'{memory_mb}M',
                '--timeout', str(duration)
            ]
            
            subprocess.Popen(cmd)
            logger.info(f"Started stress test with {cpu_workers} CPU workers and {memory_mb}MB memory")
            
            # Monitor process stats
            logger.info("Current system stats:")
            self._log_system_stats()
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to simulate combined stress: {e}")
            return False

    def simulate_ubuntu_services(self, service_count=3):
        """Create systemd services that consume CPU and memory"""
        try:
            logger.info(f"Creating {service_count} resource-intensive Ubuntu services...")
            memory_per_service = int((self.total_memory * 1024 * 0.2))  # 20% per service
            
            # Ubuntu-specific service template
            service_template = """[Unit]
Description=Ubuntu Resource Stress Test Service {0}
After=network.target
StartLimitIntervalSec=0

[Service]
Type=simple
User=ubuntu
ExecStart=/usr/bin/stress-ng --cpu 1 --cpu-load 80 --vm 1 --vm-bytes {1}M --vm-keep
Restart=always
RestartSec=3
StandardOutput=append:/var/log/resource-test-{0}.log
StandardError=append:/var/log/resource-test-{0}.log

[Install]
WantedBy=multi-user.target
"""
            
            for i in range(service_count):
                service_content = service_template.format(i, memory_per_service)
                service_file = f'/etc/systemd/system/ubuntu-resource-test-{i}.service'
                
                with open(service_file, 'w') as f:
                    f.write(service_content)

            # Reload systemd and start services
            subprocess.run(['sudo', 'systemctl', 'daemon-reload'], check=True)
            for i in range(service_count):
                subprocess.run(['sudo', 'systemctl', 'start', f'ubuntu-resource-test-{i}'], check=True)
                
            # Log service status
            for i in range(service_count):
                subprocess.run(['systemctl', 'status', f'ubuntu-resource-test-{i}'])

            return True
            
        except Exception as e:
            logger.error(f"Failed to simulate Ubuntu services: {e}")
            return False

    def simulate_ubuntu_processes(self, process_count=5, duration=300):
        """Simulate Ubuntu-specific worker processes"""
        if not self.stress_installed:
            return False
            
        try:
            logger.info(f"Starting {process_count} Ubuntu worker processes...")
            workers = []
            
            # Ubuntu process names to simulate
            process_names = [
                'apache2-worker',
                'nginx-worker',
                'mysql-worker',
                'php-fpm',
                'node-app'
            ]
            
            for i in range(process_count):
                process_name = process_names[i % len(process_names)]
                # Each worker uses different CPU and memory combinations
                cpu_load = 20 + (i * 10)  # 20%, 30%, 40%, etc.
                memory_mb = 100 + (i * 100)  # 100MB, 200MB, 300MB, etc.
                
                cmd = [
                    'stress-ng',
                    '--cpu', '1',
                    '--cpu-load', str(cpu_load),
                    '--vm', '1',
                    '--vm-bytes', f'{memory_mb}M',
                    '--timeout', str(duration),
                    '--proc-name', process_name
                ]
                
                worker = subprocess.Popen(cmd)
                workers.append(worker)
                logger.info(f"Started {process_name} worker with CPU load {cpu_load}% and memory {memory_mb}MB")
                time.sleep(2)  # Stagger worker starts
                
                # Log process info
                self._log_process_info(process_name)
                
            # Wait for workers to finish
            for worker in workers:
                worker.wait()
                
            return True
            
        except Exception as e:
            logger.error(f"Failed to simulate Ubuntu processes: {e}")
            return False

    def simulate_resource_spikes(self, duration=300, interval=60):
        """Simulate alternating CPU and memory spikes with Ubuntu process names"""
        if not self.stress_installed:
            return False
            
        try:
            logger.info(f"Simulating Ubuntu resource spikes for {duration} seconds...")
            end_time = time.time() + duration
            
            while time.time() < end_time:
                # CPU spike with Apache-like process
                logger.info("Starting CPU spike (apache2)...")
                subprocess.Popen(['stress-ng', '--cpu', str(self.cpu_count), 
                                '--timeout', str(interval),
                                '--proc-name', 'apache2-worker'])
                self._log_system_stats()
                time.sleep(interval)
                
                if time.time() >= end_time:
                    break
                    
                # Memory spike with MySQL-like process
                logger.info("Starting memory spike (mysqld)...")
                memory_mb = int(self.total_memory * 1024 * 0.7)  # 70% of total memory
                subprocess.Popen(['stress-ng', '--vm', '2', '--vm-bytes', f'{memory_mb}M', 
                                '--timeout', str(interval),
                                '--proc-name', 'mysqld'])
                self._log_system_stats()
                time.sleep(interval)
                
            return True
            
        except Exception as e:
            logger.error(f"Failed to simulate resource spikes: {e}")
            return False

    def _log_system_stats(self):
        """Log current system resource usage"""
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        swap = psutil.swap_memory()
        
        logger.info(f"CPU Usage: {cpu_percent}%")
        logger.info(f"Memory Usage: {memory.percent}% (Used: {memory.used/1024/1024:.0f}MB)")
        logger.info(f"Swap Usage: {swap.percent}% (Used: {swap.used/1024/1024:.0f}MB)")

    def _log_process_info(self, process_name):
        """Log information about a specific process"""
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
            if process_name in proc.info['name']:
                logger.info(f"Process {process_name} (PID {proc.info['pid']}): "
                          f"CPU: {proc.info['cpu_percent']}%, "
                          f"Memory: {proc.info['memory_percent']:.1f}%")

    def cleanup(self):
        """Clean up all simulated stress"""
        try:
            logger.info("Cleaning up Ubuntu resource stress simulations...")
            
            # Kill stress processes
            subprocess.run(['sudo', 'pkill', 'stress-ng'], check=False)
            
            # Stop and remove test services
            for i in range(5):
                try:
                    subprocess.run(['sudo', 'systemctl', 'stop', f'ubuntu-resource-test-{i}'], check=False)
                    subprocess.run(['sudo', 'rm', f'/etc/systemd/system/ubuntu-resource-test-{i}.service'], check=False)
                    subprocess.run(['sudo', 'rm', f'/var/log/resource-test-{i}.log'], check=False)
                except:
                    pass
                    
            subprocess.run(['sudo', 'systemctl', 'daemon-reload'], check=False)
            
            # Clear page cache
            subprocess.run(['sudo', 'sync'], check=False)
            with open('/proc/sys/vm/drop_caches', 'w') as f:
                f.write('3')
                
            logger.info("Cleanup completed")
            return True
            
        except Exception as e:
            logger.error(f"Failed to clean up: {e}")
            return False

def main():
    parser = argparse.ArgumentParser(
        description='Ubuntu 22.04 Resource Stress Simulator')
    parser.add_argument('--scenario', 
                       choices=['combined', 'spikes', 'services', 'processes'], 
                       default='combined',
                       help='Type of stress scenario to simulate')
    parser.add_argument('--duration', type=int, default=300,
                       help='Duration of simulation in seconds')
    parser.add_argument('--cpu-load', type=int, default=80,
                       help='CPU load percentage for combined stress')
    parser.add_argument('--memory-percent', type=int, default=80,
                       help='Memory usage percentage for combined stress')
    parser.add_argument('--cleanup', action='store_true',
                       help='Clean up after simulation')
    
    args = parser.parse_args()
    
    simulator = UbuntuResourceStressSimulator()
    
    try:
        if args.scenario == 'combined':
            simulator.simulate_combined_stress(args.cpu_load, args.memory_percent, args.duration)
        elif args.scenario == 'spikes':
            simulator.simulate_resource_spikes(args.duration)
        elif args.scenario == 'services':
            simulator.simulate_ubuntu_services()
        elif args.scenario == 'processes':
            simulator.simulate_ubuntu_processes(duration=args.duration)
            
        if args.scenario != 'services':  # Services keep running until cleanup
            time.sleep(args.duration)
            
        if args.cleanup:
            simulator.cleanup()
            
    except KeyboardInterrupt:
        logger.info("Simulation interrupted by user")
        simulator.cleanup()
        sys.exit(0)

if __name__ == "__main__":
    main()