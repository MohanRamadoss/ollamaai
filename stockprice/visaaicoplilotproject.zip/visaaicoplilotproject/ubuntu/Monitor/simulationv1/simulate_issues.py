#!/usr/bin/env python3
import argparse
import subprocess
import time
import os
import sys
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SystemIssueSimulator:
    def __init__(self):
        self.stress_installed = self._check_stress_installed()
        
    def _check_stress_installed(self):
        """Check if stress-ng is installed"""
        try:
            subprocess.run(['which', 'stress-ng'], check=True, capture_output=True)
            return True
        except subprocess.CalledProcessError:
            logger.warning("stress-ng not installed. Installing...")
            try:
                subprocess.run(['sudo', 'apt-get', 'update'], check=True)
                subprocess.run(['sudo', 'apt-get', 'install', '-y', 'stress-ng'], check=True)
                return True
            except subprocess.CalledProcessError:
                logger.error("Failed to install stress-ng")
                return False

    def simulate_high_cpu(self, duration=300):
        """Simulate high CPU usage"""
        if not self.stress_installed:
            return False
            
        try:
            logger.info(f"Simulating high CPU usage for {duration} seconds...")
            subprocess.Popen(['stress-ng', '--cpu', '8', '--timeout', str(duration)])
            return True
        except Exception as e:
            logger.error(f"Failed to simulate CPU load: {e}")
            return False

    def simulate_memory_pressure(self, memory_mb=1000, duration=300):
        """Simulate memory pressure"""
        if not self.stress_installed:
            return False
            
        try:
            logger.info(f"Simulating memory pressure ({memory_mb}MB) for {duration} seconds...")
            subprocess.Popen(['stress-ng', '--vm', '2', '--vm-bytes', f'{memory_mb}M', '--timeout', str(duration)])
            return True
        except Exception as e:
            logger.error(f"Failed to simulate memory pressure: {e}")
            return False

    def simulate_disk_pressure(self, size_gb=1):
        """Simulate disk pressure by creating a large file"""
        try:
            logger.info(f"Simulating disk pressure by creating {size_gb}GB file...")
            subprocess.run(['dd', 'if=/dev/zero', f'of=/tmp/large_file', f'bs={size_gb}G', 'count=1'], check=True)
            return True
        except Exception as e:
            logger.error(f"Failed to simulate disk pressure: {e}")
            return False

    def simulate_network_issues(self):
        """Simulate network issues using tc"""
        try:
            logger.info("Simulating network latency and packet loss...")
            # Add 100ms latency and 10% packet loss
            subprocess.run(['sudo', 'tc', 'qdisc', 'add', 'dev', 'eth0', 'root', 'netem', 'delay', '100ms', 'loss', '10%'], check=True)
            return True
        except Exception as e:
            logger.error(f"Failed to simulate network issues: {e}")
            return False

    def simulate_log_errors(self):
        """Simulate system log errors"""
        try:
            logger.info("Simulating system log errors...")
            error_messages = [
                "Critical error in application startup",
                "Failed to establish database connection",
                "Memory allocation failed",
                "Disk I/O error detected",
                "Network connection timeout"
            ]
            
            for msg in error_messages:
                subprocess.run(['logger', '-p', 'daemon.error', msg], check=True)
            return True
        except Exception as e:
            logger.error(f"Failed to simulate log errors: {e}")
            return False

    def simulate_service_issues(self):
        """Simulate service issues"""
        try:
            logger.info("Simulating service issues...")
            # Stop a non-critical service (if nginx is installed)
            subprocess.run(['sudo', 'systemctl', 'stop', 'nginx'], check=True)
            time.sleep(5)
            return True
        except Exception as e:
            logger.error(f"Failed to simulate service issues: {e}")
            return False

    def simulate_file_system_full(self):
        """Simulate file system getting full"""
        try:
            logger.info("Simulating file system pressure...")
            # Create multiple large files
            for i in range(5):
                subprocess.run(['dd', 'if=/dev/zero', f'of=/tmp/large_file_{i}', 'bs=100M', 'count=1'], check=True)
            return True
        except Exception as e:
            logger.error(f"Failed to simulate file system pressure: {e}")
            return False

    def simulate_security_issues(self):
        """Simulate security issues"""
        try:
            logger.info("Simulating security issues...")
            # Create suspicious files and activities
            suspicious_paths = [
                '/tmp/suspicious_executable',
                '/tmp/.hidden_file',
                '/tmp/unauthorized_ssh_key'
            ]
            
            for path in suspicious_paths:
                Path(path).touch()
                
            # Generate suspicious log entries
            security_messages = [
                "Failed password for root from 192.168.1.100",
                "Invalid user admin from 10.0.0.50",
                "Unknown user attempted sudo access",
                "Multiple authentication failures",
                "Possible brute force attempt detected"
            ]
            
            for msg in security_messages:
                subprocess.run(['logger', '-p', 'auth.warning', msg], check=True)
            return True
        except Exception as e:
            logger.error(f"Failed to simulate security issues: {e}")
            return False

    def cleanup(self):
        """Clean up all simulated issues"""
        try:
            logger.info("Cleaning up simulated issues...")
            # Kill stress processes
            subprocess.run(['pkill', 'stress-ng'], check=False)
            
            # Remove large files
            subprocess.run(['rm', '-f', '/tmp/large_file*'], check=False)
            
            # Remove suspicious files
            subprocess.run(['rm', '-f', '/tmp/suspicious_*', '/tmp/.hidden_*'], check=False)
            
            # Reset network settings
            subprocess.run(['sudo', 'tc', 'qdisc', 'del', 'dev', 'eth0', 'root'], check=False)
            
            # Restart stopped services
            subprocess.run(['sudo', 'systemctl', 'restart', 'nginx'], check=False)
            
            logger.info("Cleanup completed")
            return True
        except Exception as e:
            logger.error(f"Failed to clean up: {e}")
            return False

def main():
    parser = argparse.ArgumentParser(description='Simulate system issues for AI monitoring')
    parser.add_argument('--scenario', choices=['all', 'cpu', 'memory', 'disk', 'network', 'logs', 'service', 'security'], 
                        default='all', help='Type of issue to simulate')
    parser.add_argument('--duration', type=int, default=300, help='Duration of simulation in seconds')
    parser.add_argument('--cleanup', action='store_true', help='Clean up after simulation')
    
    args = parser.parse_args()
    
    simulator = SystemIssueSimulator()
    
    try:
        if args.scenario in ['all', 'cpu']:
            simulator.simulate_high_cpu(args.duration)
            
        if args.scenario in ['all', 'memory']:
            simulator.simulate_memory_pressure(duration=args.duration)
            
        if args.scenario in ['all', 'disk']:
            simulator.simulate_disk_pressure()
            
        if args.scenario in ['all', 'network']:
            simulator.simulate_network_issues()
            
        if args.scenario in ['all', 'logs']:
            simulator.simulate_log_errors()
            
        if args.scenario in ['all', 'service']:
            simulator.simulate_service_issues()
            
        if args.scenario in ['all', 'security']:
            simulator.simulate_security_issues()
            
        if args.scenario == 'all':
            logger.info(f"Running full simulation for {args.duration} seconds...")
            time.sleep(args.duration)
            
        if args.cleanup:
            simulator.cleanup()
            
    except KeyboardInterrupt:
        logger.info("Simulation interrupted by user")
        simulator.cleanup()
        sys.exit(0)

if __name__ == "__main__":
    main()