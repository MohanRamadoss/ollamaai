#!/usr/bin/env python3

"""
╔════════════════════════════════════════════════════════════════════╗
║            Enhanced Ubuntu 22.04 SSHD Security Analyzer            ║
║                                                                    ║
║  Features:                                                         ║
║- Multi-model AI analysis using Ollama models                       ║
║- Asynchronous processing                                           ║
║- Cached command execution                                          ║ 
║- Comprehensive security compliance checks                          ║ 
║- Ansible playbook generation                                       ║
║- Detailed reporting with AI insights                               ║ 
║                                                                    ║
║  Configuration:                                                    ║
║  - Set OLLAMA_API_URL in environment or config.xml                 ║
║  - Configure models and timeouts in config.xml                     ║
║                                                                    ║
║  Usage:                                                            ║
║  python3 sshd_analyzer.py [--config config.xml]                    ║
║                                                                    ║
╚════════════════════════════════════════════════════════════════════╝
"""
import asyncio
import aiohttp
import json
import logging
import os
import subprocess
import shutil
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
from jinja2 import Template
import argparse
from dotenv import load_dotenv
from tenacity import retry, stop_after_attempt, wait_fixed
import xml.etree.ElementTree as ET
from functools import cached_property
load_dotenv()

# Security rules for Ubuntu 22.04
UBUNTU_SECURITY_BASELINE = {
    "PermitRootLogin": "no",
    "PasswordAuthentication": "no",
    "PubkeyAuthentication": "yes",
    "Protocol": "2",
    "X11Forwarding": "no",
    "MaxAuthTries": "3",
    "PermitEmptyPasswords": "no",
    "ClientAliveInterval": "300",
    "ClientAliveCountMax": "2",
    "UsePAM": "yes",
    "AllowAgentForwarding": "no",
    "AllowTcpForwarding": "no",
    "PrintMotd": "no",
    "PrintLastLog": "yes",
    "TCPKeepAlive": "no",
    "Compression": "no",
    "StrictModes": "yes",
    "MaxSessions": "2",
    "LoginGraceTime": "30",
    "KerberosAuthentication": "no",
    "GSSAPIAuthentication": "no",
    "HostbasedAuthentication": "no",
    "IgnoreRhosts": "yes",
    "LogLevel": "VERBOSE",
    "Ciphers": "chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com",
    "MACs": "hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com",
    "KexAlgorithms": "curve25519-sha256@libssh.org,ecdh-sha2-nistp521,ecdh-sha2-nistp384,ecdh-sha2-nistp256"
}

@dataclass
class SSHDConfigData:
    """Enhanced SSHD configuration with additional features from patch script"""
    LOG_DIR: str = str(Path(os.path.dirname(os.path.abspath(__file__))) / "ubuntu_sshd")
    COMMAND_TIMEOUT: int = 300
    API_RETRIES: int = 5
    CACHE_DURATION: int = 3600
    MODEL_CONFIG: Dict[str, Dict] = field(default_factory=dict)
    OLLAMA_BASE_URL: Optional[str] = os.getenv("OLLAMA_API_URL", None)
    OLLAMA_ENDPOINTS: Dict[str, str] = field(default_factory=lambda: {
        "generate": "/api/generate",
        "status": "/api/status",
        "models": "/api/models"
    })
    OLLAMA_HEADERS: Dict[str, str] = field(default_factory=lambda: {
        "Content-Type": "application/json",
        "Accept": "application/json"
    })
    OLLAMA_RETRY_CONFIG: Dict[str, int] = field(default_factory=lambda: {
        "max_attempts": 5,
        "min_delay": 1,
        "max_delay": 10
    })
    OLLAMA_RATE_LIMIT: Dict[str, int] = field(default_factory=lambda: {
        "calls": 10,
        "period": 60
    })
    OLLAMA_TIMEOUT: int = 240
    SYSTEM_CHECKS_TIMEOUT: int = 30
    HEALTH_CHECK_PARALLEL: bool = True

    def __post_init__(self):
        """Initialize model configurations"""
        if not self.OLLAMA_BASE_URL:
            raise ValueError("OLLAMA_BASE_URL is missing or invalid.")
        if not all(self.MODEL_CONFIG.values()):
            raise ValueError("Invalid model configuration, please check your MODEL_CONFIG.")


@dataclass
class SSHDAnalysis:
    """Store SSHD configuration and analysis results"""
    timestamp: str
    config_data: Dict[str, str]
    apparmor_status: str
    ufw_status: str
    permissions: Dict[str, str]
    service_status: str
    security_issues: List[str]
    ubuntu_version: str
    last_updated: str
    total_issues: int
    critical_issues: int
    compliance_score: float
    impact_analysis: Optional[str] = None
    risk_level: Optional[str] = None
    high_priority_issues: Optional[List[str]] = None
    medium_priority_issues: Optional[List[str]] = None
    low_priority_issues: Optional[List[str]] = None
    
    

class SSHDAnalyzer:
    def __init__(
        self,
        config_file: str = "config.xml",
        cache_timeout: int = 3600,
    ):
        """Initialize with enhanced configuration handling"""
        # Load configuration
        self.config = self._load_config_from_xml(config_file)

        # Initialize other components
        self.cache_timeout = cache_timeout
        self.command_cache = {}
        self.config_path = "/etc/ssh/sshd_config"
        self.log_dir = Path(self.config.LOG_DIR)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self._setup_logging()

        # Model configuration
        self.models = self.config.MODEL_CONFIG
        self.ollama_api = f"{self.config.OLLAMA_BASE_URL}/api/generate"

        # Enhanced templates
        self.ansible_task_template = Template("""
        - name: {{ task_description }}
          tags: 
           - "{{ config_key }}"
          lineinfile:
            path: /etc/ssh/sshd_config
            regexp: '^\\s*{{ config_key }}\\s*.*'
            line: '{{ config_key }} {{ config_value }}'
            state: present
          notify: Restart sshd service
        """)
        
    def _load_config_from_xml(self, config_file: str) -> SSHDConfigData:
        """Load configuration from XML file."""
        try:
            tree = ET.parse(config_file)
            root = tree.getroot()

            config_data = {
                "LOG_DIR": str(Path(os.path.dirname(os.path.abspath(__file__))) / "ubuntu_sshd"), # Default Value
                "API_RETRIES": int(root.find("api_retries").text),
                "CACHE_DURATION": int(root.find("cache_timeout").text),
                "OLLAMA_BASE_URL": root.find("ollama_api").text,
            }

            model_config = {}
            for model_type in root.find("models"):
                if model_type.tag not in ["security", "impact", "reasoning", "ansible"]:
                    continue  # Skip if not a model type we are interested in
                model_config[model_type.tag] = {
                        'name': model_type.find("name").text,
                        'temperature': float(model_type.find("temperature").text),
                        'timeout': int(model_type.find("timeout").text),
                }
            config_data["MODEL_CONFIG"] = model_config

            return SSHDConfigData(**config_data)
        except Exception as e:
            logging.error(f"Error loading configuration from {config_file}: {e}")
            raise
        
    def _get_previous_score(self) -> float:
        """
        Get the previous compliance score from the log files
        """
        score = 0.0
        try:
          log_files = sorted(self.log_dir.glob("ubuntu_sshd_audit_*.md"), reverse=True)
          if len(log_files) > 1:
            with open(log_files[1], 'r') as f:
                for line in f:
                  if 'Compliance Score:' in line:
                    score = float(line.split(': ')[1].split('%')[0])
                    break
        except Exception as e:
            self.logger.error(f"Error getting previous score from log {e}")
        return score
    
    def _setup_logging(self):
        """Configure logging."""
        log_file = self.log_dir / "ubuntu_sshd_audit.log"
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
    
    async def __aenter__(self):
        """Async context manager entry."""
        self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc_value, traceback):
        """Async context manager exit."""
        await self.session.close()

    async def _make_api_call(self, prompt_messages: Any, model_type: str) -> str:
        """Enhanced model interaction with better error handling"""
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }

        # Handle different types of prompt inputs
        if isinstance(prompt_messages, list) and len(prompt_messages) > 1:
            # Extract prompt from message list
            prompt = prompt_messages[1].get('content', '') if isinstance(prompt_messages[1], dict) else str(prompt_messages[1])
        elif isinstance(prompt_messages, dict):
            # Extract prompt from dictionary
            prompt = prompt_messages.get('content', str(prompt_messages))
        else:
            # Use prompt as is if it's a string or convert to string
            prompt = str(prompt_messages)

        # Log the formatted prompt for debugging
        logging.debug(f"Formatted prompt for {model_type}: {prompt[:100]}...")

        for attempt in range(self.config.API_RETRIES):
            try:
                timeout = aiohttp.ClientTimeout(total=self.config.MODEL_CONFIG[model_type]['timeout'])
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    request_data = {
                        "model": self.config.MODEL_CONFIG[model_type]['name'],
                        "prompt": prompt,
                        "stream": False,
                        "temperature": self.config.MODEL_CONFIG[model_type]['temperature']
                    }
                    
                    async with session.post(
                        f"{self.config.OLLAMA_BASE_URL}/api/generate",
                        json=request_data,
                        headers=headers
                    ) as response:
                        if response.status == 200:
                            result = await response.json()
                            response_text = result.get('response', '')
                            if response_text:
                                return response_text
                            else:
                                logging.warning(f"Empty response from model on attempt {attempt + 1}")
                        else:
                            error_text = await response.text()
                            logging.error(f"API call failed with status {response.status}: {error_text}")
                        
                if attempt < self.config.API_RETRIES - 1:
                    delay = 2 ** attempt
                    logging.info(f"Retrying in {delay} seconds...")
                    await asyncio.sleep(delay)
                    
            except asyncio.TimeoutError:
                logging.error(f"Timeout on attempt {attempt + 1}")
            except Exception as e:
                logging.error(f"API call error on attempt {attempt + 1}: {str(e)}")
                if attempt == self.config.API_RETRIES - 1:
                    return f"Error calling model: {str(e)}"

        return "Failed to get response after all retries. Using fallback analysis."
    
    @retry(stop=stop_after_attempt(3), wait=wait_fixed(1))
    def run_command(self, command: List[str], capture_all: bool = False) -> Dict[str, Any]:
        """Enhanced command execution with caching and timeout"""
        cmd_str = ' '.join(command)
        if cmd_str in self.command_cache:
            cached_result = self.command_cache[cmd_str]
            if (datetime.now() - cached_result['timestamp']).seconds < self.cache_timeout:
                return cached_result['result']

        try:
            result = subprocess.run(
                command, 
                capture_output=True, 
                text=True, 
                timeout=self.config.COMMAND_TIMEOUT,
                check=True
            )
            output = result.stdout.strip()
            if capture_all:
                result_dict = {'success': True, 'output': output}
            else:
                result_dict = {'success': True, 'output': '\n'.join(output.split('\n')[1:])}

            self.command_cache[cmd_str] = {
                'result': result_dict,
                'timestamp': datetime.now()
            }
            return result_dict

        except subprocess.TimeoutExpired as e:
            self.logger.error(f"Command '{' '.join(command)}' timed out: {e}")
            return {'success': False, 'output': f'Command timed out: {str(e)}'}
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Command '{' '.join(command)}' failed: {e}")
            return {'success': False, 'output': f'Command failed with error: {str(e)}'}
        except Exception as e:
            self.logger.error(f"Command '{' '.join(command)}' failed with error: {e}")
            return {'success': False, 'output': f'Command failed with exception: {str(e)}'}

    def check_ubuntu_version(self) -> str:
        """Verify Ubuntu version"""
        try:
            with open('/etc/lsb-release', 'r') as f:
                return f.read().strip()
        except Exception as e:
            self.logger.error(f"Error checking Ubuntu version: {e}")
            return "Unknown"

    def parse_sshd_config(self) -> Dict[str, str]:
        """Parse the SSHD configuration file."""
        config = {}
        try:
            with open(self.config_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        parts = line.split(None, 1)
                        if len(parts) == 2:
                            key, value = parts
                            config[key] = value.strip()
        except Exception as e:
            self.logger.error(f"Error reading SSHD config: {e}")
        return config
    
    def _parse_ufw_port_status(self,output) -> Dict[str, str]:
         """Parse UFW output to determine SSH port status"""
         status={}
         if output:
             for line in output.splitlines():
                 if "22" in line:
                    parts = line.split()
                    if len(parts) > 2:
                        rule = ' '.join(parts[1:])
                        status = {
                            "port_22": rule
                         }
         return status
    
    def compare_with_baseline(self, config_data: Dict[str, str]) -> List[str]:
        """Compare current configuration with the security baseline."""
        issues = []
        for key, expected_value in UBUNTU_SECURITY_BASELINE.items():
            current_value = config_data.get(key, "Not set")
            if current_value != expected_value:
                issues.append(f"{key} is set to '{current_value}' but should be '{expected_value}'")
        return issues
    
    def check_ufw_status(self) -> Dict[str, Any]:
        """Enhanced UFW status check with detailed information"""
        status = {
            'is_running': False,
            'is_enabled': False,
            'ssh_allowed': False,
             'ssh_port_status': {},
            'rules': [],
            'detailed_status': '',
            'error': None
        }

        try:
            # Check if UFW is installed
            result = self.run_command(['dpkg', '-s', 'ufw'])
            if not result['success']:
                status['error'] = "ufw is not installed"
                return status

            # Check if UFW is enabled
            enable_result = self.run_command(['ufw', 'status', 'verbose'])
            status['is_enabled'] = enable_result['success'] and 'enabled' in enable_result['output']

            # Check if UFW is running
            status['is_running'] = status['is_enabled']

            if status['is_running']:
                # Get detailed status
                detailed = self.run_command(['ufw', 'status', 'numbered'])
                status['detailed_status'] = detailed['output']

                # Check if SSH is allowed
                ssh_check = self.run_command(['ufw', 'status', 'numbered'])
                if ssh_check['success']:
                    status['ssh_allowed'] = any("22" in line for line in ssh_check['output'].splitlines())
                
                 # Add specific SSH port check
                ssh_port_check = self.run_command(['ufw', 'status', 'verbose', '| grep 22'])
                if ssh_port_check['success']:
                    status['ssh_port_status'] = self._parse_ufw_port_status(ssh_port_check['output'])

                # Get rules
                rules_result = self.run_command(['ufw', 'status'])
                if rules_result['success']:
                    status['rules'] = [line.strip() for line in rules_result['output'].split('\n') if line.strip()]
            
        except Exception as e:
            status['error'] = str(e)
        return status

    def check_apparmor_status(self) -> str:
        """Check AppArmor status"""
        result = self.run_command(['apparmor_status'])
        if result['success']:
            return result['output']
        return f"Error checking AppArmor status: {result.get('error', 'Unknown error')}"
        
    
    def check_permissions(self) -> Dict[str, str]:
        """Check SSH directory and key permissions"""
        paths = [
            self.config_path,
            '/etc/ssh/ssh_host_*_key',
            '/etc/ssh/ssh_host_*_key.pub',
            '/etc/ssh',
            '/run/sshd'
        ]
        permissions = {}
        for path in paths:
            try:
                result = subprocess.run(f"ls -l {path}", shell=True, capture_output=True, text=True)
                permissions[path] = result.stdout.strip()
            except Exception as e:
                permissions[path] = f"Error: {str(e)}"
        return permissions

    def check_sshd_service_status(self) -> str:
        """Check SSHD service status"""
        result = self.run_command(['systemctl', 'status', 'ssh'])
        if result['success']:
            return result['output']
        return f"Error checking SSHD service status: {result.get('error', 'Unknown error')}"

    def get_config_last_updated(self) -> str:
        """Get the last updated time of SSHD configuration"""
        result = self.run_command(['stat', '-c', '%y', self.config_path])
        if result['success']:
            return result['output'].strip()
        return "Unknown"

    async def analyze_ssh_security_implications(self, config_data: Dict[str, str]) -> Dict[str, str]:
        """
        Analyze security implications of SSH configuration using Mistral model.
        Returns detailed analysis of risks and impacts.
        """
        # Create a comprehensive prompt for security analysis
        security_prompt = f"""
        Analyze the security implications of the following SSH configuration settings that are missing or incorrectly configured.
        For each setting, explain:
        1. The security risk if this setting is missing or incorrect
        2. Potential attack vectors
        3. Real-world impact scenarios
        4. Business impact
        5. Compliance implications
        
        Current SSH Configuration Issues:
        """
        
        # Compare with baseline and add missing/incorrect settings to prompt
        for key, expected in UBUNTU_SECURITY_BASELINE.items():
            current = config_data.get(key, "Not Set")
            if current != expected:
                security_prompt += f"\n{key}:\n"
                security_prompt += f"- Current Value: {current}\n"
                security_prompt += f"- Required Value: {expected}\n"
                
                # Add context for specific high-risk settings
                if key == "PermitRootLogin" and current != "no":
                    security_prompt += "- Critical Setting: Direct root login risk\n"
                elif key == "PasswordAuthentication" and current != "no":
                    security_prompt += "- Critical Setting: Password-based authentication risk\n"
                elif key == "Protocol" and current != "2":
                    security_prompt += "- Critical Setting: Legacy protocol risk\n"
        
        try:
            # Call Mistral model for analysis
            prompt_messages = [
                {"role": "system", "content": "You are a senior cybersecurity expert specializing in SSH security and compliance."},
                {"role": "user", "content": security_prompt}
            ]
            
            analysis = await self._make_api_call(prompt_messages, 'reasoning')
            
            # If model call fails, provide fallback analysis
            if analysis.startswith('Error') or not analysis:
                return {
                    'impact_analysis': self._generate_fallback_analysis(config_data),
                    'risk_level': 'HIGH' if any(key in ["PermitRootLogin", "PasswordAuthentication", "Protocol"] 
                                              for key in config_data.keys()) else 'MEDIUM'
                }
            
            return {
                'impact_analysis': analysis,
                'risk_level': self._determine_risk_level(config_data)
            }
            
        except Exception as e:
            logging.error(f"Error in security implication analysis: {str(e)}")
            return {
                'impact_analysis': f"Error analyzing security implications: {str(e)}",
                'risk_level': 'UNKNOWN'
            }

    def _generate_fallback_analysis(self, config_data: Dict[str, str]) -> str:
        """Generate basic fallback analysis when AI model is unavailable."""
        analysis = []
        critical_settings = {
            "PermitRootLogin": {
                "risk": "Allows direct root login, bypassing user-level authentication",
                "impact": "Complete system compromise if root password is breached"
            },
            "PasswordAuthentication": {
                "risk": "Enables password-based attacks like brute force",
                "impact": "System vulnerable to automated password guessing attacks"
            },
            "Protocol": {
                "risk": "Legacy SSH protocols have known vulnerabilities",
                "impact": "System vulnerable to man-in-the-middle attacks and exploitation"
            },
            "X11Forwarding": {
                "risk": "Potential X11 session hijacking",
                "impact": "Unauthorized access to graphical applications"
            },
            "MaxAuthTries": {
                "risk": "Unlimited authentication attempts",
                "impact": "Increased vulnerability to brute force attacks"
            }
        }
        
        for setting, details in critical_settings.items():
            if setting in config_data and config_data[setting] != UBUNTU_SECURITY_BASELINE[setting]:
                analysis.append(f"\n### {setting}")
                analysis.append(f"- Risk: {details['risk']}")
                analysis.append(f"- Impact: {details['impact']}")
        
        return "\n".join(analysis) if analysis else "Basic security analysis unavailable."

    def _determine_risk_level(self, config_data: Dict[str, str]) -> str:
        """Determine overall risk level based on configuration."""
        critical_settings = {
            "PermitRootLogin": "no",
            "PasswordAuthentication": "no",
            "Protocol": "2"
        }
        
        high_risk_settings = {
            "MaxAuthTries": "3",
            "PermitEmptyPasswords": "no",
            "X11Forwarding": "no"
        }
        
        # Check for critical risks
        for setting, expected in critical_settings.items():
            if config_data.get(setting) != expected:
                return 'HIGH'
        
        # Check for high risk settings
        for setting, expected in high_risk_settings.items():
            if config_data.get(setting) != expected:
                return 'MEDIUM'
        
        return 'LOW'

    def analyze_sshd_config(self) -> SSHDAnalysis:
        """Analyze the SSHD configuration."""
        config_data = self.parse_sshd_config()
        security_issues = self.compare_with_baseline(config_data)
        
        compliance_metrics = self.calculate_compliance_score(config_data)
        
        high_priority = []
        medium_priority = []
        low_priority = []
        
        if 'non_compliant' in compliance_metrics:
            for issue in compliance_metrics['non_compliant']:
                if issue['priority'] == 'HIGH':
                   high_priority.append(issue['setting'])
                elif issue['priority'] == 'MEDIUM':
                   medium_priority.append(issue['setting'])
                elif issue['priority'] == 'LOW':
                  low_priority.append(issue['setting'])
        

        return SSHDAnalysis(
            timestamp=datetime.now().isoformat(),
            config_data=config_data,
            apparmor_status=self.check_apparmor_status(),
            ufw_status=self.check_ufw_status(),
            permissions=self.check_permissions(),
            service_status=self.check_sshd_service_status(),
            security_issues=security_issues,
            ubuntu_version=self.check_ubuntu_version(),
            last_updated=self.get_config_last_updated(),
            total_issues=len(security_issues),
            critical_issues=sum(1 for issue in security_issues if 'Critical' in issue),
            compliance_score= ((len(UBUNTU_SECURITY_BASELINE) - len(security_issues)) 
                            / len(UBUNTU_SECURITY_BASELINE)) * 100,
            impact_analysis=None,
            risk_level=None,
            high_priority_issues=high_priority,
            medium_priority_issues=medium_priority,
            low_priority_issues = low_priority
        )
    
    async def create_security_prompt(self, config: SSHDAnalysis) -> str:
        """Create security analysis prompt."""
        return f"""
As a cybersecurity expert, analyze this Ubuntu 22.04 SSHD configuration and provide a detailed security assessment:

Current Configuration:
{json.dumps(config.config_data, indent=2)}

Security Issues Found:
{json.dumps(config.security_issues, indent=2)}

AppArmor Status:
{config.apparmor_status}

UFW Status:
{json.dumps(config.ufw_status, indent=2)}

File Permissions:
{json.dumps(config.permissions, indent=2)}

Provide a detailed analysis including:
1. Critical security vulnerabilities
2. Configuration weaknesses
3. Ubuntu 22.04-specific security concerns
4. Detailed hardening recommendations
5. Compliance status with security standards
"""
    
    async def create_impact_prompt(self, config: SSHDAnalysis) -> str:
        """Create impact analysis prompt."""
        return f"""
As an expert in system administration, analyze the potential impact of remediating the following SSHD configuration issues on an Ubuntu 22.04 System. 

Current Security Issues:
{json.dumps(config.security_issues, indent=2)}

Required Changes:
{json.dumps(UBUNTU_SECURITY_BASELINE, indent=2)}

Provide a detailed analysis of:
1. Service impact assessment
2. User access implications
3. System performance effects
4. Potential disruptions
5. Recommended implementation strategy
6. Risk mitigation steps
"""

    async def create_ansible_prompt(self, config: SSHDAnalysis) -> str:
        """Create Ansible playbook generation prompt."""
        return f"""
You are an expert Ansible playbook developer. Create an Ansible playbook to remediate the following SSHD configuration issues on Ubuntu 22.04:

Current Configuration:
{json.dumps(config.config_data, indent=2)}

Security Issues:
{json.dumps(config.security_issues, indent=2)}

Required Security Settings:
{json.dumps(UBUNTU_SECURITY_BASELINE, indent=2)}

Create a complete Ansible playbook that:
1. Backs up the current configuration
2. Implements all required security settings
3. Handles errors and rollbacks
4. Includes proper handlers for service restart
5. Uses tags for selective execution
6. Verifies changes after implementation
"""
    
    async def generate_playbook_tasks(self, config: SSHDAnalysis) -> str:
        """Generate Ansible tasks based on security issues."""
        try:
            tasks = []
            
            # Pre-check task
            tasks.append("""
    - name: Pre-check SSHD Configuration
      block:
        - name: Get current config
          command: cat /etc/ssh/sshd_config
          register: current_config
          changed_when: false
          check_mode: no
          
        - name: Create backup directory
          file:
            path: "/var/backup/sshd_{{ ansible_date_time.date }}"
            state: directory
            mode: '0700'
            
        - name: Backup current configuration
          copy:
            src: /etc/ssh/sshd_config
            dest: "/var/backup/sshd_{{ ansible_date_time.date }}/sshd_config.bak"
            remote_src: yes
            mode: '0600'
""")

            # Generate tasks for each security issue
            for key, expected_value in UBUNTU_SECURITY_BASELINE.items():
                current_value = config.config_data.get(key, "Not set")
                if current_value != expected_value:
                    task = self.ansible_task_template.render(
                        task_description=f"Set {key} to {expected_value}",
                        config_key=key,
                        config_value=expected_value
                    )
                    tasks.append(task)

            # Post-check tasks
            tasks.append("""
    - name: Verify SSHD Configuration
      block:
        - name: Verify config syntax
          command: sshd -t
          changed_when: false
          check_mode: no

        - name: Get final config
          command: cat /etc/ssh/sshd_config
          register: final_config
          changed_when: false
          check_mode: no

      rescue:
        - name: Restore backup on failure
          copy:
            src: "/var/backup/sshd_{{ ansible_date_time.date }}/sshd_config.bak"
            dest: /etc/ssh/sshd_config
            remote_src: yes
            mode: '0600'
          notify: Restart sshd service

        - name: Fail with error
          fail:
            msg: "SSHD configuration verification failed. Configuration restored from backup."
""")

            return "\n".join(tasks)
            
        except Exception as e:
            self.logger.error(f"Error generating playbook tasks: {str(e)}")
            # Return basic task structure on error
            return """
    - name: Configure SSHD (Fallback)
      lineinfile:
        path: /etc/ssh/sshd_config
        regexp: '^#?{{ item.key }}'
        line: '{{ item.key }} {{ item.value }}'
        state: present
      loop: "{{ sshd_settings | dict2items }}"
      notify: Restart sshd service
      vars:
        sshd_settings:
          PermitRootLogin: "no"
          PasswordAuthentication: "no"
          PubkeyAuthentication: "yes"
"""
    
    async def generate_additional_playbook(self, config: SSHDAnalysis) -> str:
        """Generate additional Ansible playbook for advanced configurations."""
        playbook = """---
# Additional SSHD Security Configurations
- name: Additional SSHD Security Configurations
  hosts: all
  become: true
  gather_facts: yes

  tasks:
    - name: Create SSHD backup directory
      file:
        path: /var/backups/sshd
        state: directory
        mode: '0700'
        owner: root
        group: root

    - name: Backup current SSHD configuration
      copy:
        src: /etc/ssh/sshd_config
        dest: "/var/backups/sshd/sshd_config.{{ ansible_date_time.iso8601 }}"
        remote_src: yes

    - name: Configure SSHD logging
      lineinfile:
        path: /etc/ssh/sshd_config
        line: "LogLevel VERBOSE"
        regexp: '^LogLevel'

    - name: Configure maximum authentication attempts
      lineinfile:
        path: /etc/ssh/sshd_config
        line: "MaxAuthTries 3"
        regexp: '^MaxAuthTries'

    - name: Configure client alive interval
      lineinfile:
        path: /etc/ssh/sshd_config
        line: "ClientAliveInterval 300"
        regexp: '^ClientAliveInterval'

    - name: Configure allowed users (if defined)
      lineinfile:
        path: /etc/ssh/sshd_config
        line: "AllowUsers {{ item }}"
        regexp: '^AllowUsers'
      with_items: "{{ allowed_users | default([]) }}"
      when: allowed_users is defined

    - name: Verify configuration and restart service
      block:
        - name: Test SSHD configuration
          command: sshd -t
          changed_when: false

        - name: Restart SSHD service
          service:
            name: ssh
            state: restarted

      rescue:
        - name: Restore backup on failure
          copy:
            src: "/var/backups/sshd/sshd_config.{{ ansible_date_time.iso8601 }}"
            dest: /etc/ssh/sshd_config
            remote_src: yes

        - name: Restart SSHD service with original config
          service:
            name: ssh
            state: restarted

        - name: Fail with error message
          fail:
            msg: "SSHD configuration test failed. Configuration has been restored to previous state."
"""
        return playbook
    
    def _write_ufw_section(self, f, ufw_status: Dict[str, Any]) -> None:
        """Write firewall status section to the report file."""
        f.write("## UFW Status\n")
        
        if ufw_status.get('error'):
            f.write(f"Error checking UFW: {ufw_status['error']}\n\n")
            return
            
        f.write(f"- Service Status: {'Running' if ufw_status['is_running'] else 'Not Running'}\n")
        f.write(f"- Service Enabled: {'Yes' if ufw_status['is_enabled'] else 'No'}\n")
        f.write(f"- SSH Service Allowed: {'Yes' if ufw_status['ssh_allowed'] else 'No'}\n")
         
        if ufw_status.get('ssh_port_status'):
            f.write(f"- SSH Port Status: {ufw_status['ssh_port_status']}\n")
            
        if ufw_status['rules']:
            f.write("\n### Firewall Rules\n")
            for rule in ufw_status['rules']:
                f.write(f"- {rule}\n")
            
        if ufw_status['detailed_status']:
            f.write("\n### Detailed Firewall Configuration\n")
            f.write("```\n")
            f.write(ufw_status['detailed_status'])
            f.write("\n```\n")
        f.write("\n")
    
    def calculate_compliance_score(self, config_data: Dict[str, str]) -> Dict[str, Any]:
        """Calculate detailed compliance metrics."""
        compliance_metrics = {
            'overall_score': 0.0,
            'critical_score': 0.0,
            'security_score': 0.0,
            'details': {
                'Critical Security Settings': [],
                'General Security Settings': [],
                'Best Practice Settings': []
            },
            'non_compliant': []
        }
        
        # Define critical settings
        critical_settings = {
            'PermitRootLogin': 'no',
            'PasswordAuthentication': 'no',
            'Protocol': '2'
        }
        
        # Define security settings
        security_settings = {
            'MaxAuthTries': '3',
            'PermitEmptyPasswords': 'no',
            'X11Forwarding': 'no',
            'UsePAM': 'yes'
        }
        
        # Rest are considered best practice settings
        best_practice_settings = {k: v for k, v in UBUNTU_SECURITY_BASELINE.items() 
                                if k not in critical_settings and k not in security_settings}
        
        def check_settings(settings: Dict[str, str], category: str, priority: str):
            compliant = 0
            total = len(settings)
            
            for key, expected in settings.items():
                current = config_data.get(key, 'Not Set')
                is_compliant = current == expected
                
                compliance_metrics['details'][category].append({
                    'name': key,
                    'compliant': is_compliant,
                    'current': current,
                    'required': expected
                })
                
                if not is_compliant:
                    impact = "High impact on security" if category == 'Critical Security Settings' else \
                            "Medium impact on security" if category == 'General Security Settings' else \
                            "Low impact on security"
                            
                    compliance_metrics['non_compliant'].append({
                        'setting': key,
                        'current': current,
                        'required': expected,
                        'priority': priority,
                        'impact': impact
                    })
                
                if is_compliant:
                    compliant += 1
                    
            return (compliant / total * 100) if total > 0 else 100
        
        # Calculate scores for each category
        compliance_metrics['critical_score'] = check_settings(
            critical_settings, 'Critical Security Settings', 'HIGH'
        )
        security_score = check_settings(
            security_settings, 'General Security Settings', 'MEDIUM'
        )
        best_practice_score = check_settings(
            best_practice_settings, 'Best Practice Settings', 'LOW'
        )
        
        # Calculate weighted overall score
        compliance_metrics['overall_score'] = (
            compliance_metrics['critical_score'] * 0.5 +
            security_score * 0.3 +
            best_practice_score * 0.2
        )
        
        compliance_metrics['security_score'] = security_score
        
        return compliance_metrics

    def _write_compliance_section(self, f, compliance_metrics: Dict[str, Any]) -> None:
        """Write compliance metrics section to the report file."""
        f.write("## Compliance Metrics\n")
        f.write(f"- Overall Compliance Score: {compliance_metrics['overall_score']:.2f}%\n")
        f.write(f"- Critical Settings Compliance: {compliance_metrics['critical_score']:.2f}%\n")
        f.write(f"- Security Settings Compliance: {compliance_metrics['security_score']:.2f}%\n")
        f.write("\n### Compliance Details\n")
        
        for category, settings in compliance_metrics['details'].items():
            f.write(f"\n#### {category}\n")
            for setting in settings:
                f.write(f"- {setting['name']}: {'Compliant' if setting['compliant'] else 'Non-Compliant'}\n")
                if not setting['compliant']:
                    f.write(f"  - Current: {setting['current']}\n")
                    f.write(f"  - Required: {setting['required']}\n")
        f.write("\n")
    
    def _write_prioritized_fixes(self, f, compliance_metrics: Dict[str, Any]) -> None:
        """Write prioritized fixes section to the report file."""
        f.write("## Prioritized Fixes\n")
        
        if 'non_compliant' not in compliance_metrics:
            return
            
        priorities = {
            'HIGH': [],
            'MEDIUM': [],
            'LOW': []
        }
        
        for item in compliance_metrics['non_compliant']:
            priorities[item['priority']].append(item)
        
        for priority in ['HIGH', 'MEDIUM', 'LOW']:
            if priorities[priority]:
                f.write(f"\n### {priority} Priority Fixes\n")
                for item in priorities[priority]:
                    f.write(f"- {item['setting']}\n")
                    f.write(f"  - Current Value: {item['current']}\n")
                    f.write(f"  - Required Value: {item['required']}\n")
                    f.write(f"  - Impact: {item['impact']}\n")
        f.write("\n")

    def perform_validation_checks(self) -> Dict[str, Any]:
        """Perform validation checks on SSHD configuration with improved error handling."""
        validation_results = {
            'syntax_valid': False,
            'permissions': {},
            'recommendations': [],
            'errors': []
        }
        
        try:
            # Check SSHD config syntax
            result = self.run_command(['sshd', '-t'])
            validation_results['syntax_valid'] = result['success']
            if not result['success']:
                validation_results['syntax_error'] = result['output']
                validation_results['recommendations'].append(
                    "Fix SSHD configuration syntax errors before applying changes"
                )
        
            # Check file permissions
            files_to_check = [
                ('/etc/ssh/sshd_config', '600'),
                ('/etc/ssh/ssh_host_*_key', '600'),
                ('/etc/ssh/ssh_host_*_key.pub', '644')
            ]
        
            for file_pattern, expected_perm in files_to_check:
                try:
                    # Use find to locate files and get their permissions
                    cmd = f"find /etc/ssh -name '{file_pattern.split('/')[-1]}' -exec stat -c '%n %a' {{}} \\;"
                    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                    
                    if result.returncode == 0 and result.stdout.strip():
                        for line in result.stdout.strip().split('\n'):
                            try:
                                # Use maxsplit=1 to handle filenames containing spaces
                                parts = line.rsplit(' ', maxsplit=1)
                                if len(parts) == 2:
                                    filepath, current_perm = parts
                                    validation_results['permissions'][filepath] = {
                                        'current': current_perm,
                                        'expected': expected_perm,
                                        'status': 'Valid' if current_perm == expected_perm else f'Invalid (should be {expected_perm})'
                                    }
                                    
                                    if current_perm != expected_perm:
                                        validation_results['recommendations'].append(
                                            f"Change permissions for {filepath} from {current_perm} to {expected_perm}"
                                        )
                                else:
                                    validation_results['errors'].append(
                                        f"Invalid permission format for {line}"
                                    )
                            except Exception as e:
                                validation_results['errors'].append(
                                    f"Error processing file permissions for {line}: {str(e)}"
                                )
                    else:
                        validation_results['errors'].append(
                            f"No matching files found for pattern {file_pattern}"
                        )
                        
                except Exception as e:
                    validation_results['errors'].append(
                        f"Error checking permissions for {file_pattern}: {str(e)}"
                    )
            
            # Additional checks for SSH directory permissions
            ssh_dir_check = self.run_command(['stat', '-c', '%a', '/etc/ssh'])
            if ssh_dir_check['success']:
                dir_perm = ssh_dir_check['output'].strip()
                if dir_perm != '755':
                    validation_results['permissions']['/etc/ssh'] = {
                        'current': dir_perm,
                        'expected': '755',
                        'status': 'Invalid (should be 755)'
                    }
                    validation_results['recommendations'].append(
                        "Set /etc/ssh directory permissions to 755"
                    )
        
            # Check SSH service status
            service_check = self.run_command(['systemctl', 'is-active', 'ssh'])
            if not service_check['success'] or service_check['output'].strip() != 'active':
                validation_results['recommendations'].append(
                    "SSH service is not running. Start it with: sudo systemctl start ssh"
                )
        
            # Check if there are any invalid permissions
            invalid_perms = [
                f for f, status in validation_results['permissions'].items() 
                if status['status'].startswith('Invalid')
            ]
            
            if invalid_perms:
                validation_results['recommendations'].append(
                    "Run the following commands to fix permissions:\n" +
                    "\n".join([f"chmod {validation_results['permissions'][f]['expected']} {f}" 
                            for f in invalid_perms])
                )
                
        except Exception as e:
            validation_results['errors'].append(f"Validation check error: {str(e)}")
            self.logger.error(f"Error in validation checks: {e}")
                
        return validation_results

    def _write_validation_section(self, f, validation_results: Dict[str, Any]) -> None:
        """Write validation results section to the report file with improved formatting."""
        f.write("## Configuration Validation\n\n")
        
        if validation_results.get('errors'):
            f.write("### Validation Errors\n")
            for error in validation_results['errors']:
                f.write(f"- {error}\n")
            f.write("\n")
            
        f.write("### Syntax Check\n")
        f.write(f"- Status: {'Pass' if validation_results['syntax_valid'] else 'Fail'}\n")
        if validation_results.get('syntax_error'):
            f.write(f"- Error: {validation_results['syntax_error']}\n")
        f.write("\n")
        
        if validation_results['permissions']:
            f.write("### Permission Check\n")
            for file_path, perm_info in validation_results['permissions'].items():
                f.write(f"#### {file_path}\n")
                f.write(f"- Current: {perm_info['current']}\n")
                f.write(f"- Expected: {perm_info['expected']}\n")
                f.write(f"- Status: {perm_info['status']}\n")
            f.write("\n")
        
        if validation_results.get('recommendations'):
            f.write("### Recommendations\n")
            for i, rec in enumerate(validation_results['recommendations'], 1):
                f.write(f"{i}. {rec}\n")
            f.write("\n")
    
    def backup_config(self) -> None:
        """Backup current SSHD config"""
        backup_path = self.config_path + f".backup_{int(time.time())}"
        shutil.copy2(self.config_path, backup_path)
        os.chmod(backup_path, 0o600)
    
    def validate_config(self, config_data: Dict[str, str]) -> bool:
        """Validate required settings"""
        required_settings = {'PermitRootLogin', 'PasswordAuthentication', 'Protocol'}
        return all(key in config_data for key in required_settings)
    
    async def run_parallel_checks(self) -> Dict[str, Any]:
        """Run checks in parallel"""
        tasks = [
            asyncio.to_thread(self.check_ufw_status),
            asyncio.to_thread(self.check_apparmor_status),
            asyncio.to_thread(self.check_permissions)
        ]
        results = await asyncio.gather(*tasks)
        return dict(zip(['ufw', 'apparmor', 'permissions'], results))

    def _write_ai_banner(self, f) -> None:
        """Write ASCII banner to indicate start of AI analysis section."""
        f.write("""
╔════════════════════════════════════════════════════════════════════╗
║                         AI ANALYSIS SECTION                        ║
║                                                                    ║
║  The following analysis is generated using AI models to provide:   ║
║  • Comprehensive security assessment                               ║
║  • Impact analysis                                                 ║
║  • Risk evaluation                                                 ║
║  • Compliance recommendations                                      ║
║                                                                    ║
╚════════════════════════════════════════════════════════════════════╝
\n""")

    async def generate_report(self) -> None:
        """Generate comprehensive security audit report."""
        try:
            config = self.analyze_sshd_config()
            
            # Get security implications
            security_implications = await self.analyze_ssh_security_implications(config.config_data)
            config.impact_analysis = security_implications['impact_analysis']
            config.risk_level = security_implications['risk_level']
            
            # Run checks in parallel
            results = await self.run_parallel_checks()
            config.ufw_status = results['ufw']
            config.apparmor_status = results['apparmor']
            config.permissions = results['permissions']

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report_file = self.log_dir / f"ubuntu_sshd_audit_{timestamp}.md"
            playbook_file = self.log_dir / "sshfixplaybook.yaml"
            additional_playbook_file = self.log_dir / "sshfixadditionalplaybook.yaml"

            # Write main report file
            with open(report_file, 'w') as f:
                # System Information Section
                f.write("# Ubuntu SSHD Security Audit Report\n")
                f.write(f"Generated: {datetime.now().isoformat()}\n\n")
                
                f.write("## System Information\n")
                f.write(f"- Ubuntu Version: {config.ubuntu_version}\n")
                f.write(f"- SSHD Config Last Updated: {config.last_updated}\n")
                f.write(f"- Total Issues Found: {config.total_issues}\n")
                f.write(f"- Critical Issues: {config.critical_issues}\n")
                f.write(f"- Compliance Score: {config.compliance_score:.2f}%\n")
                
                security_trend = self.calculate_security_trend(config)
                f.write(f"- Security Score Trend: Current Score is {security_trend['current_score']:.2f}%, " + 
                       f"which is {security_trend['trend']} compared to previous score of {security_trend['previous_score']:.2f}%\n")
                f.write(f"- Risk Level: {config.risk_level}\n\n")
                
                # System Status Section
                f.write("## System Status\n")
                f.write("### AppArmor Status\n```\n{}\n```\n\n".format(config.apparmor_status))
                self._write_ufw_section(f, config.ufw_status)
                
                # Write AI Analysis Banner
                self._write_ai_banner(f)
                
                # AI Analysis Sections
                f.write("## Security Analysis\n")
                f.write(f"{await self._make_api_call(await self.create_security_prompt(config), 'security')}\n\n")
                
                f.write("## Impact Analysis\n")
                f.write(f"{config.impact_analysis}\n\n")
                
                # Compliance and Fixes Section
                compliance_metrics = self.calculate_compliance_score(config.config_data)
                self._write_compliance_section(f, compliance_metrics)
                self._write_prioritized_fixes(f, compliance_metrics)
                
                # Configuration Validation
                validation_results = self.perform_validation_checks()
                self._write_validation_section(f, validation_results)
                
                # Remediation Section
                remediation_timeline = self.generate_remediation_timeline(config)
                f.write("## Remediation Timeline\n")
                for item in remediation_timeline:
                    f.write(f"- {item['priority']} Priority: {item['timeframe']}. Issues: {', '.join(item['issues'])}\n")

                # Write playbooks
                ansible_content = await self._make_api_call(await self.create_ansible_prompt(config), 'ansible')
                with open(playbook_file, 'w') as pb:
                    pb.write(ansible_content)
                
                additional_playbook = await self.generate_additional_playbook(config)
                with open(additional_playbook_file, 'w') as apb:
                    apb.write(additional_playbook)

                f.write("\n## Remediation Playbooks\n")
                f.write(f"Main playbook: {playbook_file}\n")
                f.write(f"Additional playbook: {additional_playbook_file}\n")
                
            self.logger.info(f"Audit complete! Report generated: {report_file}")
            print(f"\nAudit complete! Report generated: {report_file}")

        except Exception as e:
            self.logger.error(f"Error generating report: {e}")
            print(f"\nError: {e}")
    
    def _write_report_sections(self, f, config: SSHDAnalysis, results: Dict[str, str], playbook_file: Path) -> None:
        """Write all report sections."""
        # Write header and system information
        f.write("# Ubuntu SSHD Security Audit Report\n")
        f.write(f"Generated: {datetime.now().isoformat()}\n\n")
        f.write("## System Information\n")
        f.write(f"- Ubuntu Version: {config.ubuntu_version}\n")
        f.write(f"- SSHD Config Last Updated: {config.last_updated}\n")
        f.write(f"- Total Issues Found: {config.total_issues}\n")
        f.write(f"- Critical Issues: {config.critical_issues}\n")
        f.write(f"- Compliance Score: {config.compliance_score:.2f}%\n")
        f.write(f"- Risk Level: {config.risk_level}\n\n")

        # Write status sections
        f.write("## AppArmor Status\n")
        f.write(f"```\n{config.apparmor_status}\n```\n\n")
        
        # Enhanced UFW status
        ufw_status = self.check_ufw_status()
        self._write_ufw_section(f, ufw_status)
        
        # Write permissions
        f.write("## Permissions\n")
        for path, perm in config.permissions.items():
            f.write(f"### {path}\n```\n{perm}\n```\n\n")

        # Write analysis results
        f.write("## Security Analysis\n")
        f.write(f"{results['security']}\n\n")
        f.write("## Impact Analysis\n")
        f.write(f"{config.impact_analysis}\n\n")
        f.write("## Ansible Playbook\n")
        f.write(f"The Ansible playbook has been generated and saved to {playbook_file}\n")
        f.write("## Additional Ansible Playbook\n")
        f.write(f"The additional Ansible playbook has been generated and saved to {additional_playbook_file}\n")

    def calculate_security_trend(self, current_config: SSHDAnalysis) -> Dict[str, float]:
        """Calculates current vs previous security score"""
        return {
            'current_score': current_config.compliance_score,
            'previous_score': self._get_previous_score(),
            'trend': 'improving' if current_config.compliance_score > self._get_previous_score() else 'declining'
        }

    def generate_remediation_timeline(self, config: SSHDAnalysis) -> List[Dict[str, Any]]:
        """Generate a timeline for remediation"""
        return [
            {'priority': 'HIGH', 'timeframe': '24 hours', 'issues': config.high_priority_issues if config.high_priority_issues else []},
            {'priority': 'MEDIUM', 'timeframe': '72 hours', 'issues': config.medium_priority_issues if config.medium_priority_issues else []},
            {'priority': 'LOW', 'timeframe': '7 days', 'issues': config.low_priority_issues if config.low_priority_issues else []}
        ]
    
    async def run(self):
        """Run the SSHD analyzer."""
        if os.geteuid() != 0:
            print("This script requires root privileges.")
            return
        try:
            await self.generate_report()
        except Exception as e:
            print(f"\nError: {e}")
            self.logger.error(f"Error in SSHDAnalyzer: {e}")

async def main():
    """Main function."""
    parser = argparse.ArgumentParser(description='Enhanced Ubuntu SSHD Security Analyzer')
    parser.add_argument('--config', type=str, default='config.xml',
                       help='Path to configuration file')
    args = parser.parse_args()

    print("\n=== Enhanced Ubuntu SSHD Security Analyzer ===")
    
    # Initialize analyzer with configuration
    analyzer = SSHDAnalyzer(config_file=args.config)
    
    try:
        # Run analysis with enhanced features
        async with analyzer:
            await analyzer.run()
    except KeyboardInterrupt:
        print("\nAnalysis interrupted by user")
    except Exception as e:
        print(f"\nError: {e}")
        logging.error(f"Main execution error: {e}")

if __name__ == "__main__":
    asyncio.run(main())