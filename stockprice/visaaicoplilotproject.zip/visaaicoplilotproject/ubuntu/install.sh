#!/bin/bash

# Update package lists
sudo apt-get update

# Install system packages
sudo apt-get install -y \
    python3-pip \
    python3-venv \
    python3-dev \
    gcc \
    python3-psutil

# Create virtual environment
python3 -m venv monitoring_env

# Activate virtual environment
source monitoring_env/bin/activate

# Update pip and install packages
pip install --upgrade pip
pip install \
    aiohttp \
    jinja2 \
    python-dotenv \
    tenacity \
    psutil \
    requests \
    aiohttp \
    asyncio \
    tqdm \
    PyYAML 

# Verify installations
python3 --version
pip --version

export OLLAMA_API_URL="http://209.137.198.212:11434"