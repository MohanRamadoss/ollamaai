#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Print functions
echo_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
echo_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
echo_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check root privileges
if [ "$EUID" -ne 0 ]; then
    echo_error "Please run as root"
    exit 1
fi

# Update package list
echo_info "Updating package list..."
apt update

# Install Apache2
echo_info "Installing Apache2 and related packages..."
apt install -y apache2 apache2-utils ssl-cert

# Backup original configuration
echo_info "Backing up original configuration..."
cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.backup
cp /etc/apache2/ports.conf /etc/apache2/ports.conf.backup

# Create test directories and files
echo_info "Creating test directories and files..."
mkdir -p /var/www/test-site
mkdir -p /var/www/virtual-host1
mkdir -p /var/www/virtual-host2

# Create test HTML files
cat > /var/www/test-site/index.html << EOF
<!DOCTYPE html>
<html>
<head><title>Test Site</title></head>
<body><h1>Test Site</h1></body>
</html>
EOF

# Modify main Apache configuration with intentional errors
echo_info "Creating problematic main configuration..."
cat >> /etc/apache2/apache2.conf << EOF

# Invalid configuration directives to generate errors
MaxRequestWorkers invalid
ThreadsPerChild none
InvalidDirective On

# Problematic module configuration
LoadModule nonexistent_module /usr/lib/apache2/modules/mod_nonexistent.so
EOF

# Create problematic virtual host configurations
echo_info "Creating virtual host configurations with intentional errors..."

# Create first virtual host with errors
cat > /etc/apache2/sites-available/test1.conf << EOF
<VirtualHost *:80>
    ServerName test1.local
    DocumentRoot /var/www/nonexistent
    ErrorLog \${APACHE_LOG_DIR}/test1-error.log
    CustomLog \${APACHE_LOG_DIR}/test1-access.log combined
    
    <Directory /var/www/nonexistent>
        Options FollowSymLinks
        AllowOverride None
        Require all granted
    </Directory>
</VirtualHost>
EOF

# Create second virtual host with SSL errors
cat > /etc/apache2/sites-available/test2.conf << EOF
<VirtualHost *:443>
    ServerName test2.local
    DocumentRoot /var/www/virtual-host2
    ErrorLog \${APACHE_LOG_DIR}/test2-error.log
    CustomLog \${APACHE_LOG_DIR}/test2-access.log combined
    
    # Invalid SSL configuration
    SSLEngine on
    SSLCertificateFile /path/to/nonexistent/cert.pem
    SSLCertificateKeyFile /path/to/nonexistent/key.pem
    
    <Directory /var/www/virtual-host2>
        Options Indexes FollowSymLinks
        AllowOverride All
        # Intentionally incorrect syntax
        Order allow,deny
        Allow from
        Require all granted
    </Directory>
</VirtualHost>
EOF

# Create problematic .htaccess file
cat > /var/www/test-site/.htaccess << EOF
# Invalid rewrite rules
RewriteEngine On
RewriteRule ^index\.html$ - [L]]  # Intentional syntax error

# Invalid authentication configuration
AuthType Basic
AuthName "Restricted Area"
# Missing AuthUserFile directive intentionally
Require valid-user
EOF

# Enable modules and sites
echo_info "Enabling modules and sites..."
a2enmod ssl
a2enmod rewrite
a2ensite test1.conf
a2ensite test2.conf

# Set permissions
echo_info "Setting file permissions..."
chown -R www-data:www-data /var/www/
chmod -R 755 /var/www/

# Modify ports configuration with errors
echo_info "Modifying ports configuration..."
cat > /etc/apache2/ports.conf << EOF
# Invalid port configuration
Listen 80800
Listen invalid_port

<IfModule ssl_module>
    Listen 443
</IfModule>
EOF

# Test configuration and restart Apache
echo_info "Testing configuration and restarting Apache..."
if apache2ctl configtest; then
    echo_warn "Configuration test passed (unexpected)"
else
    echo_info "Configuration test failed (expected due to intentional errors)"
fi

# Attempt to restart Apache
systemctl restart apache2
if systemctl is-active --quiet apache2; then
    echo_warn "Apache2 started (might have ignored some errors)"
else
    echo_error "Apache2 failed to start (expected due to configuration errors)"
fi

# Display error log
echo_info "Recent error log entries:"
tail -n 20 /var/log/apache2/error.log

# Print test completion message
echo_info "Installation and test configuration complete"
echo_info "To restore original configuration:"
echo_info "cp /etc/apache2/apache2.conf.backup /etc/apache2/apache2.conf"
echo_info "cp /etc/apache2/ports.conf.backup /etc/apache2/ports.conf"
echo_info "Check logs at /var/log/apache2/error.log for error messages"

# Create cleanup function
cleanup() {
    echo_info "Would you like to restore the original configuration? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])+$ ]]; then
        # Restore original configuration
        cp /etc/apache2/apache2.conf.backup /etc/apache2/apache2.conf
        cp /etc/apache2/ports.conf.backup /etc/apache2/ports.conf
        
        # Remove test virtual hosts
        a2dissite test1.conf
        a2dissite test2.conf
        rm /etc/apache2/sites-available/test1.conf
        rm /etc/apache2/sites-available/test2.conf
        
        # Restart Apache
        systemctl restart apache2
        echo_info "Original configuration restored"
    fi
}

# Offer cleanup
cleanup