#!/usr/bin/env python3

"""
Ubuntu Log Analysis System with AI-powered reporting
- Scans /var/log/ directory
- Identifies critical issues and errors
- Generates AI-powered analysis
- Creates detailed reports
"""

import asyncio
import aiohttp
import json
import logging
import os
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple, Callable, AsyncGenerator
import xml.etree.ElementTree as ET
from jinja2 import Template
import argparse
import re
from dotenv import load_dotenv
from tenacity import retry, stop_after_attempt, wait_fixed
import psutil
import hashlib
import time
from collections import defaultdict
import functools

load_dotenv()

# Add custom exceptions for better error handling
class LogAnalyzerError(Exception):
    """Base exception for log analyzer"""
    pass

class ConfigurationError(LogAnalyzerError):
    """Configuration related errors"""
    pass

class CommandExecutionError(LogAnalyzerError):
    """Command execution errors"""
    pass

class APIError(LogAnalyzerError):
    """API call errors"""
    pass
    
class ResourceError(LogAnalyzerError):
    """System resource error"""
    pass
    
class RetryError(LogAnalyzerError):
    """Retry failure error"""
    pass


# Add constants for configuration
class LogAnalyzerConstants:
    """Constants used throughout the application"""
    VERSION = "1.0.0"
    DEFAULT_LOG_DIR = "/var/log"
    DEFAULT_OUTPUT_DIR = str(Path.home() / "log_analysis")
    MAX_LOG_SIZE = 10 * 1024 * 1024  # 10MB
    DEFAULT_COMMAND_TIMEOUT = 300
    
@dataclass
class LogAnalyzerConfig:
    """Configuration for log analyzer"""
    LOG_DIR: str = "/var/log"
    SCAN_PATTERNS: List[str] = field(default_factory=lambda: [
        "error", "critical", "failed", "failure", "fatal", "killed",
        "crash", "blocked", "corrupt", "dead", "denied", "unavailable",
        # Ubuntu-specific patterns
        r"kernel: \[ *[0-9]+\.[0-9]+\] ERROR",  # Kernel errors
        r"systemd\[[0-9]+\]: Failed",           # Systemd failures
        r"apt\[[0-9]+\].*Error",                # APT errors
        r"snapd\[[0-9]+\].*ERROR",              # Snap errors
        r"NetworkManager\[[0-9]+\].*error",     # NetworkManager errors
        r"UFW BLOCK",  # Ubuntu Firewall blocks
        r'apparmor="DENIED"'  # AppArmor denials
    ])
    OUTPUT_DIR: str = str(Path.home() / "log_analysis")
    COMMAND_TIMEOUT: int = 300
    API_RETRIES: int = 3
    MODEL_CONFIG: Dict[str, Dict] = field(default_factory=lambda: {
        'analysis': {
            'name': 'llama3.3:latest',
            'temperature': 0.3,
            'timeout': 60
        },
        'security': {
            'name': 'mistral-small:latest',
            'temperature': 0.2,
            'timeout': 60
        },
        'recommendation': {
            'name': 'mistral-small:latest',
            'temperature': 0.4,
            'timeout': 60
        },
        'commands': {
            'name': 'granite-code:20b',
            'temperature': 0.2,
            'timeout': 60
        }
    })
    OLLAMA_BASE_URL: Optional[str] = os.getenv("OLLAMA_API_URL", None)
    MAX_LOG_SIZE: int = 10 * 1024 * 1024  # 10MB limit for analysis
    MAX_API_CALLS: int = 10
    API_TIME_WINDOW: int = 60
    
    def __post_init__(self):
         if not self.OLLAMA_BASE_URL:
            raise ValueError("Ollama base url cannot be empty, provide OLLAMA_API_URL")
         if not all(self.MODEL_CONFIG.values()):
            raise ValueError("Invalid Configuration, Please check model values")
         self.validate_config()
            
    @classmethod
    def from_xml(cls, config_file: str = "config.xml"):
        """Load configuration from XML file."""
        try:
            tree = ET.parse(config_file)
            root = tree.getroot()
            config_data = {
                "LOG_DIR": root.find("log_dir").text if root.find("log_dir") is not None else LogAnalyzerConstants.DEFAULT_LOG_DIR,
                "OUTPUT_DIR": root.find("output_dir").text if root.find("output_dir") is not None else LogAnalyzerConstants.DEFAULT_OUTPUT_DIR,
                 "OLLAMA_BASE_URL": root.find("ollama_api").text if root.find("ollama_api") is not None else os.getenv("OLLAMA_API_URL"),
                 "COMMAND_TIMEOUT": int(root.find("command_timeout").text if root.find("command_timeout") is not None else LogAnalyzerConstants.DEFAULT_COMMAND_TIMEOUT),
                 "API_RETRIES": int(root.find("api_retries").text if root.find("api_retries") is not None else 3),
                 "MAX_LOG_SIZE": int(root.find("max_log_size").text if root.find("max_log_size") is not None else LogAnalyzerConstants.MAX_LOG_SIZE),
                  "MAX_API_CALLS": int(root.find("max_api_calls").text if root.find("max_api_calls") is not None else 10),
                  "API_TIME_WINDOW": int(root.find("api_time_window").text if root.find("api_time_window") is not None else 60)

            }

            patterns_elem = root.find("scan_patterns")
            if patterns_elem is not None:
                config_data["SCAN_PATTERNS"] = [p.text for p in patterns_elem.findall("pattern")]
            
            model_config = {}
            models_elem = root.find("models")
            if models_elem is not None and len(list(models_elem)) > 0:  # Explicit check for models element
                for model_type in models_elem:
                    if model_type.tag == 'commands':
                        name_elem = model_type.find("name")
                        temp_elem = model_type.find("temperature")
                        timeout_elem = model_type.find("timeout")
                        
                        if all(elem is not None for elem in [name_elem, temp_elem, timeout_elem]):
                            model_config[model_type.tag] = {
                                "name": name_elem.text,
                                "temperature": float(temp_elem.text),
                                "timeout": int(timeout_elem.text)
                            }
                    else:
                        name_elem = model_type.find("name")
                        temp_elem = model_type.find("temperature")
                        timeout_elem = model_type.find("timeout")
                        
                        if all(elem is not None for elem in [name_elem, temp_elem, timeout_elem]):
                            model_config[model_type.tag] = {
                                "name": name_elem.text,
                                "temperature": float(temp_elem.text),
                                "timeout": int(timeout_elem.text)
                            }
                
                if model_config:  # Only add if we have valid model configurations
                    config_data["MODEL_CONFIG"] = model_config


            return cls(**config_data)
        
        except Exception as e:
             logging.error(f"Error loading config from XML, using default {e}")
             return cls()
         
    def validate_config(self):
        """Validate configuration settings"""
        errors = []
        
        # Validate directories
        if not os.path.exists(self.LOG_DIR):
            errors.append(f"Log directory does not exist: {self.LOG_DIR}")
        if not os.path.exists(self.OUTPUT_DIR):
           os.makedirs(self.OUTPUT_DIR, exist_ok=True) # create if not exist
           
        # Validate model configuration
        for model_type, config in self.MODEL_CONFIG.items():
            if not all(key in config for key in ['name', 'temperature', 'timeout']):
                errors.append(f"Invalid model configuration for {model_type}")
                
        # Check API URL
        if not self.OLLAMA_BASE_URL:
            errors.append("Ollama API URL is not configured")
            
        if errors:
            raise ConfigurationError("\n".join(errors))


@dataclass
class LogAnalysis:
    """Store log analysis results"""
    timestamp: str
    total_issues: int
    critical_issues: int
    error_patterns: Dict[str, int]
    log_summaries: Dict[str, Any]
    system_impact: str = ""
    security_implications: str = ""
    recommendations: str = ""
    severity_analysis: Dict = field(default_factory=dict)
    trend_analysis: Dict = field(default_factory=dict)
    security_correlation: Dict = field(default_factory=dict)
    command_recommendations: Dict = field(default_factory=dict)

class CommandValidator:
    """Validates and sanitizes system commands"""
    def __init__(self, whitelist: List[str]):
        # Add Ubuntu-specific commands to whitelist
        self.whitelist = set(whitelist + ['journalctl', 'systemctl'])
        
    def validate_command(self, command: List[str]) -> bool:
        if not command:
            return False
        return command[0] in self.whitelist
        
    def sanitize_path(self, path: str) -> str:
        """Sanitize file path to prevent command injection"""
        return Path(path).resolve().as_posix()


class RateLimiter:
    """Rate limiting for API calls"""
    def __init__(self, max_calls: int, time_window: int):
        self.max_calls = max_calls
        self.time_window = time_window
        self.calls = []
        
    async def acquire(self):
        now = time.time()
        self.calls = [t for t in self.calls if now - t < self.time_window]
        
        if len(self.calls) >= self.max_calls:
            sleep_time = self.calls[0] + self.time_window - now
            if sleep_time > 0:
                await asyncio.sleep(sleep_time)
                
        self.calls.append(now)
        
class RetryHandler:
    """Advanced retry mechanism with exponential backoff"""
    def __init__(self, max_retries: int, base_delay: float = 1.0):
        self.max_retries = max_retries
        self.base_delay = base_delay
        
    async def execute(self, func: Callable, *args, **kwargs) -> Any:
        last_exception = None
        
        for attempt in range(self.max_retries):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                delay = self.base_delay * (2 ** attempt)
                logging.warning(f"Attempt {attempt + 1} failed: {e}")
                await asyncio.sleep(delay)
                
        raise RetryError(f"Failed after {self.max_retries} attempts") from last_exception
        
class AnalysisCache:
    """Cache for analysis results"""
    def __init__(self, cache_dir: Path, max_age: int = 3600):
        self.cache_dir = cache_dir
        self.max_age = max_age
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
    def get_cache_key(self, data: Dict[str, Any]) -> str:
        """Generate cache key from input data"""
        return hashlib.sha256(
            json.dumps(data, sort_keys=True).encode()
        ).hexdigest()
        
    async def get(self, key: str) -> Optional[Dict[str, Any]]:
        cache_file = self.cache_dir / f"{key}.json"
        if cache_file.exists():
            if time.time() - cache_file.stat().st_mtime < self.max_age:
                return json.loads(cache_file.read_text())
        return None
        
    async def set(self, key: str, data: Dict[str, Any]):
        cache_file = self.cache_dir / f"{key}.json"
        cache_file.write_text(json.dumps(data))
class MetricsCollector:
    """Collect and report performance metrics"""
    def __init__(self):
        self.metrics = defaultdict(list)
        
    async def measure(self, name: str, func: Callable, *args, **kwargs) -> Any:
        start_time = time.time()
        try:
            result = await func(*args, **kwargs)
            duration = time.time() - start_time
            self.metrics[name].append({
                'duration': duration,
                'status': 'success',
                'timestamp': datetime.now().isoformat()
            })
            return result
        except Exception as e:
            duration = time.time() - start_time
            self.metrics[name].append({
                'duration': duration,
                'status': 'error',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            })
            raise
            
class StreamingLogReader:
    """Memory-efficient log file reader"""
    def __init__(self, max_chunk_size: int = 1024 * 1024):
        self.max_chunk_size = max_chunk_size
        
    async def read_logs(self, file_path: str, patterns: List[str]) -> AsyncGenerator[str, None]:
        try:
            with open(file_path, 'r') as f:
                buffer = ""
                while chunk := f.read(self.max_chunk_size):
                    buffer += chunk
                    lines = buffer.split('\n')
                    buffer = lines.pop()
                    
                    for line in lines:
                        if any(pattern in line.lower() for pattern in patterns):
                            yield line
                            
                if buffer and any(pattern in buffer.lower() for pattern in patterns):
                    yield buffer
                    
        except Exception as e:
            logging.error(f"Error reading {file_path}: {e}")
            
class DynamicConfig:
    """Dynamic configuration with hot reload support"""
    def __init__(self, config_file: Path):
        self.config_file = config_file
        self._last_modified = 0.0
        self._config = {}
        self._load_config() # Initial load
    
    def check_update(self):
        """Check and reload configuration if changed"""
        current_mtime = self.config_file.stat().st_mtime
        if current_mtime > self._last_modified:
            self._config = self._load_config()
            self._last_modified = current_mtime

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        try:
            tree = ET.parse(self.config_file)
            return self._parse_xml(tree.getroot())
        except Exception as e:
            logging.error(f"Config load error: {e}")
            return {}
        
    def _parse_xml(self, root: ET.Element) -> Dict[str, Any]:
            """Parse XML config into a dict"""
            return {element.tag: element.text for element in root}
        

class OllamaClient:
    """Enhanced Ollama API client"""
    def __init__(self, base_url: str, rate_limiter: RateLimiter):
        self.base_url = base_url
        self.rate_limiter = rate_limiter
        self.session = None
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
            
    async def generate(self, prompt: str, model: str, temperature: float) -> str:
        await self.rate_limiter.acquire()
        async with self.session.post(
            f"{self.base_url}/api/generate",
            json={
                "model": model,
                "prompt": prompt,
                "temperature": temperature,
                "stream": False
            }
        ) as response:
            if response.status == 200:
                data = await response.json()
                return data.get('response', '')
            raise APIError(f"API call failed: {response.status}")

class ProgressTracker:
    """Track analysis progress"""
    def __init__(self):
        self.total_files = 0
        self.processed_files = 0
        self.current_phase = ""
        
    def update(self, phase: str = None, increment: int = 1):
        """Update progress"""
        if phase:
            self.current_phase = phase
        self.processed_files += increment
        self._display_progress()
        
    def _display_progress(self):
        """Display progress bar"""
        if self.total_files == 0:
             return # Avoid divison by zero
        percentage = (self.processed_files / self.total_files) * 100
        bar_length = 50
        filled_length = int(bar_length * self.processed_files // self.total_files)
        bar = '=' * filled_length + '-' * (bar_length - filled_length)
        print(f'\r{self.current_phase}: [{bar}] {percentage:.1f}%', end='')

def print_banner():
    """Print script banner with version and start time"""
    banner = """
╔════════════════════════════════════════════════════════════════╗
║                  Ubuntu Log Analysis System                     ║
║                                                                ║
║  - AI-Powered System Log Analysis                              ║
║  - Comprehensive Security Assessment                           ║
║  - Automated Recommendations                                   ║
║                                                                ║
║  Version: 1.0.0                                                ║
║  Started: {start_time}                                         ║
╚════════════════════════════════════════════════════════════════╝
    """
    print(banner.format(start_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S")))

    
class ResourceManager:
    """Manage system resources during analysis"""
    def __init__(self, max_memory_percent: float = 80.0, max_cpu_percent: float = 90.0):
        self.max_memory_percent = max_memory_percent
        self.max_cpu_percent = max_cpu_percent
        
    def check_resources(self) -> Tuple[bool, str]:
        """
        Check system resource usage
        Returns: (is_ok, message)
        """
        try:
            memory_usage = psutil.virtual_memory().percent
            cpu_usage = psutil.cpu_percent(interval=1)
            
            if memory_usage > self.max_memory_percent:
                return False, f"Memory usage too high: {memory_usage}%"
                
            if cpu_usage > self.max_cpu_percent:
                return False, f"CPU usage too high: {cpu_usage}%"
                
            return True, "Resource usage within limits"
            
        except Exception as e:
            logging.error(f"Error checking resources: {e}")
            return False, f"Resource check failed: {str(e)}"
    
    async def monitor_resources(self, interval: int = 60):
        """
        Continuously monitor system resources
        Raises ResourceError if limits are exceeded
        """
        while True:
            is_ok, message = self.check_resources()
            if not is_ok:
                raise ResourceError(message)
            await asyncio.sleep(interval)
    
    def get_resource_usage(self) -> Dict[str, float]:
        """Get current resource usage statistics"""
        return {
            'memory_percent': psutil.virtual_memory().percent,
            'cpu_percent': psutil.cpu_percent(interval=1),
            'disk_percent': psutil.disk_usage('/').percent
        }

class LogSeverityAnalyzer:
    """Add severity classification to log entries"""
    def __init__(self):
        self.severity_patterns = {
            'CRITICAL': ['fatal', 'panic', 'emergency'],
            'HIGH': ['error', 'failed', 'failure'],
            'MEDIUM': ['warning', 'denied'],
            'LOW': ['notice', 'info']
        }
    
    def classify_severity(self, log_entry: str) -> str:
        for severity, patterns in self.severity_patterns.items():
            if any(pattern in log_entry.lower() for pattern in patterns):
                return severity
        return 'INFO'

class LogTrendAnalyzer:
    """Analyze trends in log occurrences"""
    def __init__(self):
        self.time_windows = defaultdict(int)
        
    def analyze_trends(self, log_entries: List[Dict]):
        for entry in log_entries:
            timestamp = entry.get('timestamp')
            if timestamp:
                hour = datetime.fromisoformat(timestamp).replace(minute=0, second=0)
                self.time_windows[hour] += 1
        return self._get_trend_analysis()
    
    def _get_trend_analysis(self) -> Dict:
        if not self.time_windows:
            return {}
        return {
            'peak_hour': max(self.time_windows.items(), key=lambda x: x[1])[0],
            'total_events': sum(self.time_windows.values()),
            'hourly_distribution': dict(self.time_windows)
        }

class SecurityEventCorrelator:
    """Correlate security-related events across logs"""
    def correlate_security_events(self, auth_logs: List[str], 
                                syslog: List[str], 
                                kernel_logs: List[str]) -> Dict:
        """Correlate security events across Ubuntu logs."""
        # Ubuntu-specific security patterns
        attack_patterns = [
            re.compile(r'Failed password for .* from (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'),
            re.compile(r'Invalid user .* from (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'),
            re.compile(r'Accepted publickey for .* from (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'),
             re.compile(r'UFW BLOCK'),  # Ubuntu Firewall blocks
             re.compile(r'apparmor="DENIED"'),  # AppArmor denials
              re.compile(r'sudo:.*(COMMAND|NOT in sudoers)'),  # Sudo events
        ]

        auth_events = []
        for log_set, log_list in {
            "auth_logs": auth_logs,
            "syslog": syslog,
            "kernel_logs": kernel_logs
        }.items():
            for log_line in log_list:
                for pattern in attack_patterns:
                    if match := pattern.search(log_line):
                        ip = match.group(1) if 'from' in pattern.pattern else None
                        auth_events.append({
                            'log_set': log_set,
                            'ip': ip,
                            'event': log_line
                        })
        
        if not auth_events:
            return {"message": "No security events identified."}
        
        return {"security_events": auth_events}
        

class LogAnalyzer:
    def __init__(self, config_file: str = "config.xml"):
        """Initialize log analyzer"""
        self.start_time = datetime.now()
        self.config = LogAnalyzerConfig.from_xml(config_file)
        self.output_dir = Path(self.config.OUTPUT_DIR)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._setup_logging()
        self.command_validator = CommandValidator(whitelist=['find', 'grep', 'cat', 'tail'])
        self.rate_limiter = RateLimiter(max_calls=self.config.MAX_API_CALLS, time_window=self.config.API_TIME_WINDOW)
        self.retry_handler = RetryHandler(max_retries=self.config.API_RETRIES)
        self.cache = AnalysisCache(cache_dir=self.output_dir / "cache")
        self.metrics = MetricsCollector()
        self.ollama_client = OllamaClient(base_url=self.config.OLLAMA_BASE_URL, rate_limiter=self.rate_limiter)
        self.dynamic_config = DynamicConfig(config_file=Path(config_file))
        self.resource_manager = ResourceManager()
        self.progress_tracker = ProgressTracker()
        self.severity_analyzer = LogSeverityAnalyzer()
        self.trend_analyzer = LogTrendAnalyzer()
        self.security_correlator = SecurityEventCorrelator()
        

    def _setup_logging(self):
        """Configure logging"""
        log_file = self.output_dir / "log_analyzer.log"
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    def _run_command(self, command: List[str]) -> Dict[str, Any]:
        """Execute shell command safely"""
        if not self.command_validator.validate_command(command):
            logging.error(f"Invalid command: {' '.join(command)}")
            return {'success': False, 'output': '', 'error': 'Command not allowed'}
        
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=self.config.COMMAND_TIMEOUT
            )
            return {
                'success': result.returncode == 0,
                'output': result.stdout.strip(),
                'error': result.stderr.strip()
            }
        except subprocess.TimeoutExpired:
            logging.error(f"Command timed out: {' '.join(command)}")
            return {'success': False, 'output': '', 'error': 'Command timed out'}
        except Exception as e:
            logging.error(f"Command failed: {e}")
            return {'success': False, 'output': '', 'error': str(e)}
    
    async def process_single_log(self, log_file: str) -> Tuple[str, Optional[Dict[str, Any]]]:
        """Process single log file for matching pattern with enhanced error handling"""
        log_file = self.command_validator.sanitize_path(log_file)
        if not log_file:
            return None, None
        
        try:
            log_file_path = Path(log_file)
            if not log_file_path.exists():
                logging.warning(f"Log file does not exist: {log_file}")
                return None, None
            
            if log_file_path.stat().st_size > self.config.MAX_LOG_SIZE:
                logging.warning(f"Skipping large file: {log_file}")
                return None, None

            # Add specific patterns for web server logs
            if 'httpd' in str(log_file_path) or 'apache2' in str(log_file_path) or 'nginx' in str(log_file_path):
                additional_patterns = [
                    'error', 'critical', 'alert', 'emergency',
                    '[error]', '[alert]', '[critical]',
                    '404', '500', '503', 'permission denied',
                    'client denied', 'access forbidden'
                ]
                grep_pattern = '|'.join(self.config.SCAN_PATTERNS + additional_patterns)
            else:
                grep_pattern = '|'.join(self.config.SCAN_PATTERNS)

            grep_cmd = ['grep', '-iE', grep_pattern, log_file]
            result = await asyncio.to_thread(self._run_command, grep_cmd)
            
            if result['success'] and result['output']:
                matched_lines = result['output'].strip().split('\n')
                return log_file, {
                    'total_issues': len(matched_lines),
                    'matches': matched_lines[:100]  # Limit to first 100 matches
                }
                
            return log_file, { 'total_issues': 0, 'matches': [] } # Return empty results
        
        except Exception as e:
            logging.error(f"Error processing log file {log_file}: {e}")
            return None, None

    async def scan_log_files(self) -> Dict[str, Any]:
        """Scan log files with enhanced pattern matching for Ubuntu"""
        log_data = {}
        pattern_counts = {pattern: 0 for pattern in self.config.SCAN_PATTERNS}
        
        try:
            # Ubuntu-specific log patterns
            log_patterns = [
                "*.log",           # Standard log files
                "syslog",         # System logs
                "auth.log",       # Authentication logs
                "kern.log",       # Kernel logs
                "daemon.log",     # Daemon logs
                "ufw.log",        # Firewall logs
                "apache2/*",      # Apache logs
                "nginx/*",        # Nginx logs
                "snap/*.log",     # Snap logs
                 "apt/*",          # APT logs
                 "journal/*"      # Systemd journal
            ]
            
            # Build find command with multiple patterns
            find_cmd = ['find', self.config.LOG_DIR, '-type', 'f', '(']
            for i, pattern in enumerate(log_patterns):
                if i > 0:
                    find_cmd.append('-o')
                find_cmd.extend(['-name', pattern])
            find_cmd.append(')')
            
            find_result = await asyncio.to_thread(self._run_command, find_cmd)

            if not find_result['success']:
                logging.error("Failed to list log files")
                return {'log_data': {}, 'pattern_counts': pattern_counts}
                
            log_files = [f for f in find_result['output'].split('\n') if f]
            self.progress_tracker.total_files = len(log_files)
            
            logging.info(f"Found {len(log_files)} log files to analyze")
            for log_file in log_files:
                logging.debug(f"Found log file: {log_file}")
            
            async def process_log_batch(log_files: List[str], batch_size: int = 5):
                """Process log files in batches"""
                for i in range(0, len(log_files), batch_size):
                    batch = log_files[i:i + batch_size]
                    self.progress_tracker.current_phase = 'Scanning log files'
                    tasks = [self.process_single_log(log_file) for log_file in batch if log_file]
                    results = await asyncio.gather(*tasks)
                    
                    for result in results:
                        if result and result[0]:
                            log_file, data = result
                            log_data[log_file] = data
                            # Update pattern counts
                            for pattern in self.config.SCAN_PATTERNS:
                                pattern_counts[pattern] += sum(
                                    1 for line in data['matches'] 
                                    if pattern.lower() in line.lower()
                                )
                    self.progress_tracker.update(increment=len(batch))
                    
            await process_log_batch(log_files)
            print()  # New line after progress bar
            
             # Log summary of findings
            logging.info(f"Analysis complete - Found issues in {len(log_data)} files")
            for log_file, data in log_data.items():
                logging.info(f"{log_file}: {data['total_issues']} issues found")
                
            return {'log_data': log_data, 'pattern_counts': pattern_counts}
            
        except Exception as e:
            logging.error(f"Error in parallel scan: {e}")
            return {'log_data': {}, 'pattern_counts': pattern_counts}

    async def _make_api_call(self, prompt: str, model_type: str) -> str:
        """Make API call to Ollama"""
        async def attempt_api_call() -> str:
            async with self.ollama_client as client:
                return await client.generate(prompt, self.config.MODEL_CONFIG[model_type]['name'], self.config.MODEL_CONFIG[model_type]['temperature'])
        return await self.retry_handler.execute(attempt_api_call)


    def create_analysis_prompt(self, scan_results: Dict[str, Any]) -> str:
        """Create prompt for log analysis"""
        prompt = f"""
        Analyze these system log issues and provide a detailed assessment:

        Pattern Frequencies:
        {json.dumps(scan_results['pattern_counts'], indent=2)}

        Log Summaries:
        """
        
          # Add sample of issues from each log file
        for log_file, data in scan_results.get('log_data',{}).items():
            prompt += f"\nFile: {log_file}\n"
            prompt += f"Total Issues: {data.get('total_issues',0)}\n"
            prompt += "Sample Issues:\n"
            for match in data.get('matches', [])[:5]:  # Include first 5 matches as examples
                prompt += f"- {match}\n"

        prompt += """
        Provide analysis including:
        1. Most critical issues identified
        2. Pattern analysis and trends
        3. System health implications
        4. Potential root causes
        5. Priority assessment
        6. System impact evaluation
        """
        
        return prompt

    def create_security_prompt(self, scan_results: Dict[str, Any]) -> str:
        """Create prompt for security analysis"""
        return f"""
        Analyze these log entries for security implications:

        Pattern Frequencies:
        {json.dumps(scan_results['pattern_counts'], indent=2)}

        Focus on:
        1. Security vulnerabilities indicated
        2. Potential attack patterns
        3. Access control issues
        4. System compromise indicators
        5. Data security concerns
        """

    def create_command_prompt(self, issue_type: str, findings: Dict[str, Any]) -> str:
        """Create prompt for generating fix commands"""
        if issue_type == "ssh":
            return f"""
            Generate specific Ubuntu commands to fix SSH security issues:
            Findings:
            {json.dumps(findings, indent=2)}
            
            Provide commands for:
            1. Secure SSH configuration
            2. Setting up fail2ban
            3. UFW firewall rules
            4. PAM configuration
            5. User access control
            
            Format each command with description and potential risks.
            """
        elif issue_type == "apache":
            return f"""
            Generate Apache2 fix commands for Ubuntu:
            Issues Found:
            {json.dumps(findings, indent=2)}
            
            Provide commands for:
            1. Configuration validation
            2. Service management
            3. Log rotation
            4. Permission fixes
            5. Security hardening
            
            Include validation steps after each command.
            """
        elif issue_type == "package":
            return f"""
            Generate Ubuntu package management commands:
            Current Status:
            {json.dumps(findings, indent=2)}
            
            Provide commands for:
            1. Package status check
            2. APT repository management
            3. Package updates and fixes
            4. Broken dependency resolution
            5. Package configuration repair
            
            Include error handling steps.
            """
        return ""


    def create_recommendation_prompt(self, scan_results: Dict[str, Any], analysis: str) -> str:
        """Create prompt for recommendations"""
        return f"""
        Based on the log analysis and security implications, provide recommendations:

        Analysis Summary:
        {analysis}

        Pattern Frequencies:
        {json.dumps(scan_results['pattern_counts'], indent=2)}

        Provide:
        1. Immediate actions needed
        2. Long-term solutions
        3. Preventive measures
        4. Monitoring recommendations
        5. Best practices to implement
        """

    async def analyze_logs(self) -> LogAnalysis:
        """Perform comprehensive log analysis"""
        # Scan logs
        scan_results = await self.metrics.measure("scan_log_files",self.scan_log_files)
        
        # Calculate total issues
        total_issues = sum(data.get('total_issues', 0) for data in scan_results.get('log_data', {}).values())
        critical_issues = sum(
            data.get('total_issues', 0)
            for data in scan_results.get('log_data', {}).values()
             if any(critical in str(data.get('matches', [])).lower() for critical in ['critical', 'fatal', 'error'])
        )
        
        # Severity Analysis
        severity_results = {}
        for log_file, data in scan_results.get('log_data', {}).items():
            severity_results[log_file] = [
                {
                    'message': entry,
                    'severity': self.severity_analyzer.classify_severity(entry)
                }
                for entry in data.get('matches', [])
            ]

        # Trend Analysis
        trend_results = self.trend_analyzer.analyze_trends([
            {'timestamp': datetime.now().isoformat(), 'message': match}
            for data in scan_results.get('log_data', {}).values()
            for match in data.get('matches', [])
        ])

        # Security Event Correlation
        security_results = self.security_correlator.correlate_security_events(
             scan_results.get('log_data', {}).get('auth.log', {}).get('matches', []) or [],
             scan_results.get('log_data', {}).get('syslog', {}).get('matches', []) or [],
             scan_results.get('log_data', {}).get('kern.log', {}).get('matches', []) or []
        )
        
        # Get AI analysis
        analysis_prompt = self.create_analysis_prompt(scan_results)
        security_prompt = self.create_security_prompt(scan_results)
        
        analysis_text = await self.metrics.measure("_make_api_call_analysis", self._make_api_call, analysis_prompt, 'analysis')
        security_text = await self.metrics.measure("_make_api_call_security",self._make_api_call, security_prompt, 'security')
        
        # Get recommendations based on analysis
        recommendation_prompt = self.create_recommendation_prompt(scan_results, analysis_text)
        recommendations = await self.metrics.measure("_make_api_call_recommendation",self._make_api_call, recommendation_prompt, 'recommendation')
        
        # Add command generation for identified issues
        command_recommendations = {}

        # SSH Security Commands
        if any('sshd' in str(data.get('matches', [])) for data in scan_results.get('log_data', {}).values()):
             ssh_findings = {
                'failed_attempts': len([m for m in scan_results.get('log_data', {}).get('auth.log', {}).get('matches', [])
                                    if 'Failed password' in m]),
                'invalid_users': len([m for m in scan_results.get('log_data', {}).get('auth.log', {}).get('matches', [])
                                    if 'Invalid user' in m])
            }
             ssh_prompt = self.create_command_prompt("ssh", ssh_findings)
             command_recommendations['ssh'] = await self._make_api_call(ssh_prompt, 'commands')
        
        # Apache/httpd Commands
        if any('apache2' in str(data.get('matches', [])) for data in scan_results.get('log_data', {}).values()):
            apache_findings = {
                'config_errors': len([m for m in scan_results.get('log_data', {}).get('syslog', {}).get('matches', []) 
                                    if 'apache2' in m and 'error' in m.lower()]),
                'service_failures': len([m for m in scan_results.get('log_data', {}).get('syslog', {}).get('matches', []) 
                                   if 'apache2.service' in m and 'failed' in m.lower()])
             }
            apache_prompt = self.create_command_prompt("apache", apache_findings)
            command_recommendations['apache'] = await self._make_api_call(apache_prompt, 'commands')
        
        # Package Management Commands
        if any('apt' in str(data.get('matches', [])) for data in scan_results.get('log_data', {}).values()):
           package_findings = {
               'apt_errors': len([m for m in scan_results.get('log_data', {}).get('syslog', {}).get('matches', []) 
                                  if 'apt' in m and 'error' in m.lower()]),
                'apt_failures': len([m for m in scan_results.get('log_data', {}).get('syslog', {}).get('matches', []) 
                                    if 'apt' in m and 'failed' in m.lower()])
           }
           package_prompt = self.create_command_prompt("package", package_findings)
           command_recommendations['package'] = await self._make_api_call(package_prompt, 'commands')


        return LogAnalysis(
            timestamp=datetime.now().isoformat(),
            total_issues=total_issues,
            critical_issues=critical_issues,
            error_patterns=scan_results.get('pattern_counts', {}),
            log_summaries=scan_results.get('log_data', {}),
            system_impact=analysis_text,
            security_implications=security_text,
            recommendations=recommendations,
            severity_analysis=severity_results,
            trend_analysis=trend_results,
            security_correlation=security_results,
             command_recommendations=command_recommendations
        )
    def format_report(self, analysis: LogAnalysis) -> str:
        """Format analysis report"""
        template = Template("""
    # System Log Analysis Report
    Generated: {{ analysis.timestamp }}

    ## Overview
    - Total Issues: {{ analysis.total_issues }}
    - Critical Issues: {{ analysis.critical_issues }}

    ## Error Pattern Analysis
    {% for pattern, count in analysis.error_patterns.items() %}
    - {{ pattern }}: {{ count }}
    {% endfor %}

    ## System Impact Analysis
    {{ analysis.system_impact }}

    ## Security Implications
    {{ analysis.security_implications }}

    ## Recommendations
    {{ analysis.recommendations }}
    
    ## Log Severity Analysis
    {% for log_file, results in analysis.severity_analysis.items() %}
        ### {{ log_file }}
        {% for item in results %}
           -  Severity: {{ item.severity }}, Message: {{ item.message }}
        {% endfor %}
    {% endfor %}
    
    ## Log Trend Analysis
    {% if analysis.trend_analysis %}
    - Peak Hour: {{ analysis.trend_analysis.peak_hour }}
    - Total Events: {{ analysis.trend_analysis.total_events }}
    - Hourly Distribution:
        {% for hour, count in analysis.trend_analysis.hourly_distribution.items() %}
            - {{ hour }}: {{ count }}
         {% endfor %}
    {% else %}
        No Trend Data Available
    {% endif %}

     ## Security Event Correlation
    {% if analysis.security_correlation %}
    {{ analysis.security_correlation }}
    {% else %}
        No Security Correlation Available
    {% endif %}

    ## Detailed Log Summaries
    {% for log_file, data in analysis.log_summaries.items() %}
    ### {{ log_file }}
    Total Issues: {{ data.total_issues }}

    Sample Issues:
    {% for match in data.matches[:5] %}
    - {{ match }}
    {% endfor %}

    {% endfor %}

    ## Recommended Commands for Fixes

    {% if analysis.command_recommendations.ssh %}
    ### SSH Security Fixes
    {{ analysis.command_recommendations.ssh }}
    {% endif %}

    {% if analysis.command_recommendations.apache %}
    ### Apache/HTTPD Fixes
    {{ analysis.command_recommendations.apache }}
    {% endif %}

    {% if analysis.command_recommendations.package %}
    ### Package Management Fixes
    {{ analysis.command_recommendations.package }}
    {% endif %}
            """)
        return template.render(analysis=analysis)
    
    def print_completion_message(self):
        """Print completion message with timing information"""
        end_time = datetime.now()
        duration = end_time - self.start_time
        hours, remainder = divmod(duration.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        completion_msg = """
╔════════════════════════════════════════════════════════════════╗
║                    Analysis Complete                            ║
║                                                                ║
║  Start Time: {start_time}                                      ║
║  End Time:   {end_time}                                        ║
║  Duration:   {duration}                                        ║
╚════════════════════════════════════════════════════════════════╝
        """
        
        duration_str = ""
        if hours > 0:
            duration_str += f"{hours}h "
        if minutes > 0:
            duration_str += f"{minutes}m "
        duration_str += f"{seconds}s"
        
        print(completion_msg.format(
            start_time=self.start_time.strftime("%Y-%m-%d %H:%M:%S"),
            end_time=end_time.strftime("%Y-%m-%d %H:%M:%S"),
            duration=duration_str
        ))

    async def run_analysis(self):
        """Run the log analysis"""
        try:
            print_banner()  # Print banner at start
            print("Starting log analysis...")
            
            # Perform analysis
            analysis = await self.analyze_logs()
            
            # Generate report
            report = self.format_report(analysis)
            
            # Save report
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report_file = self.output_dir / f"log_analysis_{timestamp}.md"
            report_file.write_text(report)
            
            # Print completion message with timing
            self.print_completion_message()
            
            print(f"\nReport generated: {report_file}")
            print(f"\nSummary:")
            print(f"- Total Issues: {analysis.total_issues}")
            print(f"- Critical Issues: {analysis.critical_issues}")
            
        except Exception as e:
            logging.error(f"Analysis failed: {e}")
            print(f"\nError: {e}")

async def main():
    """Main function"""
    parser = argparse.ArgumentParser(description='Ubuntu Log Analyzer')
    parser.add_argument('--config', type=str, default='config.xml',
                       help='Path to configuration file')
    parser.add_argument('--version', action='version', 
                       version='Ubuntu Log Analyzer 1.0.0')
    args = parser.parse_args()

    try:
        analyzer = LogAnalyzer(args.config)
        await analyzer.run_analysis()
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(main())