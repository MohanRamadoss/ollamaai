#!/usr/bin/env python3

"""
╔════════════════════════════════════════════════════════════════════╗
║                 RHEL 9 Patch Analysis System (v1.0)                ║
║                                                                    ║
║  A comprehensive patch management and analysis tool with:          ║
║  • AI-powered patch analysis using Ollama models                   ║
║  • System health monitoring                                        ║
║  • Security impact assessment                                      ║
║  • Automated playbook generation                                   ║
║  • Dynamic validation commands                                     ║
║  • Detailed reporting with AI insights                             ║
║                                                                    ║
║  Requirements:                                                     ║
║  - Python 3.8+                                                     ║
║  - Required packages:                                              ║
║    pip install aiohttp jinja2 pyyaml python-dotenv                 ║
║                                                                    ║
║  Configuration:                                                    ║
║  - Set OLLAMA_API_URL in environment or config.yaml                ║
║  - Ensure Ollama server is running and accessible                  ║
║                                                                    ║
║  Usage:                                                            ║
║  python3 patch.py [--debug]                                        ║
║                                                                    ║
║                                                                    ║
╚════════════════════════════════════════════════════════════════════╝
"""

# Import statements and rest of the code...

import asyncio
import aiohttp
import json
import logging
import os
import subprocess
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional, Coroutine
import yaml
import re
from dotenv import load_dotenv
from jinja2 import Template
import xml.etree.ElementTree as ET
import argparse
load_dotenv()

# --- Config Class from rhel9patch11.py ---
@dataclass
class Config:
    """Application configuration"""
    LOG_DIR: str = str(Path(os.path.dirname(os.path.abspath(__file__))) / "rhel_patch")
    COMMAND_TIMEOUT: int = 300
    API_RETRIES: int = 3
    CACHE_DURATION: int = 3600
    MODEL_CONFIG: Dict[str, Dict] = None
    OLLAMA_BASE_URL: Optional[str] = None
    OLLAMA_ENDPOINTS: Dict[str, str] = field(default_factory=lambda: {
        "generate": "/api/generate",
        "status": "/api/status",
        "models": "/api/models"
    })
    OLLAMA_HEADERS: Dict[str, str] = field(default_factory=lambda: {
        "Content-Type": "application/json",
        "Accept": "application/json"
    })
    OLLAMA_RETRY_CONFIG: Dict[str, int] = field(default_factory=lambda: {
        "max_attempts": 3,
        "min_delay": 1,
        "max_delay": 10
    })
    OLLAMA_RATE_LIMIT: Dict[str, int] = field(default_factory=lambda: {
        "calls": 10,
        "period": 60
    })
    OLLAMA_TIMEOUT: int = 30
    SYSTEM_CHECKS_TIMEOUT: int = 30
    HEALTH_CHECK_PARALLEL: bool = True

    @classmethod
    def from_xml(cls, config_file: str = "config.xml"):
        """Load configuration from XML file"""
        try:
            tree = ET.parse(config_file)
            root = tree.getroot()
            
            config_data = {
                "LOG_DIR": root.find("log_dir").text if root.find("log_dir") is not None else cls.LOG_DIR,
                "COMMAND_TIMEOUT": int(root.find("command_timeout").text) if root.find("command_timeout") is not None else cls.COMMAND_TIMEOUT,
                "API_RETRIES": int(root.find("api_retries").text) if root.find("api_retries") is not None else cls.API_RETRIES,
                "CACHE_DURATION": int(root.find("cache_duration").text) if root.find("cache_duration") is not None else cls.CACHE_DURATION,
                "OLLAMA_BASE_URL": root.find("ollama_api").text if root.find("ollama_api") is not None else os.getenv("OLLAMA_API_URL"),
                "OLLAMA_TIMEOUT": int(root.find("ollama_timeout").text) if root.find("ollama_timeout") is not None else cls.OLLAMA_TIMEOUT,
                "SYSTEM_CHECKS_TIMEOUT": int(root.find("system_checks_timeout").text) if root.find("system_checks_timeout") is not None else cls.SYSTEM_CHECKS_TIMEOUT,
                "HEALTH_CHECK_PARALLEL": bool(root.find("health_check_parallel").text) if root.find("health_check_parallel") is not None else cls.HEALTH_CHECK_PARALLEL
            }

            # Load model configurations
            model_config = {}
            models_elem = root.find("models")
            if models_elem is not None:
                for model_type in models_elem:
                    if model_type.tag in ['quick_check', 'technical', 'code', 'reasoning']:
                        model_config[model_type.tag] = {
                            'name': model_type.find("name").text,
                            'temperature': float(model_type.find("temperature").text),
                            'timeout': int(model_type.find("timeout").text)
                        }
            config_data["MODEL_CONFIG"] = model_config

            return cls(**config_data)
        except Exception as e:
            logging.error(f"Error loading config from XML: {e}")
            raise ValueError(f"Failed to load configuration: {e}")

    def __post_init__(self):
        """Initialize model configurations"""
        if self.MODEL_CONFIG is None:
            self.MODEL_CONFIG = {
                'quick_check': {
                    'name': 'mistral-small:latest',
                    'temperature': 0.3,
                    'timeout': 30
                },
                'technical': {
                    'name': 'mistral-small:latest',
                    'temperature': 0.5,
                    'timeout': 60
                },
                'code': {
                    'name': 'granite-code:20b',
                    'temperature': 0.2,
                    'timeout': 120
                },
                'reasoning': {
                    'name': 'mistral-small:latest',
                    'temperature': 0.6,
                    'timeout': 180  # Increased timeout for reasoning
                }
            }
        if not self.OLLAMA_BASE_URL:
            raise ValueError("Ollama base url cannot be empty, provide OLLAMA_API_URL or set in config.yaml")
        if not all(self.MODEL_CONFIG.values()):
            raise ValueError("Invalid Configuration, Please check model values")
    def validate_config(self):
        """Validate configuration settings"""
        if not self.OLLAMA_BASE_URL:
            raise ValueError("Ollama base url cannot be empty, provide OLLAMA_API_URL")
        if not self.MODEL_CONFIG or not all(self.MODEL_CONFIG.values()):
            raise ValueError("Invalid Configuration, Please check model values")

# --- Data Classes from rhel9patch11.py ---
@dataclass
class PatchAnalysis:
    """Comprehensive patch analysis data structure"""
    timestamp: str
    total_updates: int
    security_updates: int
    critical_updates: int
    package_updates: List[str]
    kernel_updates: List[str]
    service_impacting_updates: List[str]
    reboot_required: bool
    estimated_downtime: str
    risk_level: str
    detailed_report: str = None
    implications: str = None


@dataclass
class PatchInfo:
    """Structured patch information for analysis"""
    total_updates: int
    security_updates: int
    critical_updates: int
    system_packages: List[str]
    kernel_updates: List[str]
    last_patched: str
    reboot_required: bool

def sanitize_error_message(error: str) -> str:
    """Sanitize error messages before logging or display"""
    if not error:
        return "An unknown error occurred."

    # Remove file paths, IP addresses, and other potentially sensitive information
    sanitized_error = re.sub(r'(/[\w\d\/\.\-]+)', '[FILE PATH]', error)
    sanitized_error = re.sub(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', '[IP ADDRESS]', error)
    sanitized_error = re.sub(r'(\b\w+@[\w\d\.\-]+\b)', '[EMAIL ADDRESS]', sanitized_error)

    return sanitized_error

class EnhancedPromptGenerator:
    """Advanced prompt generation for patch analysis"""

    def __init__(self):
        self.system_messages = {
            'analysis': "You are an expert RHEL system administrator with extensive experience in patch management and security analysis.",
            'playbook': "You are an expert DevOps engineer specializing in RHEL automation and Ansible playbook development.",
            'reasoning': "You are an expert systems analyst specializing in RHEL security patches and vulnerability management."
        }

    def create_analysis_prompt(self, patch_info: PatchInfo, system_health: Dict[str, Any]) -> List[Dict]:
        """Create enhanced analysis prompt with system context"""
        prompt = f"""
            Analyze this RHEL system's patch requirements with special attention to security and stability:

            System Health Metrics:
            ---------------------
            CPU Load: {system_health['cpu_load']}
            Memory Usage: {system_health['memory_usage']}
            Disk Space: {system_health['disk_space']}
            Active Services: {system_health['active_services']}

            Patch Status:
            -------------
            Total Updates: {patch_info.total_updates}
            Security Updates: {patch_info.security_updates}
            Critical Updates: {patch_info.critical_updates}
            Last Patched: {patch_info.last_patched}
            Kernel Updates: {', '.join(patch_info.kernel_updates)}

            Required Analysis:
            -----------------
            1. Risk Assessment
               - Security implications of pending updates
               - System stability impact
               - Service disruption potential
               - Resource utilization impact
            Provide a concise recommendation whether it's a good idea to proceed with patching, considering all the factors.

            Format the response as a structured markdown document with clear sections and actionable recommendations.
            """
        return [
            {"role": "system", "content": self.system_messages['analysis']},
            {"role": "user", "content": prompt}
        ]
    def create_implication_prompt(self, patch_analysis: PatchAnalysis, system_health: Dict[str, Any]) -> List[Dict]:
        """Create a prompt for patch implications with system context."""
        prompt = f"""
            Analyze potential implications of applying these patches:
            - Security Updates: {patch_analysis.security_updates}
            - Critical Updates: {patch_analysis.critical_updates}
            - Service Impact: {len(patch_analysis.service_impacting_updates)}

            System Health:
            {json.dumps(system_health, indent=2)}

            Provide:
            1. Risk Assessment
            2. Dependency Analysis
            3. Performance Impact
            4. Recovery Plan
            """
        return [
            {"role": "system", "content": self.system_messages['reasoning']},
            {"role": "user", "content": prompt}
        ]

    def create_playbook_prompt(self, patch_info: PatchInfo) -> List[Dict]:
        """Create enhanced playbook generation prompt"""
        prompt = f"""
            Generate a production-grade Ansible playbook for RHEL patch management:

            Update Requirements:
            ------------------
            - Total Updates: {patch_info.total_updates}
            - Security Updates: {patch_info.security_updates}
            - Critical Updates: {patch_info.critical_updates}
            - Kernel Updates: {len(patch_info.kernel_updates)}
            - Last Patched: {patch_info.last_patched}
            - Reboot Required: {patch_info.reboot_required}

            Playbook Requirements:
            --------------------
            1. Pre-update Tasks:
                - System health verification
                - Backup creation
                - Resource availability checks
                - Service state documentation

            2. Update Sequence:
                - Security updates first
                - Kernel updates handling
                - Service-impacting updates
                - General updates

            3. Post-update Verification:
                - System stability checks
                - Service availability tests
                - Performance validation
                - Security compliance checks

            4. Error Handling:
                - Failure detection
                - Automatic rollback
                - State preservation
                - Alert mechanisms

            Include:
            - Clear task names and descriptions
            - Proper tags for selective execution
            - Handler definitions for service restarts
            - Variable definitions for environment flexibility
            - Comprehensive error handling
            - Detailed logging
            """
        return [
            {"role": "system", "content": self.system_messages['playbook']},
            {"role": "user", "content": prompt}
        ]
    
    def create_validation_commands_prompt(self, patch_analysis: PatchAnalysis) -> List[Dict]:
        """Generate validation commands based on update context"""
        prompt = f"""
        Generate specific validation commands for RHEL9 system with:
        - Total Updates: {patch_analysis.total_updates}
        - Security Updates: {patch_analysis.security_updates}
        - Kernel Updates: {len(patch_analysis.kernel_updates)}
        - Service Impacting: {len(patch_analysis.service_impacting_updates)}

        Provide:
        1. Pre-validation commands
        2. Package verification commands
        3. Security check commands
        4. Service status commands
        5. System health commands
        6. Post-update verification commands

        Format as a markdown list with command descriptions.
        """
        return [
            {"role": "system", "content": "You are an expert RHEL system administrator."},
            {"role": "user", "content": prompt}
        ]


class RHELPatchAnalyzer:
    def __init__(self, config_file: str = "config.xml"):
        """Initialize RHEL Patch Analyzer"""
        try:
            self.config = Config.from_xml(config_file)
            self.config.validate_config()
        except Exception as e:
            raise ValueError(f"Configuration error: {e}")
        
        # Get current script directory
        self.script_dir = Path(os.path.dirname(os.path.abspath(__file__)))
        self.log_dir = self.script_dir / "patch_analysis_logs"
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.prompt_generator = EnhancedPromptGenerator()

        # Ollama AI models configuration (from config)
        self.models = self.config.MODEL_CONFIG

        # Ollama API URL from config
        self.ollama_api = f"{self.config.OLLAMA_BASE_URL}/api/generate"
       

        # Setup logging
        self._setup_logging()

    def _setup_logging(self):
        """Configure logging"""
        log_file = self.log_dir / "patch_analysis.log"
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        logging.info(f"RHEL Patch Analyzer Initialized. Log file: {log_file}")

    def _run_command(self, command: List[str], capture_all: bool = False) -> Dict[str, Any]:
        """Execute shell command with error handling"""
        try:
            result = subprocess.run(
                command, 
                capture_output=True, 
                text=True, 
                timeout=self.config.COMMAND_TIMEOUT
            )
            output = result.stdout.strip()
            if capture_all:
                return {'success': True, 'output': output}
            else:
                return {'success': True, 'output': '\n'.join(output.split('\n')[1:])}
        except subprocess.TimeoutExpired:
            logging.error(f"Command '{' '.join(command)}' timed out")
            return {'success': False, 'output': ''}
        except Exception as e:
            logging.error(f"Command '{' '.join(command)}' failed with error: {e}")
            return {'success': False, 'output': ''}
    
    def _get_system_health(self) -> Dict[str, Any]:
        """Gather system health metrics with improved CPU load parsing."""
        try:
            # Get CPU load with detailed parsing
            cpu_info = {}
            
            # Get load averages directly from /proc/loadavg
            try:
                with open('/proc/loadavg', 'r') as f:
                    loads = f.read().strip().split()[:3]
                    cpu_info['load_avg'] = f"1min: {loads[0]}, 5min: {loads[1]}, 15min: {loads[2]}"
            except (IOError, IndexError):
                # Fallback to uptime command if /proc/loadavg fails
                uptime_result = self._run_command(["uptime"])
                if uptime_result['success']:
                    # Parse load average from uptime output
                    uptime_output = uptime_result['output']
                    if 'load average:' in uptime_output:
                        loads = uptime_output.split('load average:')[1].strip().split(',')
                        cpu_info['load_avg'] = f"1min: {loads[0]}, 5min: {loads[1]}, 15min: {loads[2]}"
                    else:
                        cpu_info['load_avg'] = "N/A"
                else:
                    cpu_info['load_avg'] = "N/A"

            # Get CPU utilization
            top_result = self._run_command(["top", "-bn1"])
            if top_result['success']:
                try:
                    cpu_line = next(line for line in top_result['output'].split('\n') 
                                  if '%Cpu' in line)
                    cpu_info['utilization'] = cpu_line.strip()
                except (StopIteration, IndexError):
                    cpu_info['utilization'] = "N/A"

            # Combine CPU metrics
            cpu_load = (f"Load Average: {cpu_info.get('load_avg', 'N/A')}\n"
                       f"CPU Usage: {cpu_info.get('utilization', 'N/A')}")

            # Get other metrics
            metrics = {
                'disk_space': self._run_command(["df", "-h"])['output'],
                'memory_usage': self._run_command(["free", "-h"])['output'],
                'cpu_load': cpu_load,
                'cpu_info': self._run_command(["lscpu"])['output'],
                'active_services': len(self._run_command(
                    ["systemctl", "list-units", "--type=service", "--state=running"]
                )['output'].splitlines())
            }

            return metrics

        except Exception as e:
            logging.error(f"Error getting system health: {str(e)}")
            return {
                'disk_space': 'N/A',
                'memory_usage': 'N/A',
                'cpu_load': 'N/A',
                'cpu_info': 'N/A',
                'active_services': 0
            }

    def analyze_system_updates(self) -> PatchAnalysis:
        """Analyze system updates"""
        logging.info("Starting system update analysis")

        # Get all updates
        updates_result = self._run_command(["dnf", "list", "updates"], capture_all=True)
        if not updates_result['success']:
            raise RuntimeError("Failed to retrieve system updates")

        package_updates = updates_result['output'].split('\n')
        security_updates = [u for u in package_updates if "Security" in u]
        kernel_updates = [u for u in package_updates if "kernel" in u]
        service_impacting_updates = [u for u in package_updates if "Service" in u]
        reboot_required = any("kernel" in u for u in package_updates)
        estimated_downtime = "30 minutes"  # Placeholder
        risk_level = "Medium"  # Placeholder

        return PatchAnalysis(
            timestamp=datetime.now().isoformat(),
            total_updates=len(package_updates),
            security_updates=len(security_updates),
            critical_updates=len([u for u in security_updates if "Critical" in u]),
            package_updates=package_updates,
            kernel_updates=kernel_updates,
            service_impacting_updates=service_impacting_updates,
            reboot_required=reboot_required,
            estimated_downtime=estimated_downtime,
            risk_level=risk_level
        )

    async def _make_api_call(self, prompt_messages: List[Dict], model_type: str) -> str:
        """Enhanced model interaction with better error handling"""
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }

        for attempt in range(self.config.API_RETRIES):
             try:
                 timeout = aiohttp.ClientTimeout(total=self.config.MODEL_CONFIG[model_type]['timeout'])
                 async with aiohttp.ClientSession(timeout=timeout) as session:
                     async with session.post(
                        f"{self.config.OLLAMA_BASE_URL}/api/generate",
                        json={
                             "model": self.config.MODEL_CONFIG[model_type]['name'],
                             "prompt": prompt_messages[1]['content'],
                             "stream": False,
                             "temperature": self.config.MODEL_CONFIG[model_type]['temperature']
                        },
                        headers=headers
                     ) as response:
                         if response.status == 200:
                             result = await response.json()
                             response_text = result.get('response', '')
                             if response_text:
                                 return response_text
                             else:
                                 logging.warning(f"Empty response from model on attempt {attempt + 1}")
                         else:
                             error_text = await response.text()
                             logging.error(f"API call failed with status {response.status}: {error_text}")
                             
                 if attempt < self.config.API_RETRIES - 1:
                     delay = 2 ** attempt
                     logging.info(f"Retrying in {delay} seconds...")
                     await asyncio.sleep(delay)
                     
             except asyncio.TimeoutError:
                 logging.error(f"Timeout on attempt {attempt + 1}")
             except Exception as e:
                 logging.error(f"API call error on attempt {attempt + 1}: {str(e)}")
                 if attempt == self.config.API_RETRIES - 1:
                     return f"Error calling model: {str(e)}"

        return "Failed to get response after all retries. Using fallback analysis."

    async def generate_ai_analysis(self, patch_info: PatchInfo, patch_analysis: PatchAnalysis) -> Dict[str, str]:
        """Generate comprehensive AI-powered analysis"""
        
        # Get system health metrics
        system_health = self._get_system_health()
        analysis_prompt = self.prompt_generator.create_analysis_prompt(patch_info, system_health)
        try:
             analysis_text = await self._make_api_call(analysis_prompt, 'technical')
             implications_result = await self.analyze_patch_implications(patch_analysis,system_health)
             if analysis_text.startswith('Error') or not analysis_text:
                 return {'analysis': 'Unable to generate analysis. Using fallback analysis.\n\n' + 
                                  f'Found {patch_analysis.total_updates} total updates, ' +
                                  f'{patch_analysis.security_updates} security updates.',
                            'implications': implications_result.get('implications', 'No implications could be determined.')}

             return {'analysis': analysis_text,
                    'implications': implications_result.get('implications', 'No implications could be determined.')}

        except Exception as e:
            logging.error(f"AI analysis error: {e}")
            return {'analysis': f"Error generating analysis: {e}",
                     'implications':  'No implications could be determined.'}
        
    async def analyze_patch_implications(self, patch_analysis: PatchAnalysis, system_health: Dict) -> Dict[str, str]:
        """Use reasoning model to analyze patch implications"""
        prompt_messages = self.prompt_generator.create_implication_prompt(patch_analysis, system_health)
        try:
             implications = await self._make_api_call(prompt_messages, 'reasoning')
             return {'implications': implications}
        except Exception as e:
             logging.error(f"Reasoning analysis error: {sanitize_error_message(str(e))}")
             return {'implications': f"Error in reasoning: {sanitize_error_message(str(e))}"}

    async def generate_ansible_playbook(self, patch_info: PatchInfo, patch_analysis: PatchAnalysis) -> str:
        """Generate Ansible playbook for patch implementation"""
        playbook_prompt = self.prompt_generator.create_playbook_prompt(patch_info)

        try:
            playbook_text = await self._make_api_call(playbook_prompt, 'code')
            return playbook_text
        except Exception as e:
           logging.error(f"Playbook generation error: {e}")
           return f"Error generating playbook: {e}"

    async def generate_additional_playbook(self, patch_analysis: PatchAnalysis) -> str:
          """Generate an additional Ansible playbook based on patch updates with dynamic validation commands"""
          playbook_prompt = f"""
              Based on the following patch updates:
              - Total Updates: {patch_analysis.total_updates}
              - Security Updates: {patch_analysis.security_updates}
              - Kernel Updates: {len(patch_analysis.kernel_updates)}
              - Service Impacting: {len(patch_analysis.service_impacting_updates)}
              - Reboot Required: {patch_analysis.reboot_required}

              Generate a comprehensive Ansible playbook for RHEL9 system patching with:

              1. Pre-check Tasks:
                  - Gather facts about the system
                  - Check for sufficient disk space
                  - Check CPU and memory utilization
                  - Check current kernel version and installed packages
              2. Backups:
                  - Perform a backup of the system configuration
              3. Updates:
                  - Update all packages with dnf, ensuring any required repos are enabled
                  - Install security updates first
                  - Install kernel updates if present
                  - Install other updates
                  - Handle service-impacting updates with service restart if needed
              4. Post-updates:
                  - Verify system stability
                  - Verify updated packages
                  - Verify updated kernel version
              5. Reboot if needed
              6. Error handling with rollback

              Also, Include appropriate validation commands in your playbook for:
                  - Package status checks
                  - System health verification
                  - Service status verification
                  - Update history tracking
                  - Kernel version verification
                  - Package installation dates

              Format as a complete, executable Ansible playbook with:
              - All necessary variables
              - Proper error handling
              - Clear task names
              - Task tags
              - Handlers for service restarts
              - Comments explaining each section
              - Validation commands in appropriate tasks
          """

          try:
             prompt_messages = [
                {"role": "system", "content": "You are an expert RHEL system administrator generating an Ansible playbook."},
                {"role": "user", "content": playbook_prompt}
             ]
             playbook_text = await self._make_api_call(prompt_messages, 'code')
        
             if playbook_text.startswith('Error') or not playbook_text:
                # Fallback playbook with basic structure
                 return """---
# Basic RHEL9 Update Playbook
- name: RHEL9 System Update and Verification
  hosts: all
  become: yes
  
  vars:
    backup_dir: "/var/backup/system_update_{{ ansible_date_time.date }}"
    
  tasks:
    - name: Pre-update system check
      block:
        - name: Check available disk space
          shell: df -h
          register: disk_space
          
        - name: Verify current package status
          shell: rpm -qa
          register: package_status
          
    - name: Backup critical configurations
      file:
        path: "{{ backup_dir }}"
        state: directory
        
    - name: Update all packages
      dnf:
        name: '*'
        state: latest
      tags: [general]
        
    - name: Post-update verification
      shell: |
        rpm -qa
        uptime
        uname -r
      register: verification_result
"""
             return playbook_text
            
          except Exception as e:
            logging.error(f"Additional playbook generation error: {str(e)}")
            return f"Error generating additional playbook: {str(e)}"

    async def get_validation_commands(self, patch_analysis: PatchAnalysis) -> str:
        """Get dynamically generated validation commands"""
        try:
            prompt_messages = self.prompt_generator.create_validation_commands_prompt(patch_analysis)
            commands = await self._make_api_call(prompt_messages, 'technical')
            
            if commands.startswith('Error') or not commands:
                # Fallback validation commands
                return """
                ## Pre-validation Commands:
                - `df -h` : Check disk space
                - `free -m` : Check memory
                - `uptime` : Check system load
                
                ## Package Verification:
                - `rpm -qa` : List installed packages
                - `dnf list updates` : Check available updates
                
                ## Security Checks:
                - `dnf updateinfo list security` : List security updates
                - `rpm -Va` : Verify package integrity
                
                ## System Status:
                - `systemctl status` : Check all service statuses
                - `systemctl list-units --state=failed` : Check for failed services
                - `systemctl list-units --type=service` : List all services

                ## Post-update Verification Commands:
                - `uname -r` : Verify current kernel version
                - `rpm -qa | grep ^kernel` : List installed kernel packages
                - `dnf repolist` : Verify repository status
                - `dnf check` : Run DNF consistency check
                - `rpm -q --last kernel`: Check last installed kernel package
                - `rpm -q --last <package>`: Check last installed date of a package.
"""
            
            return commands

        except Exception as e:
            logging.error(f"Error generating validation commands: {str(e)}")
            return "Error generating validation commands. Please check logs for details."

    async def generate_patch_report(self) -> tuple[str, str, str]:
        """Generate comprehensive patch analysis report and playbook"""
        try:
            start_time = time.time()
            # Analyze updates
            patch_analysis = self.analyze_system_updates()

            #Get system health
            system_health = self._get_system_health()
             # Create a PatchInfo object from the PatchAnalysis
            patch_info = PatchInfo(
                total_updates = patch_analysis.total_updates,
                security_updates = patch_analysis.security_updates,
                critical_updates = patch_analysis.critical_updates,
                system_packages = patch_analysis.package_updates,
                kernel_updates = patch_analysis.kernel_updates,
                last_patched = "N/A", # Placeholder, we will add in the next iteration,
                reboot_required = patch_analysis.reboot_required
                )
            # Generate AI analysis
            ai_analysis = await self.generate_ai_analysis(patch_info, patch_analysis)
            patch_analysis.detailed_report = ai_analysis['analysis']
            
            # Analyze patch implications
            implications_result = await self.analyze_patch_implications(patch_analysis,system_health)
            patch_analysis.implications = implications_result.get('implications', 'No implications could be determined.')

            # Generate playbook
            playbook_content = await self.generate_ansible_playbook(patch_info, patch_analysis)

            # Generate additional playbook
            additional_playbook_content = await self.generate_additional_playbook(patch_analysis)
            
            #Get dynamic Validation Commands
            validation_commands = await self.get_validation_commands(patch_analysis)

            # Create timestamp for files
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report_path = self.log_dir / f"patch_report_{timestamp}.md"
            playbook_path = self.log_dir / f"patch_playbook_{timestamp}.yml"
            additional_playbook_path = self.log_dir / f"additional_patch_playbook_{timestamp}.yml"
            end_time = time.time()
            elapsed_time = end_time - start_time
            # Create report as Markdown with Jinja
            report_template = Template("""
                # RHEL9 Patch Analysis Report

                **Executive Summary:**
                - Total Updates: {{ patch_analysis.total_updates }}
                - Security Updates: {{ patch_analysis.security_updates }}
                - Critical Updates: {{ patch_analysis.critical_updates }}
                - Reboot Required: {{ 'Yes' if patch_analysis.reboot_required else 'No' }}
                - Estimated Downtime: {{ patch_analysis.estimated_downtime }}
                - Analysis Duration: {{ "%.2f"|format(elapsed_time) }} seconds

                **System Health:**
                - CPU Load: {{ system_health.cpu_load }}
                - CPU Info: {{ system_health.cpu_info.split('\\n')[0] }}
                - Memory Usage: {{ system_health.memory_usage.split('\\n')[0] }}
                - Disk Space: {{ system_health.disk_space.split('\\n')[0] }}
                - Active Services: {{ system_health.active_services }}

                **AI Analysis:**
                {{ ai_analysis.analysis }}
                 
                **Implications:**
                {{ patch_analysis.implications }}

                **Update Details:**
                
                ## Kernel Updates:
                {% for update in patch_analysis.kernel_updates %}
                - {{ update }}
                {% endfor %}

                ## Service-Impacting Updates:
                {% for update in patch_analysis.service_impacting_updates %}
                - {{ update }}
                {% endfor %}

                ## All Package Updates:
                {% for update in patch_analysis.package_updates %}
                - {{ update }}
                {% endfor %}
            
                **Validation Commands:**
                {{ validation_commands }}
                """)
            rendered_report = report_template.render(
                patch_analysis=patch_analysis,
                ai_analysis=ai_analysis,
                system_health = system_health,
                elapsed_time=elapsed_time,
                validation_commands=validation_commands
            )

            # Write report
            with open(report_path, 'w') as report:
                report.write(rendered_report)

            # Write playbook
            with open(playbook_path, 'w') as playbook:
                playbook.write(playbook_content)

            # Write additional playbook
            with open(additional_playbook_path, 'w') as additional_playbook:
                additional_playbook.write(additional_playbook_content)

            logging.info(f"Report generated: {report_path}")
            logging.info(f"Playbook generated: {playbook_path}")
            logging.info(f"Additional playbook generated: {additional_playbook_path}")

            return report_path, playbook_path, additional_playbook_path

        except Exception as e:
            logging.error(f"Report generation error: {e}")
            raise


async def main():
    """Main execution function"""
    parser = argparse.ArgumentParser(description='RHEL9 Patch Analysis System')
    parser.add_argument('--config', type=str, default='config.xml',
                       help='Path to configuration file')
    args = parser.parse_args()

    print("\n=== RHEL9 Patch Analysis System ===\n")

    try:
        analyzer = RHELPatchAnalyzer(config_file=args.config)
        print("Analyzing system patches...\n")

        report_path, playbook_path, additional_playbook_path = await analyzer.generate_patch_report()

        print(f"Analysis complete!")
        print(f"Report generated: {report_path}")
        print(f"Playbook generated: {playbook_path}")
        print(f"Additional playbook generated: {additional_playbook_path}")

    except KeyboardInterrupt:
        print("\nAnalysis interrupted by user")
    except Exception as e:
        print(f"\nError: {e}")
        logging.error(f"Main execution error: {e}")

if __name__ == "__main__":
    asyncio.run(main())