#python3 rhel9ssh.py --config=config.xml
sudo python3 rhel9ssh.py --config=config.xml
