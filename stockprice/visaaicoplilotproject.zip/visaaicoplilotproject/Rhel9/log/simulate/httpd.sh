#!/bin/bash

# Test Script for RHEL 9 Log Analyzer - Apache Configuration Errors
# This script intentionally creates configuration errors to generate log entries

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print status messages
print_status() {
    echo -e "${GREEN}[*]${NC} $1"
}

print_error() {
    echo -e "${RED}[!]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

# Check if script is run as root
if [ "$EUID" -ne 0 ]; then
    print_error "Please run as root"
    exit 1
fi

# Check if running on RHEL 9
check_rhel_version() {
    if [ -f /etc/redhat-release ]; then
        if ! grep -q "Red Hat Enterprise Linux release 9" /etc/redhat-release; then
            print_warning "This script is designed for RHEL 9. Your system may be different."
        fi
    else
        print_warning "Cannot determine if this is RHEL 9. Proceeding anyway..."
    fi
}

# Backup original configuration
backup_config() {
    print_status "Creating backup of original Apache configuration..."
    if [ -f /etc/httpd/conf/httpd.conf ]; then
        cp /etc/httpd/conf/httpd.conf /etc/httpd/conf/httpd.conf.backup.$(date +%Y%m%d_%H%M%S)
        print_status "Backup created successfully"
    else
        print_error "Apache configuration file not found"
        exit 1
    fi
}

# Install Apache if not present
install_apache() {
    print_status "Checking for Apache installation..."
    if ! rpm -q httpd > /dev/null; then
        print_status "Installing Apache..."
        dnf install httpd -y
        if [ $? -ne 0 ]; then
            print_error "Failed to install Apache"
            exit 1
        fi
    else
        print_status "Apache is already installed"
    fi
}

# Create problematic configuration
create_bad_config() {
    print_status "Creating problematic Apache configuration..."
    
    # Bad port configuration
    sed -i 's/Listen 80/Listen 80800/' /etc/httpd/conf/httpd.conf
    
    # Add non-existing virtual hosts and problematic configurations
    cat >> /etc/httpd/conf/httpd.conf << 'EOL'

# Test Configuration - Intentionally problematic virtual hosts
<VirtualHost *:80>
    ServerName example.com
    DocumentRoot /var/www/non_existing_dir
    # Intentionally problematic SSL configuration
    SSLEngine on
    SSLCertificateFile /etc/pki/non_existing_cert.pem
    <Directory /var/www/non_existing_dir>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
        # Invalid directive
        RequireSSL maybe
    </Directory>
</VirtualHost>

<VirtualHost *:80>
    ServerName test.com
    DocumentRoot /var/www/non_existing_test_dir
    # Invalid configuration directive
    MaxRequestWorkers invalid
    <Directory /var/www/non_existing_test_dir>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
        # Intentionally incorrect syntax
        Order allow,deny
        Allow from
    </Directory>
</VirtualHost>

# Intentionally malformed directives
RequireAll
MaxClients xyz
ThreadsPerChild none

# Bad module configuration
LoadModule nonexistent_module modules/mod_nonexistent.so
LoadModule ssl_module /wrong/path/mod_ssl.so

# Invalid MIME type configuration
AddType text/plain ..html
EOL

    # Create an invalid .htaccess file
    mkdir -p /var/www/html/test
    cat > /var/www/html/test/.htaccess << 'EOL'
# Invalid .htaccess configuration
RewriteEngine On
RewriteRule ^index\.html$ - [L]]  # Intentional syntax error
AuthType Basic
# Missing required directives for auth
Require valid-user
EOL
}

# Attempt to start Apache
test_apache_start() {
    print_status "Attempting to start Apache with bad configuration..."
    systemctl start httpd
    sleep 2
    
    # Check Apache status
    if systemctl is-active --quiet httpd; then
        print_warning "Apache started successfully (unexpected)"
    else
        print_status "Apache failed to start (expected behavior)"
    fi
    
    # Display relevant log entries
    print_status "Checking error log..."
    if [ -f /var/log/httpd/error_log ]; then
        tail -n 20 /var/log/httpd/error_log
    else
        print_error "Error log not found"
    fi
}

# Enable error logging
configure_logging() {
    print_status "Configuring detailed error logging..."
    
    # Ensure the log directory exists
    mkdir -p /var/log/httpd
    
    # Set appropriate permissions
    chown apache:apache /var/log/httpd
    chmod 755 /var/log/httpd
    
    # Add additional logging configuration
    cat >> /etc/httpd/conf/httpd.conf << 'EOL'

# Enhanced error logging configuration
LogLevel debug
ErrorLog /var/log/httpd/error_log
CustomLog /var/log/httpd/access_log combined
EOL
}

# Cleanup function
cleanup() {
    print_status "Would you like to restore the original configuration? (y/n)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])+$ ]]; then
        if [ -f /etc/httpd/conf/httpd.conf.backup.* ]; then
            cp /etc/httpd/conf/httpd.conf.backup.* /etc/httpd/conf/httpd.conf
            systemctl restart httpd
            print_status "Original configuration restored"
        else
            print_error "Backup file not found"
        fi
    fi
}

# Main execution
main() {
    print_status "Starting Apache test configuration script for RHEL 9..."
    
    # Execute functions
    check_rhel_version
    install_apache
    backup_config
    configure_logging
    create_bad_config
    test_apache_start
    
    print_status "Test configuration complete. Check /var/log/httpd/error_log for details"
    cleanup
}

# Run main function
main