#!/usr/bin/env python3
import asyncio
import aiohttp
import json
import logging
import os
import subprocess
import time
import platform
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Any, Optional
import psutil
import requests
import re
from jinja2 import Template
from pathlib import Path
import xml.etree.ElementTree as ET
from dotenv import load_dotenv
import sys
import random
from enum import Enum
import atexit

load_dotenv()

class HealthStatusCategory(Enum):
    """Enum for Health Status Categories."""
    RESOURCE = "resource"
    SERVICE = "service"
    SECURITY = "security"
    INFRASTRUCTURE = "infrastructure"
    ERROR = "error"
    AI_ENHANCED = "ai_enhanced"
    FALSE_POSITIVE = "false_positive"
    MONITORING = "monitoring"
    
class HealthStatusPriority(Enum):
    """Enum for Health Status Priorities."""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class RHELMonitorConfig:
    """Enhanced configuration management for RHEL Monitor"""
    LOG_DIR: str = str(Path.home() / "rhel9_monitor")
    COMMAND_TIMEOUT: int = 300
    API_RETRIES: int = 5
    CACHE_DURATION: int = 3600
    MODEL_CONFIG: Dict[str, Dict] = field(default_factory=dict)
    OLLAMA_BASE_URL: Optional[str] = os.getenv("OLLAMA_API_URL", None)
    OLLAMA_ENDPOINTS: Dict[str, str] = field(default_factory=lambda: {
        "generate": "/api/generate",
        "status": "/api/status",
        "models": "/api/tags"
    })
    OLLAMA_HEADERS: Dict[str, str] = field(default_factory=lambda: {
        "Content-Type": "application/json",
        "Accept": "application/json"
    })
    OLLAMA_RETRY_CONFIG: Dict[str, int] = field(default_factory=lambda: {
        "max_attempts": 5,
        "min_delay": 1,
        "max_delay": 10
    })
    OLLAMA_RATE_LIMIT: Dict[str, int] = field(default_factory=lambda: {
        "calls": 10,
        "period": 60
    })
    METADATA_URL: str = ""
    DEFAULT_INTERVAL: int = 300
    COMMAND_WHITELIST: List[str] = field(default_factory=lambda: [
        "systemctl", "ss", "ifconfig", "grep", "uptime", "dnf", "date", "cat",
        "httpd", "apachectl", "rpm", "dpkg-query", "apt", "apt-get", "aa-status", "ufw",
        "lsblk", "fdisk", "sestatus", "firewall-cmd", "ip", "who"
    ])
    MAX_HISTORY_ITEMS: int = 100
    RESOURCE_THRESHOLDS: Dict[str, Dict[str, int]] = field(default_factory=lambda: {
            'cpu': {'healthy': 70, 'warning': 85},
            'memory': {'healthy': 80, 'warning': 90},
            'disk': {'healthy': 75, 'warning': 85},
            'swap': {'healthy': 20, 'warning': 50}
        })
    METADATA_ENDPOINTS: Dict[str, str] = field(default_factory=lambda: {
        'base_url': 'http://169.254.169.254',
        'token_url': '/latest/api/token',
        'document_url': '/latest/dynamic/instance-identity/document'
    })
    METADATA_TTL: int = 21600  # Token time to live in seconds
    
    def __post_init__(self):
      if not self.OLLAMA_BASE_URL:
            raise ValueError("Ollama base url cannot be empty, provide OLLAMA_API_URL or set in config.xml")
      if not all(self.MODEL_CONFIG.values()):
            raise ValueError("Invalid Configuration, Please check model values")
      for model_config in self.MODEL_CONFIG.values():
          if not all(model_config.values()):
             raise ValueError("Invalid Configuration, Please check model values")
          
@dataclass
class SystemMetrics:
    """Store system metrics"""
    timestamp: str
    hostname: str
    os_version: str
    kernel_version: str
    uptime: str
    cpu_usage: float
    memory_used: float
    memory_total: float
    swap_used: float
    swap_total: float
    disk_usage: Dict[str, Any]
    updates_pending: int
    security_updates: int
    network_metrics: Dict[str, Any]
    top_processes: List[Dict[str, Any]]
    service_status: Dict[str, str]
    load_average: Dict[str, float]
    instance_metadata: Dict[str, Any]
    open_ports: List[str]
    syslog_errors: List[str]
    health_status: Optional['ServerHealthStatus'] = None
    ai_validation: Optional['SystemMetricsAI'] = None


@dataclass
class ServerHealthStatus:
    """Store server health assessment results"""
    resource_health: Dict[str, Dict[str, Any]]
    service_health: Dict[str, Dict[str, Any]]
    security_health: Dict[str, Dict[str, Any]]
    infrastructure_health: Dict[str, Dict[str, Any]]
    error_status: Dict[str, Dict[str, Any]]
    overall_score: float
    health_status: str
    recommendations: List[Dict[str, str]]

@dataclass
class SystemMetricsAI:
    """Store AI validation results"""
    validated_components: Dict[str, Dict[str, Any]]
    adjustments: List[str]
    false_positives: List[str]
    additional_metrics: List[str]
    recommendations: List[str]
    confidence_score: float
    overall_assessment: str


# Add these functions right after ServerHealthStatus class definition
def serialize_health_status(health_status: ServerHealthStatus) -> dict:
    """Convert ServerHealthStatus to a dictionary for JSON serialization."""
    return {
        'resource_health': health_status.resource_health,
        'service_health': health_status.service_health,
        'security_health': health_status.security_health,
        'infrastructure_health': health_status.infrastructure_health,
        'error_status': health_status.error_status,
        'overall_score': health_status.overall_score,
        'health_status': health_status.health_status,
        'recommendations': health_status.recommendations
    }

def serialize_metrics(metrics: SystemMetrics) -> dict:
    """Convert SystemMetrics to a dictionary for JSON serialization."""
    metrics_dict = {
        'timestamp': metrics.timestamp,
        'hostname': metrics.hostname,
        'os_version': metrics.os_version,
        'kernel_version': metrics.kernel_version,
        'uptime': metrics.uptime,
        'cpu_usage': metrics.cpu_usage,
        'memory_used': metrics.memory_used,
        'memory_total': metrics.memory_total,
        'swap_used': metrics.swap_used,
        'swap_total': metrics.swap_total,
        'disk_usage': metrics.disk_usage,
        'updates_pending': metrics.updates_pending,
        'security_updates': metrics.security_updates,
        'network_metrics': metrics.network_metrics,
        'top_processes': metrics.top_processes,
        'service_status': metrics.service_status,
        'load_average': metrics.load_average,
        'instance_metadata': metrics.instance_metadata,
        'open_ports': metrics.open_ports,
        'syslog_errors': metrics.syslog_errors,
    }
    
    if metrics.health_status:
        metrics_dict['health_status'] = serialize_health_status(metrics.health_status)
    
    if metrics.ai_validation:
         metrics_dict['ai_validation'] = {
                'validated_components': metrics.ai_validation.validated_components,
                'adjustments': metrics.ai_validation.adjustments,
                'false_positives': metrics.ai_validation.false_positives,
                'additional_metrics': metrics.ai_validation.additional_metrics,
                'recommendations': metrics.ai_validation.recommendations,
                'confidence_score': metrics.ai_validation.confidence_score,
                'overall_assessment': metrics.ai_validation.overall_assessment
        }
    
    return metrics_dict


class HealthAssessment:
    """Health assessment functionality for RHELMonitor"""
    
    def __init__(self, rhel_monitor, resource_thresholds=None):
        """Initialize with reference to RHELMonitor instance"""
        self.monitor = rhel_monitor
        self.RESOURCE_THRESHOLDS = resource_thresholds if resource_thresholds else {
            'cpu': {'healthy': 70, 'warning': 85},
            'memory': {'healthy': 80, 'warning': 90},
            'disk': {'healthy': 75, 'warning': 85},
            'swap': {'healthy': 20, 'warning': 50}
        }
        

    def assess_resource_health(self, metrics: SystemMetrics) -> Dict[str, Dict[str, Any]]:
        """Assess resource utilization health"""
        resource_health = {}
        
        # CPU Assessment
        cpu_status = {
            'value': metrics.cpu_usage,
            'status': 'healthy' if metrics.cpu_usage < self.RESOURCE_THRESHOLDS['cpu']['healthy']
                     else 'warning' if metrics.cpu_usage < self.RESOURCE_THRESHOLDS['cpu']['warning']
                     else 'critical',
            'threshold': self.RESOURCE_THRESHOLDS['cpu']['healthy']
        }
        resource_health['cpu'] = cpu_status

        # Memory Assessment
        memory_usage_percent = (metrics.memory_used / metrics.memory_total) * 100
        memory_status = {
            'value': memory_usage_percent,
            'status': 'healthy' if memory_usage_percent < self.RESOURCE_THRESHOLDS['memory']['healthy']
                     else 'warning' if memory_usage_percent < self.RESOURCE_THRESHOLDS['memory']['warning']
                     else 'critical',
            'threshold': self.RESOURCE_THRESHOLDS['memory']['healthy']
        }
        resource_health['memory'] = memory_status

        # Disk Assessment
        disk_status = {
            'value': metrics.disk_usage['percent'],
            'status': 'healthy' if metrics.disk_usage['percent'] < self.RESOURCE_THRESHOLDS['disk']['healthy']
                     else 'warning' if metrics.disk_usage['percent'] < self.RESOURCE_THRESHOLDS['disk']['warning']
                     else 'critical',
            'threshold': self.RESOURCE_THRESHOLDS['disk']['healthy']
        }
        resource_health['disk'] = disk_status

        # Load Average Assessment
        cpu_count = psutil.cpu_count()
        load_avg_status = {
            'value': metrics.load_average['15min'],
            'status': 'healthy' if metrics.load_average['15min'] < cpu_count * 0.8
                     else 'warning' if metrics.load_average['15min'] < cpu_count
                     else 'critical',
            'threshold': cpu_count * 0.8
        }
        resource_health['load_average'] = load_avg_status

        return resource_health

    def assess_service_health(self, metrics: SystemMetrics) -> Dict[str, Dict[str, Any]]:
        """Assess critical service health"""
        service_health = {}
        critical_services = {
            'sshd': True,  # Must be running
            'firewalld': True,  # Must be running
            'chronyd': True  # Must be running
        }
        
        for service, status in metrics.service_status.items():
            if service in critical_services:
                service_health[service] = {
                    'status': 'healthy' if status == 'active' else 'critical',
                    'value': status,
                    'required': critical_services[service]
                }
        
        return service_health

    def assess_security_health(self, metrics: SystemMetrics) -> Dict[str, Dict[str, Any]]:
        """Assess security configuration health"""
        security_health = {}
        
        # SELinux Status
        selinux_cmd = self.monitor.run_command(['getenforce'])
        selinux_status = {
            'status': 'healthy' if selinux_cmd['success'] and selinux_cmd['output'].strip() == 'Enforcing' else 'critical',
            'value': selinux_cmd['output'].strip() if selinux_cmd['success'] else "Error retrieving status",
            'required': 'Enforcing'
        }
        security_health['selinux'] = selinux_status

        # Firewall Status
        firewall_status = {
            'status': 'healthy' if metrics.service_status.get('firewalld') == 'active' else 'critical',
            'value': metrics.service_status.get('firewalld', 'unknown'),
            'required': 'active'
        }
        security_health['firewall'] = firewall_status

        # Updates Status
        updates_status = {
            'status': 'healthy' if metrics.security_updates == 0 else 'critical',
            'value': metrics.security_updates,
            'threshold': 0
        }
        security_health['security_updates'] = updates_status

        return security_health

    def assess_infrastructure_health(self, metrics: SystemMetrics) -> Dict[str, Dict[str, Any]]:
        """Assess infrastructure redundancy"""
        infrastructure_health = {}
        
        # Network Redundancy
        nic_count = len([iface for iface in metrics.network_metrics.keys() 
                        if not iface.startswith(('lo', 'docker'))])
        network_status = {
            'status': 'healthy' if nic_count >= 2 else 'critical',
            'value': nic_count,
            'required': 2
        }
        infrastructure_health['network_redundancy'] = network_status

        # Storage Redundancy (Basic check for multiple disks)
        disk_cmd = self.monitor.run_command(['lsblk', '-d', '-n'])
        disk_count = len([line for line in disk_cmd['output'].splitlines() 
                         if not any(x in line for x in ['loop', 'sr'])]) if disk_cmd['success'] else 0
        storage_status = {
            'status': 'healthy' if disk_count >= 2 else 'critical',
            'value': disk_count,
            'required': 2
        }
        infrastructure_health['storage_redundancy'] = storage_status

        return infrastructure_health

    def assess_error_status(self, metrics: SystemMetrics) -> Dict[str, Dict[str, Any]]:
        """Assess system errors"""
        error_status = {}
        
        # Analyze syslog errors
        error_count = len(metrics.syslog_errors)
        critical_keywords = ['error', 'failure', 'failed', 'critical']
        critical_errors = sum(1 for error in metrics.syslog_errors 
                            if any(keyword in error.lower() for keyword in critical_keywords))
        
        error_severity = {
            'status': 'healthy' if error_count == 0 
                     else 'warning' if critical_errors == 0 
                     else 'critical',
            'value': error_count,
            'critical_count': critical_errors,
            'threshold': 0
        }
        error_status['syslog'] = error_severity

        return error_status

    def calculate_health_score(self, health_components: Dict[str, Dict[str, Dict[str, Any]]]) -> float:
        """Calculate overall health score"""
        component_weights = {
            'resource_health': 0.25,
            'service_health': 0.20,
            'security_health': 0.25,
            'infrastructure_health': 0.20,
            'error_status': 0.10
        }

        component_scores = {}
        for component, items in health_components.items():
            healthy_count = sum(1 for item in items.values() 
                              if item['status'] == 'healthy')
            total_count = len(items)
            component_scores[component] = (healthy_count / total_count) * 100 if total_count > 0 else 0

        overall_score = sum(score * component_weights[component] 
                          for component, score in component_scores.items())
        return round(overall_score, 2)

    def determine_health_status(self, score: float) -> str:
        """Determine overall health status based on score"""
        if score >= 90:
            return "HEALTHY"
        elif score >= 75:
            return "PARTIALLY HEALTHY"
        elif score >= 60:
            return "NEEDS ATTENTION"
        else:
            return "UNHEALTHY"

    def generate_recommendations(self, health_components: Dict[str, Dict[str, Dict[str, Any]]]) -> List[Dict[str, str]]:
        """Generate recommendations based on health assessment"""
        recommendations = []

        # Resource recommendations
        resource_health = health_components['resource_health']
        for resource, details in resource_health.items():
            if details['status'] != 'healthy':
                recommendations.append({
                    'priority': HealthStatusPriority.HIGH.value if details['status'] == 'critical' else HealthStatusPriority.MEDIUM.value,
                    'category': HealthStatusCategory.RESOURCE.value,
                    'recommendation': f'Address high {resource} usage (Current: {details["value"]:.1f}%, Threshold: {details["threshold"]}%)'
                })

        # Infrastructure recommendations
        infra_health = health_components['infrastructure_health']
        for component, details in infra_health.items():
            if details['status'] != 'healthy':
                recommendations.append({
                    'priority': HealthStatusPriority.HIGH.value,
                    'category': HealthStatusCategory.INFRASTRUCTURE.value,
                    'recommendation': f'Implement {component} (Current: {details["value"]}, Required: {details["required"]})'
                })

        # Security recommendations
        security_health = health_components['security_health']
        for check, details in security_health.items():
            if details['status'] != 'healthy':
                recommendations.append({
                    'priority': HealthStatusPriority.HIGH.value,
                    'category': HealthStatusCategory.SECURITY.value,
                    'recommendation': f'Address {check} issue (Current: {details["value"]})'
                })

        return recommendations
    
    async def validate_resource_health(self, metrics: SystemMetrics, health_components: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """Use AI to validate and enhance resource health assessment."""
        prompt = f"""
        As an expert system administrator, analyze and validate these RHEL 9 resource health metrics:
        
        Resource Health:
        {json.dumps(health_components, indent=2)}
        
        System Context:
        - CPU Usage: {metrics.cpu_usage:.2f}%
        - Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB
        - Disk Usage: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB
        - Load Average: {json.dumps(metrics.load_average)}
        
        1. Validate the current assessment
        2. Suggest any adjustments to the status
        3. Provide context-aware recommendations
        4. Identify potential false positives or misleading indicators
        5. Suggest additional metrics that should be monitored
        
        Return a JSON object with the following structure:
        {{
            "validated_component": {{...}},
            "adjustments": [...],
            "false_positives": [...],
            "additional_metrics": [...],
            "recommendations": [...],
            "overall_assessment": "string",
            "confidence_score": float
        }}
        """
        
        # Make API call using the technical model for detailed analysis
        validation_result = await self.monitor._make_api_call(prompt, 'technical')
        
        try:
            # Parse the JSON response
            validated_data = json.loads(validation_result) if validation_result else None
            return validated_data
        except json.JSONDecodeError:
            logging.error("Failed to parse AI validation response")
            return None
    
    async def validate_service_health(self, metrics: SystemMetrics, health_components: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """Use AI to validate and enhance service health assessment."""
        prompt = f"""
        As an expert system administrator, analyze and validate these RHEL 9 service health metrics:
        
        Service Health:
        {json.dumps(health_components, indent=2)}
        
        System Context:
         - Service Status: {json.dumps(metrics.service_status)}
        
        1. Validate the current assessment
        2. Suggest any adjustments to the status
        3. Provide context-aware recommendations
        4. Identify potential false positives or misleading indicators
        5. Suggest additional metrics that should be monitored
        
        Return a JSON object with the following structure:
        {{
            "validated_component": {{...}},
            "adjustments": [...],
            "false_positives": [...],
            "additional_metrics": [...],
            "recommendations": [...],
            "overall_assessment": "string",
            "confidence_score": float
        }}
        """
        
        # Make API call using the technical model for detailed analysis
        validation_result = await self.monitor._make_api_call(prompt, 'technical')
        
        try:
            # Parse the JSON response
            validated_data = json.loads(validation_result) if validation_result else None
            return validated_data
        except json.JSONDecodeError:
            logging.error("Failed to parse AI validation response")
            return None
    
    async def validate_security_health(self, metrics: SystemMetrics, health_components: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
            """Use AI to validate and enhance security health assessment."""
            prompt = f"""
            As an expert system administrator, analyze and validate these RHEL 9 security health metrics:
        
            Security Health:
            {json.dumps(health_components, indent=2)}
        
            System Context:
            - SELinux Status: {self.monitor.check_selinux_status()}
            - Firewall Status: {self.monitor.check_firewall_status()}
            - Updates Pending: {metrics.updates_pending}
            - Security Updates: {metrics.security_updates}
            
            1. Validate the current assessment
            2. Suggest any adjustments to the status
            3. Provide context-aware recommendations
            4. Identify potential false positives or misleading indicators
            5. Suggest additional metrics that should be monitored
            
            Return a JSON object with the following structure:
            {{
                "validated_component": {{...}},
                "adjustments": [...],
                "false_positives": [...],
                "additional_metrics": [...],
                "recommendations": [...],
                "overall_assessment": "string",
                "confidence_score": float
            }}
            """
        
            # Make API call using the technical model for detailed analysis
            validation_result = await self.monitor._make_api_call(prompt, 'technical')
        
            try:
                # Parse the JSON response
                validated_data = json.loads(validation_result) if validation_result else None
                return validated_data
            except json.JSONDecodeError:
                 logging.error("Failed to parse AI validation response")
                 return None
    
    async def validate_infrastructure_health(self, metrics: SystemMetrics, health_components: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
            """Use AI to validate and enhance infrastructure health assessment."""
            prompt = f"""
            As an expert system administrator, analyze and validate these RHEL 9 infrastructure health metrics:
        
            Infrastructure Health:
            {json.dumps(health_components, indent=2)}
        
            System Context:
            - Network Metrics: {json.dumps(metrics.network_metrics)}
            
            1. Validate the current assessment
            2. Suggest any adjustments to the status
            3. Provide context-aware recommendations
            4. Identify potential false positives or misleading indicators
            5. Suggest additional metrics that should be monitored
            
            Return a JSON object with the following structure:
            {{
                "validated_component": {{...}},
                "adjustments": [...],
                "false_positives": [...],
                "additional_metrics": [...],
                "recommendations": [...],
                "overall_assessment": "string",
                "confidence_score": float
            }}
            """
        
            # Make API call using the technical model for detailed analysis
            validation_result = await self.monitor._make_api_call(prompt, 'technical')
        
            try:
                # Parse the JSON response
                validated_data = json.loads(validation_result) if validation_result else None
                return validated_data
            except json.JSONDecodeError:
                logging.error("Failed to parse AI validation response")
                return None
            
    async def validate_error_status(self, metrics: SystemMetrics, health_components: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
            """Use AI to validate and enhance error status assessment."""
            prompt = f"""
            As an expert system administrator, analyze and validate these RHEL 9 error status metrics:
            
            Error Status:
            {json.dumps(health_components, indent=2)}
            
            System Context:
            - Syslog Errors: {len(metrics.syslog_errors)} errors found
            
            1. Validate the current assessment
            2. Suggest any adjustments to the status
            3. Provide context-aware recommendations
            4. Identify potential false positives or misleading indicators
            5. Suggest additional metrics that should be monitored
            
            Return a JSON object with the following structure:
            {{
                "validated_component": {{...}},
                "adjustments": [...],
                "false_positives": [...],
                "additional_metrics": [...],
                "recommendations": [...],
                "overall_assessment": "string",
                "confidence_score": float
            }}
            """
        
            # Make API call using the technical model for detailed analysis
            validation_result = await self.monitor._make_api_call(prompt, 'technical')
        
            try:
                # Parse the JSON response
                validated_data = json.loads(validation_result) if validation_result else None
                return validated_data
            except json.JSONDecodeError:
                 logging.error("Failed to parse AI validation response")
                 return None

    async def validate_health_components(self, metrics: SystemMetrics, initial_health_components: Dict[str, Dict[str, Dict[str, Any]]]) -> Optional[Dict[str, Any]]:
        """Use AI to validate and enhance health assessment components with improved error handling."""
        try:
            prompt = f"""
            As an expert system administrator, analyze and validate these RHEL 9 health components:

            Resource Health:
            {json.dumps(initial_health_components['resource_health'], indent=2)}

            Service Health:
            {json.dumps(initial_health_components['service_health'], indent=2)}

            Security Health:
            {json.dumps(initial_health_components['security_health'], indent=2)}

            Infrastructure Health:
            {json.dumps(initial_health_components['infrastructure_health'], indent=2)}

            Error Status:
            {json.dumps(initial_health_components['error_status'], indent=2)}

            System Context:
            - CPU Usage: {metrics.cpu_usage:.2f}%
            - Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB
            - Disk Usage: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB
            - Service Status: {json.dumps(metrics.service_status)}
            - Syslog Errors: {len(metrics.syslog_errors)} errors found

            For each health component:
            1. Validate the current assessment
            2. Suggest any adjustments to the status
            3. Provide context-aware recommendations
            4. Identify potential false positives or misleading indicators
            5. Suggest additional metrics that should be monitored
            
            Return a JSON object with the following structure:
            {{
                "validated_components": {{
                    "resource_health": {{...}},
                    "service_health": {{...}},
                    "security_health": {{...}},
                    "infrastructure_health": {{...}},
                    "error_status": {{...}}
                }},
                "adjustments": [...],
                "false_positives": [...],
                "additional_metrics": [...],
                "recommendations": [...],
                "overall_assessment": "string",
                "confidence_score": float
            }}
            """
            
            # Make API call using the technical model for detailed analysis
            validation_result = await self.monitor._make_api_call(prompt, 'technical')
            
            if not validation_result:
                logging.warning("AI validation returned empty result, using default assessment")
                return self._create_default_validation()

            try:
                # Parse the JSON response with error handling
                validated_data = json.loads(validation_result)
                
                # Validate the required fields are present
                required_fields = ['validated_components', 'adjustments', 'false_positives', 
                                 'additional_metrics', 'recommendations', 'overall_assessment', 
                                 'confidence_score']
                
                for field in required_fields:
                    if field not in validated_data:
                        logging.warning(f"Missing required field in AI validation: {field}")
                        validated_data[field] = self._get_default_value(field)
                
                return validated_data
                
            except json.JSONDecodeError as e:
                logging.error(f"Failed to parse AI validation response: {str(e)}")
                return self._create_default_validation()
                
        except Exception as e:
            logging.error(f"Error in AI validation: {str(e)}")
            return self._create_default_validation()

    def _create_default_validation(self) -> Dict[str, Any]:
        """Create a default validation response when AI validation fails."""
        return {
            "validated_components": {},  # Will use original components
            "adjustments": [],
            "false_positives": [],
            "additional_metrics": [
                "Consider monitoring disk I/O patterns",
                "Monitor network latency",
                "Track system temperature"
            ],
            "recommendations": [
                "Regular system updates recommended",
                "Monitor system resources periodically",
                "Review security configurations"
            ],
            "overall_assessment": "System assessment defaulted to basic checks",
            "confidence_score": 0.7  # Conservative default score
        }

    def _get_default_value(self, field: str) -> Any:
        """Get default value for missing fields in AI validation response."""
        defaults = {
            'validated_components': {},
            'adjustments': [],
            'false_positives': [],
            'additional_metrics': [],
            'recommendations': [],
            'overall_assessment': "Default assessment",
            'confidence_score': 0.7
        }
        return defaults.get(field, None)

    async def assess_server_health(self, metrics: SystemMetrics) -> tuple[ServerHealthStatus, Optional[SystemMetricsAI]]:
        """Perform comprehensive server health assessment with improved error handling."""
        try:
            # First, gather initial health components using rule-based system
            initial_health_components = {
                'resource_health': self.assess_resource_health(metrics),
                'service_health': self.assess_service_health(metrics),
                'security_health': self.assess_security_health(metrics),
                'infrastructure_health': self.assess_infrastructure_health(metrics),
                'error_status': self.assess_error_status(metrics)
            }

            # Get AI validation and enhancement with error handling
            ai_validation = await self.validate_health_components(metrics, initial_health_components)
            
            if ai_validation:
                # Use AI validated components if available, otherwise use initial components
                health_components = ai_validation.get('validated_components', initial_health_components)
                if not health_components:
                    health_components = initial_health_components
                
                # Calculate score using AI confidence
                confidence_score = ai_validation.get('confidence_score', 0.7)
                overall_score = self.calculate_health_score(health_components) * confidence_score
                
                # Determine health status
                health_status = self.determine_health_status(overall_score)
            
                # Combine rule-based and AI recommendations with error handling
                recommendations = []
            
                # Add AI-generated recommendations
                ai_recs = ai_validation.get('recommendations', [])
                if ai_recs:
                    for rec in ai_recs:
                        recommendations.append({
                            'priority': 'high',
                            'category': 'ai_enhanced',
                            'recommendation': rec
                        })
            
                # Add false positive warnings
                false_positives = ai_validation.get('false_positives', [])
                if false_positives:
                    for fp in false_positives:
                        recommendations.append({
                            'priority': 'medium',
                            'category': 'false_positive',
                            'recommendation': f'Possible false positive: {fp}'
                        })
                    
                # Add additional metrics suggestions
                additional_metrics = ai_validation.get('additional_metrics', [])
                if additional_metrics:
                    for metric in additional_metrics:
                        recommendations.append({
                            'priority': 'low',
                            'category': 'monitoring',
                            'recommendation': f'Consider monitoring: {metric}'
                        })
                
                # Create AI metrics object with error handling
                ai_metrics = SystemMetricsAI(
                    validated_components=ai_validation.get('validated_components', {}),
                    adjustments=ai_validation.get('adjustments', []),
                    false_positives=ai_validation.get('false_positives', []),
                    additional_metrics=ai_validation.get('additional_metrics', []),
                    recommendations=ai_validation.get('recommendations', []),
                    confidence_score=confidence_score,
                    overall_assessment=ai_validation.get('overall_assessment', 'Assessment completed with default values')
                )

            else:
                # Fallback to rule-based assessment if AI validation fails
                health_components = initial_health_components
                overall_score = self.calculate_health_score(health_components)
                health_status = self.determine_health_status(overall_score)
                recommendations = self.generate_recommendations(health_components)
                ai_metrics = None

            return ServerHealthStatus(
                resource_health=health_components['resource_health'],
                service_health=health_components['service_health'],
                security_health=health_components['security_health'],
                infrastructure_health=health_components['infrastructure_health'],
                error_status=health_components['error_status'],
                overall_score=overall_score,
                health_status=health_status,
                recommendations=recommendations
            ), ai_metrics

        except Exception as e:
            logging.error(f"Error in server health assessment: {str(e)}")
            # Create a basic health status with minimal information
            return self._create_fallback_health_status(metrics), None

    def _create_fallback_health_status(self, metrics: SystemMetrics) -> ServerHealthStatus:
        """Create a basic health status when assessment fails."""
        basic_health = {
            'status': 'unknown',
            'value': 0,
            'threshold': 0
        }
        
        return ServerHealthStatus(
            resource_health={'cpu': basic_health, 'memory': basic_health, 'disk': basic_health},
            service_health={},
            security_health={},
            infrastructure_health={},
            error_status={},
            overall_score=50.0,  # Neutral score
            health_status="ASSESSMENT FAILED - Using Fallback",
            recommendations=[{
                'priority': 'high',
                'category': 'system',
                'recommendation': 'System assessment failed, manual inspection recommended'
            }]
        )

class RHELMonitor:
    def __init__(self, config_file: str = "config.xml"):
        """Initialize monitoring system with configuration."""
        self.config = self._load_config_from_xml(config_file)
        self.command_cache = {}
        self.log_dir = Path(self.config.LOG_DIR)
        self.logs_dir = self.log_dir / "logs"  # Add this line
        self.logs_dir.mkdir(parents=True, exist_ok=True)  # Create logs subdirectory
        self.health_assessment = HealthAssessment(self, self.config.RESOURCE_THRESHOLDS)

        self._setup_logging()  # Corrected method call here
        self.ansible_playbook_template = Template("""
        ---
        - name: System Tuning Playbook
          hosts: all
          become: true
          gather_facts: yes
          tasks:
             {{ tasks }}
          handlers:
             - name: Restart services
               service:
                 name: "{{ item }}"
                 state: restarted
               loop:
                - sshd
                - crond
                - systemd-journald
                - rsyslog
                - NetworkManager
                - firewalld
                - chronyd
        """)
        self.instance_metadata = self.get_instance_metadata()
        self.validate_config()
    
    def _load_config_from_xml(self, config_file: str) -> RHELMonitorConfig:
            """Load configuration from XML file."""
            try:
                tree = ET.parse(config_file)
                root = tree.getroot()

                # Helper function to safely get element text
                def get_element_text(element_name, default=None, parent=None):
                    parent = parent if parent is not None else root
                    element = parent.find(element_name)
                    return element.text if element is not None else default

                # Basic configuration with defaults
                config_data = {
                    "LOG_DIR": str(Path.home() / "rhel9_monitor"),
                    "API_RETRIES": int(get_element_text("api_retries", "5")),
                    "CACHE_DURATION": int(get_element_text("cache_timeout", "3600")),
                    "OLLAMA_BASE_URL": get_element_text("ollama_api"),
                    "MAX_HISTORY_ITEMS": int(get_element_text("max_history_items", "100")),
                    "DEFAULT_INTERVAL": int(get_element_text("default_interval", "300")),
                    "COMMAND_TIMEOUT": int(get_element_text("command_timeout", "300"))
                }

                # Load model configuration
                model_config = {}
                models_element = root.find("models")
                if models_element is not None:
                    for model_type in models_element:
                        if model_type.tag not in ["quick_check", "technical", "code", "reasoning", "commands"]:
                            continue
                        model_config[model_type.tag] = {
                            'name': get_element_text("name", "mistral-small:latest", model_type),
                            'temperature': float(get_element_text("temperature", "0.5", model_type)),
                            'timeout': int(get_element_text("timeout", "60", model_type))
                        }
                config_data["MODEL_CONFIG"] = model_config

                # Load command whitelist
                command_whitelist = root.find("command_whitelist")
                if command_whitelist is not None:
                    config_data['COMMAND_WHITELIST'] = [cmd.text for cmd in command_whitelist if cmd.text]

                # Load resource thresholds
                resource_thresholds = {}
                thresholds = root.find("resource_thresholds")
                if thresholds is not None:
                    for resource in ['cpu', 'memory', 'disk', 'swap']:
                        resource_element = thresholds.find(resource)
                        if resource_element is not None:
                            resource_thresholds[resource] = {
                                'healthy': int(get_element_text("healthy", "70", resource_element)),
                                'warning': int(get_element_text("warning", "85", resource_element))
                            }
                config_data['RESOURCE_THRESHOLDS'] = resource_thresholds or {
                    'cpu': {'healthy': 70, 'warning': 85},
                    'memory': {'healthy': 80, 'warning': 90},
                    'disk': {'healthy': 75, 'warning': 85},
                    'swap': {'healthy': 20, 'warning': 50}
                }

                # Load metadata endpoints
                metadata_endpoints = {}
                metadata_config = root.find("metadata_endpoints")
                if metadata_config is not None:
                    metadata_endpoints = {
                        'base_url': get_element_text("base_url", "http://169.254.169.254", metadata_config),
                        'token_url': get_element_text("token_url", "/latest/api/token", metadata_config),
                        'document_url': get_element_text("document_url", "/latest/dynamic/instance-identity/document", metadata_config)
                    }
                    config_data['METADATA_ENDPOINTS'] = metadata_endpoints
                    config_data['METADATA_TTL'] = int(get_element_text("metadata_ttl", "21600", metadata_config))

                return RHELMonitorConfig(**config_data)
            except Exception as e:
                logging.error(f"Error loading configuration from {config_file}: {e}")
                raise

    
    def _setup_logging(self):
        """Configure logging."""
        log_file = self.logs_dir / "rhel_monitor.log"  # Use self.logs_dir here
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    async def __aenter__(self):
        """Async context manager entry."""
        self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc_value, traceback):
        """Async context manager exit."""
        await self.session.close()

    def run_command(self, command: List[str], capture_all: bool = False) -> Dict[str, Any]:
        """Enhanced command execution with caching and timeout"""
        cmd_str = ' '.join(command)
        if cmd_str in self.command_cache:
            cached_result = self.command_cache[cmd_str]
            if (datetime.now() - cached_result['timestamp']).seconds < self.config.CACHE_DURATION:
                return cached_result['result']

        try:
            # Add common system commands to whitelist check
            base_commands = ['cat', 'ls', 'df', 'lsblk', 'ip', 'who', 'uptime', 'sestatus', 'getenforce', 'firewall-cmd']
            cmd_base = command[0].split('/')[-1]  # Handle full paths
            
            if cmd_base not in self.config.COMMAND_WHITELIST + base_commands:
                logging.warning(f"Command '{cmd_base}' not in whitelist")
                return {'success': False, 'output': '', 'error': 'Command not allowed'}
            if not os.access(command[0], os.X_OK):
                    logging.warning(f"Command '{cmd_base}' is not executable")
                    return {'success': False, 'output': '', 'error': 'Command not executable'}
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=self.config.COMMAND_TIMEOUT
            )
            output = result.stdout.strip()
            error = result.stderr.strip()
            
            result_dict = {
                'success': result.returncode == 0,
                'output': output if capture_all else output,
                'error': error
            }
            
            self.command_cache[cmd_str] = {
                'result': result_dict,
                'timestamp': datetime.now()
            }
            return result_dict
        except subprocess.TimeoutExpired:
            logging.error(f"Command '{cmd_str}' timed out")
            return {'success': False, 'output': '', 'error': 'Command timed out'}
        except Exception as e:
            logging.error(f"Command '{cmd_str}' failed with error: {e}")
            return {'success': False, 'output': '', 'error': str(e)}

    def get_network_metrics(self) -> Dict[str, Any]:
        """Get network metrics using ip command."""
        interfaces = {}
        try:
            # Get network statistics using ip -s link
            cmd = self.run_command(['ip', '-s', 'link'])
            if not cmd["success"]:
                logging.error(f"Error getting network metrics: {cmd['output']}")
                return {}

            current_interface = None
            lines = cmd["output"].split('\n')
            
            for i, line in enumerate(lines):
                # Interface line starts with index number
                if line[0].isdigit():
                    parts = line.split(':')
                    if len(parts) >= 2:
                        current_interface = parts[1].strip()
                        if not current_interface.startswith(('lo', 'docker')):  # Skip loopback and docker
                            interfaces[current_interface] = {"tx_bytes": 0, "rx_bytes": 0}
                # RX/TX lines contain the statistics
                elif current_interface and current_interface in interfaces:
                    if "RX:" in line and i + 1 < len(lines):
                        # RX bytes are typically the first field in statistics
                        try:
                            rx_bytes = int(lines[i + 1].split()[0])
                            interfaces[current_interface]["rx_bytes"] = rx_bytes
                        except (IndexError, ValueError):
                            continue
                    elif "TX:" in line and i + 1 < len(lines):
                        try:
                            tx_bytes = int(lines[i + 1].split()[0])
                            interfaces[current_interface]["tx_bytes"] = tx_bytes
                        except (IndexError, ValueError):
                            continue

            return interfaces
        except Exception as e:
            logging.error(f"Error processing network metrics: {e}")
            return {}

    def get_top_processes(self, count: int = 5) -> List[Dict[str, Any]]:
        """Get top CPU and memory-consuming processes."""
        try:
            processes = []
            for process in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
                processes.append(process.info)

            # Sort by CPU usage
            cpu_sorted = sorted(processes, key=lambda p: p['cpu_percent'], reverse=True)[:count]
            # Sort by Memory usage
            mem_sorted = sorted(processes, key=lambda p: p['memory_percent'], reverse=True)[:count]

            # Merge results if needed
            merged_processes = {}
            for p in cpu_sorted:
                merged_processes[p['pid']] = p
                merged_processes[p['pid']]['source'] = 'cpu'

            for p in mem_sorted:
                if p['pid'] not in merged_processes:
                    merged_processes[p['pid']] = p
                    merged_processes[p['pid']]['source'] = 'memory'
                else:
                    merged_processes[p['pid']]['source'] += ',memory'

            return list(merged_processes.values())
        except Exception as e:
            logging.error(f"Error getting top processes: {e}")
            return []

    def check_critical_services(self) -> Dict[str, str]:
        """Check status of critical services."""
        critical_services = ['sshd', 'httpd', 'mariadb', 'firewalld', 'chronyd']
        service_status = {}

        for service in critical_services:
            cmd = self.run_command(['systemctl', 'is-active', service])
            service_status[service] = cmd["output"].strip() if cmd["success"] else "unknown"

        return service_status

    def get_load_average(self) -> Dict[str, float]:
        """Get load average information."""
        load = os.getloadavg()
        return {
            '1min': load[0],
            '5min': load[1],
            '15min': load[2]
        }

    def get_instance_metadata(self) -> Dict[str, Any]:
        """Get instance metadata from AWS using IMDSv2."""
        metadata = {}
        try:
            if 'AWS_EC2_METADATA_DISABLED' in os.environ:
                logging.warning("AWS Metadata collection is disabled, skipping")
                return metadata  # Return empty dict if collection disabled
            
            base_url = self.config.METADATA_ENDPOINTS.get('base_url')
            token_url = f"{base_url}{self.config.METADATA_ENDPOINTS.get('token_url')}"
            document_url = f"{base_url}{self.config.METADATA_ENDPOINTS.get('document_url')}"

             # Check if we are running inside an ec2 instance
            try:
                response = requests.get(base_url, timeout=2)
                if response.status_code != 200:
                    return metadata
            except requests.exceptions.RequestException:
                return metadata
            
            token_headers = {"X-aws-ec2-metadata-token-ttl-seconds": str(self.config.METADATA_TTL)}
            token_response = requests.put(token_url, headers=token_headers, timeout=2)
            token_response.raise_for_status()
            token = token_response.text
             
            metadata_headers = {"X-aws-ec2-metadata-token": token}
            response = requests.get(document_url, headers=metadata_headers, timeout=5)
            response.raise_for_status()
            metadata = response.json()
        except requests.exceptions.RequestException as e:
            logging.error(f"Error getting instance metadata: {e}")
        except Exception as e:
             logging.error(f"Error getting instance metadata: {e}")

        return metadata

    def get_open_ports(self) -> List[str]:
        """Scan open ports using ss command."""
        cmd = self.run_command(['sudo', 'ss', '-antp'])
        if not cmd["success"]:
            logging.error(f"Error getting open ports: {cmd['output']}")
            return []

        ports = []
        for line in cmd["output"].splitlines():
            if "LISTEN" in line:
                parts = line.split()
                try:
                    local_address = parts[4]
                    match = re.search(r':(\d+)', local_address)
                    if match:
                        port = match.group(1)
                        ports.append(port)

                except (IndexError, ValueError):
                    continue  # Skip if line is not well formatted
        return ports

    def get_syslog_errors(self) -> List[str]:
        """Grep /var/log/messages for errors."""
        cmd = self.run_command(['grep', '-i', 'error\|fail\|critical', '/var/log/messages'])
        if not cmd["success"]:
            logging.error(f"Error getting syslog errors: {cmd['output']}")
            return []

        errors = [line.strip() for line in cmd["output"].splitlines() if line.strip()]
        return errors

    async def get_system_metrics(self) -> SystemMetrics:
        """Collect system metrics."""
        try:
            # System info
            uname = platform.uname()
            hostname = uname.node
            kernel = uname.release

            # Get OS version for RHEL
            try:
                with open('/etc/redhat-release') as f:
                    os_version = f.read().strip()
            except:
                os_version = "RHEL (version unknown)"

            # Get uptime
            uptime_cmd = self.run_command(['uptime', '-p'], capture_all=True)  # Add capture_all=True
            uptime = uptime_cmd["output"].strip() if uptime_cmd["success"] else "Unknown"

            # Resource usage
            cpu_usage = psutil.cpu_percent()
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()

            # Disk Usage
            disk = psutil.disk_usage('/')
            disk_metrics = {
                'total': disk.total / (1024 ** 3),
                'used': disk.used / (1024 ** 3),
                'free': disk.free / (1024 ** 3),
                'percent': disk.percent
            }

            # Update information
            updates = self.check_updates()

            # Additional metrics
            network_metrics = self.get_network_metrics()
            top_processes = self.get_top_processes()
            service_status = self.check_critical_services()
            load_average = self.get_load_average()
            open_ports = self.get_open_ports()
            syslog_errors = self.get_syslog_errors()

            # Health Assessment
            health_status, ai_metrics = await self.health_assessment.assess_server_health(SystemMetrics(
                timestamp=datetime.now().isoformat(),
                hostname=hostname,
                os_version=os_version,
                kernel_version=kernel,
                uptime=uptime,
                cpu_usage=cpu_usage,
                memory_used=memory.used / (1024 ** 3),
                memory_total=memory.total / (1024 ** 3),
                swap_used=swap.used / (1024 ** 3),
                swap_total=swap.total / (1024 ** 3),
                disk_usage=disk_metrics,
                updates_pending=updates['total'],
                security_updates=updates['security'],
                network_metrics=network_metrics,
                top_processes=top_processes,
                service_status=service_status,
                load_average=load_average,
                instance_metadata=self.instance_metadata,
                open_ports=open_ports,
                syslog_errors=syslog_errors
            ))
           
            return SystemMetrics(
                timestamp=datetime.now().isoformat(),
                hostname=hostname,
                os_version=os_version,
                kernel_version=kernel,
                uptime=uptime,
                cpu_usage=cpu_usage,
                memory_used=memory.used / (1024 ** 3),
                memory_total=memory.total / (1024 ** 3),
                swap_used=swap.used / (1024 ** 3),
                swap_total=swap.total / (1024 ** 3),
                disk_usage=disk_metrics,
                updates_pending=updates['total'],
                security_updates=updates['security'],
                network_metrics=network_metrics,
                top_processes=top_processes,
                service_status=service_status,
                load_average=load_average,
                instance_metadata=self.instance_metadata,
                open_ports=open_ports,
                syslog_errors=syslog_errors,
                health_status = health_status,
                ai_validation = ai_metrics
            )

        except Exception as e:
            logging.error(f"Error collecting metrics: {e}")
            raise

    def check_updates(self) -> Dict[str, int]:
        """Check for system updates using dnf."""
        try:
            # Check for updates using dnf
            check_cmd = self.run_command(['sudo', 'dnf', 'check-update', '--quiet'])
            security_cmd = self.run_command(['sudo', 'dnf', 'list-security', '--quiet'])

            updates = {
                'total': 0,
                'security': 0
            }

            # Count total updates
            if check_cmd["success"] or check_cmd["error"] and check_cmd["error"].returncode == 100:
                lines = check_cmd["output"].split('\n')
                updates['total'] = len([l for l in lines if l and not l.startswith(('Last metadata', 'Obsoleting'))])

            # Count security updates
            if security_cmd["success"]:
                lines = security_cmd["output"].split('\n')
                updates['security'] = len([l for l in lines if 'Security' in l])

            return updates

        except Exception as e:
            logging.error(f"Error checking updates: {e}")
            return {'total': 0, 'security': 0}

    async def _make_api_call(self, prompt: str, model_type: str) -> str:
        """Enhanced model interaction with better error handling and retries."""
        logging.info(f"Starting _make_api_call for model type: {model_type}")

        # Updated model mapping to match config.xml
        model_type_mapping = {
            # 'analysis': 'technical',  # llama3.3:latest
            'analysis': 'quick_check',
            'recommendation': 'quick_check',
            'technical': 'technical',
            'playbook': 'code',
            'terraform': 'code'
        }
        
        mapped_type = model_type_mapping.get(model_type)
        if not mapped_type or mapped_type not in self.config.MODEL_CONFIG:
            raise ValueError(f"Invalid model type: {model_type}")
        
        model_config = self.config.MODEL_CONFIG[mapped_type]
        model_name = model_config['name']

        for attempt in range(self.config.API_RETRIES):
            try:
                timeout = aiohttp.ClientTimeout(total=model_config['timeout'])
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    request_data = {
                        "model": model_name,
                        "prompt": prompt,
                        "stream": False,
                        "temperature": model_config['temperature']
                    }

                    async with session.post(
                        f"{self.config.OLLAMA_BASE_URL}{self.config.OLLAMA_ENDPOINTS.get('generate')}",
                        json=request_data,
                        headers=self.config.OLLAMA_HEADERS
                    ) as response:
                        if response.status == 200:
                            result = await response.json()
                            if result and 'response' in result:
                                return result['response']
                            logging.error(f"Invalid response format: {result}")
                        elif response.status in [429, 503, 504]:
                            error_text = await response.text()
                            logging.warning(f"API rate-limited with status {response.status}: {error_text}. Retrying...")
                        else:
                            error_text = await response.text()
                            logging.error(f"API call failed with status {response.status}: {error_text}")

                if attempt < self.config.API_RETRIES - 1:
                    delay = self._calculate_retry_delay(attempt)
                    logging.info(f"Retrying in {delay:.2f} seconds...")
                    await asyncio.sleep(delay)

            except aiohttp.ClientError as e:
                logging.error(f"API Client error on attempt {attempt + 1}: {str(e)}")
                if attempt < self.config.API_RETRIES - 1:
                     delay = self._calculate_retry_delay(attempt)
                     logging.info(f"Retrying in {delay:.2f} seconds...")
                     await asyncio.sleep(delay)
            except Exception as e:
                logging.error(f"API call error on attempt {attempt + 1}: {str(e)}")
        return "Failed to get valid response after all retries"
    
    def _calculate_retry_delay(self, attempt: int) -> float:
        """Calculate retry delay using exponential backoff with jitter."""
        base_delay = self.config.OLLAMA_RETRY_CONFIG['min_delay']
        max_delay = self.config.OLLAMA_RETRY_CONFIG['max_delay']
        delay = min(max_delay, base_delay * (2 ** attempt))  # Exponential backoff
        jitter = random.uniform(0, 0.2)  # Add jitter
        return delay + jitter

    def create_analysis_prompt(self, metrics: SystemMetrics) -> str:
        """Create system analysis prompt."""
        return f"""
        As a system administrator, analyze these RHEL 9 server metrics:

        System Information:
        - Hostname: {metrics.hostname}
        - OS Version: {metrics.os_version}
        - Kernel: {metrics.kernel_version}
        - Uptime: {metrics.uptime}

        Resource Usage:
        - CPU Usage: {metrics.cpu_usage:.2f}%
        - Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB
        - Swap: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB
        - Disk Usage: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB ({metrics.disk_usage['percent']}%)

        Load Average:
        - 1 minute: {metrics.load_average['1min']:.2f}
        - 5 minutes: {metrics.load_average['5min']:.2f}
        - 15 minutes: {metrics.load_average['15min']:.2f}

        Network Metrics:
        {json.dumps(metrics.network_metrics, indent=2)}

        Top Processes:
        {json.dumps(metrics.top_processes, indent=2)}

        Service Status:
        {json.dumps(metrics.service_status, indent=2)}

        Updates:
        - Total Updates Pending: {metrics.updates_pending}
        - Security Updates: {metrics.security_updates}

        Open Ports:
        {metrics.open_ports}

        Syslog Errors:
        {metrics.syslog_errors}

        AWS Instance Metadata:
        {json.dumps(metrics.instance_metadata, indent=2)}

        Provide a detailed analysis including:
        1. System health assessment
        2. Resource usage analysis
        3. Network performance analysis
        4. Process and service status evaluation
        5. Security recommendations, including which open ports should be closed
        6. Performance optimization suggestions
        7. Maintenance tasks needed
        8. Analysis of any syslog errors

        Format the response in markdown with clear sections and bullet points.
        """

    def create_recommendation_prompt(self, metrics: SystemMetrics) -> str:
        """Create instance recommendation prompt."""
        return f"""
        Based on the following RHEL 9 server metrics, provide a recommendation for the best EC2 instance type, including suggestions for CPU, memory, and storage configurations:

        System Information:
        - Hostname: {metrics.hostname}
        - OS Version: {metrics.os_version}
        - Kernel: {metrics.kernel_version}
        - Uptime: {metrics.uptime}

        Resource Usage:
        - CPU Usage: {metrics.cpu_usage:.2f}%
        - Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB
        - Swap: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB
        - Disk Usage: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB ({metrics.disk_usage['percent']}%)

        Load Average:
        - 1 minute: {metrics.load_average['1min']:.2f}
        - 5 minutes: {metrics.load_average['5min']:.2f}
        - 15 minutes: {metrics.load_average['15min']:.2f}

        Top Processes:
        {json.dumps(metrics.top_processes, indent=2)}

        AWS Instance Metadata:
        {json.dumps(metrics.instance_metadata, indent=2)}

        Updates:
        - Total Updates Pending: {metrics.updates_pending}
        - Security Updates: {metrics.security_updates}

        Consider the current resource usage, application workload, and future scalability.

        Provide the best EC2 instance type with a rationale and suggestions for system tuning.
        """

    def create_tuning_playbook_prompt(self, metrics: SystemMetrics, ports_to_close: List[str]) -> str:
            """Create system tuning playbook prompt."""
            ports_str = ", ".join(ports_to_close)
            return f"""
            Based on the following RHEL 9 server metrics, generate an Ansible playbook for system tuning:

            System Information:
            - Hostname: {metrics.hostname}
            - OS Version: {metrics.os_version}
            - Kernel: {metrics.kernel_version}
            - Uptime: {metrics.uptime}

            Resource Usage:
            - CPU Usage: {metrics.cpu_usage:.2f}%
            - Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB
            - Swap: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB
            - Disk Usage: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB ({metrics.disk_usage['percent']}%)

            Load Average:
            - 1 minute: {metrics.load_average['1min']:.2f}
            - 5 minutes: {metrics.load_average['5min']:.2f}
            - 15 minutes: {metrics.load_average['15min']:.2f}

            Top Processes:
            {json.dumps(metrics.top_processes, indent=2)}

            Updates:
            - Total Updates Pending: {metrics.updates_pending}
            - Security Updates: {metrics.security_updates}

            Open Ports:
            {metrics.open_ports}

            Syslog Errors:
            {metrics.syslog_errors}

            AWS Instance Metadata:
            {json.dumps(metrics.instance_metadata, indent=2)}

            Include tasks to:
            1. Optimize CPU usage.
            2. Adjust memory settings.
            3. Improve disk performance.
            4. Configure networking.
            5. Ensure service stability.
            6. Stop the following ports: {ports_str}, using the most appropriate method.

            The playbook must be well-structured, use clear task names, and include proper indentation.
            Use RHEL-specific modules and best practices.
            Always handle errors with a rollback when possible.
            """
    
    def create_terraform_prompt(self, metrics: SystemMetrics, new_instance_type: str) -> str:
        """Create Terraform code for instance upgrade/downgrade prompt."""
        return f"""
        Based on the current RHEL 9 server metrics and the new instance type '{new_instance_type}', generate the Terraform code to upgrade or downgrade the EC2 instance:

        System Information:
        - Hostname: {metrics.hostname}
        - OS Version: {metrics.os_version}
        - Kernel: {metrics.kernel_version}
        - Uptime: {metrics.uptime}

        Resource Usage:
        - CPU Usage: {metrics.cpu_usage:.2f}%
        - Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB
        - Swap: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB
        - Disk Usage: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB ({metrics.disk_usage['percent']}%)

        Top Processes:
        {json.dumps(metrics.top_processes, indent=2)}

        AWS Instance Metadata:
        {json.dumps(metrics.instance_metadata, indent=2)}

        Updates:
        - Total Updates Pending: {metrics.updates_pending}
        - Security Updates: {metrics.security_updates}

        The Terraform code must:
        1. Define the new instance type.
        2. Include necessary attributes for the instance.
        3. Handle dependencies for the instance.
        4. Provide clear comments for each resource.
        """

    async def analyze_metrics(self, metrics: SystemMetrics) -> Dict[str, Any]:
        """Use AI to analyze system metrics."""
        logging.info("Starting analyze_metrics")
        analysis_prompt = self.create_analysis_prompt(metrics)
        recommendation_prompt = self.create_recommendation_prompt(metrics)
        logging.info("Creating analysis and recommendation tasks")
        analysis_task = self._make_api_call(analysis_prompt, 'analysis')
        recommendation_task = self._make_api_call(recommendation_prompt, 'recommendation')
        logging.info("Gathering analysis and recommendation results")
        analysis_text, recommendation_text = await asyncio.gather(analysis_task, recommendation_task)

        tasks = await self.generate_playbook_tasks(metrics, analysis_text)
        rendered_playbook = self.ansible_playbook_template.render(tasks=tasks)

        # Include health and validation checks in the report
        validation_checks = self.perform_validation_checks()
        health_checks = self.perform_health_checks()
        return {
            'timestamp': metrics.timestamp,
            'analysis': analysis_text,
            'recommendation': recommendation_text,
            'tuning_playbook': rendered_playbook,
            'metrics': serialize_metrics(metrics),
            'health_checks': health_checks,
            'validation_checks': validation_checks
        }
    
    async def generate_playbook_tasks(self, metrics: SystemMetrics, analysis: str) -> str:
        """Generate Ansible tasks based on AI analysis."""

        ports_to_close = []
        # parse analysis to determine which ports to close
        lines = analysis.split('\n')
        for line in lines:
            if 'close port' in line.lower() and "port" in line.lower():
                match = re.search(r'\bport\s+(\d+)\b', line, re.IGNORECASE)
                if match:
                    ports_to_close.append(match.group(1))

        tuning_playbook_prompt = self.create_tuning_playbook_prompt(metrics, ports_to_close)
        tuning_playbook_text = await self._make_api_call(tuning_playbook_prompt, 'playbook')
        return tuning_playbook_text

    async def generate_terraform_code(self, metrics: SystemMetrics, new_instance_type: str) -> str:
        """Generate Terraform code for instance changes."""
        terraform_prompt = self.create_terraform_prompt(metrics, new_instance_type)
        terraform_code = await self._make_api_call(terraform_prompt, 'terraform')
        return terraform_code
    
    def format_report(self, metrics: SystemMetrics, analysis: Dict[str, Any]) -> str:
        """Format report with enhanced AI analysis section."""
        report = []
        report.append(self.format_banner("RHEL 9 System Analysis Report"))
        report.append(f"Generated: {metrics.timestamp}")
        report.append("=" * 80)

        # Add health assessment section at the beginning of the report
        if metrics.health_status:
            report.append(self.format_health_assessment(metrics.health_status))

        # Hardware Configuration Section
        report.append("\n## Hardware Configuration")
        cpu_info = self.get_cpu_info()
        disk_info = self.get_disk_info()
        nic_info = self.get_network_interfaces()
        
        report.append("\n### CPU Information")
        report.append(f"- Physical CPUs: {cpu_info['physical_cpus']}")
        report.append(f"- CPU Cores: {cpu_info['cpu_cores']}")
        report.append(f"- CPU Model: {cpu_info['cpu_model']}")
        report.append(f"- CPU Architecture: {cpu_info['architecture']}")

        report.append("\n### Storage Configuration")
        report.append("Disk Layout:")
        for disk in disk_info:
            report.append(f"- Device: {disk['device']}")
            report.append(f"  - Size: {disk['size']}")
            report.append(f"  - Model: {disk['model']}")
       
        report.append("\n### Network Configuration")
        report.append("Network Interfaces:")
        for nic in nic_info:
            report.append(f"- Interface: {nic['name']}")
            report.append(f"  - State: {nic['state']}")
            report.append(f"  - MAC Address: {nic['mac']}")
            report.append(f"  - IP Address: {nic.get('ip', 'None')}")
            report.append(f"  - Speed: {nic.get('speed','Unknown')}")
        
        # System Performance Section
        report.append("\n## System Performance")
        report.append("\n### Resource Utilization")
        report.append(f"- CPU Usage: {metrics.cpu_usage:.2f}%")
        report.append(f"- Memory Usage: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB ({(metrics.memory_used/metrics.memory_total)*100:.1f}%)")
        report.append(f"- Swap Usage: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB")
        report.append("Load Average:")
        report.append(f"- 1 minute: {metrics.load_average['1min']:.2f}")
        report.append(f"- 5 minutes: {metrics.load_average['5min']:.2f}")
        report.append(f"- 15 minutes: {metrics.load_average['15min']:.2f}")

        # Process Analysis
        report.append("\n### Top Processes")
        report.append("| PID | Name | CPU% | Memory% | Type |")
        report.append("|-----|------|------|---------|------|")
        for proc in metrics.top_processes:
            report.append(f"| {proc['pid']} | {proc['name']} | {proc['cpu_percent']:.1f} | {proc['memory_percent']:.1f} | {proc['source']} |")

        # System Health Section
        report.append("\n## System Health")
        health_checks = self.perform_health_checks()
        
        report.append("\n### Service Status")
        for service, status in metrics.service_status.items():
            report.append(f"- {service}: {status}")

        report.append("\n### Security Status")
        report.append(f"- SELinux Status: {health_checks['selinux_status']}")
        report.append(f"- Firewall Status: Active ({len(metrics.open_ports)} open ports)")
        report.append(f"- Updates Pending: {metrics.updates_pending} (Security: {metrics.security_updates})")

        # Error Analysis
        if metrics.syslog_errors:
            report.append("\n### System Errors")
            report.append("Recent Critical Events:")
            for error in metrics.syslog_errors[:5]:  # Show only last 5 errors
                report.append(f"- {error}")

        # Monitoring commands
        report.append(self.format_monitoring_commands_section())
        
        # AI Analysis Section with better formatting
        if 'analysis' in analysis:
            report.append(self.format_banner("AI ANALYSIS AND RECOMMENDATIONS"))
            
            # Split analysis into sections and format them
            analysis_text = analysis['analysis']
            sections = analysis_text.split('\n\n')
            
            for section in sections:
                if section.strip():
                    # Handle markdown headers
                    if section.startswith('#'):
                        report.append(section)
                    else:
                        # Add section header if it contains a recognized section title
                        section_lower = section.lower()
                        if any(title in section_lower for title in [
                            'system health', 'resource usage', 'network performance',
                            'process', 'security', 'performance', 'maintenance',
                            'analysis'
                        ]):
                            report.append(f"\n{section}")
                        else:
                            report.append(section)

        # Infrastructure Recommendations
        if 'recommendation' in analysis:
            report.append(self.format_banner("INFRASTRUCTURE RECOMMENDATIONS"))
            report.append(analysis['recommendation'])
            
        report.append(self.check_single_points_of_failure())
        
        return '\n'.join(report)

    # 2. Add new methods to gather detailed system information

    def get_cpu_info(self) -> Dict[str, Any]:
        """Get detailed CPU information."""
        cpu_info = {
            'physical_cpus': 0,
            'cpu_cores': 0,
            'cpu_model': '',
            'architecture': platform.machine()
        }
        
        try:
            # Get CPU information from /proc/cpuinfo
            cmd = self.run_command(['cat', '/proc/cpuinfo'])
            if cmd['success']:
                content = cmd['output']
                cpu_info['physical_cpus'] = len(re.findall(r'physical id\s+:\s+\d+', content))
                cpu_info['cpu_cores'] = len(re.findall(r'processor\s+:\s+\d+', content))
                
                # Get CPU model
                model_match = re.search(r'model name\s+:\s+(.+)', content)
                if model_match:
                    cpu_info['cpu_model'] = model_match.group(1)
        except Exception as e:
            logging.error(f"Error getting CPU info: {e}")
        
        return cpu_info

    def get_disk_info(self) -> List[Dict[str, Any]]:
         """Get detailed disk information with improved error handling"""
         disks = []
         try:
             # First try using lsblk with different format
             cmd = self.run_command(['lsblk', '--json', '--output', 'NAME,SIZE,TYPE,MOUNTPOINT'])
             if cmd['success']:
                 try:
                     disk_data = json.loads(cmd['output'])
                     for device in disk_data.get('blockdevices', []):
                         if device['type'] == 'disk' and not device['name'].startswith(('loop', 'sr')):
                             disk_info = {
                                 'device': f"/dev/{device['name']}",
                                 'size': device['size'],
                                 'model': 'Unknown',
                                 'mount_point': device.get('mountpoint', '')
                             }
                             disks.append(disk_info)
                 except json.JSONDecodeError:
                     logging.error("Failed to parse lsblk JSON output")
             
             # If no disks found, try alternative method
             if not disks:
                 cmd = self.run_command(['fdisk', '-l'])
                 if cmd['success']:
                     for line in cmd['output'].split('\n'):
                         if line.startswith('Disk /dev/') and not any(x in line for x in ['loop', 'sr']):
                             device = line.split()[1].rstrip(':')
                             size = line.split('bytes')[0].split(',')[-1].strip()
                             disks.append({
                                 'device': device,
                                 'size': size,
                                 'model': 'Unknown',
                                 'mount_point': ''
                             })
             
             return disks
             
         except Exception as e:
            logging.error(f"Error getting disk info: {e}")
            return []

    def get_nic_info(self) -> List[Dict[str, Any]]:
        """Get detailed network interface information."""
        nics = []
        try:
            # Get network interface information using ip command
             cmd = self.run_command(['ip', 'addr', 'show'])
             if cmd['success']:
                current_nic = None
                for line in cmd['output'].splitlines():
                    if ': ' in line:
                        parts = line.split(': ')
                        if len(parts) >= 2:
                            iface = parts[1].split('@')[0]
                            if iface not in ('lo', 'docker0'):
                                current_nic = {
                                    'name': iface,
                                    'mac_address': 'N/A',
                                    'ip_address': 'N/A',
                                    'speed': self._get_interface_speed(iface),
                                    'state': 'unknown'
                                }
                                nics.append(current_nic)
                    elif current_nic and 'link/ether' in line:
                        current_nic['mac_address'] = line.split()[1]
                    elif current_nic and 'inet ' in line:
                         current_nic['ip_address'] = line.split()[1].split('/')[0]
                            
        except Exception as e:
            logging.error(f"Error getting NIC info: {e}")
        
        return nics
    
    def get_network_interfaces(self) -> List[Dict[str, str]]:
        """Get list of physical network interfaces with detailed information."""
        interfaces = []
        try:
            # Try ip command first
            cmd = self.run_command(['ip', '-br', 'link', 'show'])
            if cmd['success']:
                for line in cmd['output'].split('\n'):
                    if line and not any(x in line.lower() for x in ['lo:', 'virtual', 'docker', 'veth']):
                        parts = line.split()
                        if len(parts) >= 2:
                            interface = {
                                'name': parts[0],
                                'state': parts[1],
                                'mac': parts[2] if len(parts) > 2 else 'Unknown',
                                'ip': 'None',
                                'speed': 'Unknown'
                            }
                            
                            # Get IP address
                            ip_cmd = self.run_command(['ip', '-br', 'addr', 'show', interface['name']])
                            if ip_cmd['success']:
                                ip_parts = ip_cmd['output'].strip().split()
                                if len(ip_parts) > 2:
                                    interface['ip'] = ip_parts[2].split('/')[0]
                            
                            # Get speed if available
                            try:
                                with open(f"/sys/class/net/{interface['name']}/speed", 'r') as f:
                                    speed = f.read().strip()
                                    interface['speed'] = f"{speed}Mbps" if speed.isdigit() else 'Unknown'
                            except Exception:
                                pass
                                
                            interfaces.append(interface)
        
        
        except Exception as e:
            logging.error(f"Error getting network interfaces: {e}")
            return []
        
        # If no interfaces found or command failed, try fallback method
        if not interfaces:
            cmd = self.run_command(['ls', '/sys/class/net/'])
            if cmd['success']:
                for iface in cmd['output'].split():
                    if not any(x in iface.lower() for x in ['lo', 'docker', 'veth']):
                        interface = {
                            'name': iface,
                            'state': 'unknown',
                            'mac': 'Unknown',
                            'ip': 'None',
                            'speed': 'Unknown'
                        }
                        
                        # Try to get MAC address
                        try:
                            with open(f"/sys/class/net/{iface}/address", 'r') as f:
                                mac = f.read().strip()
                                if mac:
                                    interface['mac'] = mac
                        except Exception:
                            pass
                            
                        # Try to get operational state
                        try:
                            with open(f"/sys/class/net/{iface}/operstate", 'r') as f:
                                interface['state'] = f.read().strip()
                        except Exception:
                            pass
                            
                        interfaces.append(interface)

        return interfaces


    def _format_size(self, size_bytes: int) -> str:
        """Format size in bytes to human readable format."""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size_bytes < 1024:
                return f"{size_bytes:.1f}{unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f}PB"

    def _get_interface_speed(self, interface: str) -> str:
        """Get network interface speed."""
        try:
            with open(f"/sys/class/net/{interface}/speed", 'r') as f:
                speed = int(f.read().strip())
                return f"{speed}Mbps"
        except:
            return "N/A"

    def _validate_selinux(self) -> bool:
        """Validate if SELinux is enabled"""
        result = self.run_command(['getenforce'])
        return result['success'] and result['output'].strip() == 'Enforcing'

    def _validate_firewall(self) -> bool:
          """Validate if the firewall is active"""
          status = self.check_firewall_status()
          return status['is_running']
      
    def _validate_ssh_config(self) -> bool:
        """Validate SSH configuration for key parameters."""
        try:
            cmd = self.run_command(['sshd', '-T'])
            if not cmd['success']:
                return False
                
            config = {}
            for line in cmd['output'].splitlines():
                parts = line.strip().split(None, 1)
                if len(parts) == 2:
                    config[parts[0]] = parts[1]
                    
            # Check required settings
            required_settings = {
                "permitrootlogin": ["no", "without-password", "prohibit-password"],  # Accept multiple secure options
                "passwordauthentication": "no",
                "pubkeyauthentication": "yes"
            }
            
            for key, expected_value in required_settings.items():
                if config.get(key) not in expected_value if isinstance(expected_value, list) else config.get(key) != expected_value:
                    logging.warning(f"SSH config validation failed for {key}. Current: {config.get(key)} Expected:{expected_value}")
                    return False
            return True
            
        except Exception as e:
            logging.error(f"Error validating SSH config: {e}")
            return False

    def _validate_updates(self) -> bool:
        """Validate if updates are current"""
        updates = self.check_updates()
        return updates['total'] == 0 and updates['security'] == 0

    def _validate_disk_space(self) -> bool:
        """Validate if disk space is sufficient"""
        disk = psutil.disk_usage('/')
        return disk.percent < 90

    def perform_validation_checks(self) -> Dict[str, bool]:
        """Perform validation checks on system configuration"""
        return {
            'selinux_enabled': self._validate_selinux(),
            'firewall_active': self._validate_firewall(),
            'ssh_secure': self._validate_ssh_config(),
            'updates_current': self._validate_updates(),
            'disk_space_sufficient': self._validate_disk_space()
        }
    
    def perform_health_checks(self) -> Dict[str, Any]:
        """Perform comprehensive system health checks"""
        return {
            'selinux_status': self.check_selinux_status(),
            'firewall_status': self.check_firewall_status(),
            'service_status': self.check_critical_services(),
            'system_load': self.get_load_average(),
            'update_status': self.check_updates(),
            'disk_health': self.check_disk_health(),
            'network_health': self.check_network_health()
        }
    
    def check_selinux_status(self) -> str:
        """Check SELinux status"""
        result = self.run_command(['sestatus'])
        if result['success']:
             return result['output']
        return f"Error checking SELinux status: {result.get('error', 'Unknown error')}"
    
    def check_firewall_status(self) -> Dict[str, Any]:
        """Enhanced firewalld status check with detailed information"""
        status = {
            'is_running': False,
            'is_enabled': False,
            'ssh_allowed': False,
            'zones': [],
            'detailed_status': '',
            'error': None
        }
    
        try:
            # Check if firewalld is installed
            result = self.run_command(['rpm', '-q', 'firewalld'])
            if not result['success']:
                status['error'] = "firewalld is not installed"
                return status
    
            # Check if firewalld is running
            run_result = self.run_command(['systemctl', 'is-active', 'firewalld'])
            status['is_running'] = run_result['success'] and run_result['output'].strip() == 'active'
    
            # Check if firewalld is enabled
            enable_result = self.run_command(['systemctl', 'is-enabled', 'firewalld'])
            status['is_enabled'] = enable_result['success'] and enable_result['output'].strip() == 'enabled'

            if status['is_running']:
                # Get detailed status
                detailed = self.run_command(['firewall-cmd', '--list-all'])
                status['detailed_status'] = detailed['output']

                # Check if SSH is allowed
                ssh_check = self.run_command(['firewall-cmd', '--query-service=ssh'])
                status['ssh_allowed'] = ssh_check['success'] and ssh_check['output'].strip() == 'yes'

                # Get zones
                zones_result = self.run_command(['firewall-cmd', '--get-active-zones'])
                if zones_result['success']:
                    status['zones'] = [line.strip() for line in zones_result['output'].split('\n') if line.strip()]

        except Exception as e:
            status['error'] = str(e)

        return status

    def check_disk_health(self) -> Dict[str, Any]:
        """Check disk health status"""
        result = self.run_command(['df', '-h'])  # Use df instead of smartctl as it doesn't require additional packages
        return {
            'status': result['success'],
            'details': result['output']
        }

    def check_network_health(self) -> Dict[str, Any]:
         """Check network health status"""
         ping_result = self.run_command(['ping', '-c', '4', '8.8.8.8'])
         return {
             'connectivity': ping_result['success'],
             'latency': self._parse_ping_latency(ping_result['output']) if ping_result['success'] else None
         }

    def _parse_ping_latency(self, ping_output: str) -> Optional[float]:
         """Parse ping output to get average latency."""
         try:
              match = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)/[\d.]+/[\d.]+", ping_output)
              if match:
                return float(match.group(1))
              return None
         except Exception as e:
            logging.error(f"Error parsing ping latency: {e}")
            return None
    
    def print_report(self, metrics: SystemMetrics, analysis: Dict[str, Any]) -> None:
        """Print detailed system monitoring report."""
        print(self.format_report(metrics, analysis))
    
    def check_single_points_of_failure(self) -> str:
        """Check if server has single NIC or single disk."""
        results = []
        results.append("\nSINGLE POINT OF FAILURE CHECK")
        results.append("-" * 50)
        
        # Check Network Interfaces
        try:
            # Get only physical NICs (excluding virtual interfaces)
            cmd = self.run_command(['ip', 'link', 'show'])
            if cmd['success']:
                nics = []
                for line in cmd['output'].split('\n'):
                    if ': ' in line and not any(x in line.lower() for x in ['lo:', 'virtual', 'docker', 'veth']):
                        nic_name = line.split(':')[1].strip()
                        nics.append(nic_name)
                
                results.append(f"Network Interfaces Found: {len(nics)}")
                for nic in nics:
                    results.append(f"  - {nic}")
                
                if len(nics) == 1:
                    results.append("\n**WARNING**: System has only one network interface!")
                    results.append("Recommendation: Add a second NIC for network redundancy")
        except Exception as e:
            results.append(f"Error checking NICs: {e}")

        results.append("")  # Empty line for spacing
    
        # Check Physical Disks
        try:
            # Get only physical disks (excluding virtual/loop devices)
            cmd = self.run_command(['lsblk', '-d', '-n', '-o', 'NAME,SIZE,TYPE,MOUNTPOINT'])
            if cmd['success']:
                physical_disks = [line for line in cmd['output'].split('\n') 
                                if line.strip() and 'disk' in line 
                                and not any(x in line for x in ['loop', 'sr'])]
                
                results.append(f"Physical Disks Found: {len(physical_disks)}")
                for disk in physical_disks:
                    results.append(f"  - {disk.strip()}")
                
                if len(physical_disks) == 1:
                    results.append("\n**WARNING**: System has only one physical disk!")
                    results.append("Recommendation: Add additional disk(s) and configure RAID for redundancy")

                # Check root device redundancy
                root_cmd = self.run_command(['df', '-h', '/'])
                if root_cmd['success']:
                    root_device = root_cmd['output'].split('\n')[1].split()[0]
                    if not any(x in root_device for x in ['/dev/md', '/dev/mapper']):
                        results.append("\nWARNING: Root filesystem is not on RAID or LVM!")
                        results.append("Recommendation: Consider migrating root to RAID1 or LVM mirror")
        except Exception as e:
            results.append(f"Error checking disks: {e}")

        return '\n'.join(results)

    def validate_config(self):
        """Validate configuration settings."""
        if not self.config.OLLAMA_BASE_URL:
            raise ValueError("OLLAMA_API_URL environment variable is not set")
            
        # Test Ollama API connection
        try:
            # Check root endpoint instead of /api/status
            response = requests.get(self.config.OLLAMA_BASE_URL)
            logging.info(f"Ollama API Response: Status Code: {response.status_code}, Text: {response.text}")
            if response.status_code != 200 :
                raise ValueError("Ollama service is not responding correctly")
            
        except requests.exceptions.RequestException as e:
            raise ValueError(f"Cannot connect to Ollama API: {e}")
        except Exception as e:
            raise ValueError(f"Error validating Ollama configuration: {e}")
    
    def get_detailed_uptime(self) -> Dict[str, Any]:
        """Get detailed uptime information."""
        uptime_info = {
            'uptime_pretty': '',
            'uptime_seconds': 0,
            'last_boot': '',
            'last_reboot': '',
            'users': 0,
            'load_averages': {}
        }
        
        try:
            # Get uptime in pretty format
            cmd = self.run_command(['uptime', '-p'], capture_all=True)
            if cmd['success']:
                uptime_info['uptime_pretty'] = cmd['output'].strip()

            # Get last boot time
            cmd = self.run_command(['who', '-b'], capture_all=True)
            if cmd['success']:
                uptime_info['last_boot'] = cmd['output'].strip()

            # Get uptime in seconds
            with open('/proc/uptime') as f:
                uptime_seconds = float(f.readline().split()[0])
                uptime_info['uptime_seconds'] = uptime_seconds

            # Get last reboot info
            cmd = self.run_command(['last', 'reboot', '-n', '1'], capture_all=True)
            if cmd['success']:
                uptime_info['last_reboot'] = cmd['output'].splitlines()[0] if cmd['output'] else ''

            # Get number of users
            cmd = self.run_command(['who'], capture_all=True)
            if cmd['success']:
                uptime_info['users'] = len(cmd['output'].splitlines())

            return uptime_info

        except Exception as e:
            logging.error(f"Error getting detailed uptime: {e}")
            return uptime_info

    def format_uptime_section(self) -> str:
        """Format uptime information for the report."""
        uptime_info = self.get_detailed_uptime()
        
        lines = [
            "\nUPTIME INFORMATION",
            "-" * 50,
            f"System Uptime: {uptime_info['uptime_pretty']}",
            f"Last Boot: {uptime_info['last_boot']}",
            f"Last Reboot: {uptime_info['last_reboot']}",
            f"Active Users: {uptime_info['users']}",
            f"Uptime in Seconds: {uptime_info['uptime_seconds']:.0f}"
        ]
        
        return '\n'.join(lines)
    
    def format_banner(self, text: str, width: int = 50) -> str:
        """Create a neat banner for sections."""
        return f"\n{'='*width}\n{text.center(width)}\n{'='*width}\n"
    
    async def monitor(self):
        """Run monitoring once and exit."""
        try:
            # Ensure directories exist
            self.log_dir.mkdir(parents=True, exist_ok=True)
            self.logs_dir.mkdir(parents=True, exist_ok=True)

            print("\n" + "="*50)
            print("RHEL 9 Server Monitoring System")
            print("="*50)
            print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"Log Directory: {self.logs_dir}")  # Updated to show full path
            print("="*50 + "\n")
            
            available_models = await self.check_available_models()
            print(f"Available Ollama models: {available_models}\n")

            metrics = await self.get_system_metrics()
            analysis = await self.analyze_metrics(metrics)
            
            # Generate timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # Save detailed system analysis
            metrics_file = self.logs_dir / f'metrics_{timestamp}.json'
            serialized_analysis = {
                'timestamp': analysis['timestamp'],
                'analysis': analysis['analysis'],
                'recommendation': analysis['recommendation'],
                'tuning_playbook': analysis['tuning_playbook'],
                'metrics': serialize_metrics(metrics),
                'health_checks': analysis['health_checks'],
                'validation_checks': analysis['validation_checks']
            }
            metrics_file.write_text(json.dumps(serialized_analysis, indent=2))

            # Print the report
            self.print_report(metrics, analysis)

            # Save full report
            report_file = self.logs_dir / f'report_{timestamp}.txt'
            report_content = self.format_report(metrics, analysis)
            report_file.write_text(report_content)
            print(f"\nFull Report saved to: {report_file}")

            # Save Ansible playbook
            playbook_file = self.logs_dir / f'tuning_playbook_{timestamp}.yml'
            playbook_file.write_text(analysis['tuning_playbook'])
            print(f"System Tuning Playbook saved to: {playbook_file}")

            # Generate and save Terraform code
            new_instance_type = self._extract_instance_type(analysis['recommendation'])
            if new_instance_type:
                terraform_code = await self.generate_terraform_code(metrics, new_instance_type)
                terraform_file = self.logs_dir / f'terraform_{timestamp}.tf'
                terraform_file.write_text(terraform_code)
                print(f"Terraform code saved to: {terraform_file}\n")

        except Exception as e:
            logging.error(f"Monitoring failed: {e}")
            print(f"\nError: {str(e)}")

    def _extract_instance_type(self, recommendation: str) -> str:
        """Extract recommended instance type from AI analysis."""
        # Look for common instance type patterns
        patterns = [
            r't[0-9][a-z]?\.(nano|micro|small|medium|large|xlarge)',
            r'[cmr][0-9][a-z]?\.(nano|micro|small|medium|large|xlarge)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, recommendation.lower())
            if match:
                return match.group(0)
                
        return "t3.micro"  # Default fallback if no instance type found
    
    async def check_available_models(self) -> List[str]:
        """Check which models are available in Ollama."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self.config.OLLAMA_BASE_URL}{self.config.OLLAMA_ENDPOINTS.get('models')}") as response:
                    if response.status == 200:
                        data = await response.json()
                        return [model['name'] for model in data.get('models', [])]
                    else:
                        logging.error(f"Failed to get models, status: {response.status}")
                        return []
        except Exception as e:
            logging.error(f"Error checking available models: {e}")
            return []
    
    def get_monitoring_commands(self) -> Dict[str, List[str]]:
        """Get list of monitoring commands used for system metrics collection."""
        return {
            'CPU Info': [
                'cat /proc/cpuinfo',
                'mpstat',
                'lscpu'
            ],
            'Memory Info': [
                'free -m',
                'vmstat',
                'cat /proc/meminfo'
            ],
            'Disk Info': [
                'df -h',
                'lsblk --json --output NAME,SIZE,TYPE,MOUNTPOINT',
                'iostat',
                'fdisk -l'
            ],
            'Network Info': [
                'ip -br link show',
                'ip -s link',
                'netstat -i',
                'ss -antp'
            ],
            'Process Info': [
                'top -b -n 1',
                'ps aux',
                'pstree'
            ],
            'System Load': [
                'uptime',
                'w',
                'who'
            ],
            'Service Status': [
                'systemctl status sshd',
                'systemctl status httpd',
                'systemctl status mariadb',
                'systemctl status firewalld',
                'systemctl status chronyd'
            ],
            'Security Info': [
                'sestatus',
                'getenforce',
                'firewall-cmd --list-all'
            ],
            'System Updates': [
                'dnf check-update --quiet',
                'dnf list-security --quiet'
            ]
        }

    def format_monitoring_commands_section(self) -> str:
        """Format monitoring commands section for the report."""
        commands = self.get_monitoring_commands()
        
        lines = [
            "\n## System Monitoring Commands",
            "The following commands were used to gather system metrics:\n"
        ]
        
        for category, cmd_list in commands.items():
            lines.append(f"### {category}")
            for cmd in cmd_list:
                lines.append(f"```bash\n{cmd}\n```")
            lines.append("")  # Empty line between categories
        
        return '\n'.join(lines)
    
    def format_health_assessment(self, health_status: ServerHealthStatus) -> str:
        """Format health assessment results for the report."""
        lines = [
            self.format_banner("SERVER HEALTH ASSESSMENT"),
            f"Overall Health Status: {health_status.health_status}",
            f"Health Score: {health_status.overall_score}%\n"
        ]

        # Resource Health
        lines.append("## Resource Health")
        for resource, details in health_status.resource_health.items():
            status_symbol = "✅" if details['status'] == 'healthy' else "⚠️" if details['status'] == 'warning' else "❌"
            lines.append(f"{status_symbol} {resource.replace('_', ' ').title()}: "
                        f"{details['value']:.2f}% (Threshold: {details['threshold']:.2f}%)")

        # Service Health
        lines.append("\n## Service Health")
        for service, details in health_status.service_health.items():
            status_symbol = "✅" if details['status'] == 'healthy' else "❌"
            lines.append(f"{status_symbol} {service}: {details['value']}")

        # Security Health
        lines.append("\n## Security Health")
        for check, details in health_status.security_health.items():
            status_symbol = "✅" if details['status'] == 'healthy' else "❌"
            lines.append(f"{status_symbol} {check.replace('_', ' ').title()}: {details['value']}")

        # Infrastructure Health
        lines.append("\n## Infrastructure Health")
        for component, details in health_status.infrastructure_health.items():
            status_symbol = "✅" if details['status'] == 'healthy' else "❌"
            lines.append(f"{status_symbol} {component.replace('_', ' ').title()}: "
                        f"{details['value']} (Required: {details['required']})")

        # Error Status
        lines.append("\n## Error Status")
        for source, details in health_status.error_status.items():
            status_symbol = "✅" if details['status'] == 'healthy' else "⚠️" if details['status'] == 'warning' else "❌"
            lines.append(f"{status_symbol} {source.title()}: {details['value']} errors "
                        f"({details['critical_count']} critical)")

        # Recommendations
        if health_status.recommendations:
            lines.append("\n## Recommendations")
            for rec in health_status.recommendations:
                 priority_symbol = "🔴" if rec['priority'] == 'high' else "🟡" if rec['priority'] == 'medium' else "🟢"
                 lines.append(f"{priority_symbol} {rec['recommendation']}")


        return '\n'.join(lines)
    

def serialize_health_status(health_status: ServerHealthStatus) -> dict:
    """Convert ServerHealthStatus to a dictionary for JSON serialization."""
    return {
        'resource_health': health_status.resource_health,
        'service_health': health_status.service_health,
        'security_health': health_status.security_health,
        'infrastructure_health': health_status.infrastructure_health,
        'error_status': health_status.error_status,
        'overall_score': health_status.overall_score,
        'health_status': health_status.health_status,
        'recommendations': health_status.recommendations
    }

def serialize_metrics(metrics: SystemMetrics) -> dict:
    """Convert SystemMetrics to a dictionary for JSON serialization."""
    metrics_dict = {
        'timestamp': metrics.timestamp,
        'hostname': metrics.hostname,
        'os_version': metrics.os_version,
        'kernel_version': metrics.kernel_version,
        'uptime': metrics.uptime,
        'cpu_usage': metrics.cpu_usage,
        'memory_used': metrics.memory_used,
        'memory_total': metrics.memory_total,
        'swap_used': metrics.swap_used,
        'swap_total': metrics.swap_total,
        'disk_usage': metrics.disk_usage,
        'updates_pending': metrics.updates_pending,
        'security_updates': metrics.security_updates,
        'network_metrics': metrics.network_metrics,
        'top_processes': metrics.top_processes,
        'service_status': metrics.service_status,
        'load_average': metrics.load_average,
        'instance_metadata': metrics.instance_metadata,
        'open_ports': metrics.open_ports,
        'syslog_errors': metrics.syslog_errors,
    }
    
    if metrics.health_status:
        metrics_dict['health_status'] = serialize_health_status(metrics.health_status)
    
    if metrics.ai_validation:
         metrics_dict['ai_validation'] = {
                'validated_components': metrics.ai_validation.validated_components,
                'adjustments': metrics.ai_validation.adjustments,
                'false_positives': metrics.ai_validation.false_positives,
                'additional_metrics': metrics.ai_validation.additional_metrics,
                'recommendations': metrics.ai_validation.recommendations,
                'confidence_score': metrics.ai_validation.confidence_score,
                'overall_assessment': metrics.ai_validation.overall_assessment
        }
    
    return metrics_dict
    

async def main():
    try:
        monitor = RHELMonitor()
        await monitor.monitor()
    except Exception as e:
        print(f"Error: {str(e)}")
    finally:
        # Ensure clean exit
        print("\nMonitoring completed.")
        sys.exit(0)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nMonitoring stopped by user.")
        sys.exit(0)