#!/usr/bin/env python3
import argparse
import subprocess
import time
import os
import sys
import logging
import psutil
import threading
from pathlib import Path

logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class RHEL9StressSimulator:
    def __init__(self):
        self._check_rhel_version()
        self.stress_installed = self._setup_stress_tools()
        self.total_memory = psutil.virtual_memory().total / (1024 * 1024 * 1024)  # GB
        self.cpu_count = psutil.cpu_count()
        self.stop_monitoring = False
        self.monitor_thread = None
        
    def _check_rhel_version(self):
        """Verify this is running on RHEL 9"""
        try:
            with open('/etc/redhat-release', 'r') as f:
                version = f.read().strip()
                logger.info(f"Running on {version}")
                if '9.' not in version:
                    logger.warning("This script is optimized for RHEL 9")
        except Exception as e:
            logger.warning(f"Could not verify RHEL version: {e}")

    def _setup_stress_tools(self):
        """Set up stress testing tools"""
        try:
            # First check if EPEL repository is enabled
            try:
                subprocess.run(['sudo', 'dnf', 'repolist', 'epel'], check=True, capture_output=True)
                logger.info("EPEL repository is already enabled")
            except subprocess.CalledProcessError:
                logger.info("Installing EPEL repository...")
                try:
                    # Install EPEL repository
                    epel_cmd = [
                        'sudo', 'dnf', 'install', '-y',
                        'https://dl.fedoraproject.org/pub/epel/epel-release-latest-9.noarch.rpm'
                    ]
                    subprocess.run(epel_cmd, check=True)
                    logger.info("EPEL repository installed successfully")
                except subprocess.CalledProcessError as e:
                    logger.error(f"Failed to install EPEL repository: {e}")
                    return False

            # Check if stress-ng is already installed
            try:
                subprocess.run(['which', 'stress-ng'], check=True, capture_output=True)
                logger.info("stress-ng already installed")
                return True
            except subprocess.CalledProcessError:
                logger.info("Installing stress-ng...")

            # Install stress-ng and performance monitoring tools
            install_cmd = [
                'sudo', 'dnf', 'install', '-y',
                'stress-ng',  # Modern stress testing tool
                'perf',      # Performance monitoring
                'sysstat',   # System monitoring (iostat, mpstat, etc)
                'procps-ng'  # Process monitoring tools
            ]
            subprocess.run(install_cmd, check=True)
            logger.info("Successfully installed all required tools")
            return True

        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to install required tools: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error during tool setup: {e}")
            return False

    def monitor_system(self):
        """Continuously monitor system resources"""
        while not self.stop_monitoring:
            try:
                # Get CPU info
                cpu_percent = psutil.cpu_percent(interval=1)
                cpu_freq = psutil.cpu_freq()
                
                # Get memory info
                memory = psutil.virtual_memory()
                swap = psutil.swap_memory()
                
                # Get load average
                loadavg = os.getloadavg()
                
                # Get process info
                processes = len(psutil.pids())
                
                # Get top processes by CPU and memory
                top_procs = []
                for proc in sorted(psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']), 
                                 key=lambda p: p.info['cpu_percent'],
                                 reverse=True)[:3]:
                    top_procs.append(f"{proc.info['name']}({proc.info['pid']}): "
                                   f"CPU={proc.info['cpu_percent']:.1f}%, "
                                   f"MEM={proc.info['memory_percent']:.1f}%")
                
                logger.info("\n" + "="*50)
                logger.info("System Statistics:")
                logger.info(f"CPU Usage: {cpu_percent}%")
                if cpu_freq:
                    logger.info(f"CPU Frequency: Current={cpu_freq.current:.1f}MHz")
                logger.info(f"Memory Usage: {memory.percent}% (Used: {memory.used/1024/1024/1024:.2f}GB)")
                logger.info(f"Swap Usage: {swap.percent}% (Used: {swap.used/1024/1024/1024:.2f}GB)")
                logger.info(f"Load Average: 1min={loadavg[0]:.2f}, 5min={loadavg[1]:.2f}, 15min={loadavg[2]:.2f}")
                logger.info(f"Total Processes: {processes}")
                logger.info("\nTop Processes by Resource Usage:")
                for proc in top_procs:
                    logger.info(f"  {proc}")
                
                # Get disk I/O
                try:
                    disk_io = psutil.disk_io_counters()
                    logger.info(f"\nDisk I/O:")
                    logger.info(f"  Read: {disk_io.read_bytes/1024/1024:.2f}MB")
                    logger.info(f"  Write: {disk_io.write_bytes/1024/1024:.2f}MB")
                except:
                    pass
                
                time.sleep(5)  # Update every 5 seconds
                
            except Exception as e:
                logger.error(f"Error in monitoring thread: {e}")
                time.sleep(5)  # Wait before retrying
                
    def start_monitoring(self):
        """Start the monitoring thread"""
        self.stop_monitoring = False
        self.monitor_thread = threading.Thread(target=self.monitor_system)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        
    def stop_monitoring(self):
        """Stop the monitoring thread"""
        self.stop_monitoring = True
        if self.monitor_thread:
            self.monitor_thread.join()

    def simulate_combined_stress(self, cpu_load=80, memory_percent=80, duration=300):
        """Simulate combined CPU and memory stress"""
        if not self.stress_installed:
            logger.error("Stress tools not installed. Cannot continue.")
            return False
            
        try:
            logger.info(f"Starting combined stress test:")
            logger.info(f"- CPU Load Target: {cpu_load}%")
            logger.info(f"- Memory Usage Target: {memory_percent}%")
            logger.info(f"- Duration: {duration} seconds")
            
            # Calculate CPU workers based on desired load
            cpu_workers = max(1, int((self.cpu_count * cpu_load) / 100))
            
            # Calculate memory to use
            memory_mb = int((self.total_memory * 1024 * memory_percent) / 100)
            
            # Start monitoring
            self.start_monitoring()
            
            # Start stress test
            cmd = [
                'stress-ng',
                '--cpu', str(cpu_workers),
                '--vm', '2',
                '--vm-bytes', f'{memory_mb}M',
                '--timeout', str(duration),
                '--verbose'
            ]
            
            process = subprocess.Popen(cmd)
            logger.info(f"Stress test started with PID: {process.pid}")
            
            # Wait for the stress test to complete
            process.wait()
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to simulate stress: {e}")
            return False
        finally:
            # Stop monitoring
            self.stop_monitoring = True
            if self.monitor_thread:
                self.monitor_thread.join()

    def simulate_gradual_load(self, duration=300, steps=5):
        """Simulate gradually increasing system load"""
        if not self.stress_installed:
            return False
            
        try:
            logger.info(f"Starting gradual load simulation:")
            logger.info(f"- Total Duration: {duration} seconds")
            logger.info(f"- Steps: {steps}")
            
            step_duration = duration // steps
            
            # Start monitoring
            self.start_monitoring()
            
            for step in range(1, steps + 1):
                cpu_load = (step * 20)  # Increase by 20% each step
                memory_percent = (step * 20)  # Increase by 20% each step
                
                logger.info(f"\nStep {step}/{steps}:")
                logger.info(f"- CPU Load Target: {cpu_load}%")
                logger.info(f"- Memory Usage Target: {memory_percent}%")
                
                # Calculate resources for this step
                cpu_workers = max(1, int((self.cpu_count * cpu_load) / 100))
                memory_mb = int((self.total_memory * 1024 * memory_percent) / 100)
                
                cmd = [
                    'stress-ng',
                    '--cpu', str(cpu_workers),
                    '--vm', '2',
                    '--vm-bytes', f'{memory_mb}M',
                    '--timeout', str(step_duration),
                    '--verbose'
                ]
                
                process = subprocess.Popen(cmd)
                logger.info(f"Step {step} started with PID: {process.pid}")
                
                # Wait for this step to complete
                process.wait()
                
            return True
            
        except Exception as e:
            logger.error(f"Failed to simulate gradual load: {e}")
            return False
        finally:
            # Stop monitoring
            self.stop_monitoring = True
            if self.monitor_thread:
                self.monitor_thread.join()

    def cleanup(self):
        """Clean up all simulated stress"""
        try:
            logger.info("Cleaning up stress simulation...")
            
            # Kill any remaining stress processes
            subprocess.run(['sudo', 'pkill', 'stress-ng'], check=False)
            
            # Sync filesystem
            subprocess.run(['sudo', 'sync'], check=False)
            
            # Clear page cache
            try:
                with open('/proc/sys/vm/drop_caches', 'w') as f:
                    f.write('3')
            except:
                pass
            
            # Stop monitoring
            self.stop_monitoring = True
            if self.monitor_thread:
                self.monitor_thread.join()
                
            logger.info("Cleanup completed")
            return True
            
        except Exception as e:
            logger.error(f"Failed to clean up: {e}")
            return False

def main():
    parser = argparse.ArgumentParser(
        description='RHEL 9 Resource Stress Simulator')
    parser.add_argument('--scenario', 
                       choices=['combined', 'gradual'], 
                       default='combined',
                       help='Type of stress scenario to simulate')
    parser.add_argument('--duration', type=int, default=300,
                       help='Duration of simulation in seconds')
    parser.add_argument('--cpu-load', type=int, default=80,
                       help='CPU load percentage (for combined scenario)')
    parser.add_argument('--memory-percent', type=int, default=80,
                       help='Memory usage percentage (for combined scenario)')
    parser.add_argument('--cleanup', action='store_true',
                       help='Clean up after simulation')
    
    args = parser.parse_args()
    
    simulator = RHEL9StressSimulator()
    
    try:
        if args.scenario == 'combined':
            simulator.simulate_combined_stress(
                args.cpu_load, 
                args.memory_percent, 
                args.duration
            )
        elif args.scenario == 'gradual':
            simulator.simulate_gradual_load(args.duration)
            
        if args.cleanup:
            simulator.cleanup()
            
    except KeyboardInterrupt:
        logger.info("\nSimulation interrupted by user")
        simulator.cleanup()
        sys.exit(0)

if __name__ == "__main__":
    main()