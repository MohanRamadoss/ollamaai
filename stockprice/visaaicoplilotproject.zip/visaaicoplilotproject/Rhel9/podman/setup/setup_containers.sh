#!/bin/bash

# Function to install Docker on Ubuntu 22.04
install_docker_ubuntu() {
    echo "Installing Docker on Ubuntu 22.04..."
    
    # Install prerequisites
    apt-get install -y ca-certificates curl
    
    # Set up Docker's GPG key
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
    chmod a+r /etc/apt/keyrings/docker.asc
    
    # Add the repository to Apt sources
    echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
    $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
    tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # Update and install Docker
    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    
     #####Add current user
    sudo usermod -aG docker $USER
    ##
    newgrp docker


    # Verify installation
    docker run hello-world
    
    echo "Docker installation completed!"
}

# Function to install Podman on RHEL 9
install_podman_rhel() {
    echo "Installing Podman on RHEL 9..."
    
    # Install Podman
    dnf install -y podman
    
    # Start and enable Podman socket
    systemctl enable podman.socket
    systemctl start podman.socket
    
    echo "Podman installation completed!"
}

# Function to detect OS
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$ID
        VERSION=$VERSION_ID
        echo "Detected OS: $OS"
        echo "Detected Version: $VERSION"
    else
        echo "Cannot detect OS"
        exit 1
    fi
}

# Function to clean up existing containers and images
cleanup() {
    echo "Cleaning up existing containers and images..."
    if command -v docker &> /dev/null; then
        docker rm -f cpu-hog-container mem-hog-container nginx-container python-logger 2>/dev/null || true
        docker rmi -f cpu-load-image memory-load-image nginx-custom python-logger-image 2>/dev/null || true
    fi
    if command -v podman &> /dev/null; then
        podman rm -f cpu-hog-container mem-hog-container nginx-container python-logger 2>/dev/null || true
        podman rmi -f cpu-load-image memory-load-image nginx-custom python-logger-image 2>/dev/null || true
    fi
}

# Function to set up container files
setup_container_files() {
    # Create directories
    mkdir -p cpu memory nginx python_logger

    # Create CPU load files
    cat > cpu/cpu_load.py << 'EOF'
import time
import os

def cpu_hog(duration=1000):
    start_time = time.time()
    while time.time() - start_time < duration:
        x = 0
        for i in range(1000000):
            x += i
    print(f"CPU hog process finished after: {time.time() - start_time} sec")

if __name__ == "__main__":
    print("Starting CPU hog process")
    cpu_hog(duration=int(os.environ.get('DURATION', 10000000)))
EOF

    # Create memory load files
    cat > memory/memory_load.py << 'EOF'
import time
import os

def memory_hog(size_mb=100):
    megabyte = 1024 * 1024
    large_list = bytearray(int(size_mb * megabyte))
    print(f"Allocated: {size_mb} MB")
    time.sleep(int(os.environ.get('DURATION', 300)))
    print("Finished")
    return large_list

if __name__ == "__main__":
    print("Starting memory hog process")
    memory_hog(size_mb=int(os.environ.get('SIZE', 2000)))
EOF

    # Create Python logger
    cat > python_logger/logger.py << 'EOF'
import logging
import time
import random
import sys

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)

# List of sample log messages
messages = [
    "Processing user request",
    "Database connection established",
    "Cache miss detected",
    "Background task completed",
    "API request received",
    "Data synchronization started",
    "Memory cleanup performed",
    "Configuration reloaded",
    "Authentication attempt",
    "Resource allocation completed"
]

# Log levels and their weights
log_levels = {
    logging.INFO: 70,
    logging.WARNING: 20,
    logging.ERROR: 8,
    logging.CRITICAL: 2
}

def generate_logs():
    while True:
        # Select random message and level based on weights
        message = random.choice(messages)
        level = random.choices(
            list(log_levels.keys()),
            weights=list(log_levels.values())
        )[0]
        
        # Add random context
        context = {
            'request_id': f'{random.randint(1000, 9999)}',
            'duration_ms': f'{random.randint(10, 1000)}',
            'user_id': f'user_{random.randint(1, 100)}'
        }
        
        # Log the message
        logging.log(level, f"{message} - Context: {context}")
        
        # Random sleep between 0.1 and 2 seconds
        time.sleep(random.uniform(0.1, 2))

if __name__ == "__main__":
    logging.info("Starting log generator")
    generate_logs()
EOF

    # Create Nginx config files
    cat > nginx/nginx.conf << 'EOF'
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log notice;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    access_log /var/log/nginx/access.log combined buffer=512k flush=1m;
    sendfile on;
    keepalive_timeout 65;
    include /etc/nginx/conf.d/*.conf;
}
EOF

    cat > nginx/default.conf << 'EOF'
server {
    listen 80;
    server_name localhost;
    
    location / {
        root /usr/share/nginx/html;
        index index.html;
    }
    
    location /status {
        stub_status on;
        access_log off;
    }
}
EOF
}

# Function to create Docker containers
create_docker_containers() {
    echo "Setting up Docker containers..."
    
    setup_container_files
    
    # Create Dockerfiles
    cat > cpu/Dockerfile << 'EOF'
FROM python:3.9-slim-buster
WORKDIR /app
COPY cpu_load.py .
CMD ["python", "cpu_load.py"]
EOF

    cat > memory/Dockerfile << 'EOF'
FROM python:3.9-slim-buster
WORKDIR /app
COPY memory_load.py .
ENV INITIAL_SIZE_MB=500
ENV INCREMENT_MB=100
ENV MAX_SIZE_MB=2000
ENV INCREMENT_INTERVAL=300
CMD ["python", "memory_load.py"]
EOF

    cat > nginx/Dockerfile << 'EOF'
FROM docker.io/library/nginx:latest
COPY nginx.conf /etc/nginx/nginx.conf
COPY default.conf /etc/nginx/conf.d/default.conf
EOF

    cat > python_logger/Dockerfile << 'EOF'
FROM python:3.9-slim-buster
WORKDIR /app
COPY logger.py .
CMD ["python", "logger.py"]
EOF

    # Build images
    echo "Building Docker images..."
    docker build -t cpu-load-image cpu/
    docker build -t memory-load-image memory/
    docker build -t nginx-custom nginx/
    docker build -t python-logger-image python_logger/

    # Run containers
    echo "Starting containers..."
    docker run -d --name cpu-hog-container cpu-load-image
    docker run -d -e SIZE=2000 --name mem-hog-container memory-load-image
    docker run -d --name nginx-container -p 8080:80 nginx-custom
    docker run -d --name python-logger python-logger-image

    echo "Docker containers setup complete!"
}

# Function to create Podman containers
create_podman_containers() {
    echo "Setting up Podman containers..."
    
    setup_container_files
    
    # Create Containerfiles
    cat > cpu/Containerfile << 'EOF'
FROM python:3.9-slim-buster
WORKDIR /app
COPY cpu_load.py .
CMD ["python", "cpu_load.py"]
EOF

    cat > memory/Containerfile << 'EOF'
FROM python:3.9-slim-buster
WORKDIR /app
COPY memory_load.py .
ENV INITIAL_SIZE_MB=500
ENV INCREMENT_MB=100
ENV MAX_SIZE_MB=2000
ENV INCREMENT_INTERVAL=300
CMD ["python", "memory_load.py"]
EOF

    cat > nginx/Containerfile << 'EOF'
FROM docker.io/library/nginx:latest
COPY nginx.conf /etc/nginx/nginx.conf
COPY default.conf /etc/nginx/conf.d/default.conf
EOF

    cat > python_logger/Containerfile << 'EOF'
FROM python:3.9-slim-buster
WORKDIR /app
COPY logger.py .
CMD ["python", "logger.py"]
EOF

    # Build images
    echo "Building Podman images..."
    podman build -t cpu-load-image -f cpu/Containerfile cpu/
    podman build -t memory-load-image -f memory/Containerfile memory/
    podman build -t nginx-custom -f nginx/Containerfile nginx/
    podman build -t python-logger-image -f python_logger/Containerfile python_logger/

    # Run containers
    echo "Starting containers..."
    podman run -d --name cpu-hog-container cpu-load-image
    podman run -d -e SIZE=2000 --name mem-hog-container memory-load-image
    podman run -d --name nginx-container -p 8080:80 nginx-custom
    podman run -d --name python-logger python-logger-image

    echo "Podman containers setup complete!"
}

# Main script execution starts here

# Check if script is run as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root"
    exit 1
fi

# Detect OS
detect_os

# Install container runtime based on OS
if [[ "$OS" == "ubuntu" ]]; then
    echo "Ubuntu $VERSION detected - installing Docker..."
    if ! command -v docker &> /dev/null; then
        install_docker_ubuntu
    else
        echo "Docker is already installed"
    fi
elif [[ "$OS" == "rhel" && "$VERSION" == "9"* ]]; then
    echo "RHEL 9 detected - installing Podman..."
    if ! command -v podman &> /dev/null; then
        install_podman_rhel
    else
        echo "Podman is already installed"
    fi
else
    echo "Unsupported OS: $OS $VERSION"
    echo "This script supports Ubuntu (22.04, 24.04) and RHEL 9"
    exit 1
fi

# Cleanup existing containers and images
cleanup

# Detect container runtime and execute appropriate function
if command -v docker &> /dev/null; then
    create_docker_containers
elif command -v podman &> /dev/null; then
    create_podman_containers
else
    echo "Neither Docker nor Podman is installed. Please install one of them first."
    exit 1
fi