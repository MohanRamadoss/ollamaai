#!/bin/bash

# Update system packages
#sudo dnf update -y

# Install Python and development tools
sudo dnf install -y python3 python3-pip python3-devel gcc

# Install system packages
sudo dnf install -y \
    python3-psutil \
    iproute \
    net-tools

# Create and set up virtual environment
python3 -m venv monitoring_env
source monitoring_env/bin/activate

# Upgrade pip and install required packages
pip install --upgrade pip
pip install \
    aiohttp \
    jinja2 \
    python-dotenv \
    tenacity \
    psutil \
    requests \
    xmltodict \
    tqdm \
    asyncio \
    PyYAML 

# Print Python and pip versions for verification
python3 --version
pip --version

export OLLAMA_API_URL="http://209.137.198.212:11434"