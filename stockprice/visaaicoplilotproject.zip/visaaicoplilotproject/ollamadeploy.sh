I'll provide a step-by-step guide to deploy the application using Docker with Nginx as a reverse proxy and SSL:

1. First, let's create a Dockerfile for the application:

### [Dockerfile](vscode-remote://ssh-remote/home/mohan/aiproject/visaaicodecraft/project-2/aicodecraft/Dockerfile)

```dockerfile


FROM node:18-alpine as builder

WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### [nginx.conf](vscode-remote://ssh-remote/home/mohan/aiproject/visaaicodecraft/project-2/aicodecraft/nginx.conf)

```nginx


Made changes.

server {
    listen 80;
    server_name localhost;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://ollama:11434;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### [docker-compose.yml](vscode-remote://ssh-remote/home/mohan/aiproject/visaaicodecraft/project-2/aicodecraft/docker-compose.yml)

```yaml


Made changes.

version: '3.8'

services:
  frontend:
    build: .
    container_name: aicodecraft-frontend
    restart: unless-stopped
    networks:
      - app-network

  ollama:
    image: ollama/ollama:latest
    container_name: ollama
    restart: unless-stopped
    volumes:
      - ollama-data:/root/.ollama
    networks:
      - app-network

  nginx:
    image: nginx:alpine
    container_name: nginx-proxy
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/conf.d:/etc/nginx/conf.d
      - ./nginx/ssl:/etc/nginx/ssl
      - ./nginx/data:/var/www/html
      - certbot-etc:/etc/letsencrypt
      - certbot-var:/var/lib/letsencrypt
    networks:
      - app-network
    depends_on:
      - frontend
      - ollama

  certbot:
    image: certbot/certbot
    container_name: certbot
    volumes:
      - certbot-etc:/etc/letsencrypt
      - certbot-var:/var/lib/letsencrypt
      - ./nginx/data:/var/www/html
    depends_on:
      - nginx

volumes:
  certbot-etc:
  certbot-var:
  ollama-data:

networks:
  app-network:
    driver: bridge
```

Here are the deployment steps:

1. Install Docker and Docker Compose on Ubuntu:
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo apt install docker-compose -y
```

2. Setup domain and SSL:
```bash
# Create directories
mkdir -p nginx/conf.d nginx/ssl nginx/data

# Create Nginx configuration for SSL
cat > nginx/conf.d/app.conf << 'EOF'
server {
    listen 80;
    server_name your-domain.com;
    
    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl;
    server_name your-domain.com;

    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    location / {
        proxy_pass http://frontend:80;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    location /api {
        proxy_pass http://ollama:11434;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF
```

3. Start the application:
```bash
# Start containers
docker-compose up -d

# Get SSL certificate
docker-compose run --rm certbot certonly --webroot --webroot-path /var/www/html --email your-email@domain.com --agree-tos --no-eff-email -d your-domain.com

# Reload Nginx
docker-compose exec nginx nginx -s reload
```

4. Setup auto-renewal for SSL certificates:
```bash
# Create renewal script
cat > renew-ssl.sh << 'EOF'
#!/bin/bash
docker-compose run --rm certbot renew
docker-compose exec nginx nginx -s reload
EOF

chmod +x renew-ssl.sh

# Add to crontab
(crontab -l 2>/dev/null; echo "0 12 * * * /path/to/renew-ssl.sh") | crontab -
```

5. Pull and run models:
```bash
# Pull required models
docker-compose exec ollama ollama pull falcon3:10b
docker-compose exec ollama ollama pull deepseek-coder:33b
docker-compose exec ollama ollama pull llama3.3:latest
```

6. Monitor logs:
```bash
# View logs
docker-compose logs -f

# Check specific service
docker-compose logs -f frontend
docker-compose logs -f ollama
```

Remember to:
1. Replace `your-domain.com` with your actual domain
2. Update `your-email@domain.com` with your email
3. Configure DNS to point to your server
4. Open ports 80 and 443 in your firewall:
```bash
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
```

This setup provides:
- Containerized application
- SSL encryption
- Automatic certificate renewal
- Reverse proxy
- Model serving
- Load balancing
- Persistent storage

Made changes.