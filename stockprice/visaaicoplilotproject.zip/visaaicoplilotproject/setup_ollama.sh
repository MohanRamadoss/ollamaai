#!/bin/bash

# Backup the original grub file
sudo cp /etc/default/grub /etc/default/grub.bak

# Append ipv6.disable=1 to GRUB_CMDLINE_LINUX_DEFAULT
sudo sed -i '/^GRUB_CMDLINE_LINUX_DEFAULT=/ s/"$/ ipv6.disable=1"/' /etc/default/grub

# Update GRUB
sudo update-grub

# Install Ollama
sudo curl https://ollama.ai/install.sh | sh

# Pull the models
sudo ollama pull mistral-small
sudo ollama pull llama3.3
sudo ollama pull granite-code:20b
sudo ollama pull llama3.2
sudo ollama pull mistral
### codeing models 
sudo ollama pull codellama
sudo ollama pull codellama:13b
sudo ollama pull granite-code:8b
sudo ollama pull codegemma
sudo ollama pull codestral
sudo ollama pull codeqwen
sudo ollama pull qwen2.5-coder:14b
sudo ollama pull deepseek-coder:6.7b
sudo ollama pull deepseek-coder:33b
#sudo ollama pull starcoder:15b
#AI ML Models
sudo ollama pull falcon3:10b
#sudo ollama pull nemotron

# sql code models not working 
#sudo ollama pull sqlcoder:15b 

# Create systemd service file for Ollama #
###check CORS and origins
sudo bash -c 'cat > /etc/systemd/system/ollama.service <<EOF
[Unit]
Description=Ollama Service
After=network-online.target

[Service]
Environment="OLLAMA_HOST=0.0.0.0"
#Environment="OLLAMA_ORIGINS=*"
#Environment="OLLAMA_CORS_ORIGINS=*"
Environment="OLLAMA_PORT=11434"
Environment="OLLAMA_LOG_LEVEL=info"
#Environment="OLLAMA_HEADERS=Strict-Transport-Security:max-age=31536000;includeSubDomains,X-Frame-Options:SAMEORIGIN,X-XSS-Protection:1;mode=block,X-Content-Type-Options:nosniff"
ExecStart=/usr/local/bin/ollama serve
User=ollama
Group=ollama
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF'

# Reload systemd daemon and restart Ollama service
sudo systemctl daemon-reload
sudo systemctl restart ollama

# Reload systemd daemon and restart Ollama service
#sudo systemctl daemon-reload
#sudo systemctl restart ollama

# Disable and stop unnecessary services
sudo systemctl disable postfix
sudo systemctl disable cups
sudo systemctl stop cups
sudo systemctl stop postfix
sudo systemctl stop cups


# Reboot the system
sudo reboot

echo "IPv6 has been disabled, Ollama has been installed and configured, unnecessary services have been disabled, and the system is rebooting."