from flask import Flask, request, jsonify
from typing import List, Optional, Dict, Any
import requests
import json
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import asyncio
from datetime import datetime
import sqlite3

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

class ModelConfig:
    OLLAMA_BASE_URL = "http://localhost:11434"
    PRIMARY_MODEL = "llama3"
    SECONDARY_MODELS = ["mistral", "granite", "gemma"]
    TIMEOUT = 30  # seconds
    MAX_RETRIES = 3
    RETRY_DELAY = 1  # seconds
    QUALITY_METRICS = {
        "complexity": {
            "weight": 0.3,
            "thresholds": {
                "good": 0.8,
                "medium": 0.6,
                "poor": 0.4
            }
        },
        "maintainability": {
            "weight": 0.3,
            "thresholds": {
                "good": 0.8,
                "medium": 0.6,
                "poor": 0.4
            }
        },
        "performance": {
            "weight": 0.2,
            "thresholds": {
                "good": 0.8,
                "medium": 0.6,
                "poor": 0.4
            }
        },
        "security": {
            "weight": 0.2,
            "thresholds": {
                "good": 0.8,
                "medium": 0.6,
                "poor": 0.4
            }
        }
    }
    PROMPTS = {
       "code_generation": """
        Generate code for the following task with these requirements:
        1. Focus on clean, readable code
        2. Include proper error handling
        3. Follow language-specific best practices
        4. Add appropriate comments and documentation
        
        Task: {prompt}
        Language: {language}
        Additional requirements: {requirements}
        
        Provide only the code without explanations.
        """,
        
        "code_review": """
         Analyze the following code focusing on these aspects:
         1. Code Complexity:
         - Cyclomatic complexity
         - Nesting depth
         - Function length
         
         2. Maintainability:
         - Code organization
         - Variable/function naming
         - Documentation quality
         
         3. Performance:
         - Algorithm efficiency
         - Resource usage
         - Bottlenecks
        
         4. Security:
         - Input validation
         - Error handling
         - Security best practices
         
         Code to review:
         {code}
         
        Provide feedback in this JSON structure:
        {{
             "complexity": {{
                "score": float,
                 "issues": [str],
                 "suggestions": [str]
             }},
            "maintainability": {{
                 "score": float,
                 "issues": [str],
                 "suggestions": [str]
             }},
             "performance": {{
                "score": float,
                "issues": [str],
                 "suggestions": [str]
            }},
            "security": {{
                 "score": float,
                "issues": [str],
                "suggestions": [str]
            }}
        }}
        """,

       "code_refinement": """
        Refine the following code based on the detailed feedback.
        Focus on these priorities:
        1. {priority_1}
        2. {priority_2}
        3. {priority_3}

        Original Code:
        {original_code}

        Feedback Analysis:
        {feedback}

        Quality Metrics:
        {metrics}

        Required Improvements:
        {improvements}

        Provide only the refined code without explanations.
        """
    }


class ModelClient:
    def __init__(self):
        self.session = requests.Session()

    async def call_model(self, model_name: str, prompt: str, retry_count: int = 0, temperature: float = 0.2) -> Optional[str]:
        """
        Call the Ollama API with retry logic and proper error handling
        """
        url = f"{ModelConfig.OLLAMA_BASE_URL}/api/generate"
        headers = {"Content-Type": "application/json"}
        data = {
            "model": model_name,
            "prompt": prompt,
            "stream": False,
            "temperature": temperature,
        }

        try:
            response = self.session.post(
                url,
                headers=headers,
                json=data,
                timeout=ModelConfig.TIMEOUT
            )
            response.raise_for_status()
            return response.json()["response"]

        except requests.exceptions.Timeout:
            logger.warning(f"Timeout calling {model_name}")
            return self._handle_retry(model_name, prompt, retry_count, "timeout")

        except requests.exceptions.RequestException as e:
            logger.error(f"Error calling {model_name}: {str(e)}")
            return self._handle_retry(model_name, prompt, retry_count, str(e))

    def _handle_retry(self, model_name: str, prompt: str, retry_count: int, error: str) -> Optional[str]:
        """Handle retry logic for failed API calls"""
        if retry_count < ModelConfig.MAX_RETRIES:
            logger.info(f"Retrying {model_name} after {error}. Attempt {retry_count + 1}")
            time.sleep(ModelConfig.RETRY_DELAY * (retry_count + 1))  # Exponential backoff
            return self.call_model(model_name, prompt, retry_count + 1)
        return None
class CodeReviewer:
    def __init__(self, model_client: ModelClient):
        self.model_client = model_client
        self.executor = ThreadPoolExecutor(max_workers=len(ModelConfig.SECONDARY_MODELS))

    def get_review(self, model: str, code: str, review_prompt_modifier: Optional[str] = None) -> Dict[str, str]:
        """Get code review from a single model"""
        prompt = (
            f"Review the following code:\n{code}\n"
            "Provide specific suggestions for improvements, potential errors, "
            "and alternative approaches. Format your response as valid JSON with "
            "keys: 'complexity', 'maintainability', 'performance', 'security'"
        )

        if review_prompt_modifier:
            prompt += f"\nAdditional instructions for reviews: {review_prompt_modifier}"
            
        response = self.model_client.call_model(model, prompt)

        if response:
            try:
                return {
                    "model": model,
                    "feedback": json.loads(response)
                }
            except json.JSONDecodeError:
                logger.error(f"Invalid JSON response from {model}")
                return {
                    "model": model,
                    "feedback": {"error": "Invalid response format"}
                }
        return {
            "model": model,
            "feedback": {"error": "No response received"}
        }

    def get_parallel_reviews(self, code: str, review_prompt_modifier: Optional[str] = None) -> List[Dict[str, str]]:
        """Get code reviews from all secondary models in parallel"""
        review_futures = [
            self.executor.submit(self.get_review, model, code, review_prompt_modifier)
            for model in ModelConfig.SECONDARY_MODELS
        ]

        reviews = []
        for future in as_completed(review_futures):
            try:
                review = future.result()
                reviews.append(review)
            except Exception as e:
                logger.error(f"Error getting review: {str(e)}")

        return reviews


class FeedbackAnalyzer:
    @staticmethod
    def analyze_feedback(reviews: List[Dict[str, str]]) -> Dict[str, List[str]]:
      consolidated = {
          "complexity": {"score":0, "issues":set(), "suggestions":set()},
          "maintainability": {"score":0, "issues":set(), "suggestions":set()},
          "performance": {"score":0, "issues":set(), "suggestions":set()},
          "security": {"score":0, "issues":set(), "suggestions":set()}
      }
      for review in reviews:
        feedback = review.get("feedback", {})
        for key in consolidated:
            if isinstance(feedback.get(key), dict):
              consolidated[key]["score"] += feedback[key].get("score",0)
              consolidated[key]["issues"].update(feedback[key].get("issues", []))
              consolidated[key]["suggestions"].update(feedback[key].get("suggestions", []))

      #average out the score
      for key in consolidated:
         consolidated[key]["score"] = consolidated[key]["score"] / len(reviews)
      #convert sets to lists
      for key in consolidated:
          consolidated[key]["issues"] = list(consolidated[key]["issues"])
          consolidated[key]["suggestions"] = list(consolidated[key]["suggestions"])

      return consolidated

    @staticmethod
    def score_feedback(analyzed_feedback: Dict[str, Dict[str, Any]], weights: Optional[Dict[str, float]] = None) -> Dict[str, float]:
        scores = {}

        # Default weights
        if weights is None:
            weights = {
                "complexity": 1,
                "maintainability": 1,
                "performance": 1,
                "security": 1,
            }
        
        for category, feedback in analyzed_feedback.items():
           scores[category] = feedback["score"] * weights.get(category, 0)
           
        return scores

class CodeAnalyzer:
    """New class for detailed code analysis"""
    
    def __init__(self, model_client: ModelClient):
        self.model_client = model_client
    
    def analyze_code(self, code: str) -> Dict[str, Any]:
        """Perform full code analysis"""
        complexity_analysis = self.analyze_complexity(code)
        security_analysis = self.analyze_security(code)

        return {
            "complexity": complexity_analysis,
            "security": security_analysis
        }


    def analyze_complexity(self, code: str) -> Dict[str, Any]:
      """Analyze code complexity using LLM"""
      prompt = "Analyze code complexity. Focus on cyclomatic complexity, nesting depth, and function length."
      response = self.model_client.call_model(ModelConfig.PRIMARY_MODEL, f"{prompt}\n{code}")
      # Process and structure the response
      return self._structure_analysis(response, "complexity", code)

    def analyze_security(self, code: str) -> Dict[str, Any]:
      """Analyze code security using LLM"""
      prompt = "Analyze code security. Focus on input validation, error handling, and security best practices."
      response = self.model_client.call_model(ModelConfig.PRIMARY_MODEL, f"{prompt}\n{code}")
      return self._structure_analysis(response, "security", code)

    def _structure_analysis(self, response: str, category: str, code: str) -> Dict[str, Any]:
      try:
            # Process the LLM response into structured format
          score = self._calculate_score(response, category)
          issues = self._extract_issues(response)
          suggestions = self._extract_suggestions(response)
            
          return {
            "score": score,
            "issues": issues,
            "suggestions": suggestions,
              "code": code
            }
      except Exception as e:
          logger.error(f"Error in {category} analysis: {str(e)}")
          return {"score": 0, "issues": [], "suggestions": [], "code": code}

    def _calculate_score(self, response: str, category: str) -> float:
        """Calculate a score based on the LLM response."""
        # Simple scoring logic based on keywords (customize as needed)
        if not response:
          return 0
        
        low_score_keywords = ["high", "major", "critical", "severe", "lots of issues"]
        medium_score_keywords = ["moderate", "some", "few", "medium", "not bad"]
        
        score = 0.5  # Default medium score
        
        for keyword in low_score_keywords:
          if keyword in response.lower():
              score = 0.2
              break
              
        if score == 0.5:
          for keyword in medium_score_keywords:
              if keyword in response.lower():
                  score = 0.7
                  break
        
        return score

    def _extract_issues(self, response: str) -> List[str]:
        """Extract issues from the LLM response."""
        issues = []
        
        # Split the response to extract parts that look like issues
        if response:
          for line in response.split("\n"):
             if "issue:" in line.lower():
              issue = line.lower().split("issue:")[1].strip()
              issues.append(issue)
        return issues

    def _extract_suggestions(self, response: str) -> List[str]:
        """Extract suggestions from the LLM response."""
        suggestions = []

         # Split the response to extract parts that look like suggestions
        if response:
          for line in response.split("\n"):
            if "suggestion:" in line.lower():
              suggestion = line.lower().split("suggestion:")[1].strip()
              suggestions.append(suggestion)

        return suggestions


class IterativeCodeGenerator:
    def __init__(self, model_client: ModelClient):
        self.model_client = model_client
        self.code_reviewer = CodeReviewer(model_client)
        self.feedback_analyzer = FeedbackAnalyzer()
        self.code_analyzer = CodeAnalyzer(model_client)
        self.max_iterations = 3  # Maximum number of refinement loops
        self.satisfaction_threshold = 0.8  # Score above which we consider the code satisfactory

    def calculate_satisfaction_score(self, feedback_scores: Dict[str, float], quality_metrics: Dict[str, Any] = None) -> float:
        weights = {
            "complexity": 0.2,
            "maintainability": 0.3,
            "performance": 0.3,
            "security": 0.2
        }

        overall_score = 0
        if quality_metrics:
            for metric, score in feedback_scores.items():
                overall_score += score * weights.get(metric, 0)

        if overall_score == 0:
          return 0.01 # To avoid divide by zero

        return round(overall_score, 2)
    
    async def generate_iterative_code(
        self,
        prompt: str,
        language: str = "python",
        requirements: Optional[str] = None,
        quality_threshold: Optional[float] = None,
        complexity_weight: Optional[float] = 0.3,
        maintainability_weight: Optional[float] = 0.3,
        performance_weight: Optional[float] = 0.2,
        security_weight: Optional[float] = 0.2,
        review_style: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:

        iteration_history = []
        current_code = None
        best_score = 0
        best_iteration = None
        
        for iteration in range(self.max_iterations):
          logger.info(f"Starting iteration {iteration + 1}")

          # Determine which prompt to use
          code_generation_prompt = ModelConfig.PROMPTS["code_generation"].format(
            prompt = prompt,
            language = language,
            requirements = requirements
           )

          if current_code is None:
             current_code = await self.model_client.call_model(
               ModelConfig.PRIMARY_MODEL,
               code_generation_prompt
             )

          else:
            priorities = sorted(
             feedback_scores,
              key = feedback_scores.get,
              reverse= True
           )

            refinement_prompt = ModelConfig.PROMPTS["code_refinement"].format(
             original_code = current_code,
             feedback = json.dumps(current_feedback, indent = 2),
             metrics = json.dumps(quality_metrics, indent = 2),
             improvements = json.dumps(current_feedback, indent = 2),
             priority_1 = priorities[0],
             priority_2 = priorities[1],
             priority_3 = priorities[2] if len(priorities)>2 else priorities[1]
           )

            current_code = await self.model_client.call_model(
             ModelConfig.PRIMARY_MODEL,
             refinement_prompt
            )

          reviews = self.code_reviewer.get_parallel_reviews(current_code)
          current_feedback = self.feedback_analyzer.analyze_feedback(reviews)

          feedback_weights = {
            "complexity": complexity_weight,
            "maintainability": maintainability_weight,
            "performance": performance_weight,
            "security": security_weight,
          }
          feedback_scores = self.feedback_analyzer.score_feedback(current_feedback, feedback_weights)
          quality_metrics = self.code_analyzer.analyze_code(current_code)

          satisfaction_score = self.calculate_satisfaction_score(feedback_scores, quality_metrics)
            
          iteration_result = {
             "iteration": iteration + 1,
             "code": current_code,
             "feedback": current_feedback,
             "scores": feedback_scores,
             "satisfaction_score": satisfaction_score,
             "quality_metrics": quality_metrics,
            }
          iteration_history.append(iteration_result)

          if satisfaction_score > best_score:
              best_score = satisfaction_score
              best_iteration = iteration_result
            
          logger.info(f"Iteration {iteration + 1} satisfaction score: {satisfaction_score}")
          
          if satisfaction_score >= (quality_threshold or self.satisfaction_threshold):
              logger.info(f"Satisfaction threshold reached at iteration {iteration + 1}")
              break
              
          if iteration == self.max_iterations - 1:
             logger.info("Max iterations reached, using best version found")
             current_code = best_iteration["code"]
             current_feedback = best_iteration["feedback"]
             feedback_scores = best_iteration["scores"]
             satisfaction_score = best_iteration["satisfaction_score"]
             quality_metrics = best_iteration["quality_metrics"]

        return {
            "final_code": current_code,
            "iterations": len(iteration_history),
            "satisfaction_score": satisfaction_score,
            "feedback": current_feedback,
            "feedback_scores": feedback_scores,
            "quality_metrics": quality_metrics,
            "iteration_history": iteration_history,
             "reached_threshold": satisfaction_score >= (quality_threshold or self.satisfaction_threshold)
        }

class SpecializedModelConfig:
    """Configuration for specialized models and their roles"""
    
    MODELS = {
        "architecture": {
            "model": "codellama:34b",
            "temperature": 0.2,
            "prompt_template": """
            Analyze the code architecture focusing on:
            1. Design patterns
            2. SOLID principles
            3. Component coupling
            4. Code organization
            
            Code to analyze:
            {code}
            
            Provide recommendations in JSON format with reasoning.
            """
        },
        "security": {
            "model": "llama2:70b",
            "temperature": 0.1,
            "prompt_template": """
            Perform a security audit focusing on:
            1. Common vulnerabilities
            2. Input validation
            3. Authentication/Authorization issues
            4. Data protection
            
            Code to analyze:
            {code}
            
            Provide findings in JSON format with severity levels.
            """
        },
        "performance": {
            "model": "mixtral:8x7b",
            "temperature": 0.2,
            "prompt_template": """
            Analyze performance focusing on:
            1. Time complexity
            2. Space complexity
            3. Resource usage
            4. Bottlenecks
            
            Code to analyze:
            {code}
            
            Provide optimization suggestions in JSON format.
            """
        },
         "documentation": {
            "model": "neural-chat:7b",
            "temperature": 0.4,
             "prompt_template": """
            Generate comprehensive documentation including:
            1. Function/class descriptions
            2. Parameter details
            3. Usage examples
            4. Edge cases

            Code to document:
            {code}

            Provide documentation in markdown format.
            """
       }
    }


class SpecializedModelManager:
    def __init__(self, model_client: ModelClient):
        self.model_client = model_client

    async def run_specialized_analysis(self, code: str, analysis_types: List[str]) -> Dict[str, Any]:
        """Run specialized analysis on code using selected model types"""
        results = {}

        for analysis_type in analysis_types:
          if analysis_type in SpecializedModelConfig.MODELS:
            config = SpecializedModelConfig.MODELS[analysis_type]
            prompt = config["prompt_template"].format(code=code)

            response = await self.model_client.call_model(
              model_name=config["model"],
              prompt=prompt,
              temperature=config["temperature"]
            )

            results[analysis_type] = self._process_response(response, analysis_type)

        return results

    def _process_response(self, response: str, analysis_type: str) -> Dict[str, Any]:
      """Process and structure the response based on analysis type"""
      try:
        if analysis_type == "documentation":
            return {"documentation": response}
        return json.loads(response)
      except json.JSONDecodeError:
        logger.error(f"Invalid JSON response from {analysis_type} analysis")
        return {"error": "Invalid response format"}

class EnhancedCodeGenerator(IterativeCodeGenerator):
    def __init__(self, model_client: ModelClient):
        super().__init__(model_client)
        self.specialized_manager = SpecializedModelManager(model_client)

    async def generate_code_with_specialization(
        self,
        prompt: str,
        language: str = "python",
        requirements: Optional[str] = None,
        quality_threshold: Optional[float] = None,
        complexity_weight: Optional[float] = 0.3,
        maintainability_weight: Optional[float] = 0.3,
        performance_weight: Optional[float] = 0.2,
        security_weight: Optional[float] = 0.2,
        review_style: Optional[str] = None,
        analysis_types: List[str] = ["architecture", "security", "performance"],
        **kwargs
    ) -> Dict[str, Any]:
        # Generate initial code
        result = await self.generate_iterative_code(
            prompt,
            language = language,
            requirements = requirements,
            quality_threshold=quality_threshold,
            complexity_weight=complexity_weight,
            maintainability_weight=maintainability_weight,
            performance_weight=performance_weight,
            security_weight=security_weight,
            review_style = review_style,
           **kwargs
         )

        # Run specialized analysis
        specialized_analysis = await self.specialized_manager.run_specialized_analysis(
            result["final_code"],
            analysis_types
        )

        # Generate final improvements based on specialized analysis
        final_improvements = await self._generate_final_improvements(
          result["final_code"],
          specialized_analysis
        )

        return {
            **result,
            "specialized_analysis": specialized_analysis,
            "final_improved_code": final_improvements
        }

    async def _generate_final_improvements(
        self,
        code: str,
        specialized_analysis: Dict[str, Any]
    ) -> str:
      """Generate final code improvements based on specialized analysis"""
      improvement_prompt = f"""
        Original code:
        {code}

        Specialized analysis results:
        {json.dumps(specialized_analysis, indent=2)}

        Improve the code based on all specialized analysis while maintaining its core functionality.
        Provide only the improved code without explanations.
       """

      return await self.model_client.call_model(
            ModelConfig.PRIMARY_MODEL,
            improvement_prompt
      )


class FeedbackStore:
    def __init__(self, db_path: str = "feedback.db"):
        self.db_path = db_path
        self._init_db()
        
    def _init_db(self):
        """Initialize the feedback database"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS generation_feedback (
                    id INTEGER PRIMARY KEY,
                    prompt TEXT,
                    initial_code TEXT,
                    final_code TEXT,
                    feedback_scores TEXT,
                    user_rating INTEGER,
                    user_comments TEXT,
                    timestamp DATETIME
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS prompt_patterns (
                    id INTEGER PRIMARY KEY,
                    pattern TEXT,
                    success_rate FLOAT,
                    total_uses INTEGER
                )
            """)
            
    def store_feedback(
        self,
        prompt: str,
        initial_code: str,
        final_code: str,
        feedback_scores: Dict[str, float],
        user_rating: int,
        user_comments: Optional[str] = None
    ):
        """Store user feedback for a code generation session"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                INSERT INTO generation_feedback
                (prompt, initial_code, final_code, feedback_scores, user_rating, 
                user_comments, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (prompt, initial_code, final_code, json.dumps(feedback_scores),
                user_rating, user_comments, datetime.now())
            )
            
    def update_prompt_patterns(self, prompt: str, success: bool):
        """Update success patterns for prompts"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM prompt_patterns WHERE pattern = ?",
                (prompt,)
            )
            row = cursor.fetchone()
            
            if row:
                pattern_id, _, current_rate, total = row
                new_total = total + 1
                new_rate = ((current_rate * total) + (1 if success else 0)) / new_total
                
                cursor.execute(
                    """
                    UPDATE prompt_patterns 
                    SET success_rate = ?, total_uses = ?
                    WHERE id = ?
                    """,
                    (new_rate, new_total, pattern_id)
                )
            else:
                cursor.execute(
                    """
                    INSERT INTO prompt_patterns (pattern, success_rate, total_uses)
                    VALUES (?, ?, ?)
                    """,
                    (prompt, 1 if success else 0, 1)
                )
# ... (Previous code from app.py remains here, until the definition of the FeedbackStore class) ...

class AdaptiveLearningSystem:
    def __init__(self, feedback_store: FeedbackStore):
        self.feedback_store = feedback_store
        
    def analyze_feedback_patterns(self) -> Dict[str, Any]:
        with sqlite3.connect(self.feedback_store.db_path) as conn:
            cursor = conn.cursor()
            
            # Analyze prompt patterns
            cursor.execute("""
                SELECT pattern, success_rate, total_uses
                FROM prompt_patterns
                WHERE total_uses > 5
                ORDER BY success_rate DESC
                LIMIT 10
            """)
            successful_patterns = cursor.fetchall()
            
            # Analyze common issues
            cursor.execute("""
                SELECT feedback_scores, user_rating
                FROM generation_feedback
                ORDER BY timestamp DESC
                LIMIT 100
            """)
            low_rated_generations = cursor.fetchall()
           
            return {
               "successful_patterns": [
                    {
                        "pattern": pattern,
                        "success_rate": rate,
                        "uses": uses
                    }
                    for pattern, rate, uses in successful_patterns
                ],
                 "common_issues": self._analyze_common_issues(low_rated_generations)
            }
    
    def _analyze_common_issues(self, low_rated_data: List[tuple]) -> Dict[str, Any]:
        """Analyze common issues in low-rated generations"""
        issues = {}
        for feedback_scores, _ in low_rated_data:
            scores = json.loads(feedback_scores)
            for category, score in scores.items():
                if score < 0.6:  # Low score threshold
                    if category in issues:
                         issues[category] +=1
                    else:
                        issues[category] =1

        return {
             "problematic_categories": sorted(issues, key=issues.get, reverse=True),
        }
    
    def get_prompt_improvements(self, prompt: str) -> Dict[str, Any]:
      """Get suggested improvements for a prompt based on historical data"""
      patterns = self.analyze_feedback_patterns()
      similar_patterns = [
          pattern for pattern in patterns["successful_patterns"]
          if self._calculate_similarity(prompt, pattern["pattern"]) > 0.5
      ]
      
      return {
          "suggested_modifications": self._generate_prompt_suggestions(prompt, similar_patterns, patterns["common_issues"]),
          "success_probability": self._estimate_success_probability(prompt, patterns)
        }

    def _calculate_similarity(self, prompt1: str, prompt2: str) -> float:
      """Calculate similarity between two prompts"""
      words1 = set(prompt1.lower().split())
      words2 = set(prompt2.lower().split())
      
      common_words = words1 & words2
      
      if not words1 or not words2:
         return 0
      
      return len(common_words) / max(len(words1), len(words2))

    def _generate_prompt_suggestions(self, prompt: str, similar_patterns: List[Dict[str, Any]], common_issues: Dict[str,Any] ) -> List[str]:
        """Suggest modifications to the prompt based on successful patterns and common issues"""
        
        suggestions = []
        
        if not similar_patterns:
            suggestions.append(f"No successful similar prompts found.")
        else:
            for pattern in similar_patterns:
                suggestions.append(f"Consider using a similar structure to '{pattern['pattern']}'")

        if common_issues and "problematic_categories" in common_issues:
          suggestions.append(f"Consider improving: {', '.join(common_issues['problematic_categories'])} in your prompt.")
          
        if not suggestions:
           suggestions.append("No modification required.")

        return suggestions

    def _estimate_success_probability(self, prompt: str, patterns: Dict[str, Any]) -> float:
        """Estimate success probability for a prompt based on past performance"""
        relevant_patterns = [
            pattern for pattern in patterns["successful_patterns"]
            if self._calculate_similarity(prompt, pattern["pattern"]) > 0.5
        ]
        if not relevant_patterns:
          return 0.2
        
        average_rate = sum(pattern["success_rate"] for pattern in relevant_patterns) / len(relevant_patterns)
        return average_rate

# API endpoint for specialized code generation
@app.route('/generate-specialized-code', methods=['POST'])
async def generate_specialized_code():
    try:
        data = request.get_json()
        if not data or 'prompt' not in data:
            return jsonify({'error': 'Prompt is required'}), 400
        
        analysis_types = data.get('analysis_types', ["architecture", "security", "performance"])
        
        generator = EnhancedCodeGenerator(ModelClient())
        result = await generator.generate_code_with_specialization(
            data['prompt'],
            language = data.get("language", "python"),
            requirements = data.get("requirements"),
            quality_threshold = data.get("satisfaction_threshold"),
            complexity_weight = data.get("weights", {}).get("complexity", 0.3),
            maintainability_weight = data.get("weights", {}).get("maintainability", 0.3),
            performance_weight = data.get("weights", {}).get("performance", 0.2),
            security_weight = data.get("weights", {}).get("security", 0.2),
            review_style = data.get("review_style"),
            analysis_types=analysis_types,
            max_iterations= data.get("max_iterations", 3)
        )
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"API error: {str(e)}")
        return jsonify({
            'error': 'An error occurred during specialized code generation',
            'details': str(e)
        }), 500

# API endpoint for feedback
@app.route('/submit-feedback', methods=['POST'])
def submit_feedback():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'Feedback data is required'}), 400
            
        feedback_store = FeedbackStore()
        feedback_store.store_feedback(
            prompt=data['prompt'],
            initial_code=data['initial_code'],
            final_code=data['final_code'],
            feedback_scores=data['feedback_scores'],
            user_rating=data['user_rating'],
            user_comments=data.get('user_comments')
        )
        
        feedback_store.update_prompt_patterns(
            data['prompt'],
            data['user_rating'] >= 4  # Consider ratings >= 4 as successful
        )
        
        return jsonify({'status': 'success'})
        
    except Exception as e:
        logger.error(f"Error storing feedback: {str(e)}")
        return jsonify({
            'error': 'An error occurred while storing feedback',
            'details': str(e)
        }), 500
    
class WorkflowOptimizer:
    """Enhances development workflow with AI assistance"""
    
    def __init__(self, model_client: ModelClient):
      self.model_client = model_client
    
    WORKFLOWS = {
        "code_modernization": {
            "model": "codellama:34b",
            "prompt": """
            Analyze and modernize the following legacy code, focusing on:
            1. Updating to modern language features and syntax.
            2. Improving code readability and maintainability by introducing modular design.
            3. Adding comprehensive comments for better understanding.
            4. Implementing try-except blocks for proper error handling.
            
            Legacy Code:
            {code}
            
            Provide only the improved code without explanations.
            """,
            "priority": "high"
        },
        "test_generation": {
            "model": "mixtral:8x7b",
            "prompt": """
            Generate comprehensive unit tests for the given code:
            1. Include edge cases and boundary conditions for each function.
            2. Implement different test cases to maximize coverage.
            3. Design tests for security vulnerabilities
            4. Format output for pytest.

            Code:
            {code}

            Provide only the unit tests.
            """,
            "priority": "medium"
        },
        "documentation": {
            "model": "neural-chat:7b",
            "prompt": """
            Generate comprehensive documentation for this code, including:
            1. Function and class descriptions
            2. Detailed parameter definitions
            3. Usage examples with explanations
            4. Details about all edge cases and limitations

            Code:
            {code}

            Provide documentation in Markdown format.
            """,
            "priority": "medium"
        }
    }

    async def run_workflow(self, workflow_name: str, code: str) -> Optional[str]:
            """Run a specified workflow on code"""
            workflow = self.WORKFLOWS.get(workflow_name)
            if not workflow:
                logger.error(f"Workflow {workflow_name} not found")
                return None

            prompt = workflow["prompt"].format(code=code)

            response = await self.model_client.call_model(
                workflow["model"],
                prompt
            )

            return response
    
class KnowledgeManager:
    def __init__(self):
        self.best_practices = {
            "coding_standards": self._load_standards(),
            "security_guidelines": self._load_security(),
            "performance_rules": self._load_performance()
        }
        
    def _load_standards(self):
      # Placeholder. Load from team coding standards (e.g., a markdown doc)
      return {
          "style": "PEP8",
          "comments": "Use docstrings for all functions and classes",
           "complexity": "Avoid excessive nesting and long functions"
      }
    
    def _load_security(self):
      # Placeholder. Load from internal security document
      return {
        "input_validation": "Sanitize all inputs",
         "data_encryption": "Encrypt all sensitive data",
         "secrets": "Do not expose secrets directly"
      }
    
    def _load_performance(self):
      # Placeholder. Load from performance guidelines
      return {
          "database": "Use efficient database queries",
          "caching": "Implement appropriate caching",
           "algorithm": "Use the most performant algorithms"
         }
    
    async def enhance_code_with_knowledge(self, code: str, context: Dict[str, Any]) -> str:
      """Enhances code with team's accumulated knowledge"""
      analysis = await self.analyze_code(code)
      improvements = self.generate_improvements(code, analysis, self.best_practices)
      return improvements

    async def analyze_code(self, code:str) -> Dict[str,Any]:
      # Calls the code analysis framework
      # For now returns the code.
        return {"code":code}

    def generate_improvements(self, analysis: Dict[str, Any], best_practices: Dict[str, Dict[str, str]]) -> str:
        code = analysis["code"]
        improvements = f"""
            Code:
            {code}
            
            Please review and improve the following aspects:
            """

        if "coding_standards" in best_practices:
          for k, v in best_practices["coding_standards"].items():
            improvements += f"   - Ensure code follows {k} standards {v}. \n"

        if "security_guidelines" in best_practices:
          for k, v in best_practices["security_guidelines"].items():
            improvements += f"   - Ensure code follows {k} guidelines and best practises {v}. \n"
        if "performance_rules" in best_practices:
            for k,v in best_practices["performance_rules"].items():
             improvements += f"   - Ensure code follows {k} best practises and rule {v}. \n"

        return improvements

class QualityEnhancer:
    """Improves code quality through multiple AI models"""
    
    def __init__(self, model_client: ModelClient, context: Dict[str, Any]):
       self.context = context
       self.model_client = model_client
            
    async def enhance_code(
      self,
      code: str
    ) -> Dict[str, Any]:
      """Enhances code quality through multiple passes"""

      # Initial analysis
      base_quality = await self.analyze_code_quality(code)

      # Parallel improvements
      improvements = await asyncio.gather(
        self.improve_readability(code),
        self.optimize_performance(code),
        self.enhance_security(code),
        self.generate_tests(code)
      )
      
      # Combine improvements
      enhanced_code = self.merge_improvements(code, improvements)
    
      # Measure impact
      impact_metrics = self.calculate_impact(
          original_code=code,
          enhanced_code=enhanced_code,
          base_quality=base_quality
      )
        
      return {
          "enhanced_code": enhanced_code,
          "impact_metrics": impact_metrics,
           "quality_score": self.calculate_quality_score(enhanced_code)
       }

    async def analyze_code_quality(self, code: str) -> Dict[str, Any]:
       # Calls code quality analysis framework
        return {"complexity": 0.5, "security": 0.6, "readability": 0.7}

    async def improve_readability(self, code:str) -> str:
       # Calls a model to improve readability.
        prompt = f"Improve the readability of this code {code}"
        return await self.model_client.call_model(ModelConfig.PRIMARY_MODEL, prompt)
   
    async def optimize_performance(self, code:str) -> str:
       # Calls a model to improve performance.
        prompt = f"Improve the performance of this code {code}"
        return await self.model_client.call_model(ModelConfig.PRIMARY_MODEL, prompt)

    async def enhance_security(self, code: str) -> str:
      # Calls a model to improve security
        prompt = f"Improve the security of this code {code}"
        return await self.model_client.call_model(ModelConfig.PRIMARY_MODEL, prompt)

    async def generate_tests(self, code:str) -> str:
      # Calls a model to generate tests.
        prompt = f"Generate tests for the following code {code}"
        return await self.model_client.call_model(ModelConfig.PRIMARY_MODEL, prompt)

    def merge_improvements(self, code:str, improvements: List[str]) -> str:
      # Merges code from improvements
      return f"merged code for {code} with {improvements}"

    def calculate_impact(self, original_code:str, enhanced_code:str, base_quality: Dict[str, Any]) -> Dict[str, Any]:
      # Calculate metrics from before and after.
      return {
       "complexity_change": 0.1, "security_improvement": 0.2, "readability_improvement": 0.3
      }

    def calculate_quality_score(self, enhanced_code:str) -> float:
      return 0.8


@app.route('/enhance-code', methods=['POST'])
async def enhance_code():
    """API endpoint for code enhancement"""
    try:
        data = request.get_json()
        if not data or "code" not in data:
            return jsonify({'error': 'Code is required'}), 400
        # Extract code and context
        code = data['code']
        context = {
            'team_standards': data.get('team_standards', {}),
            'project_type': data.get('project_type', 'generic'),
            'priority_areas': data.get('priority_areas', [])
        }
        
        # Initialize enhancer with team context
        enhancer = QualityEnhancer(ModelClient(), context)
        
        # Process code
        result = await enhancer.enhance_code(code)
        
        # Track impact
        
        return jsonify(result)
    
    except Exception as e:
      logger.error(f"Enhancement error: {str(e)}")
      return jsonify({
        'error': 'Code enhancement failed',
        'details': str(e)
      }), 500


if __name__ == '__main__':
    app.run(debug=True)