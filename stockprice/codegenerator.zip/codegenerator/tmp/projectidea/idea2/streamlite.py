import streamlit as st
import requests
import json
import time

# Function to call the API
def call_api(url: str, data: dict) -> dict:
    try:
        response = requests.post(url, headers={'Content-Type': 'application/json'}, json=data)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        st.error(f"An error occurred: {e}")
        return {"error": str(e)}

st.title("CodeSwarm: AI-Powered Code Generation and Review")

# Sidebar for Settings
with st.sidebar:
  st.header("Configuration")
  language = st.selectbox("Language", ["python", "javascript", "java", "shell", "ansible"], index=0)
  user_prompt = st.text_area("Prompt", placeholder="Enter code generation requirements...", height=150)
  initial_prompt_modifier = st.text_area("Initial Prompt Modifier", placeholder = "Additional instructions for primary model", height=80)
  review_prompt_modifier = st.text_area("Review Prompt Modifier", placeholder = "Additional instructions for reviewer models", height=80)
  
  custom_prompts = st.text_area("Custom Prompts (JSON)", placeholder='{"code_generation": "...", "code_refinement": "..."}', height=100)
  
  max_iterations = st.number_input("Max Iterations", min_value=1, max_value=10, value=3, step=1)
  satisfaction_threshold = st.number_input("Satisfaction Threshold", min_value=0.0, max_value=1.0, value=0.8, step=0.1)
  review_style = st.selectbox("Review Style", ["detailed", "focused", "quick"], index=0)

  st.subheader("Quality Weights")
  complexity_weight = st.slider("Complexity Weight", 0, 100, 30) / 100
  maintainability_weight = st.slider("Maintainability Weight", 0, 100, 30) / 100
  performance_weight = st.slider("Performance Weight", 0, 100, 20) / 100
  security_weight = st.slider("Security Weight", 0, 100, 20) / 100
  
# Main Area

if user_prompt:
    
    if st.button("Generate Code"):
      
      with st.spinner("Generating Code..."):
            try:
                custom_prompts_json = json.loads(custom_prompts) if custom_prompts else None
            except json.JSONDecodeError:
                 st.error("Invalid JSON format for custom prompts")
                 custom_prompts_json = None

            data = {
               "prompt": user_prompt,
                 "language": language,
                 "max_iterations": max_iterations,
                 "satisfaction_threshold": satisfaction_threshold,
                 "review_style": review_style,
                 "weights": {
                    "complexity": complexity_weight,
                   "maintainability": maintainability_weight,
                    "performance": performance_weight,
                     "security": security_weight
                   },
                 "initial_prompt_modifier": initial_prompt_modifier,
                 "review_prompt_modifier": review_prompt_modifier,
                "custom_prompts": custom_prompts_json
            }

            result = call_api(url = "http://localhost:5000/generate-specialized-code", data = data)

            if "error" in result:
                 st.error(f"Error: {result['error']} - {result.get('details', '')}")
            elif result:
                  st.subheader("Final Code Output")
                  st.code(result['final_improved_code'], language = language)

                  st.subheader("Feedback Analysis")
                  st.json(result.get('feedback', {}), expanded=False)
                  
                  st.subheader("Feedback Scores")
                  st.json(result.get('feedback_scores', {}), expanded=False)
                  
                  st.subheader("Quality Metrics")
                  st.json(result.get('quality_metrics', {}), expanded=False)
                  
                  st.subheader("Iteration History")
                  st.json(result.get("iteration_history", []), expanded=False)