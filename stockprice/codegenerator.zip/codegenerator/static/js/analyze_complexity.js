document.addEventListener('DOMContentLoaded', function() {
    const analyzeBtn = document.getElementById('analyzeComplexityBtn');
    const analysisResult = document.getElementById('analysisResult');
    let complexityChart = null;
    let maintenanceChart = null;

    function updateAnalysisResult(data) {
        if (!data.metrics) {
            analysisResult.innerHTML = '<div class="alert alert-danger">No metrics available</div>';
            return;
        }

        const metrics = data.metrics;
        
        // Update each tab with the analysis results
        updateOverviewTab(metrics);
        updateComplexityTab(metrics);
        updateMaintainabilityTab(metrics);
        updateDuplicationTab(metrics);

        // Show recommendations if available
        if (data.ai_suggestions) {
            showAISuggestions(data.ai_suggestions);
        }

        // Show security issues if available
        if (data.security_scan) {
            showSecurityIssues(data.security_scan);
        }
    }

    function showAISuggestions(suggestions) {
        const suggestionsDiv = document.createElement('div');
        suggestionsDiv.className = 'mt-4';
        suggestionsDiv.innerHTML = `
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0">AI Suggestions for Improvement</h6>
                </div>
                <div class="card-body">
                    <pre class="bg-light p-3 rounded">${suggestions}</pre>
                </div>
            </div>
        `;
        analysisResult.appendChild(suggestionsDiv);
    }

    function showSecurityIssues(issues) {
        if (issues.length > 0) {
            const securityDiv = document.createElement('div');
            securityDiv.className = 'mt-4';
            securityDiv.innerHTML = `
                <div class="card border-danger">
                    <div class="card-header bg-danger text-white">
                        <h6 class="mb-0">Security Issues Found</h6>
                    </div>
                    <div class="card-body">
                        <ul class="list-group">
                            ${issues.map(issue => `
                                <li class="list-group-item">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1">${issue.type}</h6>
                                        <small class="text-danger">Line ${issue.line}</small>
                                    </div>
                                    <p class="mb-1">${issue.description}</p>
                                    ${issue.recommendation ? `<small class="text-muted">Recommendation: ${issue.recommendation}</small>` : ''}
                                </li>
                            `).join('')}
                        </ul>
                    </div>
                </div>
            `;
            analysisResult.appendChild(securityDiv);
        }
    }

    // Event handler for analyze button
    analyzeBtn.addEventListener('click', async () => {
        const code = document.getElementById('codeToAnalyze').value.trim();
        const language = document.getElementById('languageSelect').value;
        
        if (!code) {
            analysisResult.innerHTML = '<div class="alert alert-warning">Please enter code to analyze.</div>';
            return;
        }

        // Show loading state
        analysisResult.innerHTML = `
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Analyzing...</span>
                </div>
                <p>Analyzing code...</p>
            </div>
        `;

        try {
            const response = await fetch('/analyze_complexity', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code, language })
            });
            
            const data = await response.json();
            
            if (response.ok && data.status === 'success') {
                // Clear previous results
                analysisResult.innerHTML = '';
                // Update the UI with new results
                updateAnalysisResult(data);
            } else {
                analysisResult.innerHTML = `
                    <div class="alert alert-danger">
                        ${data.error || 'Analysis failed'}
                    </div>
                `;
            }
        } catch (err) {
            analysisResult.innerHTML = `
                <div class="alert alert-danger">
                    Request failed: ${err.message}
                </div>
            `;
        }
    });

    function updateOverviewTab(metrics) {
        const overview = document.getElementById('overview');
        overview.innerHTML = `
            <div class="alert ${getAlertClass(metrics.maintainability?.maintainability_index)}">
                <h6>Summary</h6>
                <p>${metrics.maintainability?.maintainability_rank || 'N/A'}</p>
                <p>${metrics.raw_metrics ? `Total Lines: ${metrics.raw_metrics.loc}` : ''}</p>
            </div>
            <div class="row g-3">
                <div class="col-md-6">
                    <div class="card h-100">
                        <div class="card-body">
                            <h6 class="card-title">Code Metrics</h6>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Source Lines</span>
                                    <span class="badge bg-primary">${metrics.raw_metrics?.sloc || 0}</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Logical Lines</span>
                                    <span class="badge bg-info">${metrics.raw_metrics?.lloc || 0}</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Comment Lines</span>
                                    <span class="badge bg-secondary">${metrics.raw_metrics?.comments || 0}</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card h-100">
                        <div class="card-body">
                            <h6 class="card-title">Structure</h6>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Functions</span>
                                    <span class="badge bg-primary">${metrics.ast_metrics?.function_count || 0}</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Classes</span>
                                    <span class="badge bg-info">${metrics.ast_metrics?.class_count || 0}</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Imports</span>
                                    <span class="badge bg-secondary">${metrics.ast_metrics?.import_count || 0}</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            ${generateRecommendations(metrics)}
        `;
    }

    function updateComplexityTab(metrics) {
        const complexity = document.getElementById('complexity');
        if (metrics.complexity) {
            complexity.innerHTML = `
                <div class="row">
                    <div class="col-md-12 mb-4">
                        <canvas id="complexityChart"></canvas>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th>Function</th>
                                <th>Complexity</th>
                                <th>Risk</th>
                                <th>Lines</th>
                                <th>Nesting</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${metrics.complexity.complexity_by_function.map(func => `
                                <tr class="${getRiskClass(func.risk)}">
                                    <td>${func.name}</td>
                                    <td>${func.complexity}</td>
                                    <td><span class="badge ${getBadgeClass(func.risk)}">${func.risk}</span></td>
                                    <td>${func.length}</td>
                                    <td>${func.nested_depth}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
            
            createComplexityChart(metrics.complexity.complexity_by_function);
        }
    }

    function updateMaintainabilityTab(metrics) {
        // ...implementation for maintainability tab...
    }

    function updateDuplicationTab(metrics) {
        // ...implementation for duplication tab...
    }

    function createComplexityChart(functions) {
        const ctx = document.getElementById('complexityChart').getContext('2d');
        if (complexityChart) {
            complexityChart.destroy();
        }
        
        complexityChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: functions.map(f => f.name),
                datasets: [{
                    label: 'Cyclomatic Complexity',
                    data: functions.map(f => f.complexity),
                    backgroundColor: functions.map(f => getComplexityColor(f.complexity)),
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Complexity Score'
                        }
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: 'Function Complexity Distribution'
                    }
                }
            }
        });
    }

    // Helper functions for styling
    function getAlertClass(mi) {
        if (!mi) return 'alert-info';
        if (mi >= 85) return 'alert-success';
        if (mi >= 65) return 'alert-info';
        if (mi >= 40) return 'alert-warning';
        return 'alert-danger';
    }

    function getRiskClass(risk) {
        switch (risk) {
            case 'low': return 'table-success';
            case 'moderate': return 'table-warning';
            case 'high': return 'table-danger';
            case 'very high': return 'table-danger';
            default: return '';
        }
    }

    function getBadgeClass(risk) {
        switch (risk) {
            case 'low': return 'bg-success';
            case 'moderate': return 'bg-warning';
            case 'high': return 'bg-danger';
            case 'very high': return 'bg-danger';
            default: return 'bg-secondary';
        }
    }

    function getComplexityColor(complexity) {
        if (complexity <= 5) return 'rgba(40, 167, 69, 0.7)';  // green
        if (complexity <= 10) return 'rgba(255, 193, 7, 0.7)'; // yellow
        if (complexity <= 20) return 'rgba(255, 77, 77, 0.7)'; // red
        return 'rgba(220, 53, 69, 0.7)'; // dark red
    }

    function generateRecommendations(metrics) {
        const recommendations = metrics.maintainability?.recommendations || [];
        if (recommendations.length === 0) return '';

        return `
            <div class="mt-4">
                <h6>Recommendations</h6>
                <div class="alert alert-info">
                    <ul class="mb-0">
                        ${recommendations.map(rec => `<li>${rec}</li>`).join('')}
                    </ul>
                </div>
            </div>
        `;
    }

    function getRiskColor(risk) {
        switch(risk) {
            case 'low': return 'success';
            case 'moderate': return 'warning';
            case 'high': return 'danger';
            case 'very high': return 'danger';
            default: return 'secondary';
        }
    }
});