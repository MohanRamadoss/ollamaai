document.addEventListener('DOMContentLoaded', function() {
    const generateBtn = document.getElementById('generateBtn');
    const resultsDiv = document.getElementById('results');

    // Temperature range handler
    const temperatureRange = document.getElementById('temperatureRange');
    const temperatureValue = document.getElementById('temperatureValue');
    
    temperatureRange.addEventListener('input', function() {
        temperatureValue.textContent = this.value;
    });

    const handleDownload = (filepath) => {
        console.log('Downloading file:', filepath);
        window.location.href = `/download_code?file=${encodeURIComponent(filepath)}`;
    };

    generateBtn.addEventListener('click', async function() {
        const selectedModels = Array.from(document.querySelectorAll('#modelSelection input:checked'))
            .map(checkbox => checkbox.value);
        const selectedLanguage = document.getElementById('languageSelect').value;
        const customPrompt = document.getElementById('customPrompt').value;
        const temperature = parseFloat(temperatureRange.value);
        const complexity = document.getElementById('complexitySelect').value;

        if (!selectedModels.length || !selectedLanguage) {
            alert('Please select at least one model and a language');
            return;
        }

        // Show loading state
        this.disabled = true;
        resultsDiv.innerHTML = `
            <div class="progress mb-3">
                <div class="progress-bar progress-bar-striped progress-bar-animated" 
                     role="progressbar" style="width: 0%" 
                     aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
            </div>
            <div id="status-message" class="text-center mb-3">Initializing...</div>
            <div id="results-container"></div>
        `;

        const progressBar = resultsDiv.querySelector('.progress-bar');
        const statusMessage = document.getElementById('status-message');
        const resultsContainer = document.getElementById('results-container');

        try {
            const response = await fetch('/generate_stream', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'text/event-stream'
                },
                body: JSON.stringify({
                    models: selectedModels,
                    language: selectedLanguage,
                    customPrompt: customPrompt,
                    temperature: temperature,
                    complexity: complexity
                })
            });

            // Create EventSource from response
            const eventStream = response.body
                .pipeThrough(new TextDecoderStream())
                .pipeThrough(new TransformStream({
                    transform(chunk, controller) {
                        chunk.split('\n\n').forEach(event => {
                            if (event.trim()) {
                                const data = JSON.parse(event.replace('data: ', ''));
                                handleStreamUpdate(data, progressBar, statusMessage, resultsContainer);
                            }
                        });
                    }
                }));

            const reader = eventStream.getReader();
            while (true) {
                const {done, value} = await reader.read();
                if (done) break;
            }

        } catch (error) {
            console.error('Stream error:', error);
            statusMessage.innerHTML = `
                <div class="alert alert-danger">
                    Error: ${error.message}
                </div>
            `;
        } finally {
            this.disabled = false;
        }
    });

    function handleStreamUpdate(data, progressBar, statusMessage, resultsContainer) {
        switch(data.type) {
            case 'progress':
                progressBar.style.width = `${data.percentage}%`;
                progressBar.setAttribute('aria-valuenow', data.percentage);
                progressBar.textContent = `${data.percentage}%`;
                statusMessage.textContent = data.progress;
                break;

            case 'result':
                const resultDiv = document.createElement('div');
                resultDiv.className = 'card mb-3';
                
                if (data.status === 'success') {
                    resultDiv.innerHTML = `
                        <div class="card-body">
                            <h5 class="card-title">${data.model}</h5>
                            <div class="alert alert-success">
                                Generated successfully${data.is_fallback ? 
                                ` (using fallback model: ${data.model_used})` : 
                                ''}
                            </div>
                            <pre><code class="code-block">${data.code}</code></pre>
                            <button class="btn btn-primary download-btn" 
                                    data-filepath="${data.filepath}">
                                Download File
                            </button>
                        </div>
                    `;
                    
                    const downloadBtn = resultDiv.querySelector('.download-btn');
                    downloadBtn.addEventListener('click', () => {
                        handleDownload(data.filepath);
                    });
                } else {
                    resultDiv.innerHTML = `
                        <div class="card-body">
                            <h5 class="card-title">${data.model}</h5>
                            <div class="alert alert-danger">
                                Error: ${data.error}
                            </div>
                        </div>
                    `;
                }
                
                resultsContainer.appendChild(resultDiv);
                hljs.highlightAll();
                break;

            case 'complete':
                progressBar.classList.remove('progress-bar-animated');
                statusMessage.textContent = 'Generation completed!';
                break;

            case 'error':
                statusMessage.innerHTML = `
                    <div class="alert alert-danger">
                        Error: ${data.error}
                    </div>
                `;
                break;
        }
    }

    // Add API test functionality
    const apiTestBtn = document.getElementById('apiTestBtn');
    const apiTestModal = new bootstrap.Modal(document.getElementById('apiTestModal'));
    const apiTestResult = document.getElementById('apiTestResult');

    apiTestBtn.addEventListener('click', async () => {
        apiTestModal.show();
        apiTestResult.innerHTML = `
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Testing...</span>
            </div>
            <div class="mt-2">Testing API connection...</div>
        `;

        try {
            const response = await fetch('/check_ollama');
            const data = await response.json();
            
            let statusClass = 'text-success';
            let icon = 'check-circle-fill';
            let statusBadge = '';
            
            if (response.status === 206) {
                statusClass = 'text-warning';
                icon = 'exclamation-triangle-fill';
                statusBadge = `<span class="badge bg-warning text-dark ms-2">Partial</span>`;
            } else if (response.status !== 200) {
                statusClass = 'text-danger';
                icon = 'x-circle-fill';
                statusBadge = `<span class="badge bg-danger ms-2">Error</span>`;
            } else {
                statusBadge = `<span class="badge bg-success ms-2">OK</span>`;
            }

            apiTestResult.innerHTML = `
                <div class="mb-3">
                    <div class="${statusClass} d-flex align-items-center">
                        <i class="bi bi-${icon} me-2"></i>
                        <strong>${data.status}</strong>
                        ${statusBadge}
                    </div>
                    ${data.server_version ? `<div class="text-muted small">Server Version: ${data.server_version}</div>` : ''}
                </div>
                ${data.available_models ? `
                    <div class="mb-2">
                        <strong>Available Models:</strong> ${data.available_count}/${data.total_models}
                    </div>
                    <div class="mb-3">
                        <div class="list-group">
                            ${data.available_models.map(model => `
                                <div class="list-group-item list-group-item-success">
                                    <i class="bi bi-check-circle-fill me-2"></i>${model}
                                </div>
                            `).join('')}
                            ${data.missing_models.map(model => `
                                <div class="list-group-item list-group-item-warning">
                                    <i class="bi bi-exclamation-triangle-fill me-2"></i>${model}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
                <div class="mt-2">
                    <pre class="bg-light p-2 rounded"><code>${JSON.stringify(data, null, 2)}</code></pre>
                </div>
            `;
        } catch (error) {
            apiTestResult.innerHTML = `
                <div class="text-danger">
                    <i class="bi bi-x-circle-fill me-2"></i>
                    <strong>Connection Error</strong>
                </div>
                <div class="mt-2">
                    <pre class="bg-light p-2 rounded"><code>${error.message}</code></pre>
                </div>
            `;
        }
    });

    const analyzeBtn = document.getElementById('analyzeBtn');
    analyzeBtn.addEventListener('click', async () => {
        const codeToAnalyze = document.getElementById('customPrompt').value; // or any other code source
        if (!codeToAnalyze) {
            alert('Please provide code for analysis.');
            return;
        }
        try {
            const response = await fetch('/analyze_complexity', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code: codeToAnalyze })
            });
            const data = await response.json();
            if (response.ok) {
                alert(`Complexity score: ${data.complexity_score}`);
            } else {
                alert(`Error: ${data.error}`);
            }
        } catch (err) {
            alert(`Request failed: ${err.message}`);
        }
    });
});