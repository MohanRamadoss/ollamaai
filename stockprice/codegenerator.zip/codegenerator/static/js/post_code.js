function sanitizeFilePath(path) {
    // Convert backslashes to forward slashes
    return path.replace(/\\/g, '/');
}

document.addEventListener('DOMContentLoaded', function() {
    const postOutputDirectory = document.getElementById('postOutputDirectory');
    
    // Set default directory
    postOutputDirectory.value = 'D:/del/posted_code';
    
    // Add input handler for directory path
    postOutputDirectory.addEventListener('input', function() {
        this.value = sanitizeFilePath(this.value);
    });
    
    document.getElementById('postCodeBtn').addEventListener('click', async function() {
        const code = document.getElementById('postCode').value;
        const language = document.getElementById('postLanguageSelect').value;
        const filename = document.getElementById('postFilename').value;
        const model = document.getElementById('postModelSelect').value;
        const outputDir = sanitizeFilePath(postOutputDirectory.value);
        
        // Validate input fields
        if (!code) {
            alert('Please enter the code');
            return;
        }
        if (!language) {
            alert('Please select a language');
            return;
        }
        if (!filename) {
            alert('Please specify the filename');
            return;
        }
        if (!model) {
            alert('Please select a model');
            return;
        }
        if (!outputDir) {
            alert('Please specify the output directory');
            return;
        }
        
        // Show loading state
        this.disabled = true;
        const postResultsDiv = document.getElementById('postResults');
        postResultsDiv.innerHTML = `
            <div class="progress mb-3">
                <div class="progress-bar progress-bar-striped progress-bar-animated" 
                     role="progressbar" style="width: 0%" 
                     aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
            </div>
            <div id="status-message" class="text-center mb-3">Posting...</div>
            <div id="results-container"></div>
        `;

        const progressBar = postResultsDiv.querySelector('.progress-bar');
        progressBar.style.width = '10%'; // Initialize at 10%
        const statusMessage = document.getElementById('status-message');
        const resultsContainer = document.getElementById('results-container');
        
        try {
            progressBar.style.width = '50%'; // Move halfway when request is sent
            const response = await fetch('/post_code', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    code: code,
                    language: language,
                    filename: filename,
                    model: model,
                    outputDirectory: outputDir
                })
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to post code');
            }
            
            // Display results
            progressBar.style.width = '100%';
            postResultsDiv.innerHTML = `
                <div class="alert alert-success">
                    Code posted successfully. Saved to: ${data.filepath}
                    <br>
                    Generated Code: <pre><code class="code-block">${data.generated_code}</code></pre>
                </div>
            `;
            
            // Apply syntax highlighting
            document.querySelectorAll('pre code').forEach((block) => {
                hljs.highlightBlock(block);
            });
            
        } catch (error) {
            progressBar.style.width = '100%';
            postResultsDiv.innerHTML = `
                <div class="alert alert-danger">
                    ${error.message}
                </div>
            `;
        } finally {
            this.disabled = false;
            this.innerHTML = 'Post Code';
        }
    });
});
