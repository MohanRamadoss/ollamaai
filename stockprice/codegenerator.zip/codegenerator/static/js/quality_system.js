document.addEventListener('DOMContentLoaded', function() {
    const analyzeBtn = document.getElementById('analyzeQualityBtn');
    const checkModelsBtn = document.getElementById('checkModelsBtn');
    const codeInput = document.getElementById('codeInput');
    const languageSelect = document.getElementById('languageSelect');
    let qualityChart = null;

    checkModelsBtn?.addEventListener('click', checkModelStatus);
    analyzeBtn?.addEventListener('click', analyzeCode);

    function checkModelStatus() {
        const modelStatus = document.getElementById('modelStatus');
        modelStatus.innerHTML = `
            <div class="d-flex align-items-center">
                <div class="spinner-border spinner-border-sm text-info me-2"></div>
                <span>Checking model availability...</span>
            </div>
        `;

        fetch('/check_ollama')
            .then(response => response.json())
            .then(data => {
                if (data.error) throw new Error(data.error);
                
                const statusClass = data.status === 'All Models Available' ? 'success' : 'warning';
                modelStatus.innerHTML = `
                    <div class="alert alert-${statusClass} mb-0">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <i class="bi bi-${data.status === 'All Models Available' ? 'check-circle' : 'exclamation-triangle'}-fill"></i>
                                Models Available: ${data.available_count}/${data.total_models}
                            </div>
                            <small>${data.server_version}</small>
                        </div>
                    </div>
                `;
            })
            .catch(error => {
                modelStatus.innerHTML = `
                    <div class="alert alert-danger mb-0">
                        <i class="bi bi-x-circle-fill"></i>
                        Error: ${error.message}
                    </div>
                `;
            });
    }

    async function analyzeCode() {
        if (!codeInput.value.trim()) {
            alert('Please enter code to analyze');
            return;
        }

        const analysisResult = document.getElementById('analysisResult');
        analysisResult.innerHTML = `
            <div class="d-flex align-items-center justify-content-center">
                <div class="spinner-border text-info me-2"></div>
                <span>Analyzing code...</span>
            </div>
        `;

        try {
            // Changed from /analyze_code to /analyze_quality
            const response = await fetch('/analyze_quality', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    code: codeInput.value,
                    language: languageSelect.value,
                    models: Array.from(document.getElementById('modelSelect').selectedOptions).map(opt => opt.value),
                    options: {
                        checkStyle: true,
                        checkSecurity: true,
                        checkPerformance: true,
                        checkBestPractices: true
                    }
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            if (data.error) throw new Error(data.error);
            
            displayResults(data);
        } catch (error) {
            analysisResult.innerHTML = `
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    Error analyzing code: ${error.message}
                </div>
            `;
        }
    }

    function displayResults(analysis) {
        try {
            // Calculate scores
            const scores = {
                overall: analysis.overallScore / 100,
                security: calculateScore(analysis.securityAnalysis),
                performance: calculateScore(analysis.performanceAnalysis),
                quality: calculateScore(analysis.styleAnalysis)
            };

            // Update overview tab
            updateOverview(scores, analysis.summary);
            
            // Update security tab
            updateSecurityTab(analysis.securityAnalysis);
            
            // Update performance tab
            updatePerformanceTab(analysis.performanceAnalysis);
            
            // Update AI insights tab
            updateAIInsights(analysis.ai_feedback);
            
            // Show the results container
            document.querySelector('#resultsTabs').classList.remove('d-none');
            
            // Switch to overview tab
            const overviewTab = new bootstrap.Tab(document.querySelector('#overview-tab'));
            overviewTab.show();
        } catch (error) {
            showError('Error displaying results: ' + error.message);
        }
    }

    function updateOverview(scores, summary) {
        // Update the radar chart
        updateQualityChart(scores);
        
        // Update overview details
        const overviewDetails = document.getElementById('overviewDetails');
        overviewDetails.innerHTML = `
            <div class="card mb-3">
                <div class="card-header bg-${getScoreClass(scores.overall)}">
                    <h5 class="mb-0 text-white">
                        Overall Score: ${Math.round(scores.overall * 100)}%
                    </h5>
                </div>
                <div class="card-body">
                    <h6>Risk Level: ${summary.risk_level.toUpperCase()}</h6>
                    <div class="mb-3">
                        <h6>Critical Issues Found:</h6>
                        <ul class="list-unstyled">
                            ${summary.critical_issues.map(issue => `
                                <li class="text-danger">
                                    <i class="bi bi-exclamation-triangle-fill"></i>
                                    ${issue.type}: ${issue.issue.description}
                                </li>
                            `).join('')}
                        </ul>
                    </div>
                    <div>
                        <h6>Top Recommendations:</h6>
                        <ul>
                            ${summary.top_recommendations.map(rec => `
                                <li>${rec}</li>
                            `).join('')}
                        </ul>
                    </div>
                </div>
            </div>
        `;
    }

    function updateSecurityTab(securityAnalysis) {
        const container = document.getElementById('securityResults');
        
        if (!securityAnalysis || !securityAnalysis.items?.length) {
            container.innerHTML = createAlertBox('success', 'No security issues found');
            return;
        }

        const riskLevel = securityAnalysis.risk_level;
        const vulns = securityAnalysis.vulnerabilities || [];
        const warnings = securityAnalysis.warnings || [];

        container.innerHTML = `
            <div class="alert alert-${getRiskLevelClass(riskLevel)} mb-3">
                <h5 class="mb-0">Security Risk Level: ${riskLevel.toUpperCase()}</h5>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="card bg-danger text-white">
                        <div class="card-body">
                            <h3 class="card-title">${vulns.length}</h3>
                            <p class="card-text">Critical Vulnerabilities</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card bg-warning">
                        <div class="card-body">
                            <h3 class="card-title">${warnings.length}</h3>
                            <p class="card-text">Security Warnings</p>
                        </div>
                    </div>
                </div>
            </div>

            ${vulns.length ? `
                <h5>Critical Vulnerabilities</h5>
                <div class="list-group mb-3">
                    ${vulns.map(createVulnerabilityItem).join('')}
                </div>
            ` : ''}

            ${warnings.length ? `
                <h5>Security Warnings</h5>
                <div class="list-group">
                    ${warnings.map(createWarningItem).join('')}
                </div>
            ` : ''}
        `;
    }

    function createVulnerabilityItem(vuln) {
        return `
            <div class="list-group-item list-group-item-danger">
                <div class="d-flex w-100 justify-content-between">
                    <h6 class="mb-1">${vuln.type}</h6>
                    <small>Line ${vuln.line}</small>
                </div>
                <p class="mb-1">${vuln.description}</p>
                <small class="text-muted">Suggestion: ${vuln.suggestion}</small>
            </div>
        `;
    }

    function updatePerformanceTab(performance) {
        const performanceIssues = document.getElementById('performanceIssues');
        if (!performance.issues.length) {
            performanceIssues.innerHTML = `
                <div class="alert alert-success">
                    <i class="bi bi-speedometer2"></i>
                    No performance issues detected
                </div>
            `;
            return;
        }

        performanceIssues.innerHTML = performance.issues.map(issue => `
            <div class="alert alert-warning">
                <h5 class="alert-heading">${issue.type}</h5>
                <p>${issue.suggestion}</p>
                <small>Line: ${issue.line}</small>
            </div>
        `).join('');
    }

    function updateAIInsights(responses) {
        const aiSuggestions = document.getElementById('aiSuggestions');
        if (!responses || !responses.length) {
            aiSuggestions.innerHTML = '<div class="alert alert-info">No AI feedback available</div>';
            return;
        }

        const detailedAnalysis = responses.filter(r => r.type === 'detailed');
        const quickAnalysis = responses.filter(r => r.type === 'quick');

        let html = '<div class="ai-feedback">';
        
        // Show detailed analysis first
        if (detailedAnalysis.length) {
            html += '<h4>Detailed Analysis</h4>';
            detailedAnalysis.forEach(response => {
                html += `
                    <div class="card mb-3">
                        <div class="card-header bg-info text-white">
                            ${response.model} ${response.model_used !== response.model ? `(Fallback: ${response.model_used})` : ''}
                        </div>
                        <div class="card-body">
                            <pre class="mb-0">${response.feedback}</pre>
                        </div>
                    </div>`;
            });
        }

        // Then show quick analysis
        if (quickAnalysis.length) {
            html += '<h4>Quick Analysis</h4>';
            quickAnalysis.forEach(response => {
                html += `
                    <div class="card mb-3">
                        <div class="card-header bg-secondary text-white">
                            ${response.model} ${response.model_used !== response.model ? `(Fallback: ${response.model_used})` : ''}
                        </div>
                        <div class="card-body">
                            <pre class="mb-0">${response.feedback}</pre>
                        </div>
                    </div>`;
            });
        }

        html += '</div>';
        aiSuggestions.innerHTML = html;
    }

    function getScoreAlertClass(score) {
        if (score >= 0.8) return 'success';
        if (score >= 0.6) return 'info';
        if (score >= 0.4) return 'warning';
        return 'danger';
    }

    function getSecurityAlertClass(severity) {
        switch (severity.toUpperCase()) {
            case 'HIGH': return 'danger';
            case 'MEDIUM': return 'warning';
            default: return 'info';
        }
    }

    // Initial model status check
    checkModelStatus();
    
    // Add utility functions
    function getRiskLevelClass(level) {
        switch (level?.toLowerCase()) {
            case 'critical': return 'danger';
            case 'high': return 'danger';
            case 'medium': return 'warning';
            case 'low': return 'success';
            default: return 'info';
        }
    }

    function createAlertBox(type, message) {
        return `
            <div class="alert alert-${type}">
                <i class="bi bi-info-circle-fill me-2"></i>
                ${message}
            </div>
        `;
    }

    function formatFindings(findings, category) {
        switch (category) {
            case 'security':
                return formatSecurityFindings(findings);
            case 'performance':
                return formatPerformanceFindings(findings);
            case 'quality':
                return formatQualityFindings(findings);
            default:
                return `<pre class="mb-0">${JSON.stringify(findings, null, 2)}</pre>`;
        }
    }

    // Helper functions for formatting specific findings
    function formatSecurityFindings(findings) {
        return `
            <div class="security-findings">
                ${findings.vulnerabilities ? `
                    <h6>Vulnerabilities Found:</h6>
                    <ul class="list-unstyled">
                        ${findings.vulnerabilities.map(v => `
                            <li class="text-danger">
                                <i class="bi bi-exclamation-triangle-fill"></i> ${v}
                            </li>
                        `).join('')}
                    </ul>
                ` : ''}
                ${findings.risk_level ? `
                    <div class="alert alert-${getRiskLevelClass(findings.risk_level)} mb-2">
                        Risk Level: ${findings.risk_level.toUpperCase()}
                    </div>
                ` : ''}
                ${findings.critical_issues ? `
                    <h6>Critical Issues:</h6>
                    <ul class="mb-0">
                        ${findings.critical_issues.map(issue => `
                            <li>${issue}</li>
                        `).join('')}
                    </ul>
                ` : ''}
            </div>
        `;
    }
});
