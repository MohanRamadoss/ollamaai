document.addEventListener('DOMContentLoaded', function() {
    checkModelStatus();
    
    document.getElementById('refreshStatus')?.addEventListener('click', function() {
        checkModelStatus();
    });
});

function checkModelStatus() {
    const statusContent = document.getElementById('modelStatusContent');
    const statusTable = document.getElementById('modelStatusTable');
    
    if (!statusContent || !statusTable) return;
    
    statusContent.innerHTML = `
        <div class="d-flex align-items-center">
            <div class="spinner-border spinner-border-sm text-primary me-2" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <span>Checking model status...</span>
        </div>
    `;
    
    fetch('/check_ollama')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'Error' || data.error) {
                statusContent.innerHTML = `
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle-fill"></i>
                        Error checking model status: ${data.error || 'Unknown error'}
                    </div>
                `;
                return;
            }
            
            // Update status display
            const tbody = statusTable.querySelector('tbody');
            tbody.innerHTML = '';
            
            data.available_models.forEach(model => {
                tbody.innerHTML += `
                    <tr>
                        <td>${model}</td>
                        <td><span class="badge bg-success">Available</span></td>
                        <td>${new Date().toLocaleTimeString()}</td>
                    </tr>
                `;
            });
            
            data.missing_models.forEach(model => {
                tbody.innerHTML += `
                    <tr>
                        <td>${model}</td>
                        <td><span class="badge bg-danger">Unavailable</span></td>
                        <td>${new Date().toLocaleTimeString()}</td>
                    </tr>
                `;
            });
            
            statusContent.innerHTML = `
                <div class="alert ${data.status === 'All Models Available' ? 'alert-success' : 'alert-warning'}">
                    <i class="bi ${data.status === 'All Models Available' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill'}"></i>
                    Server Status: ${data.server_status} (v${data.server_version})
                    <br>
                    Models Available: ${data.available_count}/${data.total_models}
                </div>
            `;
            
            statusTable.style.display = 'table';
        })
        .catch(error => {
            statusContent.innerHTML = `
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    Failed to check model status: ${error.message}
                </div>
            `;
        });
}
