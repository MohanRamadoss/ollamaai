document.addEventListener('DOMContentLoaded', function() {
    const generateForm = document.getElementById('generateForm');
    const checkModelsBtn = document.getElementById('checkModelsBtn');
    const modelStatus = document.getElementById('modelStatus');
    const resultsDiv = document.getElementById('results');

    // Update range input values
    ['temperature', 'topP'].forEach(id => {
        const input = document.getElementById(id);
        const valueDisplay = document.getElementById(`${id}Value`);
        if (input && valueDisplay) {
            input.addEventListener('input', () => {
                valueDisplay.textContent = input.value;
            });
        }
    });

    // Check selected models
    checkModelsBtn?.addEventListener('click', function(e) {
        e.preventDefault();
        const selectedModels = Array.from(document.querySelectorAll('.model-checkbox:checked'))
            .map(cb => cb.value);
        checkSelectedModels(selectedModels);
    });

    // Form submission
    generateForm?.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const selectedModels = Array.from(document.querySelectorAll('.model-checkbox:checked'))
            .map(cb => cb.value);
            
        if (selectedModels.length === 0) {
            alert('Please select at least one model');
            return;
        }

        const formData = {
            models: selectedModels,
            language: document.getElementById('languageSelect').value,
            customPrompt: document.getElementById('promptInput').value,
            complexity: document.getElementById('complexityLevel').value,
            temperature: parseFloat(document.getElementById('temperature').value),
            top_p: parseFloat(document.getElementById('topP').value),
            top_k: parseInt(document.getElementById('topK').value),
            max_tokens: parseInt(document.getElementById('maxTokens').value),
            options: {
                addComments: document.getElementById('addComments').checked,
                addErrorHandling: document.getElementById('addErrorHandling').checked,
                addTests: document.getElementById('addTests').checked,
                optimizeCode: document.getElementById('optimizeCode').checked,
                addLogging: document.getElementById('addLogging').checked
            }
        };

        // Show loading state
        resultsDiv.innerHTML = `
            <div class="d-flex align-items-center">
                <div class="spinner-border text-primary me-2"></div>
                <span>Generating code...</span>
            </div>
        `;

        try {
            const response = await fetch('/generate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });

            const data = await response.json();
            displayResults(data);
        } catch (error) {
            resultsDiv.innerHTML = `
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    Error generating code: ${error.message}
                </div>
            `;
        }
    });

    // Check selected models status
    function checkSelectedModels(selectedModels) {
        if (selectedModels.length === 0) {
            modelStatus.innerHTML = `
                <div class="alert alert-warning">
                    <i class="bi bi-exclamation-triangle"></i>
                    Please select at least one model to check
                </div>
            `;
            return;
        }

        modelStatus.innerHTML = `
            <div class="d-flex align-items-center">
                <div class="spinner-border spinner-border-sm text-primary me-2"></div>
                <span>Checking model status...</span>
            </div>
        `;

        fetch('/check_ollama')
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    throw new Error(data.error);
                }

                const availableModels = new Set(data.available_models);
                const unavailableModels = selectedModels.filter(model => !availableModels.has(model));
                
                if (unavailableModels.length > 0) {
                    modelStatus.innerHTML = `
                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-triangle"></i>
                            Some selected models are unavailable: ${unavailableModels.join(', ')}
                        </div>
                    `;
                } else {
                    modelStatus.innerHTML = `
                        <div class="alert alert-success">
                            <i class="bi bi-check-circle"></i>
                            All selected models are available
                        </div>
                    `;
                }
            })
            .catch(error => {
                modelStatus.innerHTML = `
                    <div class="alert alert-danger">
                        <i class="bi bi-x-circle"></i>
                        Error checking models: ${error.message}
                    </div>
                `;
            });
    }

    // Display generated code results
    function displayResults(data) {
        let resultsHtml = '';
        
        for (const [model, result] of Object.entries(data)) {
            if (result.status === 'success') {
                resultsHtml += `
                    <div class="card mb-3">
                        <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                            <span>${model}</span>
                            ${result.is_fallback ? `<span class="badge bg-warning">Fallback: ${result.model_used}</span>` : ''}
                            <a href="/download_code?file=${encodeURIComponent(result.filepath)}" 
                               class="btn btn-sm btn-light">
                                <i class="bi bi-download"></i> Download
                            </a>
                        </div>
                        <div class="card-body">
                            <pre><code class="language-${document.getElementById('languageSelect').value}">${result.code}</code></pre>
                        </div>
                    </div>
                `;
            } else {
                resultsHtml += `
                    <div class="alert alert-danger">
                        <strong>${model}:</strong> ${result.error}
                    </div>
                `;
            }
        }

        resultsDiv.innerHTML = resultsHtml;

        // Initialize syntax highlighting if available
        if (window.hljs) {
            document.querySelectorAll('pre code').forEach((block) => {
                hljs.highlightElement(block);
            });
        }
    }
});
