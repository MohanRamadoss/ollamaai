document.addEventListener('DOMContentLoaded', function() {
    const convertBtn = document.getElementById('convertBtn');
    const resultsDiv = document.getElementById('results');
    const loadingSpinner = '<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div>';

    convertBtn?.addEventListener('click', async function() {
        const sourceCode = document.getElementById('sourceCode').value;
        const sourceLanguage = document.getElementById('sourceLanguage').value;
        const targetLanguage = document.getElementById('targetLanguage').value;
        const selectedModels = Array.from(document.querySelectorAll('#modelSelection input:checked'))
            .map(checkbox => checkbox.value);

        // Validation
        if (!sourceCode) {
            alert('Please enter source code');
            return;
        }
        if (!sourceLanguage) {
            alert('Please select source language');
            return;
        }
        if (!targetLanguage) {
            alert('Please select target language');
            return;
        }
        if (selectedModels.length === 0) {
            alert('Please select at least one model');
            return;
        }

        // Get options
        const options = {
            maintainComments: document.getElementById('maintainComments').checked,
            optimizeCode: document.getElementById('optimizeCode').checked,
            addExplanations: document.getElementById('addExplanations').checked
        };

        // Show loading state
        this.disabled = true;
        this.innerHTML = `${loadingSpinner} Converting...`;
        resultsDiv.innerHTML = `<div class="text-center p-4">${loadingSpinner}<p class="mt-3">Converting code...</p></div>`;

        try {
            const response = await fetch('/code_convert', {  // Changed from /convert_code to /code_convert
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    sourceCode,
                    sourceLanguage,
                    targetLanguage,
                    models: selectedModels,
                    options
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            displayResults(data, targetLanguage);
        } catch (error) {
            resultsDiv.innerHTML = `
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    ${error.message}
                </div>
            `;
        } finally {
            this.disabled = false;
            this.innerHTML = '<i class="bi bi-arrow-left-right"></i> Convert Code';
        }
    });

    function displayResults(data, targetLanguage) {
        if (!data.conversions || data.conversions.length === 0) {
            resultsDiv.innerHTML = `
                <div class="alert alert-warning">
                    <i class="bi bi-exclamation-triangle"></i>
                    No conversions received
                </div>
            `;
            return;
        }

        let resultsHtml = '<div class="conversions-container">';
        
        data.conversions.forEach(conversion => {
            resultsHtml += `
                <div class="card mb-4">
                    <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">${conversion.model}</h5>
                        <span class="badge ${conversion.status === 'success' ? 'bg-success' : 'bg-danger'}">
                            ${conversion.status}
                        </span>
                    </div>
                    <div class="card-body code-display" style="background: #1e1e1e; color: #fff;">
                        <pre><code class="language-${targetLanguage}">${escapeHtml(conversion.code || conversion.error)}</code></pre>
                    </div>
                    ${conversion.status === 'success' ? `
                        <div class="card-footer bg-dark d-flex justify-content-end">
                            <button class="btn btn-sm btn-light copy-btn" onclick="copyToClipboard(this, '${encodeURIComponent(conversion.code)}')">
                                <i class="bi bi-clipboard"></i> Copy
                            </button>
                        </div>
                    ` : ''}
                </div>
            `;
        });

        resultsHtml += '</div>';
        resultsDiv.innerHTML = resultsHtml;

        // Apply syntax highlighting
        if (window.hljs) {
            document.querySelectorAll('pre code').forEach((block) => {
                hljs.highlightElement(block);
            });
        }
    }

    function escapeHtml(unsafe) {
        if (!unsafe) return '';
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function copyToClipboard(button, encodedText) {
        const text = decodeURIComponent(encodedText);
        navigator.clipboard.writeText(text).then(() => {
            const originalText = button.innerHTML;
            button.innerHTML = '<i class="bi bi-check"></i> Copied!';
            button.disabled = true;
            setTimeout(() => {
                button.innerHTML = originalText;
                button.disabled = false;
            }, 2000);
        });
    }
});
