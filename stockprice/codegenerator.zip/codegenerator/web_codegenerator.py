# Standard library imports
import os
import sys
import json
import time
import logging
import re
from datetime import datetime
from functools import wraps

# Third-party imports
from flask import (
    Flask, request, jsonify, render_template, 
    send_file, session, redirect, url_for, 
    Response, stream_with_context
)
import requests
from tenacity import retry, stop_after_attempt, wait_exponential, RetryError
from ratelimit import limits, sleep_and_retry
from dotenv import load_dotenv
from werkzeug.urls import quote, unquote  # Changed from url_quote, url_unquote
from werkzeug.exceptions import HTTPException

# Local imports
from utils import sanitize_path, ensure_directory_exists
from config import Config
from utils.code_analyzer import CodeAnalyzer
from utils.quality_system import QualitySystem

load_dotenv()

# Initialize Flask app
app = Flask(__name__, 
           template_folder=os.path.join(os.path.dirname(__file__), 'templates'),
           static_folder=os.path.join(os.path.dirname(__file__), 'static'))

# Add secret key for session management
app.secret_key = 'your-secret-key-here'  # Change this to a secure secret key

# Login credentials
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'password'

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Setup logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Setup HTTP connection debug logging
if app.debug:
    import http.client as http_client
    http_client.HTTPConnection.debuglevel = 1
    requests_log = logging.getLogger("requests.packages.urllib3")
    requests_log.setLevel(logging.DEBUG)
    requests_log.propagate = True

# Initialize configuration
OLLAMA_API_URL = os.getenv("OLLAMA_API_URL", Config.OLLAMA_API_URL)
OLLAMA_MODELS = Config.OLLAMA_MODELS
LANGUAGES = Config.LANGUAGES

# Add prompt optimization templates
PROMPT_TEMPLATES = {
    "basic": "Write a simple example program in {language} that demonstrates basic functionality. Include comments explaining the code.",
    "advanced": "Create a comprehensive {language} program that demonstrates best practices, error handling, and modern syntax. Include detailed comments and documentation.",
    "optimized": "Generate production-ready {language} code with optimal performance, following clean code principles. Include error handling, logging, and comprehensive documentation."
}

def optimize_prompt(prompt: str, language: str, complexity: str = "basic") -> str:
    """Optimize the prompt by adding context and requirements"""
    if not prompt:
        prompt = PROMPT_TEMPLATES.get(complexity, PROMPT_TEMPLATES["basic"]).format(language=language)
    
    # Add language-specific context
    prompt = f"As an expert {language} developer, {prompt}\n"
    prompt += "Requirements:\n"
    prompt += "- Write clean, maintainable code\n"
    prompt += "- Include proper error handling\n"
    prompt += "- Add comprehensive comments\n"
    prompt += "- Follow language-specific best practices\n"
    
    return prompt

# ...existing imports...

# Add Ollama API Configuration
OLLAMA_ENDPOINTS = {
    "generate": "/api/generate",
    "status": "/api/status",
    "models": "/api/tags",  # Changed from /api/models to /api/tags
    "version": "/api/version"
}

OLLAMA_HEADERS = {
    "Content-Type": "application/json",
    "Accept": "application/json"
}

OLLAMA_RETRY_CONFIG = {
    "max_attempts": 5,
    "min_delay": 1,
    "max_delay": 10
}

OLLAMA_RATE_LIMIT = {
    "calls": 10,
    "period": 60
}

# Add new constants after OLLAMA_ENDPOINTS
OLLAMA_MODEL_STATES = {
    "READY": "ready",
    "LOADING": "loading",
    "FAILED": "failed"
}

OLLAMA_POLLING_CONFIG = {
    "interval": 10,  # seconds between checks
    "timeout": 300,  # total seconds to wait
    "max_concurrent_loads": 2  # max models to load at once
}

# Add this after OLLAMA_MODEL_STATES
MODEL_STATE_CACHE = {
    'last_check': 0,
    'cache_duration': 30,  # Cache results for 30 seconds
    'models': {},
    'loading_queue': []
}

def parse_model_details(model_data: dict) -> dict:
    """Parse and normalize model information from Ollama response"""
    try:
        size_gb = round(model_data.get('size', 0) / (1024 * 1024 * 1024), 2)
        details = model_data.get('details', {})
        return {
            'name': model_data.get('name', ''),
            'size': f"{size_gb}GB",
            'modified': model_data.get('modified_at', ''),
            'digest': model_data.get('digest', ''),
            'parameter_size': details.get('parameter_size', 'unknown'),
            'family': details.get('family', 'unknown'),
            'format': details.get('format', 'unknown'),
            'quantization': details.get('quantization_level', 'unknown')
        }
    except Exception as e:
        logging.error(f"Error parsing model details: {e}")
        return {}

@app.route('/')
def root():
    """Root route that handles initial access"""
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard after login"""
    try:
        return render_template('index.html', 
                             models=OLLAMA_MODELS, 
                             languages=LANGUAGES)
    except Exception as e:
        logger.error(f"Error rendering dashboard: {str(e)}")
        return f"Error: {str(e)}", 500

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Handle login"""
    if session.get('logged_in'):
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['logged_in'] = True
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error='Invalid credentials')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Handle logout"""
    session.clear()
    return redirect(url_for('login'))

@app.before_request
def before_request():
    """Check login status and ensure directories exist"""
    # Skip auth check for login page and static files
    if (request.endpoint and 
        not request.endpoint.startswith('static') and 
        request.endpoint != 'login' and 
        not session.get('logged_in')):
        return redirect(url_for('login'))
        
    # Ensure required directories exist
    try:
        os.makedirs('generated_code', exist_ok=True)
    except Exception as e:
        app.logger.error(f"Failed to create required directories: {str(e)}")
        raise

# ...rest of existing code...

# Model Configuration with Fallbacks
MODEL_CONFIGS = {
    'primary_models': {
        "codellama": {  # 3.8 GB
            "fallbacks": ["codellama:13b", "deepseek-coder:6.7b", "granite-code:8b"],
            "timeout": 30,
            "temperature": 0.7
        },
        "codellama:13b": {  # 7.4 GB
            "fallbacks": ["deepseek-coder:6.7b", "codegemma", "granite-code:8b"],
            "timeout": 30,
            "temperature": 0.7
        },
        "deepseek-coder:33b": {  # 18 GB
            "fallbacks": ["mistral-small", "granite-code:20b", "codellama:13b"],
            "timeout": 30,
            "temperature": 0.7
        },
        "deepseek-coder:6.7b": {  # 3.8 GB
            "fallbacks": ["codellama", "granite-code:8b", "codegemma"],
            "timeout": 30,
            "temperature": 0.7
        },
        "qwen2.5-coder:14b": {  # 9.0 GB
            "fallbacks": ["codeqwen", "codellama:13b", "granite-code:8b"],
            "timeout": 30,
            "temperature": 0.7
        },
        "codeqwen": {  # 4.2 GB
            "fallbacks": ["codellama", "granite-code:8b", "codegemma"],
            "timeout": 30,
            "temperature": 0.7
        },
        "codestral": {  # 12 GB
            "fallbacks": ["mistral-small", "codellama:13b", "granite-code:20b"],
            "timeout": 30,
            "temperature": 0.7
        },
        "codegemma": {  # 5.0 GB
            "fallbacks": ["codellama", "granite-code:8b", "deepseek-coder:6.7b"],
            "timeout": 30,
            "temperature": 0.7
        },
        "granite-code:8b": {  # 4.6 GB
            "fallbacks": ["codellama", "codegemma", "deepseek-coder:6.7b"],
            "timeout": 30,
            "temperature": 0.7
        },
        "granite-code:20b": {  # 11 GB
            "fallbacks": ["codellama:13b", "codestral", "mistral-small"],
            "timeout": 30,
            "temperature": 0.7
        },
        "mistral-small": {  # 12 GB
            "fallbacks": ["codestral", "codellama:13b", "granite-code:20b"],
            "timeout": 30,
            "temperature": 0.7
        },
        "granite28b": {  # Add missing model
            "fallbacks": ["granite-code:20b", "deepseek-coder:33b", "codellama:13b"],
            "timeout": 30,
            "temperature": 0.7
        },
        "mistral": {  # 4.1 GB
            "fallbacks": ["mistral-small", "codellama", "codegemma"],
            "timeout": 30,
            "temperature": 0.7,
            "purpose": "quick_analysis"  # Good for quick code analysis
        },
        "mistral-small": {  # 12 GB
            "fallbacks": ["mistral", "codellama:13b", "deepseek-coder:6.7b"],
            "timeout": 30,
            "temperature": 0.7,
            "purpose": "detailed_analysis"  # Better for detailed analysis
        }
    },
    'rate_limit': 60  # requests per minute
}

# Rate limiting decorator
ONE_MINUTE = 60
@sleep_and_retry
@limits(calls=MODEL_CONFIGS['rate_limit'], period=ONE_MINUTE)
def rate_limited_api_call(url, payload, timeout):
    return requests.post(url, json=payload, timeout=timeout)

# Retry decorator with exponential backoff
@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
def retry_api_call(url, payload, timeout):
    response = rate_limited_api_call(url, payload, timeout=timeout)
    if response.status_code != 200:
        raise Exception(f"API call failed with status {response.status_code}")
    return response

class ModelManager:
    def __init__(self):
        self.error_counts = {model: 0 for model in MODEL_CONFIGS['primary_models']}
        self.last_error_times = {model: 0 for model in MODEL_CONFIGS['primary_models']}
        self.model_aliases = {
            # Add model aliases for handling different model name formats
            "granite28b": "granite28b",
            "granite-code:8b": "granite-code:8b",
            "granite-code:20b": "granite-code:20b",
            # Add other aliases as needed
            "mistral": "mistral:latest",
            "mistral-small": "mistral-small:latest"
        }

    def normalize_model_name(self, model: str) -> str:
        """Normalize model name to handle different formats"""
        return self.model_aliases.get(model, model)

    def should_use_fallback(self, model):
        if time.time() - self.last_error_times[model] > 300:  # Reset after 5 minutes
            self.error_counts[model] = 0
            return False
        return self.error_counts[model] >= 3

    def handle_model_error(self, model):
        self.error_counts[model] += 1
        self.last_error_times[model] = time.time()

    def generate_code_sync(self, model, prompt):
        """Attempt model generation with fallback chain."""
        # Normalize model name before lookup
        normalized_model = self.normalize_model_name(model)
        
        try:
            # Get fallback chain with error handling
            if normalized_model not in MODEL_CONFIGS['primary_models']:
                logging.error(f"Unknown model: {model} (normalized: {normalized_model})")
                return None, f"Model {model} not configured", model

            chain = [normalized_model] + MODEL_CONFIGS['primary_models'][normalized_model].get('fallbacks', [])
            
            for idx, current_model in enumerate(chain, start=1):
                try:
                    # Get model config with fallback to default values
                    model_config = MODEL_CONFIGS['primary_models'].get(current_model, {
                        "timeout": 30,
                        "temperature": 0.7
                    })
                    
                    temperature = model_config.get('temperature', 0.7)
                    logging.debug(f"[DEBUG] Attempting model #{idx} in fallback chain: {current_model}")
                    
                    # Minimal payload for Ollama API
                    payload = {
                        "model": current_model,
                        "prompt": prompt,
                        "stream": False,
                        "temperature": temperature
                    }
                    
                    response = retry_api_call(
                        f"{OLLAMA_API_URL}/api/generate",
                        payload,
                        timeout=30
                    )
                    
                    logging.debug(f"API call to model: {current_model} status: {response.status_code}")
                    if response.status_code == 200:
                        return response.json().get('response', ''), None, current_model
                    else:
                        if current_model == model:
                            self.handle_model_error(model)
                        error_msg = f"API request failed with status {response.status_code}"
                        logging.debug(f"[DEBUG] {error_msg}")
                except RetryError as e:
                    if current_model == model:
                        self.handle_model_error(model)
                    error_msg = f"RetryError: {str(e)}"
                    logging.debug(f"[DEBUG] {error_msg}")
                except Exception as e:
                    if current_model == model:
                        self.handle_model_error(model)
                    error_msg = str(e)
                    logging.exception(f"[DEBUG] Exception in model {current_model}: {error_msg}", exc_info=True)
            # Fallback chain exhausted
            return None, "All fallback attempts failed", chain[-1]
        except Exception as e:
            logging.error(f"Error in generate_code_sync for model {model}: {str(e)}")
            return None, str(e), model

# Initialize model manager
model_manager = ModelManager()
quality_system = QualitySystem()

@app.route('/')
@login_required
def index():
    try:
        return render_template('index.html', 
                             models=OLLAMA_MODELS, 
                             languages=LANGUAGES)
    except Exception as e:
        logger.error(f"Error rendering index page: {str(e)}")
        return f"Error: {str(e)}", 500

@app.route('/post_code_page')
@login_required
def post_code_page():
    return render_template('post_code.html', models=OLLAMA_MODELS, languages=LANGUAGES)

# Add @login_required decorator to other routes that need protection
@app.route('/generate', methods=['POST'])
@login_required
def generate_code():
    logging.debug("Received /generate request")
    data = request.json
    selected_models = data.get('models', [])
    language = data.get('language', '')
    custom_prompt = data.get('customPrompt', '')
    
    # Use fixed output directory instead of user input
    output_directory = os.path.join(os.getcwd(), 'generated_code')
    logging.debug(f"Using output directory: {output_directory}")
    
    # Ensure the directory exists
    os.makedirs(output_directory, exist_ok=True)
    
    complexity = data.get('complexity', 'basic')
    temperature = data.get('temperature', 0.7)
    top_p = data.get('top_p', 0.8)
    top_k = data.get('top_k', 30)
    max_tokens = data.get('max_tokens', 1000)
    presence_penalty = data.get('presence_penalty', 0.5)
    frequency_penalty = data.get('frequency_penalty', 0.5)
    
    if not selected_models or not language:
        return jsonify({'error': 'Missing required parameters'}), 400

    results = {}
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    for model in selected_models:
        logging.debug(f"Processing model: {model}")
        try:
            # Optimize the prompt
            optimized_prompt = optimize_prompt(custom_prompt, LANGUAGES[language]['name'], complexity)
            
            # Use the synchronous version of generate_code
            code, error, used_model = model_manager.generate_code_sync(model, optimized_prompt)
            
            # Use relative path for response
            if code:
                filename = f"generated_{language}_{model}_{timestamp}.{LANGUAGES[language]['extension']}"
                filepath = os.path.join('generated_code', filename)  # Use relative path
                absolute_filepath = os.path.join(os.getcwd(), filepath)  # For file writing
                
                logging.debug(f"Saving to: {absolute_filepath}")
                
                with open(absolute_filepath, 'w', encoding='utf-8') as f:
                    f.write(code)
                
                results[model] = {
                    'code': code,
                    'filename': filename,  # Send just filename
                    'filepath': filepath,  # Send relative path
                    'status': 'success',
                    'model_used': used_model,
                    'is_fallback': used_model != model
                }
            else:
                results[model] = {
                    'error': error,
                    'status': 'error',
                    'model_used': used_model,
                    'is_fallback': used_model != model
                }
                
        except Exception as e:
            logging.error(f"Exception processing model {model}: {str(e)}", exc_info=True)
            results[model] = {
                'error': str(e),
                'status': 'error'
            }
    
    logging.debug("Finished /generate request")
    return jsonify(results)

@app.route('/generate_stream', methods=['POST'])
@login_required
def generate_code_stream():
    def generate():
        try:
            data = request.get_json()
            if not data:
                yield "data: " + json.dumps({'error': 'Invalid JSON data'}) + "\n\n"
                return

            selected_models = data.get('models', [])
            language = data.get('language', '')
            custom_prompt = data.get('customPrompt', '')
            
            if not selected_models or not language:
                yield "data: " + json.dumps({'error': 'Missing parameters'}) + "\n\n"
                return

            total_models = len(selected_models)
            
            for idx, model in enumerate(selected_models, 1):
                yield "data: " + json.dumps({
                    'type': 'progress',
                    'model': model,
                    'progress': f"Processing model {idx}/{total_models}: {model}",
                    'percentage': (idx * 100) // total_models
                }) + "\n\n"

                try:
                    optimized_prompt = optimize_prompt(
                        custom_prompt, 
                        LANGUAGES[language]['name'], 
                        data.get('complexity', 'basic')
                    )
                    
                    code, error, used_model = model_manager.generate_code_sync(model, optimized_prompt)
                    
                    if code:
                        filename = f"generated_{language}_{model}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.{LANGUAGES[language]['extension']}"
                        filepath = os.path.join('generated_code', filename)
                        
                        with open(filepath, 'w', encoding='utf-8') as f:
                            f.write(code)
                        
                        yield "data: " + json.dumps({
                            'type': 'result',
                            'model': model,
                            'status': 'success',
                            'code': code,
                            'filepath': filepath,
                            'model_used': used_model,
                            'is_fallback': used_model != model
                        }) + "\n\n"
                    else:
                        yield "data: " + json.dumps({
                            'type': 'result',
                            'model': model,
                            'status': 'error',
                            'error': error
                        }) + "\n\n"
                        
                except Exception as e:
                    yield "data: " + json.dumps({
                        'type': 'result',
                        'model': model,
                        'status': 'error',
                        'error': str(e)
                    }) + "\n\n"

            yield "data: " + json.dumps({
                'type': 'complete',
                'message': 'Generation completed'
            }) + "\n\n"
            
        except Exception as e:
            yield "data: " + json.dumps({
                'type': 'error',
                'error': str(e)
            }) + "\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'X-Accel-Buffering': 'no',
            'Connection': 'keep-alive',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type'
        }
    )

@app.route('/post_code', methods=['GET', 'POST'])
@login_required
def post_code():
    if request.method == 'GET':
        return render_template('post_code.html',
                             models=OLLAMA_MODELS,
                             languages=LANGUAGES)
    logging.debug("Received /post_code request")
    data = request.json
    code = data.get('code', '')
    language = data.get('language', '')
    selected_models = data.get('models', [])
    action = data.get('action', 'analyze')
    
    if not code or not language or not selected_models:
        return jsonify({'error': 'Missing required parameters'}), 400

    results = []
    
    for model in selected_models:
        try:
            if action == 'document':
                prompt = f"""Add comprehensive documentation and comments to this {LANGUAGES[language]['name']} code. 
                Include:
                - File-level documentation
                - Function/class purpose
                - Parameter descriptions
                - Return value descriptions
                - Usage examples where appropriate
                - Important notes or warnings
                - Any dependencies or requirements
                
                Code to document:
                ```{language}
                {code}
                ```
                
                Return the documented version with clear explanations, preserving the original code structure."""
            elif action == 'analyze':
                prompt = f"""Analyze the following {LANGUAGES[language]['name']} code and provide detailed suggestions:
                ```{language}
                {code}
                ```
                Focus on:
                - Code structure and organization
                - Potential bugs and issues
                - Performance improvements
                - Best practices
                - Security concerns"""
            else:
                prompt = f"""{action.capitalize()} the following {LANGUAGES[language]['name']} code:
                ```{language}
                {code}
                ```
                Provide detailed {action} suggestions and improvements."""

            code_response, error, used_model = model_manager.generate_code_sync(model, prompt)
            
            if code_response:
                results.append({
                    'model': OLLAMA_MODELS[model],
                    'content': code_response,
                    'status': 'success',
                    'type': action
                })
            else:
                results.append({
                    'model': OLLAMA_MODELS[model],
                    'content': f"Error: {error}",
                    'status': 'error'
                })
                
        except Exception as e:
            logging.error(f"Exception processing model {model}: {str(e)}", exc_info=True)
            results.append({
                'model': OLLAMA_MODELS[model],
                'content': f"Error: {str(e)}",
                'status': 'error'
            })
    
    return jsonify({'suggestions': results})

@app.route('/check_ollama', methods=['GET'])
def check_ollama():
    """Check Ollama server status and available models with caching"""
    current_time = time.time()
    
    # Return cached results if they're still valid
    if (current_time - MODEL_STATE_CACHE['last_check'] < MODEL_STATE_CACHE['cache_duration'] and 
        MODEL_STATE_CACHE['models']):
        return jsonify(MODEL_STATE_CACHE['models']), 206

    try:
        # Basic connectivity check
        try:
            logging.debug("Starting Ollama version check")
            ping_response = requests.get(
                f"{OLLAMA_API_URL}{OLLAMA_ENDPOINTS['version']}", 
                headers=OLLAMA_HEADERS,
                timeout=5
            )
            server_version = ping_response.json().get('version', 'unknown')
            server_status = "Connected"
            logging.info(f"Ollama server version: {server_version}")
        except requests.exceptions.RequestException as e:
            logging.error(f"Failed to connect to Ollama server: {str(e)}")
            return jsonify({
                "status": "Unavailable",
                "error": f"Cannot connect to AI server: {str(e)}",
                "server_status": "Offline"
            }), 500

        # Check model loading status
        try:
            models_response = requests.get(
                f"{OLLAMA_API_URL}{OLLAMA_ENDPOINTS['models']}", 
                headers=OLLAMA_HEADERS,
                timeout=5
            )
            
            if models_response.status_code == 200:
                models_data = models_response.json().get('models', [])
                available_models = []
                loading_models = MODEL_STATE_CACHE['loading_queue']
                model_details = {}
                configured_models = list(MODEL_CONFIGS['primary_models'].keys())
                
                # Process available models
                for model in models_data:
                    model_name = model.get('name', '')
                    if model_name in configured_models:
                        available_models.append(model_name)
                        model_details[model_name] = parse_model_details(model)
                
                # Update loading queue
                current_loading = []
                for model in loading_models:
                    if model not in available_models:
                        current_loading.append(model)
                MODEL_STATE_CACHE['loading_queue'] = current_loading
                
                # Identify truly missing models
                missing_models = [m for m in configured_models 
                               if m not in available_models + current_loading]
                
                # Try to load missing models if under max_concurrent_loads
                if len(current_loading) < OLLAMA_POLLING_CONFIG["max_concurrent_loads"]:
                    models_to_load = missing_models[:OLLAMA_POLLING_CONFIG["max_concurrent_loads"] - len(current_loading)]
                    for model in models_to_load:
                        try:
                            # Trigger model load
                            load_response = requests.post(
                                f"{OLLAMA_API_URL}/api/pull",
                                json={"name": model},
                                headers=OLLAMA_HEADERS
                            )
                            if load_response.status_code == 200:
                                MODEL_STATE_CACHE['loading_queue'].append(model)
                                model_details[model] = {
                                    'state': OLLAMA_MODEL_STATES["LOADING"],
                                    'size': 'unknown',
                                    'modified': 'loading'
                                }
                        except Exception as e:
                            logging.error(f"Failed to initiate loading for model {model}: {str(e)}")
                
                status_data = {
                    "status": "All Models Available" if not missing_models else "Partially Available",
                    "server_status": server_status,
                    "server_version": server_version,
                    "available_models": available_models,
                    "loading_models": MODEL_STATE_CACHE['loading_queue'],
                    "missing_models": [m for m in missing_models if m not in MODEL_STATE_CACHE['loading_queue']],
                    "total_models": len(configured_models),
                    "available_count": len(available_models),
                    "model_details": model_details,
                    "api_url": OLLAMA_API_URL,
                    "polling_config": OLLAMA_POLLING_CONFIG,
                    "next_refresh": current_time + MODEL_STATE_CACHE['cache_duration']
                }

                # Update cache
                MODEL_STATE_CACHE['last_check'] = current_time
                MODEL_STATE_CACHE['models'] = status_data

                logging.info(f"Models check complete - Available: {len(available_models)}, Loading: {len(MODEL_STATE_CACHE['loading_queue'])}, Missing: {len(missing_models)}")
                
                status_code = 200 if not missing_models and not MODEL_STATE_CACHE['loading_queue'] else 206
                return jsonify(status_data), status_code

        except requests.exceptions.RequestException as e:
            logging.error(f"Failed to list Ollama models: {str(e)}")
            return jsonify({
                "status": "Partially Available",
                "error": f"Connected but cannot list models: {str(e)}",
                "server_status": server_status,
                "server_version": server_version
            }), 206

    except Exception as e:
        logging.error(f"Unexpected error in check_ollama: {str(e)}", exc_info=True)
        return jsonify({
            "status": "Error",
            "error": str(e),
            "server_status": "Error"
        }), 500

@app.route('/download_code', methods=['GET'])
@login_required
def download_code():
    try:
        file_path = request.args.get('file')
        logging.debug(f"Download request for file: {file_path}")
        
        if not file_path:
            return "No file specified", 400
            
        # Clean and normalize the path using the updated unquote function
        decoded_path = unquote(file_path)  # Changed from url_unquote
        base_path = os.path.abspath(os.getcwd())
        safe_path = os.path.normpath(os.path.join(base_path, decoded_path))
        
        # Ensure the path is within the generated_code directory
        if not safe_path.startswith(os.path.join(base_path, 'generated_code')):
            logging.error(f"Invalid path: {safe_path}")
            return "Invalid file path", 400
            
        if not os.path.exists(safe_path):
            logging.error(f"File not found: {safe_path}")
            # If file doesn't exist but we have the content in the request
            if request.args.get('code'):
                # Create a temporary file with the content
                code_content = request.args.get('code')
                with open(safe_path, 'w', encoding='utf-8') as f:
                    f.write(code_content)
            else:
                return "File not found", 404
            
        logging.debug(f"Sending file: {safe_path}")
        return send_file(
            safe_path,
            as_attachment=True,
            download_name=os.path.basename(safe_path),
            mimetype='text/plain'
        )
    except Exception as e:
        logging.error(f"Error downloading file: {str(e)}")
        return f"Error downloading file: {str(e)}", 500

@app.route('/code_convert', methods=['GET', 'POST'])
@login_required
def code_convert():
    if request.method == 'GET':
        return render_template('code_convert.html',
                             models=OLLAMA_MODELS,
                             languages=LANGUAGES)
    data = request.json
    source_code = data.get('sourceCode', '')
    source_lang = data.get('sourceLanguage', '')
    target_lang = data.get('targetLanguage', '')
    selected_models = data.get('models', [])
    options = data.get('options', {})
    
    if not all([source_code, source_lang, target_lang, selected_models]):
        return jsonify({'error': 'Missing required parameters'}), 400

    results = []
    
    for model in selected_models:
        try:
            prompt = f"""Convert the following {LANGUAGES[source_lang]['name']} code to {LANGUAGES[target_lang]['name']}.
            
Original code:
```{source_lang}
{source_code}
```

Requirements:
- Maintain functionality
- Follow {LANGUAGES[target_lang]['name']} best practices
{f'- Preserve comments and documentation' if options.get('maintainComments') else ''}
{f'- Optimize the code for performance' if options.get('optimizeCode') else ''}
{f'- Add explanations for the conversion' if options.get('addExplanations') else ''}

Converted code:"""

            code_response, error, used_model = model_manager.generate_code_sync(model, prompt)
            
            if code_response:
                results.append({
                    'model': OLLAMA_MODELS[model],
                    'code': code_response,
                    'status': 'success',
                    'explanation': None  # You could add explanation handling here
                })
            else:
                results.append({
                    'model': OLLAMA_MODELS[model],
                    'error': error,
                    'status': 'error'
                })
                
        except Exception as e:
            logger.error(f"Exception processing model {model}: {str(e)}", exc_info=True)
            results.append({
                'model': OLLAMA_MODELS[model],
                'error': str(e),
                'status': 'error'
            })
    
    return jsonify({'conversions': results})

@app.route('/quality_system')
@login_required
def quality_system_page():
    """Render the quality system page"""
    return render_template('quality_system.html', 
                         languages=Config.LANGUAGES, 
                         models=Config.OLLAMA_MODELS)

# Add error handlers
@app.errorhandler(Exception)
def handle_exception(e):
    """Handle all exceptions"""
    if isinstance(e, HTTPException):
        return jsonify({
            "error": str(e),
            "status": e.code
        }), e.code
    
    # Log the error
    app.logger.error(f"Unhandled Exception: {str(e)}", exc_info=True)
    
    # Return a generic error response
    return jsonify({
        "error": "An internal server error occurred",
        "status": 500
    }), 500

@app.before_request
def before_request():
    """Ensure required directories exist"""
    try:
        os.makedirs('generated_code', exist_ok=True)
    except Exception as e:
        app.logger.error(f"Failed to create required directories: {str(e)}")
        raise

@app.route('/code_analysis')
@login_required
def code_analysis():
    return redirect(url_for('quality_system_page'))

@app.route('/generate_code_page')
@login_required
def generate_code_page():
    """Render the code generation page"""
    return render_template('generate_code.html',
                         models=OLLAMA_MODELS,
                         languages=LANGUAGES)

@app.route('/analyze_quality', methods=['POST'])
@login_required
def analyze_quality():
    """Handle code quality analysis requests"""
    try:
        data = request.json
        code = data.get('code', '')
        language = data.get('language', '')
        selected_models = data.get('models', ['mistral-small', 'mistral'])

        if not code or not language:
            return jsonify({'error': 'Missing code or language'}), 400

        # Step 1: Static Analysis
        analysis_results = quality_system.analyze_code(
            code=code,
            language=language,
            options={
                'checkStyle': True,
                'checkSecurity': True,
                'checkPerformance': True,
                'checkBestPractices': True
            }
        )

        # Step 2: AI Model Analysis
        language_name = LANGUAGES[language]['name']
        ai_responses = []

        for model in selected_models:
            try:
                # Create specialized prompts based on model capabilities
                prompt = f"""Analyze this {language_name} code with focus on security, performance, and best practices:

Code to analyze:
```{language}
{code}
```

Please provide analysis in the following format:
1. Security Analysis:
   - Vulnerabilities found
   - Security risks
   - Recommended fixes

2. Performance Analysis:
   - Performance bottlenecks
   - Optimization opportunities
   - Resource usage concerns

3. Code Quality:
   - Code structure issues
   - Maintainability concerns
   - Best practices violations

4. Recommendations:
   - Prioritized list of improvements
   - Specific code changes needed
   - Security hardening steps
"""
                
                response, error, used_model = model_manager.generate_code_sync(model, prompt)
                if response:
                    ai_responses.append({
                        'model': OLLAMA_MODELS[model],
                        'feedback': response,
                        'model_used': used_model,
                        'type': 'detailed' if 'small' in model or '33b' in model else 'quick',
                        'categories': {
                            'security': extract_security_findings(response),
                            'performance': extract_performance_findings(response),
                            'quality': extract_quality_findings(response)
                        }
                    })
            except Exception as e:
                logging.error(f"Error getting AI feedback from {model}: {str(e)}")

        # Step 3: Combine Results
        analysis_results['ai_feedback'] = ai_responses
        analysis_results['summary'] = generate_analysis_summary(analysis_results)
        
        return jsonify(analysis_results)

    except Exception as e:
        logging.error(f"Error in analyze_quality: {str(e)}")
        return jsonify({
            'error': 'Analysis failed',
            'details': str(e)
        }), 500

def extract_security_findings(response: str) -> dict:
    """Extract security-related findings from AI response"""
    return {
        'vulnerabilities': extract_section(response, 'Security Analysis'),
        'risk_level': determine_risk_level(response),
        'critical_issues': extract_critical_issues(response)
    }

def extract_performance_findings(response: str) -> dict:
    """Extract performance-related findings from AI response"""
    return {
        'bottlenecks': extract_section(response, 'Performance Analysis'),
        'optimization_suggestions': extract_optimization_suggestions(response)
    }

def extract_quality_findings(response: str) -> dict:
    """Extract code quality findings from AI response"""
    return {
        'issues': extract_section(response, 'Code Quality'),
        'best_practices': extract_best_practices(response)
    }

if __name__ == '__main__':
    try:
        # Configure logging with both stdout and file handlers
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(),  # Changed from sys.stdout to default stream
                logging.FileHandler('app.log')
            ]
        )
        
        # Ensure required directories exist
        os.makedirs('generated_code', exist_ok=True)
        
        # Start the app
        app.run(debug=True, port=5000)
    except Exception as e:
        logging.critical(f"Failed to start application: {str(e)}", exc_info=True)
        sys.exit(1)