from typing import Tuple, Optional, Dict, Any
import requests
from tenacity import retry, stop_after_attempt, wait_exponential
from ratelimit import limits, sleep_and_retry
import logging

logger = logging.getLogger('code_generator')

class APIManager:
    def __init__(self, config: Dict[str, Any]):
        self.primary_api = config['primary']
        self.fallback_api = config['fallback']
        self.error_count = 0
        self.last_error_time = 0
        self.fallback_mode = False
    
    @retry(stop=stop_after_attempt(2), 
           wait=wait_exponential(multiplier=1, min=4, max=10))
    def _retry_api_call(self, url: str, data: Dict[str, Any], 
                        timeout: int) -> requests.Response:
        response = requests.post(url, json=data, timeout=timeout/1000)  # Convert to seconds
        if response.status_code != 200:
            logger.error(f"API call failed with status {response.status_code}")
            raise Exception(f"API call failed with status {response.status_code}")
        return response

    def generate_code(self, model: str, prompt: str, temperature: float = 0.7) -> Tuple[Optional[str], Optional[str]]:
        try:
            if not 0 <= temperature <= 1:
                return None, "Temperature must be between 0 and 1"
            
            api_config = self.fallback_api if self.should_use_fallback() else self.primary_api
            
            # Use configuration defaults
            defaults = api_config['defaults']
            
            payload = {
                "model": model,
                "prompt": prompt,
                "stream": defaults['stream'],
                "temperature": temperature,
                "top_p": defaults['top_p'],
                "top_k": defaults['top_k'],
                "num_ctx": defaults['num_ctx'],
                "num_predict": defaults['num_predict']
            }
            
            response = self._retry_api_call(
                f"{api_config['url']}/api/generate",
                payload,
                timeout=api_config['timeout']
            )
            
            return response.json().get('response', ''), None
                
        except Exception as e:
            logger.error(f"Error generating code: {str(e)}")
            self.handle_api_error()
            return None, "An error occurred while generating code"
    
    def should_use_fallback(self) -> bool:
        if self.error_count >= 3 and (time.time() - self.last_error_time) < 300:
            self.fallback_mode = True
        else:
            self.fallback_mode = False
        return self.fallback_mode
    
    def handle_api_error(self):
        self.error_count += 1
        self.last_error_time = time.time()
