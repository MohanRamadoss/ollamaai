from flask import Flask, request, jsonify, render_template
from datetime import datetime
import os
from werkzeug.urls import url_unquote
from config import Config
from api_manager import APIManager
from logger import setup_logger

app = Flask(__name__)
logger = setup_logger()
api_manager = APIManager(Config.API_CONFIGS)

def validate_request_data(data: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
    if not data.get('models') or not data.get('language'):
        return False, "Missing required parameters"
    if data.get('language') not in Config.LANGUAGES:
        return False, "Invalid language specified"
    if not all(model in Config.OLLAMA_MODELS for model in data.get('models', [])):
        return False, "Invalid model specified"
    return True, None

@app.route('/')
def index():
    return render_template('index.html', 
                         models=Config.OLLAMA_MODELS, 
                         languages=Config.LANGUAGES)

@app.route('/generate', methods=['POST'])
def generate_code():
    try:
        data = request.json
        is_valid, error_message = validate_request_data(data)
        if not is_valid:
            return jsonify({'error': error_message}), 400

        selected_models = data.get('models', [])
        language = data.get('language', '')
        custom_prompt = data.get('customPrompt', '')
        temperature = float(data.get('temperature', 0.7))
        complexity = data.get('complexity', 'basic')
        
        results = {}
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        for model in selected_models:
            optimized_prompt = optimize_prompt(
                custom_prompt, 
                Config.LANGUAGES[language]['name'], 
                complexity
            )
            
            code, error = api_manager.generate_code(
                model, 
                optimized_prompt, 
                temperature
            )
            
            if code:
                filename = f"generated_{language}_{model}_{timestamp}.{Config.LANGUAGES[language]['extension']}"
                filepath = os.path.join('generated_code', filename)
                
                os.makedirs('generated_code', exist_ok=True)
                with open(filepath, 'w') as f:
                    f.write(code)
                
                results[model] = {
                    'code': code,
                    'filename': filename,
                    'status': 'success'
                }
            else:
                results[model] = {
                    'error': "Code generation failed",
                    'status': 'error'
                }
                
    except Exception as e:
        logger.error(f"Error in generate_code endpoint: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500
    
    return jsonify(results)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT', 5000)), 
            debug=os.getenv('FLASK_DEBUG', 'False').lower() == 'true')
