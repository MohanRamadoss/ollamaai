#!/bin/bash

# Navigate to the project directory
cd "$(dirname "$0")"

# Create a virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi

# Activate the virtual environment
source venv/bin/activate

# Install required dependencies
pip install -r requirements.txt

# Set environment variables
export FLASK_APP=web_codegenerator:app
export FLASK_ENV=development
export OLLAMA_API_URL="http://209.137.198.205:11434"  # Replace with your Ollama IP

# Print the FLASK_APP and OLLAMA_API_URL environment variables for debugging
echo "FLASK_APP is set to: $FLASK_APP"
echo "OLLAMA_API_URL is set to: $OLLAMA_API_URL"

# Run the Flask application
flask run
