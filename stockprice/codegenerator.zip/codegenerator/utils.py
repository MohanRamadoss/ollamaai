import os
import pathlib
from typing import Optional

def sanitize_path(path: str) -> str:
    """Sanitize and normalize file path for both Windows and Unix systems."""
    # Normalize slashes for cross-platform compatibility
    normalized_path = os.path.normpath(path.replace('\\', '/'))
    # Convert to absolute path
    abs_path = os.path.abspath(normalized_path)
    return abs_path

def is_safe_path(base_path: str, path: str) -> bool:
    """Check if the path is safe (doesn't try to escape base directory)."""
    base_abs = os.path.abspath(base_path)
    path_abs = os.path.abspath(path)
    return os.path.commonpath([base_abs]) == os.path.commonpath([base_abs, path_abs])

def ensure_directory_exists(directory: str) -> Optional[str]:
    """
    Ensure directory exists and is writable.
    Returns None if successful, error message if failed.
    """
    try:
        pathlib.Path(directory).mkdir(parents=True, exist_ok=True)
        # Test if directory is writable
        test_file = os.path.join(directory, '.write_test')
        try:
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
            return None
        except (IOError, PermissionError) as e:
            return f"Directory not writable: {str(e)}"
    except Exception as e:
        return f"Error creating directory: {str(e)}"
