import ast
import radon.complexity as radon_cc
import radon.metrics as radon_metrics
import radon.raw as radon_raw
import bandit
from bandit.core import manager as bandit_manager
from typing import Dict, Any, List, Optional, Tuple
import logging
from collections import defaultdict
import re
from flask import Flask, request, jsonify
from flask_login import login_required
import asyncio

app = Flask(__name__)

class QualitySystem:
    def __init__(self):
        self.metrics_config = {
            'complexity_thresholds': {
                'low': 5,
                'moderate': 10,
                'high': 20,
                'very_high': 30
            },
            'maintainability_thresholds': {
                'excellent': 85,
                'good': 65,
                'fair': 40,
                'poor': 0
            }
        }

        self.security_patterns = {
            'sql_injection': r'.*execute\s*\(.*\%.*\)',
            'shell_injection': r'.*os\.system\(.*\)',
            'hardcoded_secrets': r'(?i)(?:password|secret|api_key)\s*=\s*["\'][^"\']+["\']',
            'eval_usage': r'eval\s*\(',
            'unsafe_yaml': r'yaml\.load\(',
            'pickle_usage': r'pickle\.loads?\('
        }

        # New AI model configuration
        self.MODEL_CONFIG = {
            'analysis': {
                'primary': {
                    'name': 'mistral:latest',
                    'temperature': 0.3,
                    'context_length': 4096
                },
                'fallback': {
                    'name': 'codestral',
                    'temperature': 0.3,
                    'context_length': 2048
                }
            },
            'security': {
                'primary': {
                    'name': 'mistral:latest',
                    'temperature': 0.2,
                    'context_length': 4096
                },
                'fallback': {
                    'name': 'granite-code:8b',
                    'temperature': 0.2,
                    'context_length': 2048
                }
            },
            'recommendation': {
                'name': 'deepseek-coder:33b',
                'temperature': 0.4,
                'context_length': 4096
            },
            'commands': {
                'name': 'granite-code:8b',
                'temperature': 0.2,
                'context_length': 2048
            }
        }

    def analyze_code(self, code: str, language: str) -> Dict[str, Any]:
        """Complete code analysis including quality, security, and performance"""
        try:
            analysis = {
                'quality': self._analyze_quality(code, language),
                'security': self._analyze_security(code, language),
                'performance': self._analyze_performance(code, language),
                'maintainability': self._analyze_maintainability(code),
                'recommendations': []
            }

            # Calculate scores and generate recommendations
            scores = self._calculate_scores(analysis)
            analysis['scores'] = scores
            analysis['recommendations'] = self._generate_recommendations(analysis)
            analysis['overall_score'] = self._calculate_overall_score(scores)

            return {
                'status': 'success',
                'analysis': analysis
            }
        except Exception as e:
            logging.error(f"Analysis failed: {str(e)}")
            return {
                'status': 'error',
                'error': str(e)
            }

    def _analyze_quality(self, code: str, language: str) -> Dict[str, Any]:
        """Analyze code quality metrics"""
        metrics = {}
        
        # Basic metrics using radon
        raw = radon_raw.analyze(code)
        metrics['raw'] = {
            'loc': raw.loc,
            'sloc': raw.sloc,
            'comments': raw.comments,
            'multi': raw.multi,
            'blank': raw.blank,
            'single_comments': raw.single_comments
        }

        # Language-specific analysis
        if language.lower() == 'python':
            try:
                tree = ast.parse(code)
                metrics.update(self._analyze_python_specifics(tree))
            except Exception as e:
                logging.error(f"Python-specific analysis failed: {str(e)}")

        return metrics

    def _analyze_security(self, code: str, language: str) -> Dict[str, Any]:
        """Analyze security vulnerabilities"""
        security_issues = []

        # Use bandit for Python security analysis
        if language.lower() == 'python':
            try:
                b_mgr = bandit_manager.BanditManager()
                b_mgr.discover_files([code])
                b_mgr.run_tests()
                
                for issue in b_mgr.get_issue_list():
                    security_issues.append({
                        'severity': issue.severity,
                        'confidence': issue.confidence,
                        'description': issue.text,
                        'line': issue.line_number,
                        'type': issue.test_id
                    })
            except Exception as e:
                logging.error(f"Bandit security analysis failed: {str(e)}")

        # Pattern-based security checks
        for vuln_type, pattern in self.security_patterns.items():
            matches = re.finditer(pattern, code, re.MULTILINE)
            for match in matches:
                security_issues.append({
                    'severity': 'HIGH',
                    'type': vuln_type,
                    'line': code.count('\n', 0, match.start()) + 1,
                    'description': f'Potential {vuln_type} vulnerability detected'
                })

        return {
            'vulnerabilities': security_issues,
            'risk_level': self._assess_security_risk(security_issues)
        }

    def _analyze_performance(self, code: str, language: str) -> Dict[str, Any]:
        """Analyze code for performance issues"""
        performance_issues = []
        
        if language.lower() == 'python':
            try:
                tree = ast.parse(code)
                visitor = PerformanceVisitor()
                visitor.visit(tree)
                performance_issues.extend(visitor.issues)
            except Exception as e:
                logging.error(f"Performance analysis failed: {str(e)}")

        return {
            'issues': performance_issues,
            'optimizations': self._suggest_optimizations(performance_issues)
        }

    def _analyze_maintainability(self, code: str) -> Dict[str, Any]:
        """Analyze code maintainability"""
        try:
            mi_score = radon_metrics.mi_visit(code, multi=True)
            cc_score = radon_cc.cc_visit(code)
            
            maintainability = {
                'maintainability_index': mi_score,
                'rank': self._get_maintainability_rank(mi_score),
                'complexity_details': [
                    {
                        'name': item.name,
                        'complexity': item.complexity,
                        'rank': self._assess_complexity_rank(item.complexity)
                    } for item in cc_score
                ]
            }
            
            maintainability['suggestions'] = self._get_maintainability_suggestions(maintainability)
            return maintainability
            
        except Exception as e:
            logging.error(f"Maintainability analysis failed: {str(e)}")
            return {'error': str(e)}

    def _calculate_scores(self, analysis: Dict[str, Any]) -> Dict[str, float]:
        """Calculate normalized scores for each aspect"""
        scores = {
            'quality': self._calculate_quality_score(analysis['quality']),
            'security': self._calculate_security_score(analysis['security']),
            'performance': self._calculate_performance_score(analysis['performance']),
            'maintainability': self._calculate_maintainability_score(analysis['maintainability'])
        }
        return scores

    def _generate_recommendations(self, analysis: Dict[str, Any]) -> List[str]:
        """Generate actionable recommendations"""
        recommendations = []
        
        # Quality recommendations
        if analysis['quality'].get('raw', {}).get('comments', 0) / analysis['quality'].get('raw', {}).get('loc', 1) < 0.1:
            recommendations.append("Increase code documentation - current comment ratio is low")

        # Security recommendations
        for vuln in analysis['security'].get('vulnerabilities', []):
            recommendations.append(f"Security ({vuln['severity']}): {vuln['description']} on line {vuln['line']}")

        # Performance recommendations
        for issue in analysis['performance'].get('issues', []):
            recommendations.append(f"Performance: {issue['suggestion']}")

        # Maintainability recommendations
        if analysis['maintainability'].get('maintainability_index', 100) < 65:
            recommendations.append("Code maintainability needs improvement - consider refactoring")

        return recommendations

    def _calculate_overall_score(self, scores: Dict[str, float]) -> float:
        """Calculate weighted overall score"""
        weights = {
            'quality': 0.3,
            'security': 0.3,
            'performance': 0.2,
            'maintainability': 0.2
        }
        return sum(score * weights[aspect] for aspect, score in scores.items())

    # Helper classes and methods
    class PerformanceVisitor(ast.NodeVisitor):
        def __init__(self):
            self.issues = []

        def visit_For(self, node):
            # Check for nested loops
            for_nodes = []
            self._find_nested_for(node, for_nodes)
            if len(for_nodes) > 1:
                self.issues.append({
                    'type': 'nested_loops',
                    'line': node.lineno,
                    'suggestion': 'Consider optimizing nested loops'
                })
            self.generic_visit(node)

        def _find_nested_for(self, node, for_nodes):
            for_nodes.append(node)
            for child in ast.iter_child_nodes(node):
                if isinstance(child, ast.For):
                    self._find_nested_for(child, for_nodes)

    @staticmethod
    def _get_maintainability_rank(mi_score: float) -> str:
        if mi_score >= 85: return 'A (Excellent)'
        elif mi_score >= 65: return 'B (Good)'
        elif mi_score >= 40: return 'C (Fair)'
        return 'D (Poor)'

    @staticmethod
    def _assess_security_risk(issues: List[Dict[str, Any]]) -> str:
        high_severity = sum(1 for i in issues if i['severity'] == 'HIGH')
        if high_severity > 0: return 'HIGH'
        if issues: return 'MODERATE'
        return 'LOW'

    def get_ai_suggestions(self, code: str, language: str, analysis: Dict[str, Any]) -> List[str]:
        """Get AI-powered suggestions for code improvement"""
        suggestions = []
        
        # Add suggestions based on analysis results
        if analysis['scores']['maintainability'] < 0.7:
            suggestions.append("Consider refactoring to improve maintainability")
        
        if analysis['security']['vulnerabilities']:
            suggestions.append("Fix security vulnerabilities before deployment")
        
        if analysis['performance']['issues']:
            suggestions.append("Optimize identified performance bottlenecks")
            
        return suggestions

    async def _call_ollama_api(self, prompt: str, config: Dict[str, Any]) -> str:
        """Make async call to Ollama API"""
        try:
            payload = {
                "model": config['name'],
                "prompt": prompt,
                "temperature": config['temperature'],
                "stream": False
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(f"{OLLAMA_API_URL}/api/generate", json=payload) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get('response', '')
                    else:
                        raise Exception(f"API call failed with status {response.status}")
        except Exception as e:
            logging.error(f"API call failed: {str(e)}")
            raise

    async def get_model_response(self, prompt: str, task_type: str) -> str:
        """Get response from primary model with fallback"""
        try:
            config = self.MODEL_CONFIG[task_type]['primary']
            return await self._call_ollama_api(prompt, config)
        except Exception as e:
            logging.warning(f"Primary model failed, using fallback: {str(e)}")
            fallback_config = self.MODEL_CONFIG[task_type]['fallback']
            return await self._call_ollama_api(prompt, fallback_config)

    def _create_suggestion_prompt(self, code: str, language: str, analysis: Dict[str, Any]) -> str:
        """Create detailed prompt for AI suggestions"""
        prompt = f"""Analyze this {language} code and provide specific improvements:

Code:
```
{code}
```

Analysis:
{analysis}

Suggestions:"""
        return prompt

    async def get_ai_suggestions(self, code: str, language: str, analysis: Dict[str, Any]) -> List[str]:
        """Get AI-powered suggestions for code improvement"""
        prompt = self._create_suggestion_prompt(code, language, analysis)
        suggestions = await self.get_model_response(prompt, 'recommendation')
        return suggestions.split('\n')

@app.route('/analyze_code', methods=['POST'])
@login_required
def analyze_code():
    """Comprehensive code analysis endpoint"""
    try:
        data = request.get_json()
        code = data.get('code')
        language = data.get('language', 'python')
        analysis_type = data.get('type', 'full')  # full, security, quality, or performance
        
        if not code:
            return jsonify({'error': 'No code provided'}), 400
            
        # Initialize results dictionary
        results = {
            'status': 'success',
            'analysis': {}
        }
        
        # Get analysis based on requested type
        if analysis_type in ['full', 'quality']:
            quality_metrics = analyze_quality(code, language)
            results['analysis']['quality'] = quality_metrics
            
        if analysis_type in ['full', 'security']:
            security_scan = analyze_security(code, language)
            results['analysis']['security'] = security_scan
            
        if analysis_type in ['full', 'performance']:
            performance_metrics = analyze_performance(code, language)
            results['analysis']['performance'] = performance_metrics
        
        # Add AI suggestions if issues found
        if analysis_type == 'full':
            has_issues = (
                results['analysis'].get('quality', {}).get('score', 1) < 0.7 or
                results['analysis'].get('security', {}).get('vulnerabilities') or
                results['analysis'].get('performance', {}).get('issues')
            )
            
            if has_issues:
                improvement_suggestions = get_ai_suggestions(
                    code, language, results['analysis']
                )
                results['suggestions'] = improvement_suggestions
        
        return jsonify(results)
        
    except Exception as e:
        logger.error(f"Error in comprehensive code analysis: {str(e)}")
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500

def analyze_quality(code: str, language: str) -> Dict[str, Any]:
    """Analyze code quality metrics"""
    try:
        metrics = {}
        
        # Get raw metrics
        raw = radon_raw.analyze(code)
        metrics['raw_metrics'] = {
            'loc': raw.loc,
            'lloc': raw.lloc,
            'sloc': raw.sloc,
            'comments': raw.comments,
            'blank': raw.blank
        }

        # Python-specific analysis
        if language.lower() == 'python':
            # Add complexity metrics
            cc_results = list(radon_cc.cc_visit(code))
            functions_data = []
            total_complexity = 0
            
            for item in cc_results:
                complexity = item.complexity
                total_complexity += complexity
                
                functions_data.append({
                    'name': item.name,
                    'complexity': complexity,
                    'risk': _assess_risk(complexity)
                })
            
            avg_complexity = total_complexity / len(cc_results) if cc_results else 0
            metrics['complexity'] = {
                'functions': functions_data,
                'average_complexity': round(avg_complexity, 2),
                'total_complexity': total_complexity
            }
            
            # Add maintainability index
            mi_score = radon_metrics.mi_visit(code, multi=True)
            metrics['maintainability'] = {
                'score': round(mi_score, 2),
                'rank': _get_maintainability_rank(mi_score)
            }
        
        return metrics
        
    except Exception as e:
        logger.error(f"Error in quality analysis: {str(e)}")
        return {'error': str(e)}
