from typing import Dict, Any
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    OLLAMA_API_URL = os.getenv("OLLAMA_API_URL", "http://209.137.198.193:11434")
    
    OLLAMA_MODELS = {
        "granite28b": "Granite 28B",
        "codellama": "CodeLlama",
        "codellama:13b": "CodeLlama 13B",
        "codegemma": "CodeGemma",
        "codestral": "Codestral",
        "codeqwen": "CodeQwen",
        "qwen2.5-coder:14b": "Qwen 2.5 Coder 14B",
        "granite-code:8b": "Granite Code 8B",
        "deepseek-coder:33b": "DeepSeek Coder 33B"
    }
    
    LANGUAGES = {
        "ansible": {"name": "Ansible", "extension": "yml", "icon": "file-earmark-text"},
        "python": {"name": "Python", "extension": "py", "icon": "filetype-py"},
        "javascript": {"name": "JavaScript", "extension": "js", "icon": "filetype-js"},
        "java": {"name": "Java", "extension": "java", "icon": "filetype-java"},
        "cpp": {"name": "C++", "extension": "cpp", "icon": "file-earmark-code"},
        "go": {"name": "Go", "extension": "go", "icon": "file-earmark-code"},
        "terraform": {"name": "Terraform", "extension": "tf", "icon": "file-earmark-code"},
        "ruby": {"name": "Ruby", "extension": "rb", "icon": "file-earmark-code"},
        "php": {"name": "PHP", "extension": "php", "icon": "file-earmark-code"},
        "csharp": {"name": "C#", "extension": "cs", "icon": "file-earmark-code"},
        "typescript": {"name": "TypeScript", "extension": "ts", "icon": "file-earmark-code"},
        "shell": {"name": "Shell (Bash)", "extension": "sh", "icon": "file-earmark-code"},
        "powershell": {"name": "PowerShell", "extension": "ps1", "icon": "file-earmark-code"}
    }
    
    API_CONFIGS = {
        'primary': {
            'url': OLLAMA_API_URL,
            'timeout': 60000,  # 60 seconds
            'retry': {
                'attempts': 2,
                'delay': 1000,
                'backoff': 1.5
            },
            'defaults': {
                'num_ctx': 2048,
                'stream': False,
                'temperature': 0.7,
                'top_p': 0.8,
                'top_k': 30,
                'num_predict': 2000  # max tokens for longer responses
            }
        },
        'fallback': {
            'url': os.getenv("FALLBACK_API_URL", OLLAMA_API_URL),
            'timeout': 60000,
            'retry': {
                'attempts': 2,
                'delay': 1000,
                'backoff': 1.5
            },
            'defaults': {
                'num_ctx': 2048,
                'stream': False,
                'temperature': 0.7,
                'top_p': 0.8,
                'top_k': 30,
                'num_predict': 2000
            }
        }
    }
    
    OLLAMA_ENDPOINTS: Dict[str, str] = {
        "generate": "/api/generate",
        "ping": "/",              # Changed for basic connectivity test
        "models": "/api/tags",    # Correct endpoint for listing models
        "health": "/api/health"   # Added health check endpoint
    }
