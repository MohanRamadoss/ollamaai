import os
import logging
from pathlib import Path

def sanitize_path(path: str) -> str:
    """
    Sanitize file paths by removing potential directory traversal attempts
    and normalizing the path.
    """
    try:
        # Convert to absolute path and resolve any symlinks
        base_dir = os.path.abspath(os.getcwd())
        requested_path = os.path.abspath(os.path.join(base_dir, path.lstrip('/')))
        
        # Ensure the path is within the base directory
        if not requested_path.startswith(base_dir):
            return os.path.join(base_dir, 'generated_code')
            
        return requested_path
    except Exception as e:
        logging.error(f"Error sanitizing path: {str(e)}")
        return os.path.join(os.getcwd(), 'generated_code')

def ensure_directory_exists(directory: str) -> bool:
    """
    Ensure a directory exists, create if it doesn't.
    Returns True if successful, False otherwise.
    """
    try:
        os.makedirs(directory, exist_ok=True)
        return True
    except Exception as e:
        logging.error(f"Failed to create directory {directory}: {str(e)}")
        return False

# Re-export CodeAnalyzer
from .code_analyzer import CodeAnalyzer
