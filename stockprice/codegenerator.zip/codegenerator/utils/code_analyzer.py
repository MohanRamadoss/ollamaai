import ast
import radon.complexity as radon_cc
import radon.metrics as radon_metrics
import radon.raw as radon_raw
from typing import Dict, Any
import logging

class CodeAnalyzer:
    @staticmethod
    def analyze_complexity(code: str, language: str) -> Dict[str, Any]:
        """Analyze code complexity using multiple metrics"""
        try:
            metrics = {}
            
            # Get raw metrics first
            try:
                raw = radon_raw.analyze(code)
                metrics['raw_metrics'] = {
                    'loc': raw.loc,
                    'lloc': raw.lloc,
                    'sloc': raw.sloc,
                    'comments': raw.comments,
                    'blank': raw.blank
                }
            except Exception as e:
                logging.error(f"Error in raw metrics: {str(e)}")
                metrics['raw_metrics'] = {
                    'loc': len(code.splitlines()),
                    'lloc': 0,
                    'sloc': 0,
                    'comments': 0,
                    'blank': 0
                }

            # Python-specific analysis
            if language.lower() == 'python':
                try:
                    # Get cyclomatic complexity
                    cc_results = list(radon_cc.cc_visit(code))
                    
                    # Function-level metrics
                    functions_data = []
                    total_complexity = 0
                    
                    for item in cc_results:
                        complexity = item.complexity
                        total_complexity += complexity
                        
                        functions_data.append({
                            'name': item.name,
                            'complexity': complexity,
                            'line_number': item.lineno,
                            'type': item.type,
                            'risk': CodeAnalyzer._assess_risk(complexity)
                        })
                    
                    avg_complexity = total_complexity / len(cc_results) if cc_results else 0
                    
                    metrics['complexity'] = {
                        'functions': functions_data,
                        'total_complexity': total_complexity,
                        'average_complexity': round(avg_complexity, 2),
                        'number_of_functions': len(cc_results)
                    }
                    
                    # Maintainability Index
                    try:
                        mi_score = radon_metrics.mi_visit(code, multi=True)
                        metrics['maintainability'] = {
                            'mi_score': round(mi_score, 2),
                            'rank': CodeAnalyzer._get_maintainability_rank(mi_score)
                        }
                    except Exception as e:
                        logging.error(f"Error calculating maintainability: {str(e)}")
                        metrics['maintainability'] = {
                            'mi_score': 0,
                            'rank': 'Unknown'
                        }
                        
                except Exception as e:
                    logging.error(f"Error in complexity analysis: {str(e)}")
                    metrics['complexity'] = {
                        'error': str(e)
                    }
            
            return {
                'status': 'success',
                'metrics': metrics,
                'summary': CodeAnalyzer._generate_summary(metrics)
            }
            
        except Exception as e:
            logging.error(f"Error in analyze_complexity: {str(e)}")
            return {
                'status': 'error',
                'error': str(e)
            }

    @staticmethod
    def _assess_risk(complexity: int) -> str:
        if complexity <= 5:
            return 'low'
        elif complexity <= 10:
            return 'moderate'
        elif complexity <= 20:
            return 'high'
        return 'very high'

    @staticmethod
    def _get_maintainability_rank(mi_score: float) -> str:
        if mi_score >= 80:
            return 'Excellent'
        elif mi_score >= 60:
            return 'Good'
        elif mi_score >= 40:
            return 'Fair'
        return 'Poor'

    @staticmethod
    def _generate_summary(metrics: Dict[str, Any]) -> str:
        parts = []
        
        if 'complexity' in metrics:
            complexity = metrics['complexity']
            if isinstance(complexity, dict) and 'average_complexity' in complexity:
                parts.append(f"Average Complexity: {complexity['average_complexity']}")
                parts.append(f"Functions Analyzed: {complexity['number_of_functions']}")
        
        if 'maintainability' in metrics:
            maintain = metrics['maintainability']
            if isinstance(maintain, dict):
                parts.append(f"Maintainability: {maintain['rank']} (MI={maintain['mi_score']})")
        
        if 'raw_metrics' in metrics:
            raw = metrics['raw_metrics']
            parts.append(f"Lines of Code: {raw['loc']}")
        
        return " | ".join(parts) if parts else "Basic analysis completed"
