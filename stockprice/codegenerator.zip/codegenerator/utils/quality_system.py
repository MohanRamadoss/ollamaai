import re
import logging
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)

class QualitySystem:
    def __init__(self):
        self.analyzers = {
            'style': self.analyze_style,
            'security': self.analyze_security,
            'performance': self.analyze_performance,
            'best_practices': self.analyze_best_practices
        }

    def analyze_code(self, code: str, language: str, options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Analyze code quality using selected options."""
        if options is None:
            options = {
                'checkStyle': True,
                'checkSecurity': True,
                'checkPerformance': True,
                'checkBestPractices': True
            }

        results = {
            'overallScore': 0,
            'recommendations': [],
            'styleAnalysis': None,
            'securityAnalysis': None,
            'performanceAnalysis': None,
            'bestPracticesAnalysis': None,
            'generalAnalysis': {
                'items': [],
                'recommendations': []
            }
        }
        
        try:
            total_weight = 0
            total_score = 0
            
            # Run enabled analyzers
            if options.get('checkStyle', True):
                results['styleAnalysis'] = self.analyze_style(code, language)
                weight = self.get_check_weight('checkStyle')
                score = self.calculate_check_score(results['styleAnalysis'])
                total_weight += weight
                total_score += score * weight
                
            if options.get('checkSecurity', True):
                results['securityAnalysis'] = self.analyze_security(code, language)
                weight = self.get_check_weight('checkSecurity')
                score = self.calculate_check_score(results['securityAnalysis'])
                total_weight += weight
                total_score += score * weight
                
            if options.get('checkPerformance', True):
                results['performanceAnalysis'] = self.analyze_performance(code, language)
                weight = self.get_check_weight('checkPerformance')
                score = self.calculate_check_score(results['performanceAnalysis'])
                total_weight += weight
                total_score += score * weight
                
            if options.get('checkBestPractices', True):
                results['bestPracticesAnalysis'] = self.analyze_best_practices(code, language)
                weight = self.get_check_weight('checkBestPractices')
                score = self.calculate_check_score(results['bestPracticesAnalysis'])
                total_weight += weight
                total_score += score * weight
            
            # Calculate overall score
            if total_weight > 0:
                results['overallScore'] = round((total_score / total_weight) * 100)
            
            # Collect all recommendations
            for analysis_key in ['styleAnalysis', 'securityAnalysis', 'performanceAnalysis', 'bestPracticesAnalysis']:
                analysis = results.get(analysis_key)
                if analysis and 'recommendations' in analysis:
                    results['recommendations'].extend(analysis['recommendations'])
            
            return results
            
        except Exception as e:
            logger.error(f"Error in analyze_code: {str(e)}")
            return {
                'overallScore': 0,
                'error': str(e),
                'recommendations': [],
                'items': []
            }

    def analyze_style(self, code: str, language: str) -> Dict[str, Any]:
        """Analyze code style."""
        issues = []
        
        # Check line length
        for i, line in enumerate(code.split('\n')):
            if len(line.strip()) > 80:
                issues.append({
                    'severity': 'warning',
                    'title': 'Line too long',
                    'description': f'Line {i+1} exceeds 80 characters',
                    'suggestion': 'Consider breaking the line into multiple lines'
                })
        
        # Check indentation
        indent_pattern = re.compile(r'^\s+')
        for i, line in enumerate(code.split('\n')):
            match = indent_pattern.match(line)
            if match and len(match.group()) % 4 != 0:
                issues.append({
                    'severity': 'warning',
                    'title': 'Inconsistent indentation',
                    'description': f'Line {i+1} has non-standard indentation',
                    'suggestion': 'Use 4 spaces for indentation'
                })
        
        return {
            'items': issues,
            'recommendations': [
                {'priority': 'medium', 'text': 'Maintain consistent indentation'}
            ]
        }

    def analyze_security(self, code: str, language: str) -> Dict[str, Any]:
        """Analyze code security with improved detection"""
        issues = []
        
        # Security patterns to check
        security_patterns = [
            # Credential patterns
            (r'password\s*=\s*[\'"][^\'"]+[\'"]', 'Hardcoded password', 'error'),
            (r'secret\s*=\s*[\'"][^\'"]+[\'"]', 'Hardcoded secret', 'error'),
            (r'api[_-]?key\s*=\s*[\'"][^\'"]+[\'"]', 'Hardcoded API key', 'error'),
            
            # SQL Injection patterns
            (r'execute\s*\(\s*[\'"][^\'"%]*%[^\']*[\'"]\s*%', 'Potential SQL injection', 'error'),
            
            # Command injection patterns
            (r'os\.system\s*\(|subprocess\.call\s*\(|eval\s*\(', 'Potential command injection', 'error'),
            
            # File operation patterns
            (r'open\s*\([^,]+,[^,]*[\'"]w[\'"]\)', 'Unsafe file write', 'warning'),
        ]
        
        for pattern, issue_type, severity in security_patterns:
            matches = re.finditer(pattern, code, re.IGNORECASE)
            for match in matches:
                line_num = code.count('\n', 0, match.start()) + 1
                issues.append({
                    'severity': severity,
                    'type': issue_type,
                    'line': line_num,
                    'description': f'{issue_type} detected on line {line_num}',
                    'suggestion': self.get_security_suggestion(issue_type)
                })
        
        return {
            'items': issues,
            'vulnerabilities': [i for i in issues if i['severity'] == 'error'],
            'warnings': [i for i in issues if i['severity'] == 'warning'],
            'risk_level': self.calculate_risk_level(issues),
            'recommendations': self.generate_security_recommendations(issues)
        }

    def calculate_risk_level(self, issues: List[Dict[str, Any]]) -> str:
        """Calculate overall risk level based on issues found"""
        if not issues:
            return 'low'
            
        error_count = sum(1 for i in issues if i['severity'] == 'error')
        warning_count = sum(1 for i in issues if i['severity'] == 'warning')
        
        if error_count > 2:
            return 'critical'
        elif error_count > 0:
            return 'high'
        elif warning_count > 2:
            return 'medium'
        elif warning_count > 0:
            return 'low'
        return 'info'

    def generate_security_recommendations(self, issues: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate security recommendations based on issues"""
        recommendations = []
        
        # Group issues by type
        issue_types = {}
        for issue in issues:
            issue_type = issue['type']
            if issue_type not in issue_types:
                issue_types[issue_type] = []
            issue_types[issue_type].append(issue)
        
        # Generate recommendations for each type
        for issue_type, type_issues in issue_types.items():
            recommendations.append({
                'priority': 'high' if any(i['severity'] == 'error' for i in type_issues) else 'medium',
                'text': f"Fix {len(type_issues)} {issue_type} issue(s)",
                'details': [i['suggestion'] for i in type_issues if 'suggestion' in i]
            })
        
        return recommendations

    def get_security_suggestion(self, issue_type: str) -> str:
        """Get security suggestion based on issue type"""
        suggestions = {
            'Hardcoded password': 'Use environment variables or a secure credential manager',
            'Hardcoded secret': 'Use environment variables or a secure credential manager',
            'Hardcoded API key': 'Use environment variables or a secure credential manager',
            'Potential SQL injection': 'Use parameterized queries or an ORM',
            'Potential command injection': 'Use subprocess.run with shell=False or validate input',
            'Unsafe file write': 'Validate file paths and use secure file operations'
        }
        return suggestions.get(issue_type, 'Review and fix this security issue')

    def analyze_performance(self, code: str, language: str) -> Dict[str, Any]:
        """Analyze code performance with improved metrics"""
        issues = []
        
        # Performance patterns to check
        patterns = [
            (r'for.*\s+for.*:', 'Nested loop', 'Potential O(n²) complexity'),
            (r'while.*\s+while.*:', 'Nested while loop', 'Potential infinite loop risk'),
            (r'\.append\s*\(.*\)\s*in\s*for', 'List growth in loop', 'Consider list comprehension'),
            (r'{\s*([^}]*,\s*)*[^}]*}', 'Large dictionary literal', 'Memory usage concern')
        ]
        
        for pattern, issue_type, description in patterns:
            matches = re.finditer(pattern, code)
            for match in matches:
                line_num = code.count('\n', 0, match.start()) + 1
                issues.append({
                    'severity': 'warning',
                    'type': issue_type,
                    'line': line_num,
                    'description': description,
                    'suggestion': get_performance_suggestion(issue_type)
                })
        
        return {
            'items': issues,
            'bottlenecks': identify_bottlenecks(issues),
            'optimization_suggestions': generate_optimization_suggestions(issues),
            'complexity_analysis': analyze_complexity(code)
        }

    def analyze_best_practices(self, code: str, language: str) -> Dict[str, Any]:
        """Analyze code against best practices."""
        issues = []
        
        # Check for TODO comments
        todos = re.finditer(r'#\s*TODO:', code)
        for todo in todos:
            issues.append({
                'severity': 'info',
                'title': 'TODO Found',
                'description': f'Found TODO comment at position {todo.start()}',
                'suggestion': 'Implement or remove TODO comments before production'
            })
        
        return {
            'items': issues,
            'recommendations': [
                {'priority': 'low', 'text': 'Review and implement TODO items'}
            ]
        }

    def get_check_weight(self, check: str) -> float:
        """Get weight for different types of checks."""
        weights = {
            'checkSecurity': 0.4,
            'checkPerformance': 0.3,
            'checkStyle': 0.2,
            'checkBestPractices': 0.1
        }
        return weights.get(check, 0.25)

    def calculate_check_score(self, analysis: Dict[str, Any]) -> float:
        """Calculate score for a specific check based on issues."""
        issues = analysis.get('items', [])
        if not issues:
            return 1.0
            
        severity_weights = {
            'error': 1.0,
            'warning': 0.5,
            'info': 0.2
        }
        
        total_weight = sum(severity_weights[issue['severity']] for issue in issues)
        max_penalty = len(issues) * max(severity_weights.values())
        
        if max_penalty == 0:
            return 1.0
            
        return 1.0 - (total_weight / max_penalty)

    def create_mistral_prompt(self, code: str, language: str, is_detailed: bool) -> str:
        """Create a Mistral-specific analysis prompt"""
        base_prompt = f"""As an expert code reviewer, analyze this {language} code for quality:
```
{code}
```
"""
        if is_detailed:
            base_prompt += "Provide a detailed analysis with recommendations for improvement."
        else:
            base_prompt += "Provide a brief summary of the code quality."

        return base_prompt

    def generate_analysis_summary(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a comprehensive analysis summary"""
        try:
            return {
                'overall_score': results.get('overallScore', 0),
                'risk_level': self.calculate_overall_risk_level(results),
                'critical_issues': self.get_critical_issues(results),
                'summary_by_category': {
                    'security': self.summarize_security(results.get('securityAnalysis')),
                    'performance': self.summarize_performance(results.get('performanceAnalysis')),
                    'quality': self.summarize_quality(results)
                },
                'top_recommendations': self.get_top_recommendations(results)
            }
        except Exception as e:
            logger.error(f"Error generating analysis summary: {str(e)}")
            return {
                'overall_score': 0,
                'risk_level': 'unknown',
                'error': str(e)
            }

    def calculate_overall_risk_level(self, results: Dict[str, Any]) -> str:
        """Calculate overall risk level from all analyses"""
        security = results.get('securityAnalysis', {})
        if security.get('vulnerabilities', []):
            return 'high'
        if security.get('warnings', []):
            return 'medium'
        return 'low'

    def get_critical_issues(self, results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Get list of critical issues from all analyses"""
        critical_issues = []
        
        # Check security issues
        security = results.get('securityAnalysis', {})
        for issue in security.get('vulnerabilities', []):
            critical_issues.append({
                'type': 'security',
                'issue': issue
            })
            
        # Check performance issues
        performance = results.get('performanceAnalysis', {})
        for issue in performance.get('items', []):
            if issue.get('severity') == 'error':
                critical_issues.append({
                    'type': 'performance',
                    'issue': issue
                })
        
        return critical_issues

    def get_top_recommendations(self, results: Dict[str, Any]) -> List[str]:
        """Get prioritized list of top recommendations"""
        recommendations = []
        
        # Add high-priority security recommendations
        security = results.get('securityAnalysis', {})
        for rec in security.get('recommendations', []):
            if rec.get('priority') == 'high':
                recommendations.append(rec['text'])
        
        # Add high-priority performance recommendations
        performance = results.get('performanceAnalysis', {})
        for rec in performance.get('recommendations', []):
            if rec.get('priority') == 'high':
                recommendations.append(rec['text'])
        
        return recommendations[:5]  # Return top 5 recommendations
