import React, { Suspense } from 'react';
import { Download, Copy, Check, Code2 } from 'lucide-react';
import CodeMirror from '@uiw/react-codemirror';
import { vscodeDark } from '@uiw/codemirror-theme-vscode';
import { javascript } from '@codemirror/lang-javascript';
import { python } from '@codemirror/lang-python';
import { yaml } from '@codemirror/lang-yaml';
import { json } from '@codemirror/lang-json';
import { FILE_EXTENSIONS } from '../../config/constants';

interface CodeOutputProps {
  code: string;
  language: string;
  isGenerating: boolean;
  progress: number;
  maxTokens: number;
  score?: number | null;
}

const getLanguageExtension = (language: string) => {
  switch (language.toLowerCase()) {
    case 'python':
      return python();
    case 'yaml':
      return yaml();
    case 'json':
      return json();
    case 'javascript':
    case 'typescript':
    default:
      return javascript();
  }
};

export function CodeOutput({ code, language, isGenerating, progress, score }: CodeOutputProps) {
  const [copied, setCopied] = React.useState(false);
  const [editorError, setEditorError] = React.useState<Error | null>(null);

  console.log('CodeOutput props:', { code, language, isGenerating, progress, score }); // Debug log

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `generated.${FILE_EXTENSIONS[language.toLowerCase()] || 'txt'}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const renderEditor = () => {
    try {
      if (!code) {
        console.log('No code to render');
        return null;
      }

      return (
        <Suspense fallback={<div>Loading editor...</div>}>
          <CodeMirror
            value={code}
            height="400px"
            theme={vscodeDark}
            extensions={[getLanguageExtension(language)]}
            editable={false}
            onError={(error) => {
              console.error('Editor error:', error);
              setEditorError(error);
            }}
          />
        </Suspense>
      );
    } catch (error) {
      console.error('Editor render error:', error);
      return (
        <pre className="p-4 bg-gray-100 rounded overflow-auto">
          {code}
        </pre>
      );
    }
  };

  if (isGenerating) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center justify-center space-x-2">
          <div className="animate-spin rounded-full h-4 w-4 border-2 border-indigo-500 border-t-transparent" />
          <span className="text-gray-500">Generating code... {progress}%</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="flex justify-between items-center px-4 py-2 bg-gray-50 border-b">
        <div className="flex items-center space-x-2">
          <Code2 className="w-5 h-5 text-gray-500" />
          <span className="text-sm font-medium text-gray-700">Generated Code</span>
          {score !== null && (
            <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
              Score: {score}
            </span>
          )}
        </div>
        {code && (
          <div className="flex space-x-2">
            <button
              onClick={handleCopy}
              className="p-1 text-gray-500 hover:text-gray-700"
              title="Copy to clipboard"
            >
              {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
            </button>
            <button
              onClick={handleDownload}
              className="p-1 text-gray-500 hover:text-gray-700"
              title="Download code"
            >
              <Download className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>
      <div className="p-4 max-h-[600px] overflow-auto">
        {editorError ? (
          <pre className="p-4 bg-gray-100 rounded overflow-auto">{code}</pre>
        ) : (
          code ? renderEditor() : (
            <div className="text-center p-8 text-gray-500">
              Generated code will appear here
            </div>
          )
        )}
      </div>
    </div>
  );
}