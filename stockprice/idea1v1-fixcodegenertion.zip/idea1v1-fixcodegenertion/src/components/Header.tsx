import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Code2, LogOut } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { Avatar } from './Avatar';

export function Header() {
  const location = useLocation();
  const { user, signOut } = useAuth();

  return (
    <header className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link to="/" className="flex items-center">
              <Code2 className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">VisaCodeCraft</span>
            </Link>
            
            <nav className="ml-8 flex space-x-4">
              <Link 
                to="/generate"
                className={`inline-flex items-center px-3 py-2 text-sm font-medium ${
                  location.pathname === '/generate' 
                    ? 'text-indigo-600 border-b-2 border-indigo-600' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Generate
              </Link>
              <Link 
                to="/convert"
                className={`inline-flex items-center px-3 py-2 text-sm font-medium ${
                  location.pathname === '/convert' 
                    ? 'text-indigo-600 border-b-2 border-indigo-600' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Convert
              </Link>
              <Link 
                to="/analyze"
                className={`inline-flex items-center px-3 py-2 text-sm font-medium ${
                  location.pathname === '/analyze' 
                    ? 'text-indigo-600 border-b-2 border-indigo-600' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Analyze
              </Link>
              <Link 
                to="/cloud"
                className={`inline-flex items-center px-3 py-2 text-sm font-medium ${
                  location.pathname === '/cloud' 
                    ? 'text-indigo-600 border-b-2 border-indigo-600' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Cloud
              </Link>
              <Link 
                to="/cicd"
                className={`inline-flex items-center px-3 py-2 text-sm font-medium ${
                  location.pathname === '/cicd' 
                    ? 'text-indigo-600 border-b-2 border-indigo-600' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                CI/CD
              </Link>
              <Link 
                to="/sql"
                className={`inline-flex items-center px-3 py-2 text-sm font-medium ${
                  location.pathname === '/sql' 
                    ? 'text-indigo-600 border-b-2 border-indigo-600' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                SQL
              </Link>
              <Link 
                to="/agent"
                className={`inline-flex items-center px-3 py-2 text-sm font-medium ${
                  location.pathname === '/agent' 
                    ? 'text-indigo-600 border-b-2 border-indigo-600' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Agent
              </Link>
              <Link 
                to="/prompts"
                className={`inline-flex items-center px-3 py-2 text-sm font-medium ${
                  location.pathname === '/prompts' 
                    ? 'text-indigo-600 border-b-2 border-indigo-600' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Prompts
              </Link>
            </nav>
          </div>

          <div className="flex items-center">
            {user && (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-3">
                  <Avatar name={user.name} size="sm" />
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-gray-900">{user.name}</span>
                    <span className="text-xs text-gray-500">{user.email}</span>
                  </div>
                </div>
                <button
                  onClick={signOut}
                  className="inline-flex items-center px-3 py-2 border border-gray-200 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-gray-900 transition-colors"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}