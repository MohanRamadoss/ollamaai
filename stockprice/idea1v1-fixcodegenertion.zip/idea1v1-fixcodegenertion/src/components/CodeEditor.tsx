import React, { useState } from 'react';
import Editor, { loader } from '@monaco-editor/react';
import { Download, Copy, Check } from 'lucide-react';

// Configure Monaco Editor loader
loader.config({
  paths: {
    vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.43.0/min/vs'
  },
  'vs/nls': {
    availableLanguages: {}
  }
});

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  language: string;
  readOnly?: boolean;
  isGenerating?: boolean;
  progress?: number;
}

export function CodeEditor({ 
  value, 
  onChange, 
  language, 
  readOnly = false,
  isGenerating = false,
  progress = 0 
}: CodeEditorProps) {
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      // Create file with appropriate extension
      const extension = language.toLowerCase();
      const blob = new Blob([value], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `generated-code.${extension}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-2">
      {/* Progress Bar */}
      {isGenerating && (
        <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
          <div 
            className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}

      {/* Status Message */}
      {isGenerating && (
        <div className="text-sm text-gray-600 mb-2">
          {progress < 100 
            ? `Generating code... ${progress}%`
            : 'Code generation complete!'
          }
        </div>
      )}

      {/* Code Editor */}
      <div className="relative">
        <div className="h-[500px] border border-gray-200 rounded-lg overflow-hidden">
          <Editor
            height="100%"
            defaultLanguage={language}
            value={value}
            onChange={(value) => onChange(value || '')}
            theme="vs-dark"
            options={{
              minimap: { enabled: false },
              fontSize: 14,
              readOnly,
              wordWrap: 'on',
              scrollBeyondLastLine: false,
              automaticLayout: true,
            }}
            loading={<div className="p-4 text-gray-500">Loading editor...</div>}
          />
        </div>

        {/* Action Buttons */}
        <div className="absolute top-2 right-2 flex space-x-2">
          <button
            onClick={handleCopy}
            className="p-2 rounded-md bg-gray-800 text-white hover:bg-gray-700 transition-colors"
            title="Copy code"
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
          </button>
          <button
            onClick={handleDownload}
            disabled={!value || downloading}
            className={`p-2 rounded-md bg-gray-800 text-white transition-colors ${
              value && !downloading ? 'hover:bg-gray-700' : 'opacity-50 cursor-not-allowed'
            }`}
            title="Download code"
          >
            <Download size={16} className={downloading ? 'animate-bounce' : ''} />
          </button>
        </div>
      </div>

      {/* Model Progress Indicators */}
      {isGenerating && (
        <div className="mt-4 space-y-2">
          <div className="text-sm font-medium text-gray-700">Model Progress</div>
          <div className="space-y-3">
            {['GPT-4', 'Gemini Pro'].map((model, index) => (
              <div key={model} className="space-y-1">
                <div className="flex justify-between text-xs text-gray-600">
                  <span>{model}</span>
                  <span>{Math.min(progress + (index * 10), 100)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-1.5">
                  <div 
                    className="bg-indigo-600 h-1.5 rounded-full transition-all duration-500"
                    style={{ 
                      width: `${Math.min(progress + (index * 10), 100)}%`,
                      opacity: 0.7 + (index * 0.3)
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}