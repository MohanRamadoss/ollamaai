import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { CICDControl } from '../components/CICD/CICDControl';
import { CICDProgress } from '../components/CICD/CICDProgress';
import { CICDOutput } from '../components/CICD/CICDOutput';
import { ModelMultiSelect } from '../components/CodeGeneration/ModelMultiSelect';
import { ComplexitySelector } from '../components/CodeGeneration/ComplexitySelector';
import { TokenCounter } from '../components/TokenCounter';
import type { Platform, PipelineType } from '../types/cicd';
import type { ComplexityLevel } from '../types/models';

const cicdSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  platform: z.enum(['github', 'gitlab', 'azure-devops', 'jenkins']),
  pipelineType: z.enum(['build', 'test', 'deploy', 'monitor']),
  complexity: z.enum(['basic', 'intermediate', 'advanced']),
  requirements: z.string().min(10, 'Requirements must be at least 10 characters'),
  temperature: z.number().min(0).max(1),
  topP: z.number().min(0).max(1),
  topK: z.number().min(1).max(100),
  maxTokens: z.number().min(1).max(8192),
});

type CICDForm = z.infer<typeof cicdSchema>;

const getPlaceholder = (platform: Platform, pipelineType: PipelineType): string => {
  const placeholders = {
    github: {
      build: 'Example: Create a Node.js build pipeline with npm and testing...',
      test: 'Example: Set up Jest and Cypress testing for React...',
      deploy: 'Example: Deploy to AWS ECS with container builds...',
      monitor: 'Example: Set up monitoring with GitHub Actions...'
    },
    gitlab: {
      build: 'Example: Create a Python build pipeline with poetry...',
      test: 'Example: Configure pytest with coverage reports...',
      deploy: 'Example: Deploy to GitLab k8s cluster...',
      monitor: 'Example: Monitor using GitLab metrics...'
    },
    'azure-devops': {
      build: 'Example: .NET build pipeline with NuGet...',
      test: 'Example: MSTest with code coverage...',
      deploy: 'Example: Deploy to Azure App Service...',
      monitor: 'Example: Application Insights setup...'
    },
    jenkins: {
      build: 'Example: Java Maven build pipeline...',
      test: 'Example: JUnit and Selenium testing...',
      deploy: 'Example: Deploy with Jenkins Pipeline...',
      monitor: 'Example: Monitoring with Prometheus...'
    }
  };
  return placeholders[platform]?.[pipelineType] || 'Describe your pipeline requirements...';
};

export function CICDPage() {
  const [generatedCode, setGeneratedCode] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<CICDForm>({
    resolver: zodResolver(cicdSchema),
    defaultValues: {
      temperature: 0.7,
      topP: 0.9,
      topK: 50,
      maxTokens: 2048,
      complexity: 'intermediate' as ComplexityLevel,
      platform: 'github',
      pipelineType: 'build',
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedModels = watch('modelIds');
  const selectedPlatform = watch('platform') as Platform;
  const selectedPipelineType = watch('pipelineType') as PipelineType;
  const selectedComplexity = watch('complexity');
  const maxTokens = watch('maxTokens');

  const onSubmit = async (data: CICDForm) => {
    setIsGenerating(true);
    setProgress(0);
    
    try {
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      // TODO: Implement actual CICD pipeline generation
      await new Promise(resolve => setTimeout(resolve, 3000));
      setGeneratedCode('# Generated pipeline configuration will appear here');
      setProgress(100);
    } catch (error) {
      console.error('Generation failed:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">CI/CD Pipeline</h1>
          <p className="mt-2 text-sm text-gray-500">
            Generate CI/CD pipeline configurations using AI.
          </p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white rounded-lg shadow-sm p-6 space-y-6">
            <ModelMultiSelect 
              selectedModels={selectedModels} 
              onChange={(models) => setValue('modelIds', models)} 
            />

            <CICDControl
              platform={selectedPlatform}
              pipelineType={selectedPipelineType}
              onPlatformChange={(platform) => setValue('platform', platform)}
              onPipelineTypeChange={(type) => setValue('pipelineType', type)}
            />

            <ComplexitySelector
              value={selectedComplexity}
              onChange={(complexity) => setValue('complexity', complexity as ComplexityLevel)}
            />

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Temperature ({watch('temperature')})
                </label>
                <input
                  type="range"
                  {...register('temperature', { valueAsNumber: true })}
                  min="0"
                  max="1"
                  step="0.1"
                  className="w-full"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Controls creativity in the generation process
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Top P ({watch('topP')})
                </label>
                <input
                  type="range"
                  {...register('topP', { valueAsNumber: true })}
                  min="0"
                  max="1"
                  step="0.1"
                  className="w-full"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Controls diversity in the output
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Top K ({watch('topK')})
                </label>
                <input
                  type="range"
                  {...register('topK', { valueAsNumber: true })}
                  min="1"
                  max="100"
                  className="w-full"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Limits token consideration during generation
                </p>
              </div>
            </div>
          </div>

          {/* Requirements Section */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label className="block text-sm font-medium text-gray-700">Requirements</label>
                <TokenCounter code={watch('requirements') || ''} maxTokens={maxTokens} />
              </div>
              <textarea
                {...register('requirements')}
                rows={6}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder={getPlaceholder(selectedPlatform, selectedPipelineType)}
              />
              {errors.requirements && (
                <p className="text-sm text-red-600">{errors.requirements.message}</p>
              )}
            </div>
          </div>

          {/* Output Section */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <CICDProgress isGenerating={isGenerating} progress={progress} />
            
            <CICDOutput
              code={generatedCode}
              isGenerating={isGenerating}
              platform={selectedPlatform}
              pipelineType={selectedPipelineType}
            />
          </div>

          {/* Generate Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isGenerating}
              className="px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? 'Generating...' : 'Generate Pipeline'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}