import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ModelMultiSelect } from '../components/CodeGeneration/ModelMultiSelect';
import { LanguageSelector } from '../components/LanguageSelector';
import { ActionSelect } from '../components/CodeAnalysis/ActionSelect';
import { AnalysisOutput } from '../components/CodeAnalysis/AnalysisOutput';
import { CodeEditor } from '../components/CodeEditor';
import { TokenCounter } from '../components/TokenCounter';
import { FileAttachment } from '../components/CodeConversion/FileAttachment';
import { analyzeCode } from '../lib/api/analyze';

const analysisSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  language: z.string().min(1, 'Select a programming language'),
  action: z.string().min(1, 'Select an analysis type'),
  temperature: z.number().min(0).max(1),
  topP: z.number().min(0).max(1),
  topK: z.number().min(1).max(100),
  maxTokens: z.number().min(1).max(8192),
});

type AnalysisForm = z.infer<typeof analysisSchema>;

export function CodeAnalysisPage() {
  const [sourceCode, setSourceCode] = useState('');
  const [analysisResults, setAnalysisResults] = useState<any[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<AnalysisForm>({
    resolver: zodResolver(analysisSchema),
    defaultValues: {
      temperature: 0.7,
      topP: 0.9,
      topK: 50,
      maxTokens: 2048,
      language: 'javascript',
      action: 'analyze',
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedModels = watch('modelIds');
  const selectedLanguage = watch('language');
  const selectedAction = watch('action');
  const maxTokens = watch('maxTokens');

  const handleFileSelect = (content: string) => {
    setSourceCode(content);
  };

  const onSubmit = async (data: AnalysisForm) => {
    if (!sourceCode.trim()) {
      return;
    }

    setIsAnalyzing(true);
    setProgress(0);
    
    try {
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      const result = await analyzeCode({
        ...data,
        sourceLanguage: selectedLanguage,
        prompt: sourceCode,
      });

      const parsedResults = parseAnalysisResults(result);
      setAnalysisResults(parsedResults);
      setProgress(100);
    } catch (error) {
      console.error('Analysis failed:', error);
      setAnalysisResults([{
        type: 'error',
        message: 'Analysis failed. Please try again.',
      }]);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const parseAnalysisResults = (rawResults: string) => {
    const lines = rawResults.split('\n');
    return lines
      .filter(line => line.trim())
      .map(line => {
        if (line.toLowerCase().includes('error')) {
          return { type: 'error', message: line };
        }
        if (line.toLowerCase().includes('warning')) {
          return { type: 'warning', message: line };
        }
        if (line.toLowerCase().includes('suggestion')) {
          return { type: 'info', message: line };
        }
        return { type: 'success', message: line };
      });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Code Analysis</h1>
          <p className="mt-2 text-sm text-gray-500">
            Analyze, test, and improve your code using AI.
          </p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white rounded-lg shadow-sm p-6 space-y-6">
            <ModelMultiSelect 
              selectedModels={selectedModels} 
              onChange={(models) => setValue('modelIds', models)} 
            />

            <LanguageSelector 
              value={selectedLanguage}
              onChange={(language) => setValue('language', language)}
            />

            <ActionSelect
              selectedAction={selectedAction}
              onChange={(action) => setValue('action', action)}
            />

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Temperature ({watch('temperature')})
                </label>
                <input
                  type="range"
                  {...register('temperature', { valueAsNumber: true })}
                  min="0"
                  max="1"
                  step="0.1"
                  className="w-full"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Controls creativity in the analysis
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Top P ({watch('topP')})
                </label>
                <input
                  type="range"
                  {...register('topP', { valueAsNumber: true })}
                  min="0"
                  max="1"
                  step="0.1"
                  className="w-full"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Controls diversity in the analysis
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Top K ({watch('topK')})
                </label>
                <input
                  type="range"
                  {...register('topK', { valueAsNumber: true })}
                  min="1"
                  max="100"
                  className="w-full"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Limits token consideration during analysis
                </p>
              </div>
            </div>
          </div>

          {/* File Upload Section */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <FileAttachment onFileSelect={handleFileSelect} />
          </div>

          {/* Code and Analysis Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Source Code Section */}
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-medium text-gray-900">Source Code</h2>
                  <TokenCounter code={sourceCode} maxTokens={maxTokens} />
                </div>
                
                <CodeEditor
                  value={sourceCode}
                  onChange={setSourceCode}
                  language={selectedLanguage}
                />
              </div>
            </div>

            {/* Analysis Results Section */}
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-medium text-gray-900">Analysis Results</h2>
                  <TokenCounter code={analysisResults.map(r => r.message).join('\n')} maxTokens={maxTokens} />
                </div>
                <AnalysisOutput
                  results={analysisResults}
                  isAnalyzing={isAnalyzing}
                  progress={progress}
                />
              </div>
            </div>
          </div>

          {/* Analyze Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isAnalyzing || !sourceCode.trim()}
              className="px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isAnalyzing ? 'Analyzing...' : 'Analyze Code'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}