import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { CloudControl } from '../components/Cloud/CloudControl';
import { CloudProgress } from '../components/Cloud/CloudProgress';
import { CloudOutput } from '../components/Cloud/CloudOutput';
import { ModelMultiSelect } from '../components/CodeGeneration/ModelMultiSelect';
import { ComplexitySelector } from '../components/CodeGeneration/ComplexitySelector';
import { TokenCounter } from '../components/TokenCounter';
import type { CloudProvider, ResourceType } from '../types/cloud';
import type { ComplexityLevel } from '../types/models';
import { getPlaceholder } from '../utils/cloudPlaceholders';

const cloudSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  provider: z.enum(['aws', 'azure', 'gcp']),
  resourceType: z.enum([
    'terraform',
    'cloudformation',
    'azurearm',
    'gcpdeployment',
    'kubernetes',
    'serverless',
    'database',
    'storage',
    'networking'
  ]),
  complexity: z.enum(['basic', 'intermediate', 'advanced']),
  requirements: z.string().min(10, 'Requirements must be at least 10 characters'),
  temperature: z.number().min(0).max(1),
  topP: z.number().min(0).max(1),
  topK: z.number().min(1).max(100),
  maxTokens: z.number().min(1).max(8192),
});

type CloudForm = z.infer<typeof cloudSchema>;

export function CloudPage() {
  const [generatedCode, setGeneratedCode] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<CloudForm>({
    resolver: zodResolver(cloudSchema),
    defaultValues: {
      temperature: 0.7,
      topP: 0.9,
      topK: 50,
      maxTokens: 2048,
      complexity: 'intermediate' as ComplexityLevel,
      provider: 'aws',
      resourceType: 'terraform',
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedModels = watch('modelIds');
  const selectedProvider = watch('provider') as CloudProvider;
  const selectedResourceType = watch('resourceType') as ResourceType;
  const selectedComplexity = watch('complexity');
  const maxTokens = watch('maxTokens');

  const onSubmit = async (data: CloudForm) => {
    setIsGenerating(true);
    setProgress(0);
    
    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      // TODO: Implement actual cloud code generation
      await new Promise(resolve => setTimeout(resolve, 3000));
      setGeneratedCode('# Generated infrastructure code will appear here');
      setProgress(100);
    } catch (error) {
      console.error('Generation failed:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Cloud Infrastructure</h1>
          <p className="mt-2 text-sm text-gray-500">
            Generate cloud infrastructure code using AI.
          </p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white rounded-lg shadow-sm p-6 space-y-6">
            <ModelMultiSelect 
              selectedModels={selectedModels} 
              onChange={(models) => setValue('modelIds', models)} 
            />

            <CloudControl
              provider={selectedProvider}
              resourceType={selectedResourceType}
              onProviderChange={(provider) => setValue('provider', provider)}
              onResourceTypeChange={(type) => setValue('resourceType', type)}
            />

            <ComplexitySelector
              value={selectedComplexity}
              onChange={(complexity) => setValue('complexity', complexity as ComplexityLevel)}
            />

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Temperature ({watch('temperature')})
                </label>
                <input
                  type="range"
                  {...register('temperature', { valueAsNumber: true })}
                  min="0"
                  max="1"
                  step="0.1"
                  className="w-full"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Controls creativity in the generation process
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Top P ({watch('topP')})
                </label>
                <input
                  type="range"
                  {...register('topP', { valueAsNumber: true })}
                  min="0"
                  max="1"
                  step="0.1"
                  className="w-full"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Controls diversity in the output
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Top K ({watch('topK')})
                </label>
                <input
                  type="range"
                  {...register('topK', { valueAsNumber: true })}
                  min="1"
                  max="100"
                  className="w-full"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Limits token consideration during generation
                </p>
              </div>
            </div>
          </div>

          {/* Requirements Section */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label className="block text-sm font-medium text-gray-700">Requirements</label>
                <TokenCounter code={watch('requirements') || ''} maxTokens={maxTokens} />
              </div>
              <textarea
                {...register('requirements')}
                rows={6}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder={getPlaceholder(selectedProvider, selectedResourceType)}
              />
              {errors.requirements && (
                <p className="text-sm text-red-600">{errors.requirements.message}</p>
              )}
            </div>
          </div>

          {/* Output Section */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <CloudProgress isGenerating={isGenerating} progress={progress} />
            
            <CloudOutput
              code={generatedCode}
              isGenerating={isGenerating}
              provider={selectedProvider}
              resourceType={selectedResourceType}
            />
          </div>

          {/* Generate Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isGenerating}
              className="px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? 'Generating...' : 'Generate Infrastructure'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}