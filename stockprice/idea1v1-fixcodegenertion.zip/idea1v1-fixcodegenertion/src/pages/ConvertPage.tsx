import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ModelMultiSelect } from '../components/CodeGeneration/ModelMultiSelect';
import { ComplexitySelector } from '../components/CodeGeneration/ComplexitySelector';
import { ConversionProgress } from '../components/CodeConversion/ConversionProgress';
import { LanguageConverter } from '../components/CodeConversion/LanguageConverter';
import { ConversionParameters } from '../components/CodeConversion/ConversionParameters';
import { FileAttachment } from '../components/CodeConversion/FileAttachment';
import { CodeOutput } from '../components/CodeGeneration/CodeOutput';
import { CodeEditor } from '../components/CodeEditor';
import { TokenCounter } from '../components/TokenCounter';
import type { ComplexityLevel } from '../types/models';
import { convertCode } from '../lib/api/convert';

const convertSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  sourceLanguage: z.string().min(1, 'Select a source language'),
  targetLanguage: z.string().min(1, 'Select a target language'),
  complexity: z.enum(['basic', 'intermediate', 'advanced']),
  temperature: z.number().min(0).max(1),
  topP: z.number().min(0).max(1),
  topK: z.number().min(1).max(100),
  maxTokens: z.number().min(1).max(8192),
});

type ConvertForm = z.infer<typeof convertSchema>;

export function ConvertPage() {
  const [sourceCode, setSourceCode] = useState('');
  const [convertedCode, setConvertedCode] = useState('');
  const [isConverting, setIsConverting] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<ConvertForm>({
    resolver: zodResolver(convertSchema),
    defaultValues: {
      temperature: 0.7,
      topP: 0.9,
      topK: 50,
      maxTokens: 2048,
      complexity: 'intermediate' as ComplexityLevel,
      sourceLanguage: 'javascript',
      targetLanguage: 'python',
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedModels = watch('modelIds');
  const sourceLanguage = watch('sourceLanguage');
  const targetLanguage = watch('targetLanguage');
  const maxTokens = watch('maxTokens');

  const handleFileSelect = (content: string) => {
    setSourceCode(content);
  };

  const onSubmit = async (data: ConvertForm) => {
    if (!sourceCode.trim()) {
      return;
    }

    setIsConverting(true);
    setProgress(0);
    
    try {
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      const result = await convertCode({
        ...data,
        prompt: sourceCode,
      });

      setConvertedCode(result);
      setProgress(100);
    } catch (error) {
      console.error('Conversion failed:', error);
    } finally {
      setIsConverting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Convert Code</h1>
          <p className="mt-2 text-sm text-gray-500">
            Convert code from one programming language to another using AI.
          </p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white rounded-lg shadow-sm p-6 space-y-6">
            <ModelMultiSelect 
              selectedModels={selectedModels} 
              onChange={(models) => setValue('modelIds', models)} 
            />

            <LanguageConverter
              sourceLanguage={sourceLanguage}
              targetLanguage={targetLanguage}
              onSourceChange={(language) => setValue('sourceLanguage', language)}
              onTargetChange={(language) => setValue('targetLanguage', language)}
            />

            <ConversionParameters register={register} watch={watch} />
          </div>

          {/* File Upload Section */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <FileAttachment onFileSelect={handleFileSelect} />
          </div>

          {/* Code Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Source Code Section */}
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-medium text-gray-900">Source Code</h2>
                  <TokenCounter code={sourceCode} maxTokens={maxTokens} />
                </div>
                
                <CodeEditor
                  value={sourceCode}
                  onChange={setSourceCode}
                  language={sourceLanguage}
                />
              </div>
            </div>

            {/* Generated Code Section */}
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <ConversionProgress isConverting={isConverting} progress={progress} />
                
                <CodeOutput
                  code={convertedCode}
                  language={targetLanguage}
                  isGenerating={isConverting}
                  progress={progress}
                  maxTokens={maxTokens}
                />
              </div>
            </div>
          </div>

          {/* Convert Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isConverting || !sourceCode.trim()}
              className="px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isConverting ? 'Converting...' : 'Convert Code'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}