import React, { useState, Suspense } from 'react';
import { ErrorBoundary } from 'react-error-boundary';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ModelMultiSelect } from '../components/CodeGeneration/ModelMultiSelect';
import { LanguageSelector } from '../components/LanguageSelector';
import { ComplexitySelector } from '../components/CodeGeneration/ComplexitySelector';
import { GenerationProgress } from '../components/CodeGeneration/GenerationProgress';
import { CodeOutput } from '../components/CodeGeneration/CodeOutput';
import type { ComplexityLevel } from '../types/models';
import { generateCode } from '../lib/api/generate';
import { scoreCode } from '../lib/utils/codeScoring';
import { SUPPORTED_LANGUAGES } from '../config/languages';

const generateSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  language: z.string().min(1, 'Select a programming language'),
  complexity: z.enum(['basic', 'intermediate', 'advanced']),
  prompt: z.string().min(10, 'Prompt must be at least 10 characters'),
  temperature: z.number().min(0).max(1),
  topP: z.number().min(0).max(1),
  topK: z.number().min(1).max(100),
  maxTokens: z.number().min(1).max(8192),
});

type GenerateForm = z.infer<typeof generateSchema>;

export function GeneratePage() {
  const [generatedCode, setGeneratedCode] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [codeScore, setCodeScore] = useState<number | null>(null);
  
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<GenerateForm>({
    resolver: zodResolver(generateSchema),
    defaultValues: {
      temperature: 0.7,
      topP: 0.9,
      topK: 50,
      maxTokens: 2048,
      complexity: 'intermediate' as ComplexityLevel,
      language: SUPPORTED_LANGUAGES[0].id, // Use first supported language as default
      modelIds: ['gemini-pro'], // Ensure correct model ID
    },
  });

  const selectedModels = watch('modelIds');
  const selectedLanguage = watch('language');
  const selectedComplexity = watch('complexity');
  const maxTokens = watch('maxTokens');

  const onSubmit = async (data: GenerateForm) => {
    setIsGenerating(true);
    setProgress(0);
    setError(null);
    setGeneratedCode('');
    setCodeScore(null);
    
    const progressTimer = setInterval(() => {
      setProgress(prev => Math.min(prev + 5, 90));
    }, 300);

    try {
      console.log('Generating with params:', data); // Debug log

      const result = await generateCode({
        ...data,
        modelIds: [data.modelIds[0]], // Use first model only for now
      });

      console.log('Generation result:', result); // Debug log

      if (!result) {
        throw new Error('No code generated');
      }

      const score = scoreCode(result, data.language);
      setCodeScore(score);
      setGeneratedCode(result);
      setProgress(100);

    } catch (error) {
      console.error('Generation error:', error);
      setError(error instanceof Error ? error.message : 'Failed to generate code');
    } finally {
      clearInterval(progressTimer);
      setIsGenerating(false);
    }
  };

  if (!selectedLanguage || !selectedModels) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p>Loading configuration...</p>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary fallback={<div>Something went wrong. Please try again.</div>}>
      <Suspense fallback={<div>Loading...</div>}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="space-y-8">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Generate Code</h1>
              <p className="mt-2 text-sm text-gray-500">
                Select your preferences and provide a prompt to generate code using AI.
              </p>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
              <ModelMultiSelect 
                selectedModels={selectedModels} 
                onChange={(models) => setValue('modelIds', models)} 
              />

              <LanguageSelector 
                value={selectedLanguage}
                onChange={(language) => setValue('language', language)}
                languages={SUPPORTED_LANGUAGES}
              />

              <ComplexitySelector
                value={selectedComplexity}
                onChange={(complexity) => setValue('complexity', complexity as ComplexityLevel)}
              />

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Temperature ({watch('temperature')})
                  </label>
                  <input
                    type="range"
                    {...register('temperature', { valueAsNumber: true })}
                    min="0"
                    max="1"
                    step="0.1"
                    className="w-full"
                  />
                  <p className="mt-1 text-sm text-gray-500">
                    Higher values make the output more creative but less predictable
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Top P ({watch('topP')})
                  </label>
                  <input
                    type="range"
                    {...register('topP', { valueAsNumber: true })}
                    min="0"
                    max="1"
                    step="0.1"
                    className="w-full"
                  />
                  <p className="mt-1 text-sm text-gray-500">
                    Controls diversity via nucleus sampling
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Top K ({watch('topK')})
                  </label>
                  <input
                    type="range"
                    {...register('topK', { valueAsNumber: true })}
                    min="1"
                    max="100"
                    className="w-full"
                  />
                  <p className="mt-1 text-sm text-gray-500">
                    Limits the number of tokens considered for each step
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Prompt</label>
                <textarea
                  {...register('prompt')}
                  rows={4}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Describe the code you want to generate..."
                />
                {errors.prompt && (
                  <p className="mt-1 text-sm text-red-600">{errors.prompt.message}</p>
                )}
              </div>

              <div>
                <button
                  type="submit"
                  disabled={isGenerating}
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isGenerating ? 'Generating...' : 'Generate Code'}
                </button>
              </div>
            </form>

            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-md">
                <p className="text-sm text-red-600">{error}</p>
              </div>
            )}

            <GenerationProgress isGenerating={isGenerating} progress={progress} />

            <CodeOutput
              code={generatedCode}
              language={selectedLanguage}
              isGenerating={isGenerating}
              progress={progress}
              maxTokens={maxTokens}
              score={codeScore}
            />
          </div>
        </div>
      </Suspense>
    </ErrorBoundary>
  );
}