import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Wand2, Save, Plus, Trash2, Edit2 } from 'lucide-react';
import { TokenCounter } from '../components/TokenCounter';
import { ModelSelector } from '../components/ModelSelector';

const promptSchema = z.object({
  title: z.string().min(3, 'Title must be at least 3 characters'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  template: z.string().min(20, 'Template must be at least 20 characters'),
  category: z.enum(['code', 'conversion', 'documentation', 'testing', 'optimization', 'custom']),
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  variables: z.array(z.object({
    name: z.string().min(1),
    description: z.string(),
    required: z.boolean(),
    defaultValue: z.string().optional(),
  })),
});

type PromptForm = z.infer<typeof promptSchema>;

const SAMPLE_PROMPTS = [
  {
    id: '1',
    title: 'Code Refactoring',
    description: 'Refactor code to improve readability and maintainability',
    template: 'Please refactor the following {language} code to improve its {aspect}:\n\n{code}\n\nFocus on:\n- {focus_points}\n- Maintaining functionality\n- Following best practices',
    category: 'optimization',
    variables: [
      { name: 'language', description: 'Programming language', required: true },
      { name: 'aspect', description: 'Aspect to improve (e.g., performance, readability)', required: true },
      { name: 'code', description: 'Code to refactor', required: true },
      { name: 'focus_points', description: 'Specific areas to focus on', required: false, defaultValue: 'code organization' },
    ],
  },
  {
    id: '2',
    title: 'API Documentation',
    description: 'Generate comprehensive API documentation',
    template: 'Create detailed documentation for the following {language} API endpoint:\n\n{code}\n\nInclude:\n- Endpoint description\n- Request/Response format\n- {additional_sections}',
    category: 'documentation',
    variables: [
      { name: 'language', description: 'Programming language', required: true },
      { name: 'code', description: 'API endpoint code', required: true },
      { name: 'additional_sections', description: 'Additional documentation sections', required: false, defaultValue: 'Authentication, Error handling' },
    ],
  },
];

export function PromptsPage() {
  const [prompts, setPrompts] = useState(SAMPLE_PROMPTS);
  const [editingPrompt, setEditingPrompt] = useState<(typeof SAMPLE_PROMPTS)[0] | null>(null);
  const [previewPrompt, setPreviewPrompt] = useState('');
  const [variables, setVariables] = useState<Record<string, string>>({});

  const { register, handleSubmit, watch, setValue, reset, formState: { errors } } = useForm<PromptForm>({
    resolver: zodResolver(promptSchema),
    defaultValues: {
      category: 'code',
      variables: [],
      modelIds: ['gemini-pro-code'],
    },
  });

  const template = watch('template');
  const selectedModels = watch('modelIds');

  const handleAddVariable = () => {
    setValue('variables', [
      ...(watch('variables') || []),
      { name: '', description: '', required: false },
    ]);
  };

  const handleRemoveVariable = (index: number) => {
    const variables = watch('variables');
    setValue('variables', variables.filter((_, i) => i !== index));
  };

  const handlePreview = () => {
    let preview = template;
    Object.entries(variables).forEach(([key, value]) => {
      preview = preview.replace(new RegExp(`{${key}}`, 'g'), value);
    });
    setPreviewPrompt(preview);
  };

  const onSubmit = (data: PromptForm) => {
    if (editingPrompt) {
      setPrompts(prompts.map(p => p.id === editingPrompt.id ? { ...data, id: editingPrompt.id } : p));
    } else {
      setPrompts([...prompts, { ...data, id: Date.now().toString() }]);
    }
    reset();
    setEditingPrompt(null);
  };

  const handleEdit = (prompt: (typeof SAMPLE_PROMPTS)[0]) => {
    setEditingPrompt(prompt);
    reset(prompt);
  };

  const handleDelete = (id: string) => {
    setPrompts(prompts.filter(p => p.id !== id));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Prompt Templates</h1>
          <p className="mt-2 text-sm text-gray-500">
            Create and manage your AI prompt templates for consistent code generation and conversion.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Prompt Editor */}
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-medium text-gray-900 mb-4">
                {editingPrompt ? 'Edit Prompt Template' : 'Create New Template'}
              </h2>
              
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <ModelSelector 
                  selectedModels={selectedModels} 
                  onChange={(models) => setValue('modelIds', models)} 
                />

                <div>
                  <label className="block text-sm font-medium text-gray-700">Title</label>
                  <input
                    type="text"
                    {...register('title')}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                  />
                  {errors.title && (
                    <p className="mt-1 text-sm text-red-600">{errors.title.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Description</label>
                  <textarea
                    {...register('description')}
                    rows={2}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                  />
                  {errors.description && (
                    <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Category</label>
                  <select
                    {...register('category')}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                  >
                    <option value="code">Code Generation</option>
                    <option value="conversion">Code Conversion</option>
                    <option value="documentation">Documentation</option>
                    <option value="testing">Testing</option>
                    <option value="optimization">Optimization</option>
                    <option value="custom">Custom</option>
                  </select>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-medium text-gray-700">Template</label>
                    <TokenCounter code={template || ''} maxTokens={2048} />
                  </div>
                  <textarea
                    {...register('template')}
                    rows={6}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm font-mono"
                    placeholder="Write your prompt template here. Use {variable} syntax for dynamic values."
                  />
                  {errors.template && (
                    <p className="mt-1 text-sm text-red-600">{errors.template.message}</p>
                  )}
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-medium text-gray-700">Variables</label>
                    <button
                      type="button"
                      onClick={handleAddVariable}
                      className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add Variable
                    </button>
                  </div>
                  
                  <div className="space-y-4">
                    {watch('variables')?.map((_, index) => (
                      <div key={index} className="flex gap-4 items-start">
                        <div className="flex-1">
                          <input
                            {...register(`variables.${index}.name`)}
                            placeholder="Variable name"
                            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                          />
                        </div>
                        <div className="flex-1">
                          <input
                            {...register(`variables.${index}.description`)}
                            placeholder="Description"
                            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <label className="inline-flex items-center">
                            <input
                              type="checkbox"
                              {...register(`variables.${index}.required`)}
                              className="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                            />
                            <span className="ml-2 text-sm text-gray-600">Required</span>
                          </label>
                          <button
                            type="button"
                            onClick={() => handleRemoveVariable(index)}
                            className="p-1 text-gray-400 hover:text-red-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end space-x-4">
                  <button
                    type="button"
                    onClick={() => {
                      reset();
                      setEditingPrompt(null);
                    }}
                    className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Save className="w-4 h-4 inline-block mr-2" />
                    {editingPrompt ? 'Update Template' : 'Save Template'}
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Preview and Saved Prompts */}
          <div className="space-y-6">
            {/* Preview */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Preview</h2>
              
              <div className="space-y-4">
                {watch('variables')?.map((variable, index) => (
                  <div key={index}>
                    <label className="block text-sm font-medium text-gray-700">
                      {variable.name} {variable.required && <span className="text-red-500">*</span>}
                    </label>
                    <input
                      type="text"
                      value={variables[variable.name] || ''}
                      onChange={(e) => setVariables({ ...variables, [variable.name]: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                      placeholder={variable.description}
                    />
                  </div>
                ))}

                <button
                  type="button"
                  onClick={handlePreview}
                  className="w-full flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
                >
                  <Wand2 className="w-4 h-4 mr-2" />
                  Generate Preview
                </button>

                {previewPrompt && (
                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Generated Prompt
                    </label>
                    <div className="bg-gray-50 rounded-md p-4 font-mono text-sm whitespace-pre-wrap">
                      {previewPrompt}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Saved Prompts */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Saved Templates</h2>
              
              <div className="space-y-4">
                {prompts.map((prompt) => (
                  <div key={prompt.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-gray-900">{prompt.title}</h3>
                        <p className="text-sm text-gray-500">{prompt.description}</p>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleEdit(prompt)}
                          className="p-1 text-gray-400 hover:text-indigo-500"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(prompt.id)}
                          className="p-1 text-gray-400 hover:text-red-500"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <div className="mt-2">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                        {prompt.category}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}