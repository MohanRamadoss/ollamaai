interface CodeMetrics {
  complexity: number;
  length: number;
  readability: number;
}

/**
 * Score the generated code based on various metrics
 * @param code The generated code to score
 * @param language The programming language of the code
 * @returns A score between 0 and 100
 */
export function scoreCode(code: string, language: string): number {
  const metrics = calculateMetrics(code);
  const weightedScore = calculateWeightedScore(metrics);
  return normalizeScore(weightedScore);
}

function calculateMetrics(code: string): CodeMetrics {
  const lines = code.split('\n').filter(line => line.trim().length > 0);
  
  return {
    complexity: calculateComplexity(code),
    length: lines.length,
    readability: calculateReadability(code),
  };
}

function calculateComplexity(code: string): number {
  // Simple complexity calculation based on control structures
  const controlStructures = (code.match(/(if|for|while|switch|try|catch)/g) || []).length;
  return Math.min(controlStructures / 5, 1) * 100;
}

function calculateReadability(code: string): number {
  // Basic readability score based on line length and comments
  const lines = code.split('\n');
  const averageLineLength = lines.reduce((sum, line) => sum + line.length, 0) / lines.length;
  const commentRatio = (code.match(/\/\//g) || []).length / lines.length;
  
  const lengthScore = Math.max(0, 100 - Math.abs(averageLineLength - 40));
  const commentScore = Math.min(commentRatio * 100, 100);
  
  return (lengthScore + commentScore) / 2;
}

function calculateWeightedScore(metrics: CodeMetrics): number {
  return (
    metrics.complexity * 0.3 +
    metrics.readability * 0.4 +
    Math.min(metrics.length * 2, 100) * 0.3
  );
}

function normalizeScore(score: number): number {
  return Math.min(Math.max(Math.round(score), 0), 100);
}
