import { generateWithOpenAI } from '../ai/openai';
import { generateWithGemini } from '../ai/gemini';
import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from '@google/generative-ai';
import { SUPPORTED_LANGUAGES } from '../../config/languages';
import { ENV_CONFIG } from '../../config/env.config';
import type { GenerationRequest } from '../../types/models';

const genAI = new GoogleGenerativeAI(ENV_CONFIG.GOOGLE_API_KEY);

const COMPLEXITY_PROMPTS = {
  basic: `
    Create simple, straightforward code with:
    - Basic error handling
    - Clear variable names
    - Single responsibility functions
    - Minimal complexity
  `,
  intermediate: `
    Create production-ready code with:
    - Proper error handling
    - Input validation
    - Clean code principles
    - Basic optimization
    - Appropriate design patterns
  `,
  advanced: `
    Create enterprise-grade code with:
    - Advanced error handling
    - Full input validation
    - Advanced design patterns
    - Performance optimization
    - Scalability considerations
    - Security best practices
  `
};

export interface GenerateParams {
  modelIds: string[];
  language: string;
  prompt: string;
  complexity: 'basic' | 'intermediate' | 'advanced';
  temperature: number;
  topP: number;
  topK: number;
  maxTokens: number;
}

const buildPrompt = (params: GenerateParams): string => {
  const language = SUPPORTED_LANGUAGES.find(l => l.id === params.language);
  const complexityGuide = COMPLEXITY_PROMPTS[params.complexity];
  
  return `Generate a complete ${language?.name || params.language} code example.

Requirements:
${complexityGuide}

Language: ${language?.name}
Complexity: ${params.complexity}

Task Description:
${params.prompt}

Please provide the code in a code block format using triple backticks. Focus on generating working, well-structured code.`;
};

export async function generateCode(params: GenerateParams): Promise<string> {
  try {
    if (!ENV_CONFIG.GOOGLE_API_KEY) {
      throw new Error('Google API key is not configured');
    }

    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

    const prompt = buildPrompt(params);
    console.log('Sending prompt:', prompt); // Debug log

    try {
      const result = await model.generateContent(prompt);
      const response = await result.response;
      let text = response.text().trim();
      console.log('Raw response:', text); // Debug log

      // Improved code block extraction
      if (text.includes('```')) {
        const codeBlockRegex = /```(?:\w+)?\n([\s\S]+?)```/;
        const match = text.match(codeBlockRegex);
        if (match) {
          return match[1].trim();
        }
      }
      
      return text;

    } catch (apiError) {
      console.error('API Error:', apiError);
      throw new Error(`API Error: ${apiError.message || 'Unknown error'}`);
    }

  } catch (error) {
    console.error('Generation error:', error);
    throw error;
  }
}