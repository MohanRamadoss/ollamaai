export const FILE_EXTENSIONS: Record<string, string> = {
  javascript: 'js',
  typescript: 'ts',
  python: 'py',
  java: 'java',
  cpp: 'cpp',
  csharp: 'cs',
  yaml: 'yml',
  json: 'json',
  markdown: 'md',
  html: 'html',
  css: 'css'
};
