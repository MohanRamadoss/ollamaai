export const AVAILABLE_MODELS = [
  {
    id: 'gemini-pro',  // This is the correct model ID
    name: 'Gemini Pro',
    provider: 'google',
    description: 'General purpose model optimized for text and code generation',
    maxTokens: 30720,
  }
] as const;

export type ModelId = typeof AVAILABLE_MODELS[number]['id'];
