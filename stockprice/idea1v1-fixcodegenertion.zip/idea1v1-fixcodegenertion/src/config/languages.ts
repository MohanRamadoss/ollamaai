import { ProgrammingLanguage } from '../types/models';

export const PROGRAMMING_LANGUAGES: Record<string, ProgrammingLanguage> = {
  // Existing languages
  python: { id: 'python', name: 'Python', features: ['Type Hints', 'Async/Await'], extension: 'py', icon: '🐍' },
  javascript: { id: 'javascript', name: 'JavaScript', features: ['ES6+', 'Node.js'], extension: 'js', icon: '📜' },
  typescript: { id: 'typescript', name: 'TypeScript', features: ['Static Types', 'ES6+'], extension: 'ts', icon: '💪' },
  java: { id: 'java', name: 'Java', features: ['OOP', 'Spring'], extension: 'java', icon: '☕' },
  cpp: { id: 'cpp', name: 'C++', features: ['STL', 'Templates'], extension: 'cpp', icon: '⚡' },
  go: { id: 'go', name: 'Go', features: ['Concurrency', 'Modules'], extension: 'go', icon: '🐹' },
  ruby: { id: 'ruby', name: 'Ruby', features: ['Rails', 'Gems'], extension: 'rb', icon: '💎' },
  php: { id: 'php', name: 'PHP', features: ['Laravel', 'Composer'], extension: 'php', icon: '🐘' },
  csharp: { id: 'csharp', name: 'C#', features: ['.NET', 'LINQ'], extension: 'cs', icon: '🎯' },
  rust: { id: 'rust', name: 'Rust', features: ['Memory Safety', 'Zero Cost'], extension: 'rs', icon: '🦀' },
  swift: { id: 'swift', name: 'Swift', features: ['iOS', 'macOS'], extension: 'swift', icon: '🎯' },
  kotlin: { id: 'kotlin', name: 'Kotlin', features: ['Android', 'JVM'], extension: 'kt', icon: '🎯' },

  // Configuration Management Languages
  ansible: {
    id: 'ansible',
    name: 'Ansible',
    features: [
      'Infrastructure as Code',
      'Playbooks',
      'Roles',
      'Inventory Management',
      'Module System'
    ],
    extension: 'yml',
    icon: '🔧',
    category: 'config'
  },
  shell: {
    id: 'shell',
    name: 'Shell Script',
    features: [
      'System Administration',
      'Process Management',
      'File Operations',
      'Environment Variables',
      'Service Control'
    ],
    extension: 'sh',
    icon: '🐚',
    category: 'config'
  },
  powershell: {
    id: 'powershell',
    name: 'PowerShell',
    features: [
      'Windows Management',
      'Azure Integration',
      'Object Pipeline',
      'Remote Management',
      'DSC (Desired State Configuration)'
    ],
    extension: 'ps1',
    icon: '⚡',
    category: 'config'
  },
  terraform: {
    id: 'terraform',
    name: 'Terraform',
    features: [
      'Infrastructure as Code',
      'Multi-Cloud',
      'State Management',
      'Resource Graph',
      'Provider System'
    ],
    extension: 'tf',
    icon: '🌍',
    category: 'config'
  }
} as const;

export interface Language {
  id: string;
  name: string;
  extension: string;
  mode: string;
}

export const SUPPORTED_LANGUAGES: Language[] = [
  { id: 'javascript', name: 'JavaScript', extension: 'js', mode: 'javascript' },
  { id: 'typescript', name: 'TypeScript', extension: 'ts', mode: 'typescript' },
  { id: 'python', name: 'Python', extension: 'py', mode: 'python' },
  { id: 'java', name: 'Java', extension: 'java', mode: 'java' },
  { id: 'cpp', name: 'C++', extension: 'cpp', mode: 'cpp' },
  { id: 'csharp', name: 'C#', extension: 'cs', mode: 'csharp' },
  { id: 'go', name: 'Go', extension: 'go', mode: 'go' },
  { id: 'rust', name: 'Rust', extension: 'rs', mode: 'rust' },
  { id: 'ruby', name: 'Ruby', extension: 'rb', mode: 'ruby' },
  { id: 'php', name: 'PHP', extension: 'php', mode: 'php' },
  { id: 'swift', name: 'Swift', extension: 'swift', mode: 'swift' },
  { id: 'kotlin', name: 'Kotlin', extension: 'kt', mode: 'kotlin' }
];