import { z } from 'zod';

const EnvConfig = z.object({
  GOOGLE_API_KEY: z.string().min(1),
  GOOGLE_API_URL: z.string().url().default('https://generativelanguage.googleapis.com/v1'),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  API_TIMEOUT: z.number().default(60000),
});

type EnvConfigType = z.infer<typeof EnvConfig>;

function loadConfig(): EnvConfigType {
  try {
    const config = {
      GOOGLE_API_KEY: import.meta.env.VITE_GOOGLE_API_KEY,
      GOOGLE_API_URL: import.meta.env.VITE_GOOGLE_API_URL || 'https://generativelanguage.googleapis.com/v1',
      NODE_ENV: import.meta.env.MODE,
      API_TIMEOUT: parseInt(import.meta.env.VITE_API_TIMEOUT as string) || 60000,
    };

    return EnvConfig.parse(config);
  } catch (error) {
    console.error('Invalid environment configuration:', error);
    throw new Error('Environment configuration is invalid');
  }
}

export const ENV_CONFIG = loadConfig();
