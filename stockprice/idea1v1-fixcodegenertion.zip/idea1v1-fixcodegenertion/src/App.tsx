import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Header } from './components/Header';
import { MainScreen } from './pages/MainScreen';
import { LoginPage } from './pages/LoginPage';
import { GeneratePage } from './pages/GeneratePage';
import { ConvertPage } from './pages/ConvertPage';
import { CodeAnalysisPage } from './pages/CodeAnalysisPage';
import { CloudPage } from './pages/CloudPage';
import { CICDPage } from './pages/CICDPage';
import { SQLPage } from './pages/SQLPage';
import { AgentPage } from './pages/AgentPage';
import { PromptsPage } from './pages/PromptsPage';
import { useAuth } from './hooks/useAuth';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/*"
            element={
              <ProtectedRoute>
                <>
                  <Header />
                  <Routes>
                    <Route path="/" element={<MainScreen />} />
                    <Route path="/generate" element={<GeneratePage />} />
                    <Route path="/convert" element={<ConvertPage />} />
                    <Route path="/analyze" element={<CodeAnalysisPage />} />
                    <Route path="/cloud" element={<CloudPage />} />
                    <Route path="/cicd" element={<CICDPage />} />
                    <Route path="/sql" element={<SQLPage />} />
                    <Route path="/agent" element={<AgentPage />} />
                    <Route path="/prompts" element={<PromptsPage />} />
                    <Route path="*" element={<Navigate to="/" replace />} />
                  </Routes>
                </>
              </ProtectedRoute>
            }
          />
        </Routes>
      </BrowserRouter>
    </div>
  );
}