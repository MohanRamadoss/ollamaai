export async function executeKubectlCommand(command: string): Promise<string> {
  try {
    // Hardcoded development API URL
    const K8S_API_URL = 'http://localhost:8001';
    
    // Parse the kubectl command
    const parts = command.split(' ');
    const firstPart = parts[0];
    
    // Validate it's a kubectl command
    if (firstPart !== 'kubectl') {
      throw new Error('Only kubectl commands are supported');
    }
    
    // Remove 'kubectl' from the parts array
    parts.shift();
    
    // Map kubectl commands to REST API endpoints
    let endpoint = '';
    const action = parts[0]; // Store the action (get, create, etc.)
    
    if (action === 'get') {
      if (parts[1] === 'nodes') {
        endpoint = '/api/v1/nodes';
      } else if (parts[1] === 'ns' || parts[1] === 'namespaces') {
        endpoint = '/api/v1/namespaces';
      } else {
        throw new Error('Unsupported resource type');
      }
    } else {
      throw new Error('Unsupported command');
    }

    console.log('Fetching from:', `${K8S_API_URL}${endpoint}`);

    const response = await fetch(`${K8S_API_URL}${endpoint}`, {
      headers: {
        'Accept': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`API request failed: ${response.statusText}`);
    }

    const data = await response.json();
    
    // Format the output similar to kubectl
    let output = '';
    if (parts[1] === 'nodes') {
      output = 'NAME\tSTATUS\tROLES\tAGE\tVERSION\n';
      data.items.forEach((node: any) => {
        const status = node.status.conditions.find((c: any) => c.type === 'Ready')?.status || 'Unknown';
        output += `${node.metadata.name}\t${status}\t${node.metadata.labels['kubernetes.io/role'] || 'none'}\t${node.metadata.creationTimestamp}\t${node.status.nodeInfo.kubeletVersion}\n`;
      });
    } else if (parts[1] === 'ns' || parts[1] === 'namespaces') {
      output = 'NAME\tSTATUS\tAGE\n';
      data.items.forEach((ns: any) => {
        output += `${ns.metadata.name}\t${ns.status.phase}\t${ns.metadata.creationTimestamp}\n`;
      });
    }

    return output || 'Command executed successfully';
  } catch (error) {
    console.error('Error executing kubectl command:', error);
    throw error;
  }
}