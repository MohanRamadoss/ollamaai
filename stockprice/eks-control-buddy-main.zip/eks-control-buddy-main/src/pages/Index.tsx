import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import CredentialsForm from "@/components/CredentialsForm";
import ClusterOverview from "@/components/ClusterOverview";
import KubectlTerminal from "@/components/KubectlTerminal";
import LLMDeployment from "@/components/LLMDeployment";
import ResourceMetrics from "@/components/ResourceMetrics";
import ClusterHealth from "@/components/ClusterHealth";
import DeploymentManager from "@/components/DeploymentManager";
import ConfigurationManager from "@/components/ConfigurationManager";
import NetworkManager from "@/components/NetworkManager";
import StorageManager from "@/components/StorageManager";

const Index = () => {
  const [isConfigured, setIsConfigured] = useState(false);
  const { toast } = useToast();

  const handleCredentialsSubmit = (credentials: any) => {
    setIsConfigured(true);
    toast({
      title: "Connected successfully",
      description: "Your EKS credentials have been configured.",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">EKS Management Dashboard</h1>
        
        {!isConfigured ? (
          <CredentialsForm onSubmit={handleCredentialsSubmit} />
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ResourceMetrics />
              <ClusterHealth />
            </div>
            <KubectlTerminal />
            <ClusterOverview />
            <DeploymentManager />
            <ConfigurationManager />
            <NetworkManager />
            <StorageManager />
            <LLMDeployment />
          </div>
        )}
      </div>
    </div>
  );
};

export default Index;