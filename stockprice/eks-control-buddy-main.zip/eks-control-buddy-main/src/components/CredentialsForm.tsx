import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { STSClient, GetCallerIdentityCommand } from "@aws-sdk/client-sts";
import { EKSClient, DescribeClusterCommand } from "@aws-sdk/client-eks";

interface CredentialsFormProps {
  onSubmit: (credentials: {
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken?: string;
    region: string;
    clusterName: string;
  }) => void;
}

const CredentialsForm = ({ onSubmit }: CredentialsFormProps) => {
  const { toast } = useToast();
  const [isVerifying, setIsVerifying] = useState(false);
  const [credentials, setCredentials] = useState({
    accessKeyId: "",
    secretAccessKey: "",
    sessionToken: "",
    region: "",
    clusterName: "",
  });

  const verifyAwsCredentials = async () => {
    try {
      const stsClient = new STSClient({
        region: credentials.region,
        credentials: {
          accessKeyId: credentials.accessKeyId,
          secretAccessKey: credentials.secretAccessKey,
          sessionToken: credentials.sessionToken || undefined,
        },
      });

      const command = new GetCallerIdentityCommand({});
      const response = await stsClient.send(command);
      
      toast({
        title: "AWS Credentials Verified",
        description: `Account ID: ${response.Account}`,
      });
      return true;
    } catch (error) {
      toast({
        title: "AWS Credentials Verification Failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
      return false;
    }
  };

  const verifyEksCluster = async () => {
    try {
      const eksClient = new EKSClient({
        region: credentials.region,
        credentials: {
          accessKeyId: credentials.accessKeyId,
          secretAccessKey: credentials.secretAccessKey,
          sessionToken: credentials.sessionToken || undefined,
        },
      });

      const command = new DescribeClusterCommand({
        name: credentials.clusterName,
      });

      const response = await eksClient.send(command);
      
      toast({
        title: "EKS Cluster Verified",
        description: `Cluster Status: ${response.cluster?.status}`,
      });
      return true;
    } catch (error) {
      toast({
        title: "EKS Cluster Verification Failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
      return false;
    }
  };

  const handleVerify = async () => {
    setIsVerifying(true);
    try {
      const awsVerified = await verifyAwsCredentials();
      if (awsVerified) {
        await verifyEksCluster();
      }
    } finally {
      setIsVerifying(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifying(true);
    try {
      const awsVerified = await verifyAwsCredentials();
      const eksVerified = await verifyEksCluster();
      
      if (awsVerified && eksVerified) {
        onSubmit(credentials);
      }
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold mb-4">Configure EKS Credentials</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Access Key ID</label>
          <Input
            type="text"
            value={credentials.accessKeyId}
            onChange={(e) =>
              setCredentials({ ...credentials, accessKeyId: e.target.value })
            }
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Secret Access Key</label>
          <Input
            type="password"
            value={credentials.secretAccessKey}
            onChange={(e) =>
              setCredentials({ ...credentials, secretAccessKey: e.target.value })
            }
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Session Token (Optional)</label>
          <Input
            type="password"
            value={credentials.sessionToken}
            onChange={(e) =>
              setCredentials({ ...credentials, sessionToken: e.target.value })
            }
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Region</label>
          <Input
            type="text"
            value={credentials.region}
            onChange={(e) =>
              setCredentials({ ...credentials, region: e.target.value })
            }
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Cluster Name</label>
          <Input
            type="text"
            value={credentials.clusterName}
            onChange={(e) =>
              setCredentials({ ...credentials, clusterName: e.target.value })
            }
            required
          />
        </div>
        <div className="flex space-x-4">
          <Button
            type="button"
            variant="outline"
            onClick={handleVerify}
            disabled={isVerifying}
          >
            {isVerifying ? "Verifying..." : "Verify Credentials"}
          </Button>
          <Button type="submit" disabled={isVerifying}>
            {isVerifying ? "Connecting..." : "Connect to Cluster"}
          </Button>
        </div>
      </form>
    </Card>
  );
};

export default CredentialsForm;