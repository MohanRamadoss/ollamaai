import { Card } from "@/components/ui/card";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

const ResourceMetrics = () => {
  // Sample data - in a real app, this would come from your Kubernetes API
  const data = [
    { time: "00:00", cpu: 65, memory: 45 },
    { time: "01:00", cpu: 70, memory: 50 },
    { time: "02:00", cpu: 55, memory: 48 },
    { time: "03:00", cpu: 80, memory: 52 },
  ];

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold mb-4">Resource Usage</h2>
      <div className="w-full h-[300px]">
        <LineChart width={600} height={300} data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="time" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="cpu" stroke="#8884d8" name="CPU %" />
          <Line type="monotone" dataKey="memory" stroke="#82ca9d" name="Memory %" />
        </LineChart>
      </div>
    </Card>
  );
};

export default ResourceMetrics;