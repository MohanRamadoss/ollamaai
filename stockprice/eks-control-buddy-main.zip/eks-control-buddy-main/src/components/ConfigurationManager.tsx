import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";

const ConfigurationManager = () => {
  const { toast } = useToast();
  const [configMaps, setConfigMaps] = useState([
    { name: "app-config", namespace: "default", data: { API_URL: "https://api.example.com" } },
    { name: "db-config", namespace: "database", data: { DB_HOST: "db.internal" } },
  ]);

  const [quotas, setQuotas] = useState([
    { namespace: "default", cpu: "4", memory: "8Gi", pods: "10" },
    { namespace: "database", cpu: "8", memory: "16Gi", pods: "5" },
  ]);

  const handleConfigMapUpdate = (name: string, newData: any) => {
    toast({
      title: "ConfigMap Updated",
      description: `ConfigMap ${name} has been updated successfully.`,
    });
  };

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold mb-4">Configuration Management</h2>
      
      <Tabs defaultValue="configmaps" className="space-y-4">
        <TabsList>
          <TabsTrigger value="configmaps">ConfigMaps</TabsTrigger>
          <TabsTrigger value="secrets">Secrets</TabsTrigger>
          <TabsTrigger value="env">Environment</TabsTrigger>
          <TabsTrigger value="quotas">Resource Quotas</TabsTrigger>
        </TabsList>

        <TabsContent value="configmaps" className="space-y-4">
          {configMaps.map((config) => (
            <div key={config.name} className="p-4 border rounded-lg space-y-2">
              <div className="flex justify-between items-center">
                <h3 className="font-medium">{config.name}</h3>
                <Badge>{config.namespace}</Badge>
              </div>
              <div className="grid gap-2">
                {Object.entries(config.data).map(([key, value]) => (
                  <div key={key} className="flex gap-2">
                    <Input value={key} readOnly className="w-1/3" />
                    <Input value={value as string} className="w-2/3" />
                  </div>
                ))}
              </div>
              <Button
                size="sm"
                onClick={() => handleConfigMapUpdate(config.name, config.data)}
              >
                Update
              </Button>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="quotas">
          <div className="space-y-4">
            {quotas.map((quota) => (
              <div key={quota.namespace} className="p-4 border rounded-lg">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-medium">Namespace: {quota.namespace}</h3>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">CPU Limit</p>
                    <p className="font-medium">{quota.cpu} cores</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Memory Limit</p>
                    <p className="font-medium">{quota.memory}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Pod Limit</p>
                    <p className="font-medium">{quota.pods} pods</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  );
};

export default ConfigurationManager;