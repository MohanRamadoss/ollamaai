import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";

const StorageManager = () => {
  const [volumes] = useState([
    { name: "data-vol-1", size: "100Gi", used: "45Gi", status: "Bound", storageClass: "standard" },
    { name: "backup-vol", size: "500Gi", used: "123Gi", status: "Bound", storageClass: "ssd" },
  ]);

  const [storageClasses] = useState([
    { name: "standard", provisioner: "ebs.csi.aws.com", reclaimPolicy: "Delete" },
    { name: "ssd", provisioner: "ebs.csi.aws.com", reclaimPolicy: "Retain" },
  ]);

  const [backups] = useState([
    { name: "daily-backup", status: "Completed", timestamp: "2024-02-20 00:00", size: "50Gi" },
    { name: "weekly-backup", status: "Running", timestamp: "2024-02-19 00:00", size: "200Gi" },
  ]);

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold mb-4">Storage Management</h2>
      
      <Tabs defaultValue="volumes" className="space-y-4">
        <TabsList>
          <TabsTrigger value="volumes">Volumes</TabsTrigger>
          <TabsTrigger value="classes">Storage Classes</TabsTrigger>
          <TabsTrigger value="backups">Backups</TabsTrigger>
          <TabsTrigger value="metrics">Metrics</TabsTrigger>
        </TabsList>

        <TabsContent value="volumes" className="space-y-4">
          {volumes.map((volume) => (
            <div key={volume.name} className="p-4 border rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium">{volume.name}</h3>
                <Badge>{volume.status}</Badge>
              </div>
              <p className="text-sm text-gray-500">Storage Class: {volume.storageClass}</p>
              <div className="mt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Usage: {volume.used} / {volume.size}</span>
                  <span>{Math.round((parseInt(volume.used) / parseInt(volume.size)) * 100)}%</span>
                </div>
                <Progress 
                  value={Math.round((parseInt(volume.used) / parseInt(volume.size)) * 100)} 
                />
              </div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="classes" className="space-y-4">
          {storageClasses.map((sc) => (
            <div key={sc.name} className="p-4 border rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium">{sc.name}</h3>
                <Badge variant="secondary">{sc.reclaimPolicy}</Badge>
              </div>
              <p className="text-sm text-gray-500">Provisioner: {sc.provisioner}</p>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="backups" className="space-y-4">
          {backups.map((backup) => (
            <div key={backup.name} className="p-4 border rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium">{backup.name}</h3>
                <Badge 
                  variant={backup.status === "Completed" ? "default" : "secondary"}
                >
                  {backup.status}
                </Badge>
              </div>
              <div className="text-sm text-gray-500">
                <p>Size: {backup.size}</p>
                <p>Timestamp: {backup.timestamp}</p>
              </div>
            </div>
          ))}
        </TabsContent>
      </Tabs>
    </Card>
  );
};

export default StorageManager;