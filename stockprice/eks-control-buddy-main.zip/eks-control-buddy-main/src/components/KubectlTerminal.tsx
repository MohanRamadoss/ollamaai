import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { executeKubectlCommand } from "@/api/kubernetes";

const LINES_PER_PAGE = 10;

const KubectlTerminal = () => {
  const [command, setCommand] = useState("");
  const [output, setOutput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const { toast } = useToast();

  const executeCommand = async () => {
    if (!command) return;
    
    setIsLoading(true);
    try {
      const result = await executeKubectlCommand(command);
      setOutput(result);
      setCurrentPage(1); // Reset to first page on new command
    } catch (error) {
      toast({
        title: "Command execution failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickCommand = async (cmd: string) => {
    setCommand(cmd);
    setIsLoading(true);
    try {
      const result = await executeKubectlCommand(cmd);
      setOutput(result);
      setCurrentPage(1); // Reset to first page on new command
    } catch (error) {
      toast({
        title: "Command execution failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Split output into lines and get current page's lines
  const outputLines = output.split('\n');
  const totalPages = Math.ceil(outputLines.length / LINES_PER_PAGE);
  const startIndex = (currentPage - 1) * LINES_PER_PAGE;
  const currentPageLines = outputLines.slice(startIndex, startIndex + LINES_PER_PAGE);

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold mb-4">Kubectl Terminal</h2>
      
      <div className="flex gap-2 mb-4">
        <Button 
          variant="outline" 
          onClick={() => handleQuickCommand("kubectl get nodes")}
          disabled={isLoading}
        >
          Get Nodes
        </Button>
        <Button 
          variant="outline" 
          onClick={() => handleQuickCommand("kubectl get ns")}
          disabled={isLoading}
        >
          Get Namespaces
        </Button>
      </div>

      <div className="flex gap-2 mb-4">
        <Input
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          placeholder="Enter kubectl command..."
          className="flex-1"
          disabled={isLoading}
        />
        <Button 
          onClick={executeCommand}
          disabled={isLoading || !command}
        >
          {isLoading ? "Executing..." : "Execute"}
        </Button>
      </div>

      {output && (
        <div className="space-y-4">
          <ScrollArea className="h-[300px] rounded-md border">
            <div className="bg-black text-green-400 p-4 font-mono whitespace-pre-wrap">
              {currentPageLines.join('\n')}
            </div>
          </ScrollArea>
          
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-2">
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm">
                  Page {currentPage} of {totalPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
              <div className="text-sm text-muted-foreground">
                Showing {startIndex + 1}-{Math.min(startIndex + LINES_PER_PAGE, outputLines.length)} of {outputLines.length} lines
              </div>
            </div>
          )}
        </div>
      )}
    </Card>
  );
};

export default KubectlTerminal;