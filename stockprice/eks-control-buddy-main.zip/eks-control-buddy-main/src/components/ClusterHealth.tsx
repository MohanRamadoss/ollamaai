import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useEffect, useState } from "react";

interface NodeStatus {
  name: string;
  status: "Ready" | "NotReady";
  cpu: string;
  memory: string;
}

interface PodHealth {
  name: string;
  status: "Running" | "Pending" | "Failed";
  restarts: number;
  namespace: string;
}

const ClusterHealth = () => {
  const [nodes, setNodes] = useState<NodeStatus[]>([
    { name: "node-1", status: "Ready", cpu: "75%", memory: "60%" },
    { name: "node-2", status: "Ready", cpu: "45%", memory: "30%" },
  ]);

  const [pods, setPods] = useState<PodHealth[]>([
    { name: "web-pod-1", status: "Running", restarts: 0, namespace: "default" },
    { name: "db-pod-1", status: "Running", restarts: 1, namespace: "database" },
  ]);

  // Simulate real-time updates with mock data
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate node updates
      setNodes(currentNodes => 
        currentNodes.map(node => ({
          ...node,
          cpu: `${Math.floor(Math.random() * 100)}%`,
          memory: `${Math.floor(Math.random() * 100)}%`
        }))
      );

      // Simulate pod updates
      setPods(currentPods => 
        currentPods.map(pod => ({
          ...pod,
          status: Math.random() > 0.8 
            ? "Pending"
            : Math.random() > 0.9 
              ? "Failed" 
              : "Running",
          restarts: Math.random() > 0.9 
            ? pod.restarts + 1 
            : pod.restarts
        }))
      );
    }, 5000); // Update every 5 seconds

    return () => clearInterval(interval);
  }, []);

  const getPodStatusVariant = (status: PodHealth['status']) => {
    switch (status) {
      case "Running":
        return "default";
      case "Pending":
        return "secondary";
      case "Failed":
        return "destructive";
      default:
        return "default";
    }
  };

  return (
    <Card className="p-6">
      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold mb-4">Node Status</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {nodes.map((node) => (
              <div key={node.name} className="p-4 border rounded-lg">
                <div className="flex justify-between items-center">
                  <h3 className="font-medium">{node.name}</h3>
                  <Badge variant={node.status === "Ready" ? "default" : "destructive"}>
                    {node.status}
                  </Badge>
                </div>
                <div className="mt-2 text-sm text-gray-600">
                  <p>CPU: {node.cpu}</p>
                  <p>Memory: {node.memory}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-4">Pod Health</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pods.map((pod) => (
              <div key={pod.name} className="p-4 border rounded-lg">
                <div className="flex justify-between items-center">
                  <h3 className="font-medium">{pod.name}</h3>
                  <Badge variant={getPodStatusVariant(pod.status)}>
                    {pod.status}
                  </Badge>
                </div>
                <div className="mt-2 text-sm text-gray-600">
                  <p>Namespace: {pod.namespace}</p>
                  <p>Restarts: {pod.restarts}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
};

export default ClusterHealth;