import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";

interface DeploymentHistory {
  id: string;
  version: string;
  timestamp: string;
  status: "success" | "failed" | "in-progress";
}

const DeploymentManager = () => {
  const { toast } = useToast();

  const deploymentHistory: DeploymentHistory[] = [
    { id: "1", version: "v1.0.1", timestamp: "2024-02-20 10:00", status: "success" },
    { id: "2", version: "v1.0.0", timestamp: "2024-02-19 15:30", status: "success" },
  ];

  const handleRollback = (version: string) => {
    toast({
      title: "Rolling back deployment",
      description: `Rolling back to version ${version}...`,
    });
  };

  const handleCanaryDeploy = () => {
    toast({
      title: "Canary Deployment",
      description: "Starting canary deployment with 10% traffic...",
    });
  };

  const handleBlueGreenDeploy = () => {
    toast({
      title: "Blue-Green Deployment",
      description: "Preparing blue-green deployment environment...",
    });
  };

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold mb-4">Deployment Management</h2>
      
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-medium mb-3">Deployment Actions</h3>
          <div className="flex gap-4">
            <Button onClick={handleCanaryDeploy}>
              Start Canary Deployment
            </Button>
            <Button onClick={handleBlueGreenDeploy} variant="outline">
              Start Blue-Green Deployment
            </Button>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium mb-3">Deployment History</h3>
          <div className="space-y-3">
            {deploymentHistory.map((deployment) => (
              <div
                key={deployment.id}
                className="flex items-center justify-between p-4 border rounded-lg"
              >
                <div>
                  <p className="font-medium">{deployment.version}</p>
                  <p className="text-sm text-gray-500">{deployment.timestamp}</p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant={deployment.status === "success" ? "default" : "destructive"}>
                    {deployment.status}
                  </Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleRollback(deployment.version)}
                  >
                    Rollback
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
};

export default DeploymentManager;