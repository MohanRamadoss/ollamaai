import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const ClusterOverview = () => {
  const [namespaces, setNamespaces] = useState<string[]>([]);
  const [deployments, setDeployments] = useState<any[]>([]);

  useEffect(() => {
    // Fetch initial data
    fetchNamespaces();
    fetchDeployments();
  }, []);

  const fetchNamespaces = async () => {
    try {
      const response = await fetch("/api/kubernetes/namespaces");
      const data = await response.json();
      setNamespaces(data);
    } catch (error) {
      console.error("Failed to fetch namespaces:", error);
    }
  };

  const fetchDeployments = async () => {
    try {
      const response = await fetch("/api/kubernetes/deployments");
      const data = await response.json();
      setDeployments(data);
    } catch (error) {
      console.error("Failed to fetch deployments:", error);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Namespaces</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {namespaces.map((namespace) => (
            <div
              key={namespace}
              className="p-4 bg-white rounded-lg border shadow-sm"
            >
              {namespace}
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Deployments</h2>
        <div className="space-y-4">
          {deployments.map((deployment) => (
            <div
              key={deployment.name}
              className="p-4 bg-white rounded-lg border shadow-sm"
            >
              <h3 className="font-medium">{deployment.name}</h3>
              <p className="text-sm text-gray-500">
                Replicas: {deployment.replicas}
              </p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default ClusterOverview;