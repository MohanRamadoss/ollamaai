import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Define the Ollama server URL
const OLLAMA_SERVER_URL = "http://localhost:11434"; // Default local Ollama server

const LLMDeployment = () => {
  const [prompt, setPrompt] = useState("");
  const [model, setModel] = useState("phi4");
  const [task, setTask] = useState("get-namespaces");
  const [output, setOutput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const tasks = [
    { id: "get-namespaces", label: "Get Namespaces" },
    { id: "get-pods", label: "Get Pods" },
    { id: "get-deployments", label: "Get Deployments" },
    { id: "get-services", label: "Get Services" },
  ];

  const models = [
    { id: "phi4", label: "Phi-4" },
    { id: "deepseekr1", label: "DeepSeek-R1" },
  ];

  const getSystemPrompt = (task: string) => {
    const prompts = {
      "get-namespaces": "List all namespaces in the EKS cluster and provide their status.",
      "get-pods": "List all pods across namespaces, including their status and health.",
      "get-deployments": "List all deployments with their replica counts and status.",
      "get-services": "List all services with their type and cluster IP.",
    };
    return prompts[task as keyof typeof prompts] || "";
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`${OLLAMA_SERVER_URL}/api/generate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model,
          systemPrompt: getSystemPrompt(task),
          prompt,
          task,
        }),
      });
      
      const data = await response.json();
      setOutput(data.response || "No output generated");
      
      toast({
        title: "Command Processed",
        description: "The LLM has processed your request.",
      });
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process your request. Please check if Ollama server is running.",
        variant: "destructive",
      });
      setOutput("Error processing request");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold mb-4">LLM Deployment Assistant</h2>
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Model</label>
            <Select value={model} onValueChange={setModel}>
              <SelectTrigger>
                <SelectValue placeholder="Select model" />
              </SelectTrigger>
              <SelectContent>
                {models.map((m) => (
                  <SelectItem key={m.id} value={m.id}>
                    {m.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Task</label>
            <Select value={task} onValueChange={setTask}>
              <SelectTrigger>
                <SelectValue placeholder="Select task" />
              </SelectTrigger>
              <SelectContent>
                {tasks.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-2">Additional Instructions (Optional)</label>
          <Textarea
            placeholder="Add any specific instructions or filters..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="min-h-[100px]"
          />
        </div>

        <Button
          onClick={handleSubmit}
          disabled={isLoading}
          className="w-full"
        >
          {isLoading ? "Processing..." : "Execute Command"}
        </Button>

        {output && (
          <div className="mt-4">
            <label className="block text-sm font-medium mb-2">Output</label>
            <div className="bg-gray-100 p-4 rounded-md">
              <pre className="whitespace-pre-wrap text-sm">{output}</pre>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
};

export default LLMDeployment;