import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const NetworkManager = () => {
  const [services] = useState([
    { name: "frontend", type: "ClusterIP", ports: ["80:8080"], namespace: "default" },
    { name: "backend-api", type: "LoadBalancer", ports: ["443:8443"], namespace: "default" },
  ]);

  const [ingresses] = useState([
    {
      name: "main-ingress",
      namespace: "default",
      rules: [
        { host: "app.example.com", service: "frontend", port: 80 },
        { host: "api.example.com", service: "backend-api", port: 443 },
      ],
    },
  ]);

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold mb-4">Network Management</h2>
      
      <Tabs defaultValue="services" className="space-y-4">
        <TabsList>
          <TabsTrigger value="services">Service Mesh</TabsTrigger>
          <TabsTrigger value="ingress">Ingress</TabsTrigger>
          <TabsTrigger value="policies">Network Policies</TabsTrigger>
          <TabsTrigger value="traffic">Traffic Flow</TabsTrigger>
        </TabsList>

        <TabsContent value="services" className="space-y-4">
          {services.map((service) => (
            <div key={service.name} className="p-4 border rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium">{service.name}</h3>
                <Badge>{service.type}</Badge>
              </div>
              <p className="text-sm text-gray-500">Namespace: {service.namespace}</p>
              <div className="mt-2">
                <p className="text-sm text-gray-500">Ports:</p>
                <div className="flex gap-2 mt-1">
                  {service.ports.map((port) => (
                    <Badge key={port} variant="secondary">{port}</Badge>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="ingress" className="space-y-4">
          {ingresses.map((ingress) => (
            <div key={ingress.name} className="p-4 border rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium">{ingress.name}</h3>
                <Badge>{ingress.namespace}</Badge>
              </div>
              <div className="space-y-2">
                {ingress.rules.map((rule, index) => (
                  <div key={index} className="p-2 bg-gray-50 rounded">
                    <p className="text-sm">
                      <span className="font-medium">{rule.host}</span> →{" "}
                      {rule.service}:{rule.port}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </TabsContent>
      </Tabs>
    </Card>
  );
};

export default NetworkManager;