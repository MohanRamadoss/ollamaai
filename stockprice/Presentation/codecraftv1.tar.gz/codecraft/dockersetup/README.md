# Docker Setup

This directory contains all Docker-related configuration files for development and production environments.

## Development Setup

```bash
# Start all services in development mode
docker-compose -f dockersetup/docker-compose.yml up --build

# View logs
docker-compose -f dockersetup/docker-compose.yml logs -f

# Stop services
docker-compose -f dockersetup/docker-compose.yml down
```

## Production Setup

```bash
# Start all services in production mode
docker-compose -f dockersetup/docker-compose.prod.yml up --build -d

# Stop services
docker-compose -f dockersetup/docker-compose.prod.yml down
```

## Environment Variables

Copy `.env.docker` to `.env` in the project root and update the values:

```bash
cp dockersetup/.env.docker .env
```

## Services

- **App**: Node.js application with Vite
- **Redis**: Cache and session storage
- **PostgreSQL**: Main database

## Volumes

- `redis_data`: Redis persistence
- `postgres_data`: PostgreSQL data

## Important Notes

1. Never commit `.env` file with real credentials
2. Update default passwords in production
3. Enable Redis authentication in production
4. Configure proper firewall rules
5. Use Docker Swarm or Kubernetes for production scaling