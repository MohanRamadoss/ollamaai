import { CodeExample } from '../../../types/security';

export const juliaExamples: CodeExample[] = [
  {
    name: 'Secure File Operations',
    description: 'Safe file handling in Julia',
    code: `# VULNERABLE: Unsafe file operations
function read_file_unsafe(filename)
    open(filename) do f
        read(f, String)
    end
end

# SECURE: Safe file operations with validation
function read_file_secure(filename)
    # Validate path
    abs_path = abspath(filename)
    base_dir = abspath("safe_directory")
    
    if !startswith(abs_path, base_dir)
        throw(ArgumentError("Access denied: Path traversal attempt"))
    end
    
    # Check file exists and is regular file
    if !isfile(abs_path)
        throw(ArgumentError("Not a regular file"))
    end
    
    # Safe read with proper error handling
    try
        open(abs_path) do f
            read(f, String)
        end
    catch e
        @error "File read error" exception=e
        rethrow()
    end
end`,
  },
  {
    name: 'Cryptographic Operations',
    description: 'Secure cryptographic practices',
    code: `using SHA
using Random

# VULNERABLE: Weak hashing
function hash_password_unsafe(password)
    return bytes2hex(sha1(password))  # SHA1 is not secure for passwords
end

# SECURE: Strong password hashing
function hash_password_secure(password)
    # Generate random salt
    salt = rand(UInt8, 16)
    
    # Use stronger hash function with salt
    function pbkdf2_hash(password, salt, iterations=100000)
        key_length = 32  # 256 bits
        return bytes2hex(PBKDF2_HMAC_SHA256(
            password,
            salt,
            iterations,
            key_length
        ))
    end
    
    hash = pbkdf2_hash(password, salt)
    return Dict(
        "hash" => hash,
        "salt" => bytes2hex(salt),
        "iterations" => 100000
    )
end`,
  }
];
