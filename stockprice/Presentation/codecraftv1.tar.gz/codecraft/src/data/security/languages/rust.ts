import { CodeExample } from '../../../types/security';

export const rustExamples: CodeExample[] = [
  {
    name: 'Memory Safety',
    description: 'Safe vs unsafe memory handling',
    code: `// VULNERABLE: Unsafe memory access
unsafe fn dangerous_operation(ptr: *mut u8) {
    *ptr = 42;  // Direct pointer manipulation - dangerous!
}

// SECURE: Safe memory handling with ownership
fn safe_operation(data: &mut Vec<u8>) {
    if let Some(value) = data.get_mut(0) {
        *value = 42;  // Safe access with bounds checking
    }
}

// SECURE: Using Option for null safety
struct User {
    id: u64,
    name: String,
    email: Option<String>  // Explicit optional value
}

impl User {
    fn get_email(&self) -> Option<&String> {
        self.email.as_ref()
    }
}`,
  },
  {
    name: 'Concurrency Safety',
    description: 'Thread-safe data handling',
    code: `use std::sync::{Arc, Mutex};
use std::thread;

// VULNERABLE: Data race condition
fn unsafe_counter() {
    let counter = Box::new(0);
    let ptr = Box::into_raw(counter);
    
    let handles: Vec<_> = (0..3).map(|_| {
        unsafe {
            thread::spawn(move || {
                *ptr += 1;  // Data race!
            })
        }
    }).collect();
}

// SECURE: Thread-safe counter
fn safe_counter() {
    let counter = Arc::new(Mutex::new(0));
    let mut handles = vec![];
    
    for _ in 0..3 {
        let counter_clone = Arc::clone(&counter);
        let handle = thread::spawn(move || {
            let mut num = counter_clone.lock().unwrap();
            *num += 1;
        });
        handles.push(handle);
    }
    
    for handle in handles {
        handle.join().unwrap();
    }
}`,
  },
  {
    name: 'Input Validation',
    description: 'Secure input handling and validation',
    code: `use std::path::Path;

// VULNERABLE: Path traversal risk
fn unsafe_file_access(filename: &str) -> std::io::Result<String> {
    std::fs::read_to_string(filename)  // No path validation
}

// SECURE: Safe file access with path validation
fn safe_file_access(filename: &str) -> Result<String, Box<dyn std::error::Error>> {
    let path = Path::new(filename);
    
    // Validate absolute path
    let canonical = path.canonicalize()?;
    let safe_root = Path::new("/safe/path").canonicalize()?;
    
    if !canonical.starts_with(safe_root) {
        return Err("Path traversal detected".into());
    }
    
    Ok(std::fs::read_to_string(canonical)?)
}

// SECURE: Type-safe input validation
#[derive(Debug)]
struct ValidatedInput {
    value: String
}

impl ValidatedInput {
    fn new(input: &str) -> Result<Self, &'static str> {
        // Validation rules
        if input.is_empty() {
            return Err("Input cannot be empty");
        }
        
        if input.len() > 100 {
            return Err("Input too long");
        }
        
        // Additional validation checks
        if !input.chars().all(|c| c.is_alphanumeric() || c == '_') {
            return Err("Invalid characters in input");
        }
        
        Ok(Self {
            value: input.to_string()
        })
    }
}`,
  }
];
