import { CodeExample } from '../../../types/security';

export const javascriptExamples: CodeExample[] = [
  {
    name: 'NoSQL Injection Example',
    description: 'Example showing NoSQL injection vulnerability',
    code: `// Vulnerable Code
const userInput = req.body.username;
const query = { username: userInput };
db.users.find(query);`,
    securityContext: {
      riskLevel: 'high',
      vulnerabilityType: 'nosql-injection'
    }
  },
  {
    name: 'Secure NoSQL Query',
    description: 'Example of secure NoSQL query handling',
    code: `// Secure Code
const username = req.body.username;
const query = { username: { $eq: username } };
db.users.find(query);`,
    securityContext: {
      riskLevel: 'low',
      vulnerabilityType: 'nosql-injection'
    }
  },
  {
    name: 'XSS Vulnerability',
    description: 'Cross-site scripting vulnerable code',
    code: `// Vulnerable Code
app.get('/echo', (req, res) => {
  res.send(req.query.userInput);
});`,
    securityContext: {
      riskLevel: 'high',
      vulnerabilityType: 'xss'
    }
  },
  {
    name: 'XSS Prevention',
    description: 'Preventing Cross-Site Scripting (XSS) attacks',
    code: `// VULNERABLE: Direct HTML injection
function displayUserInput(input) {
    document.getElementById('output').innerHTML = input;  // XSS vulnerability
}

// SECURE: Using proper HTML escaping
function displayUserInputSecure(input) {
    const escapeHtml = (unsafe) => {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    };
    
    document.getElementById('output').textContent = input;  // Safe approach
    // Or if HTML is needed:
    // document.getElementById('output').innerHTML = escapeHtml(input);
}`,
  },
  {
    name: 'CSRF Protection',
    description: 'Implementing CSRF tokens in API requests',
    code: `// VULNERABLE: No CSRF protection
async function unsafeApiCall(data) {
    const response = await fetch('/api/data', {
        method: 'POST',
        body: JSON.stringify(data)
    });
}

// SECURE: Using CSRF tokens
async function safeApiCall(data) {
    const token = document.querySelector('meta[name="csrf-token"]').content;
    
    const response = await fetch('/api/data', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': token
        },
        credentials: 'same-origin',
        body: JSON.stringify(data)
    });
    
    if (!response.ok) {
        throw new Error('Request failed');
    }
    return response.json();
}`,
  },
  {
    name: 'Secure Authentication',
    description: 'Secure user authentication practices',
    code: `// VULNERABLE: Insecure authentication
function loginUnsafe(username, password) {
    localStorage.setItem('userToken', btoa(username + ':' + password));  // Never store passwords!
}

// SECURE: Proper authentication handling
class SecureAuthService {
    static async login(username, password) {
        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            if (!response.ok) throw new Error('Authentication failed');

            const { token } = await response.json();
            
            // Store token securely
            sessionStorage.setItem('authToken', token);
            
            // Set secure, httpOnly cookie on server side
            // Set secure headers and CSP
        } catch (error) {
            console.error('Login failed:', error);
            throw error;
        }
    }

    static logout() {
        sessionStorage.removeItem('authToken');
        // Also invalidate token on server
    }

    static isAuthenticated() {
        return !!sessionStorage.getItem('authToken');
    }
}`,
  }
];
