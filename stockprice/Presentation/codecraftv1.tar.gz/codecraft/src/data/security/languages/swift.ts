import { CodeExample } from '../../../types/security';

export const swiftExamples: CodeExample[] = [
  {
    name: 'Secure Data Storage',
    description: 'Safe handling of sensitive data using Keychain',
    code: `// VULNERABLE: Insecure data storage
class UnsafeStorage {
    func saveCredentials(username: String, password: String) {
        UserDefaults.standard.set(password, forKey: "userPassword")  // ISSUE: Storing sensitive data in UserDefaults
        UserDefaults.standard.set(username, forKey: "userName")
    }
}

// SECURE: Using Keychain for sensitive data
import Security

class SecureStorage {
    enum KeychainError: Error {
        case duplicateEntry
        case unknown(OSStatus)
    }
    
    func saveCredentials(username: String, password: String) throws {
        let credentials = "\(username):\(password)".data(using: .utf8)!
        
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "userCredentials",
            kSecValueData as String: credentials,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        
        let status = SecItemAdd(query as CFDictionary, nil)
        guard status != errSecDuplicateItem else {
            throw KeychainError.duplicateEntry
        }
        guard status == errSecSuccess else {
            throw KeychainError.unknown(status)
        }
    }
}`
  },
  {
    name: 'Input Validation',
    description: 'Secure input handling and validation',
    code: `// VULNERABLE: No input validation
struct UnsafeUser {
    var name: String
    var email: String
    
    init(name: String, email: String) {
        self.name = name     // No validation
        self.email = email   // No validation
    }
}

// SECURE: Input validation with proper error handling
struct ValidatedUser {
    var name: String
    var email: String
    
    enum ValidationError: Error {
        case invalidName
        case invalidEmail
        case emptyField
    }
    
    static func validateEmail(_ email: String) throws {
        guard !email.isEmpty else {
            throw ValidationError.emptyField
        }
        
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailRegex)
        
        guard emailPredicate.evaluate(with: email) else {
            throw ValidationError.invalidEmail
        }
    }
    
    init(name: String, email: String) throws {
        guard !name.isEmpty else {
            throw ValidationError.emptyField
        }
        
        try ValidatedUser.validateEmail(email)
        
        self.name = name
        self.email = email
    }
}`
  },
  {
    name: 'Network Security',
    description: 'Secure networking practices',
    code: `// VULNERABLE: Insecure network request
class UnsafeNetworking {
    func fetchData(from urlString: String) {
        guard let url = URL(string: urlString) else { return }
        URLSession.shared.dataTask(with: url) { data, response, error in
            // No SSL pinning
            // No response validation
            // No error handling
        }.resume()
    }
}

// SECURE: Protected network requests
class SecureNetworking {
    enum NetworkError: Error {
        case invalidResponse
        case invalidCertificate
        case serverError(Int)
    }
    
    private let session: URLSession
    
    init() {
        let configuration = URLSessionConfiguration.default
        configuration.tlsMinimumSupportedProtocolVersion = .TLSv12
        
        let delegate = SecureURLSessionDelegate()
        self.session = URLSession(configuration: configuration,
                                delegate: delegate,
                                delegateQueue: nil)
    }
    
    func fetchData(from url: URL) async throws -> Data {
        let (data, response) = try await session.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw NetworkError.invalidResponse
        }
        
        guard (200...299).contains(httpResponse.statusCode) else {
            throw NetworkError.serverError(httpResponse.statusCode)
        }
        
        return data
    }
}

class SecureURLSessionDelegate: NSObject, URLSessionDelegate {
    func urlSession(_ session: URLSession,
                   didReceive challenge: URLAuthenticationChallenge,
                   completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        
        guard let serverTrust = challenge.protectionSpace.serverTrust,
              let certificate = SecTrustGetCertificateAtIndex(serverTrust, 0) else {
            completionHandler(.cancelAuthenticationChallenge, nil)
            return
        }
        
        // Implement certificate pinning here
        if validateCertificate(certificate) {
            let credential = URLCredential(trust: serverTrust)
            completionHandler(.useCredential, credential)
        } else {
            completionHandler(.cancelAuthenticationChallenge, nil)
        }
    }
    
    private func validateCertificate(_ certificate: SecCertificate) -> Bool {
        // Implement your certificate validation logic
        return true
    }
}`
  }
];
