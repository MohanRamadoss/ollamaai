import { CodeExample } from '../../../types/security';

export const kotlinExamples: CodeExample[] = [
  {
    name: 'Secure Data Class Usage',
    description: 'Implementing secure data classes with validation',
    code: `// VULNERABLE: No input validation
data class UserCredentials(
    val username: String,
    val password: String
)

// SECURE: Data class with validation
data class SecureCredentials private constructor(
    val username: String,
    private val hashedPassword: String
) {
    companion object {
        fun create(username: String, password: String): SecureCredentials {
            require(username.length >= 3) { "Username too short" }
            require(password.length >= 8) { "Password too short" }
            
            val hashedPwd = hashPassword(password)
            return SecureCredentials(username, hashedPwd)
        }
        
        private fun hashPassword(password: String): String {
            // Use proper password hashing (e.g., BCrypt)
            return BCrypt.hashpw(password, BCrypt.gensalt())
        }
    }
}`,
  },
  {
    name: 'Coroutine Security',
    description: 'Secure asynchronous operations with coroutines',
    code: `// VULNERABLE: Unstructured concurrent operations
class UnsafeDataService {
    fun fetchData() = GlobalScope.launch {  // Bad practice
        val data = api.fetchSensitiveData()
        processData(data)
    }
}

// SECURE: Structured concurrency with proper error handling
class SecureDataService {
    suspend fun fetchData() = coroutineScope {
        try {
            supervisorScope {
                val data = async(Dispatchers.IO + securityContext) { 
                    api.fetchSensitiveData() 
                }
                
                withTimeout(5000L) {
                    processData(data.await())
                }
            }
        } catch (e: SecurityException) {
            logger.error("Security violation", e)
            throw e
        } finally {
            clearSensitiveData()
        }
    }
    
    private val securityContext = SecurityContext()
}`,
  },
  {
    name: 'Null Safety',
    description: 'Secure null handling practices',
    code: `// VULNERABLE: Unsafe null handling
class UnsafeUserService {
    fun getUser(id: String): User? {
        return database.findUser(id)
    }
    
    fun processUser(id: String) {
        val user = getUser(id)!!  // Dangerous: can throw NPE
        println(user.name)
    }
}

// SECURE: Safe null handling with validation
class SecureUserService {
    fun getUser(id: String): Result<User> {
        return runCatching {
            database.findUser(id)
                ?.let { Result.success(it) }
                ?: Result.failure(UserNotFoundException(id))
        }
    }
    
    fun processUser(id: String) {
        getUser(id)
            .onSuccess { user -> 
                validateUserAccess(user)
                processUserSecurely(user)
            }
            .onFailure { error ->
                logger.error("User processing failed", error)
                handleError(error)
            }
    }
}`,
  }
];
