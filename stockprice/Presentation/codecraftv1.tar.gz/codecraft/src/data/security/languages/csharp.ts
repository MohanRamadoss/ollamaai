import { CodeExample } from '../../../types/security';

export const csharpExamples: CodeExample[] = [
  {
    name: 'SQL Injection Prevention',
    description: 'Secure database access patterns in C#',
    code: `// VULNERABLE: SQL Injection risk
public User FindUserVulnerable(string username)
{
    using (var conn = new SqlConnection(connectionString))
    {
        var cmd = new SqlCommand(
            $"SELECT * FROM Users WHERE Username = '{username}'", // Vulnerable
            conn);
        // Process results...
    }
}

// SECURE: Using parameterized queries
public async Task<User> FindUserSecureAsync(string username)
{
    using (var conn = new SqlConnection(connectionString))
    {
        await conn.OpenAsync();
        using var cmd = new SqlCommand(
            "SELECT * FROM Users WHERE Username = @Username",
            conn);
        
        cmd.Parameters.AddWithValue("@Username", username);
        // Process results safely...
    }
}`,
  },
  {
    name: 'Secure File Operations',
    description: 'Safe file handling and path traversal prevention',
    code: `// VULNERABLE: Path traversal risk
public string ReadFileVulnerable(string fileName)
{
    // UNSAFE: Direct file path concatenation
    return File.ReadAllText(Path.Combine(basePath, fileName));
}

// SECURE: Safe file access
public async Task<string> ReadFileSecureAsync(string fileName)
{
    // Validate and sanitize file path
    if (Path.GetFileName(fileName) != fileName)
    {
        throw new SecurityException("Path traversal detected");
    }

    string safePath = Path.Combine(basePath, fileName);
    string fullPath = Path.GetFullPath(safePath);
    
    if (!fullPath.StartsWith(basePath, StringComparison.OrdinalIgnoreCase))
    {
        throw new SecurityException("Invalid file path");
    }

    if (!File.Exists(fullPath))
    {
        throw new FileNotFoundException();
    }

    return await File.ReadAllTextAsync(fullPath);
}`,
  },
  {
    name: 'Secure Password Handling',
    description: 'Implementing secure password hashing and validation',
    code: `using System.Security.Cryptography;

// VULNERABLE: Weak password hashing
public class UnsafePasswordHasher
{
    public string HashPasswordVulnerable(string password)
    {
        // UNSAFE: Using MD5
        using (var md5 = MD5.Create())
        {
            byte[] hash = md5.ComputeHash(
                Encoding.UTF8.GetBytes(password));
            return Convert.ToBase64String(hash);
        }
    }
}

// SECURE: Strong password hashing
public class SecurePasswordHasher
{
    public string HashPassword(string password)
    {
        return BCrypt.Net.BCrypt.HashPassword(password, 
            workFactor: 12);
    }

    public bool VerifyPassword(string password, string hash)
    {
        try
        {
            return BCrypt.Net.BCrypt.Verify(password, hash);
        }
        catch
        {
            return false;
        }
    }
    
    // Additional security for password reset tokens
    public string GenerateSecureToken()
    {
        var randomBytes = new byte[32];
        using (var rng = new RNGCryptoServiceProvider())
        {
            rng.GetBytes(randomBytes);
        }
        return Convert.ToBase64String(randomBytes);
    }
}`,
  }
];
