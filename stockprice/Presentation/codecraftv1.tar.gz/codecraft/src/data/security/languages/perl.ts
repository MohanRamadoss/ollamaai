import { CodeExample } from '../../../types/security';

export const perlExamples: CodeExample[] = [
  {
    name: 'Taint Mode Usage',
    description: 'Using Perl taint mode for input validation',
    code: `#!/usr/bin/perl -T
use strict;
use warnings;

# VULNERABLE: No input validation
sub process_unsafe {
    my $user_input = shift;
    system("echo $user_input");  # Command injection risk
}

# SECURE: Using taint mode and input validation
sub process_safe {
    my $user_input = shift;
    
    # Validate and untaint input
    if ($user_input =~ /^([a-zA-Z0-9_-]+)$/) {
        $user_input = $1;  # Untainted data
    } else {
        die "Invalid input";
    }
    
    system("echo", $user_input);
}`,
  },
  {
    name: 'SQL Injection Prevention',
    description: 'Secure database operations in Perl',
    code: `use DBI;
use strict;
use warnings;

# VULNERABLE: SQL Injection risk
sub find_user_unsafe {
    my ($dbh, $username) = @_;
    my $query = "SELECT * FROM users WHERE username = '$username'";
    return $dbh->selectall_arrayref($query);
}

# SECURE: Using prepared statements
sub find_user_safe {
    my ($dbh, $username) = @_;
    my $query = "SELECT * FROM users WHERE username = ?";
    my $sth = $dbh->prepare($query);
    $sth->execute($username);
    return $sth->fetchall_arrayref();
}`,
  }
];
