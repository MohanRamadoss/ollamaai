import { CodeExample } from '../../../types/security';

export const javaExamples: CodeExample[] = [
  {
    name: 'SQL Injection Prevention',
    description: 'Secure database query handling in Java',
    code: `// VULNERABLE: SQL Injection risk
public User findUserVulnerable(String username) {
    String query = "SELECT * FROM users WHERE username = '" + username + "'";
    Statement stmt = connection.createStatement();
    ResultSet rs = stmt.executeQuery(query);
    // ... process results
}

// SECURE: Using PreparedStatement
public User findUserSecure(String username) {
    String query = "SELECT * FROM users WHERE username = ?";
    PreparedStatement stmt = connection.prepareStatement(query);
    stmt.setString(1, username);
    ResultSet rs = stmt.executeQuery();
    // ... process results
}`,
  },
  {
    name: 'XSS Prevention',
    description: 'Cross-Site Scripting (XSS) prevention techniques',
    code: `import org.owasp.encoder.Encode;

// VULNERABLE: Direct HTML output
@GetMapping("/profile")
public String profileVulnerable(@RequestParam String name) {
    return "<div>Welcome, " + name + "!</div>";  // XSS vulnerability
}

// SECURE: Using proper encoding
@GetMapping("/profile")
public String profileSecure(@RequestParam String name) {
    return "<div>Welcome, " + Encode.forHtml(name) + "!</div>";
}

// SECURE: Using Spring Security
@GetMapping("/profile")
public String profileSecureSpring(@RequestParam String name) {
    model.addAttribute("username", name);  // Automatically escaped in Thymeleaf
    return "profile";
}`,
  },
  {
    name: 'Secure Password Storage',
    description: 'Implementation of secure password hashing',
    code: `import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class SecurityConfig {
    // VULNERABLE: Weak password storage
    private String hashPasswordVulnerable(String password) {
        return password.hashCode().toString();  // Never use this!
    }

    // SECURE: Using BCrypt
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);  // Work factor of 12
    }

    public class UserService {
        private final PasswordEncoder passwordEncoder;

        public void createUser(String username, String password) {
            String hashedPassword = passwordEncoder.encode(password);
            // Store hashedPassword in database
        }

        public boolean verifyPassword(String password, String hashedPassword) {
            return passwordEncoder.matches(password, hashedPassword);
        }
    }
}`,
  }
];
