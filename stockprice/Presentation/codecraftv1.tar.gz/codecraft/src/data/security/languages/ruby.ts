import { CodeExample } from '../../../types/security';

export const rubyExamples: CodeExample[] = [
  {
    name: 'SQL Injection Prevention',
    description: 'Secure database query handling in Ruby',
    code: `# VULNERABLE: SQL Injection risk
def find_user_vulnerable(username)
  query = "SELECT * FROM users WHERE username = '#{username}'"
  User.find_by_sql(query)
end

# SECURE: Using ActiveRecord or prepared statements
def find_user_secure(username)
  # Using ActiveRecord
  User.where(username: username)
  
  # Or using prepared statements
  stmt = db.prepare("SELECT * FROM users WHERE username = ?")
  stmt.execute(username)
end`,
  },
  {
    name: 'Secure Cookie Handling',
    description: 'Implementing secure cookie settings in Rails',
    code: `# config/initializers/session_store.rb

# VULNERABLE: Insecure cookie settings
Rails.application.config.session_store :cookie_store, 
  key: '_app_session'

# SECURE: Proper cookie security settings
Rails.application.config.session_store :cookie_store, 
  key: '_app_session',
  secure: Rails.env.production?, # Ensures HTTPS-only in production
  httponly: true,              # Prevents JavaScript access
  same_site: :strict,          # Prevents CSRF
  expire_after: 12.hours      # Limited session duration`,
  },
  {
    name: 'File Upload Security',
    description: 'Secure file upload handling in Ruby',
    code: `# VULNERABLE: Unsafe file handling
def unsafe_upload
  uploaded_file = params[:file]
  File.open(Rails.root.join('public', uploaded_file.original_filename), 'wb') do |file|
    file.write(uploaded_file.read)
  end
end

# SECURE: Safe file upload handling
def secure_upload
  uploaded_file = params[:file]
  
  # Validate file type
  unless valid_mime_type?(uploaded_file)
    raise "Invalid file type"
  end
  
  # Generate secure filename
  secure_filename = SecureRandom.uuid + File.extname(uploaded_file.original_filename)
  
  # Validate file size
  max_size = 10.megabytes
  if uploaded_file.size > max_size
    raise "File too large"
  end
  
  # Save file securely
  File.open(Rails.root.join('storage', secure_filename), 'wb') do |file|
    file.write(uploaded_file.read)
  end
end

private

def valid_mime_type?(file)
  allowed_types = ['image/jpeg', 'image/png', 'application/pdf']
  allowed_types.include?(Marcel::MimeType.for(file))
end`,
  }
];
