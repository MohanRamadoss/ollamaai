import { CodeExample } from '../../../types/security';

export const phpExamples: CodeExample[] = [
  {
    name: 'SQL Injection Prevention',
    description: 'Secure database operations in PHP',
    code: `<?php
// VULNERABLE: SQL Injection risk
function getUserUnsafe($username) {
    $conn = new mysqli("localhost", "user", "pass", "db");
    $query = "SELECT * FROM users WHERE username = '$username'";
    return $conn->query($query);
}

// SECURE: Using prepared statements
function getUserSafe($username) {
    $conn = new mysqli("localhost", "user", "pass", "db");
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    return $stmt->get_result();
}`,
  },
  {
    name: 'XSS Prevention',
    description: 'Cross-Site Scripting prevention',
    code: `<?php
// VULNERABLE: XSS risk
function displayNameUnsafe($name) {
    echo "<div>Welcome, $name!</div>";
}

// SECURE: Using proper escaping
function displayNameSafe($name) {
    $safe_name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
    echo "<div>Welcome, $safe_name!</div>";
}

// SECURE: Using modern context-aware escaping
function displayNameSecure($name) {
    $encoder = new HTMLPurifier();
    $safe_name = $encoder->purify($name);
    echo "<div>Welcome, $safe_name!</div>";
}`,
  }
];
