import { CodeExample } from '../../../types/security';

export const terraformExamples: CodeExample[] = [
  {
    name: 'Secure Cloud Storage Configuration',
    description: 'Implementing secure S3 bucket policies',
    code: String.raw`# VULNERABLE: Insecure S3 bucket configuration
resource "aws_s3_bucket" "vulnerable_bucket" {
  bucket = "my-sensitive-data-bucket"
  acl    = "public-read"  # ISSUE: Public access

  versioning {
    enabled = false  # ISSUE: No versioning
  }
}

# SECURE: Properly configured S3 bucket
resource "aws_s3_bucket" "secure_bucket" {
  bucket = "my-sensitive-data-bucket"
  acl    = "private"

  versioning {
    enabled = true
  }

  server_side_encryption_configuration {
    rule {
      apply_server_side_encryption_by_default {
        sse_algorithm = "AES256"
      }
    }
  }

  logging {
    target_bucket = aws_s3_bucket.log_bucket.id
    target_prefix = "log/"
  }
}`
  },
  {
    name: 'Network Security Groups',
    description: 'Secure network access controls',
    code: String.raw`# VULNERABLE: Overly permissive security group
resource "aws_security_group" "vulnerable_sg" {
  name        = "allow_all"
  description = "Allow all inbound traffic"

  ingress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]  # ISSUE: Open to world
  }
}

# SECURE: Properly restricted security group
resource "aws_security_group" "secure_sg" {
  name        = "restricted_access"
  description = "Allow specific inbound traffic"

  ingress {
    description = "HTTPS"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }

  ingress {
    description = "SSH from bastion"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    security_groups = [var.bastion_sg_id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = [var.vpc_cidr]
  }

  tags = {
    Name = "secure-sg"
    Environment = var.environment
  }
}`
  },
  {
    name: 'Secure State Management',
    description: 'Secure handling of Terraform state',
    code: String.raw`# VULNERABLE: Insecure state storage
terraform {
  backend "local" {
    path = "terraform.tfstate"  # ISSUE: Local state storage
  }
}

# SECURE: Encrypted remote state with access logging
terraform {
  backend "s3" {
    bucket         = "terraform-state-prod"
    key            = "global/s3/terraform.tfstate"
    region         = "us-west-2"
    encrypt        = true
    kms_key_id     = "arn:aws:kms:us-west-2:ACCOUNT-ID:key/KEY-ID"
    dynamodb_table = "terraform-locks"
  }
}

# Additional security measures
resource "aws_kms_key" "terraform_state_key" {
  description             = "KMS key for Terraform state"
  deletion_window_in_days = 7
  enable_key_rotation     = true

  policy = {
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "Enable IAM User Permissions"
        Effect = "Allow"
        Principal = {
          AWS = "*"
        }
        Action   = "kms:*"
        Resource = "*"
      }
    ]
  }
}`
  }
];
