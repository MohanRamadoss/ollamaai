import { CodeExample } from '../../../types/security';

export const pythonExamples: CodeExample[] = [
  {
    name: 'SQL Injection Prevention',
    description: 'Example showing vulnerable vs secure SQL query handling',
    code: `# Vulnerable to SQL Injection
def get_user_vulnerable(username):
    cursor.execute("SELECT * FROM users WHERE username = '" + username + "'")
    return cursor.fetchone()

# Secure way using parameterized queries
def get_user_secure(username):
    cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
    return cursor.fetchone()`,
  },
  {
    name: 'Password Hashing',
    description: 'Secure password storage using modern hashing',
    code: `import hashlib
import os
from argon2 import PasswordHasher

# Vulnerable - using MD5
def hash_password_vulnerable(password):
    return hashlib.md5(password.encode()).hexdigest()

# Secure - using Argon2
def hash_password_secure(password):
    ph = PasswordHasher()
    return ph.hash(password)

def verify_password(password, hash):
    ph = PasswordHasher()
    try:
        return ph.verify(hash, password)
    except:
        return False`,
  },
  {
    name: 'File Path Traversal Prevention',
    description: 'Preventing path traversal attacks',
    code: `import os
from pathlib import Path

# Vulnerable to path traversal
def read_file_vulnerable(filename):
    with open(filename) as f:
        return f.read()

# Secure way with path validation
def read_file_secure(filename):
    base_dir = '/safe/path'
    try:
        safe_path = Path(base_dir).resolve() / filename
        if not str(safe_path).startswith(str(Path(base_dir).resolve())):
            raise ValueError("Path traversal detected")
        with open(safe_path) as f:
            return f.read()
    except (ValueError, OSError) as e:
        raise ValueError(f"Invalid file access: {e}")`,
  }
];
