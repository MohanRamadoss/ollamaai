import { CodeExample } from '../../../types/security';

export const powershellExamples: CodeExample[] = [
  {
    name: 'Secure Credential Handling',
    description: 'Secure handling of credentials in PowerShell',
    code: `# VULNERABLE: Plain text credentials
$password = "SuperSecret123"
$username = "admin"

# SECURE: Using SecureString and credentials
$securePassword = ConvertTo-SecureString "SuperSecret123" -AsPlainText -Force
$credentials = New-Object System.Management.Automation.PSCredential($username, $securePassword)

# SECURE: Reading credentials securely
function Get-SecureCredentials {
    $credentials = Get-Credential
    return $credentials
}

# Using secure credentials
$result = Invoke-Command -ComputerName "server" -Credential $credentials -ScriptBlock {
    # Secure operations
}`,
  },
  {
    name: 'Command Injection Prevention',
    description: 'Preventing command injection in PowerShell scripts',
    code: `# VULNERABLE: Command injection risk
function Invoke-UnsafeCommand {
    param($userInput)
    Invoke-Expression "Get-Process $userInput"  # Dangerous
}

# SECURE: Using proper parameter handling
function Invoke-SafeCommand {
    param(
        [Parameter(Mandatory=$true)]
        [ValidatePattern("^[a-zA-Z0-9_-]+$")]
        [string]$ProcessName
    )
    Get-Process -Name $ProcessName
}

# SECURE: Using argument list
function Start-SafeProcess {
    param($Command, $Arguments)
    & $Command $Arguments
}`,
  }
];
