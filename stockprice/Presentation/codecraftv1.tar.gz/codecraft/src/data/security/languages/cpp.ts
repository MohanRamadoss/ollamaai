import { CodeExample } from '../../../types/security';

export const cppExamples: CodeExample[] = [
  {
    name: 'Buffer Overflow Prevention',
    description: 'Preventing buffer overflow vulnerabilities',
    code: `// VULNERABLE: Buffer overflow risk
void vulnerable_copy(char* input) {
    char buffer[10];
    strcpy(buffer, input);  // No bounds checking
}

// SECURE: Safe string handling
void secure_copy(const char* input) {
    char buffer[10];
    strncpy(buffer, input, sizeof(buffer) - 1);
    buffer[sizeof(buffer) - 1] = '\\0';  // Ensure null termination
    
    // Modern C++ approach
    std::string secure_str(input);
    std::string_view sv(secure_str);  // Use string_view for read-only ops
}`,
  },
  {
    name: 'Memory Management Security',
    description: 'Secure memory handling and RAII principles',
    code: `// VULNERABLE: Manual memory management
class UnsafeResource {
    char* data;
public:
    UnsafeResource() {
        data = new char[100];  // Potential memory leak
    }
    // Missing destructor
};

// SECURE: RAII and smart pointers
class SafeResource {
private:
    std::unique_ptr<char[]> data;
    std::mutex mutex;
public:
    SafeResource() : data(std::make_unique<char[]>(100)) {
        // Resource automatically cleaned up
    }
    
    void process_data() {
        std::lock_guard<std::mutex> lock(mutex);  // RAII lock management
        // Process data safely
    }
    // No need for destructor - RAII handles cleanup
};`,
  },
  {
    name: 'Integer Overflow Protection',
    description: 'Preventing integer overflow vulnerabilities',
    code: `// VULNERABLE: Integer overflow
void vulnerable_allocation(size_t n) {
    int* array = new int[n * sizeof(int)];  // Overflow possible
    // Use array...
    delete[] array;
}

// SECURE: Safe integer operations
#include <limits>

template<typename T>
bool safe_multiply(T a, T b, T* result) {
    if (a > 0) {
        if (b > std::numeric_limits<T>::max() / a) {
            return false;  // Would overflow
        }
    } else if (a < 0) {
        if (b < std::numeric_limits<T>::max() / a) {
            return false;  // Would overflow
        }
    }
    *result = a * b;
    return true;
}

void secure_allocation(size_t n) {
    size_t size;
    if (!safe_multiply(n, sizeof(int), &size)) {
        throw std::overflow_error("allocation would overflow");
    }
    
    std::vector<int> array(n);  // Safe allocation with vector
}`,
  }
];
