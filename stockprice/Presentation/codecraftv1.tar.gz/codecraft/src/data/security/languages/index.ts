import { pythonExamples } from './python';
import { javascriptExamples } from './javascript';
import { typeScriptExamples } from './typescript';
import { javaExamples } from './java';
import { goExamples } from './go';
import { rubyExamples } from './ruby';
import { ansibleExamples } from './ansible';
import { bashExamples } from './bash';
import { cppExamples } from './cpp';
import { csharpExamples } from './csharp';
import { kotlinExamples } from './kotlin';
import { juliaExamples } from './julia';
import { perlExamples } from './perl';
import { phpExamples } from './php';
import { powershellExamples } from './powershell';
import { rustExamples } from './rust';
import { terraformExamples } from './terraform';

export const languageExamples = {
  python: pythonExamples,
  javascript: javascriptExamples,
  typescript: typeScriptExamples,
  java: javaExamples,
  go: goExamples,
  ruby: rubyExamples,
  ansible: ansibleExamples,
  bash: bashExamples,
  cpp: cppExamples,
  csharp: csharpExamples,
  kotlin: kotlinExamples,
  julia: juliaExamples,
  perl: perlExamples,
  php: phpExamples,
  powershell: powershellExamples,
  rust: rustExamples,
  terraform: terraformExamples
};

export const getExamplesForLanguage = (language: string): any[] => {
  return languageExamples[language.toLowerCase()] || [];
};
