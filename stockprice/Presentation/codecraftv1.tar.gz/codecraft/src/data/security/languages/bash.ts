import { CodeExample } from '../../../types/security';

export const bashExamples: CodeExample[] = [
  {
    name: 'Command Injection Prevention',
    description: 'Preventing command injection vulnerabilities',
    code: String.raw`#!/bin/bash

# VULNERABLE: Command injection risk
function unsafe_command() {
    user_input=$1
    eval "echo Hello $user_input"  # Dangerous eval usage
}

# SECURE: Safe command handling
function safe_command() {
    user_input=$1
    printf "Hello %s\n" "$user_input"
}`
  },
  {
    name: 'File System Security',
    description: 'Safe handling of files and directories',
    code: String.raw`#!/bin/bash

# VULNERABLE: Unsafe file operations
function unsafe_file_ops() {
    dir=$1
    file=$2
    
    # Race condition in file checks
    if [ -f "$file" ]; then
        sleep 1
        rm "$file"  # TOCTOU vulnerability
    fi
    
    # Unsafe permissions
    chmod 777 "$dir"
}

# SECURE: Safe file operations
function safe_file_ops() {
    dir=$1
    file=$2
    
    # Validate paths
    if [[ ! "$dir" =~ ^[a-zA-Z0-9/_-]+$ ]]; then
        echo "Invalid directory path"
        return 1
    fi
    
    # Use atomic operations
    mv -n "$file" "$file.new" || {
        echo "File operation failed"
        return 1
    }
    
    # Set secure permissions
    chmod 600 "$file.new"
}`
  },
  {
    name: 'Path Traversal Prevention',
    description: 'Preventing directory traversal attacks',
    code: String.raw`#!/bin/bash

# VULNERABLE: Path traversal vectors
function unsafe_path() {
    input_path=$1
    cat "../$input_path"  # Potential path traversal
}

# SECURE: Safe path handling
function safe_path() {
    input_path=$1
    safe_root="/var/www/files"
    
    # Normalize and validate path
    full_path=$(realpath -q "$safe_root/$input_path")
    
    if [[ "$full_path" != "$safe_root"/* ]]; then
        echo "Path traversal detected"
        return 1
    fi
    
    if [ -f "$full_path" ]; then
        cat "$full_path"
    fi
}`
  },
  {
    name: 'Secure Configuration',
    description: 'Secure system configuration',
    code: String.raw`#!/bin/bash

# VULNERABLE: Insecure configuration
function unsafe_config() {
    echo "data" > /etc/app.conf
    chmod 666 /etc/app.conf  # World-writable
    PATH=.:$PATH            # Dangerous PATH
}

# SECURE: Safe configuration
function safe_config() {
    # Secure file permissions
    echo "data" > /etc/app.conf
    chmod 600 /etc/app.conf
    chown root:root /etc/app.conf
    
    # Safe PATH setting
    PATH=/usr/local/bin:/usr/bin:/bin
    
    # Validate configuration
    if [ ! -f /etc/app.conf ]; then
        echo "Configuration missing"
        return 1
    fi
}`
  }
];
