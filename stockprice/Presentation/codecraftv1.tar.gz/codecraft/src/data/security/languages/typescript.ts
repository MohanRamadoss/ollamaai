export const typeScriptExamples = [
  {
    name: 'Type-based SQL Injection',
    description: 'Example showing SQL injection in TypeScript',
    code: `// Vulnerable Code
interface UserInput {
  username: string;
  password: string;
}

async function login(input: UserInput) {
  const query = \`SELECT * FROM users WHERE username = '\${input.username}' AND password = '\${input.password}'\`;
  return await db.execute(query);
}`,
    securityContext: {
      riskLevel: 'critical',
      vulnerabilityType: 'sql-injection'
    }
  },
  {
    name: 'Secure Parameterized Query',
    description: 'Example of secure parameterized query in TypeScript',
    code: `// Secure Code
interface UserInput {
  username: string;
  password: string;
}

async function login(input: UserInput) {
  const query = 'SELECT * FROM users WHERE username = ? AND password = ?';
  return await db.execute(query, [input.username, input.password]);
}`,
    securityContext: {
      riskLevel: 'low',
      vulnerabilityType: 'sql-injection'
    }
  },
  {
    name: 'CSRF Protection',
    description: 'Example of CSRF token implementation',
    code: `// Secure Code
interface CSRFProtection {
  token: string;
  validate(token: string): boolean;
}

class CSRFMiddleware {
  validateToken(req: Request, res: Response, next: NextFunction) {
    const token = req.headers['csrf-token'];
    if (!token || !csrfProtection.validate(token)) {
      return res.status(403).json({ error: 'Invalid CSRF token' });
    }
    next();
  }
}`,
    securityContext: {
      riskLevel: 'medium',
      vulnerabilityType: 'csrf'
    }
  }
];
