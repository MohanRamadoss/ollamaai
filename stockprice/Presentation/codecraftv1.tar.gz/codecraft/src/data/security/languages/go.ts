import { CodeExample } from '../../../types/security';

export const goExamples: CodeExample[] = [
  {
    name: 'SQL Injection Prevention',
    description: 'Secure database query handling in Go',
    code: `package main

// Vulnerable database query
func getUserVulnerable(db *sql.DB, username string) (*User, error) {
    // UNSAFE: Direct string concatenation
    query := "SELECT * FROM users WHERE username = '" + username + "'"
    row := db.QueryRow(query)
    return scanUser(row)
}

// Secure database query
func getUserSecure(db *sql.DB, username string) (*User, error) {
    // SAFE: Using parameterized query
    query := "SELECT * FROM users WHERE username = ?"
    row := db.QueryRow(query, username)
    return scanUser(row)
}`,
  },
  {
    name: 'JWT Token Security',
    description: 'Secure JWT token handling and validation',
    code: `package main

import (
    "github.com/golang-jwt/jwt"
    "time"
)

// VULNERABLE: Weak JWT implementation
func createTokenVulnerable(userID string) string {
    // ISSUES: 
    // - Weak algorithm (none)
    // - No expiration
    // - Hardcoded secret
    token := jwt.NewWithClaims(jwt.SigningMethodNone, jwt.MapClaims{
        "user_id": userID,
    })
    tokenString, _ := token.SignedString([]byte("secret"))
    return tokenString
}

// SECURE: Strong JWT implementation
func createTokenSecure(userID string) (string, error) {
    claims := jwt.MapClaims{
        "user_id": userID,
        "exp": time.Now().Add(time.Hour * 24).Unix(),
        "iat": time.Now().Unix(),
    }
    
    token := jwt.NewWithClaims(jwt.SigningMethodHS512, claims)
    return token.SignedString(getSecretKey())
}

func validateTokenSecure(tokenString string) (*jwt.Token, error) {
    return jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
        if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
            return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
        }
        return getSecretKey(), nil
    })
}`,
  },
  {
    name: 'Secure File Operations',
    description: 'Safe file handling and upload validation',
    code: `package main

import (
    "io"
    "mime/multipart"
    "path/filepath"
    "strings"
)

// VULNERABLE: Unsafe file handling
func saveFileVulnerable(file multipart.File, filename string) error {
    // ISSUES:
    // - No file type validation
    // - No size limits
    // - Path traversal possible
    dst, err := os.Create(filename)
    if err != nil {
        return err
    }
    defer dst.Close()
    
    _, err = io.Copy(dst, file)
    return err
}

// SECURE: Safe file handling
func saveFileSecure(file multipart.File, filename string) error {
    // Validate file size
    const maxSize = 10 << 20 // 10MB
    limitedReader := io.LimitReader(file, maxSize)
    
    // Validate file extension
    ext := strings.ToLower(filepath.Ext(filename))
    allowedExts := map[string]bool{".jpg": true, ".png": true, ".pdf": true}
    if !allowedExts[ext] {
        return fmt.Errorf("unsupported file type: %s", ext)
    }
    
    // Create safe filename
    safeFilename := filepath.Base(filename)
    uploadPath := filepath.Join("uploads", safeFilename)
    
    // Ensure path is within uploads directory
    if !strings.HasPrefix(filepath.Clean(uploadPath), "uploads/") {
        return fmt.Errorf("invalid file path")
    }
    
    dst, err := os.Create(uploadPath)
    if err != nil {
        return err
    }
    defer dst.Close()
    
    _, err = io.Copy(dst, limitedReader)
    return err
}`,
  }
];
