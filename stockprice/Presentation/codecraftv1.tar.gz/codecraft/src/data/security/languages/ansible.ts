import { CodeExample } from '../../../types/security';

export const ansibleExamples: CodeExample[] = [
  {
    name: 'Secure Database Configuration',
    description: 'Implementing secure database server setup',
    code: `---
# VULNERABLE: Insecure database configuration
- name: Setup Database
  hosts: db_servers
  vars:
    mysql_password: "admin123"  # ISSUE: Hardcoded password
  
  tasks:
    - name: Configure MySQL
      mysql_user:
        name: root
        password: "{{ mysql_password }}"
        host: "%"  # ISSUE: Too permissive

# SECURE: Proper database configuration
- name: Setup Database Securely
  hosts: db_servers
  vars_files:
    - vault/secrets.yml  # Encrypted secrets
  
  tasks:
    - name: Configure MySQL securely
      mysql_user:
        name: "{{ db_user }}"
        password: "{{ vault_db_password }}"
        host: "localhost"
        priv: "{{ db_name }}.*:SELECT,INSERT,UPDATE,DELETE"
        
    - name: Set secure permissions
      file:
        path: /etc/mysql/my.cnf
        mode: '0600'
        owner: mysql
        group: mysql`,
  },
  {
    name: 'SSH Hardening',
    description: 'Secure SSH server configuration',
    code: `---
# VULNERABLE: Basic SSH setup
- name: Configure SSH
  hosts: all
  tasks:
    - name: Install SSH
      apt: name=openssh-server

# SECURE: Hardened SSH configuration
- name: Configure SSH Securely
  hosts: all
  vars:
    ssh_port: 22222
    allowed_users: ["admin", "deploy"]
    
  tasks:
    - name: Install SSH
      apt: 
        name: openssh-server
        state: present
        update_cache: yes
        
    - name: Configure SSH
      template:
        src: sshd_config.j2
        dest: /etc/ssh/sshd_config
        mode: '0600'
        validate: '/usr/sbin/sshd -t -f %s'
      notify: restart ssh
      
    - name: Set SSH allowed users
      lineinfile:
        path: /etc/ssh/sshd_config
        line: "AllowUsers {{ allowed_users | join(' ') }}"
        
    - name: Disable password authentication
      lineinfile:
        path: /etc/ssh/sshd_config
        regexp: '^PasswordAuthentication'
        line: 'PasswordAuthentication no'
        
  handlers:
    - name: restart ssh
      service:
        name: ssh
        state: restarted`,
  }
];
