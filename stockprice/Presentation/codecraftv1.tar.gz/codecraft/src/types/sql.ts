export type SQLDialect = 'postgresql' | 'mysql' | 'sqlite' | 'mssql' | 'oracle';

export interface SQLGenerationResult {
  query: string;
  explanation?: string;
  optimizations?: {
    indexRecommendations?: string[];
    queryPlan?: string;
    partitioningStrategy?: string;
    replicationSetup?: string;
  };
}

export interface OptimizationFeatures {
  indexDesign: boolean;
  queryTuning: boolean;
  partitioning: boolean;
  replication: boolean;
}

export interface SQLExample {
  title: string;
  description: string;
  schema?: string;
  dialect: SQLDialect;
  complexity: 'basic' | 'intermediate' | 'advanced';
}