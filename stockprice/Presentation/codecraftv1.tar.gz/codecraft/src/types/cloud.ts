export type CloudProvider = 'aws' | 'azure' | 'gcp';

export type ResourceType =
  | 'terraform'
  | 'cloudformation'
  | 'azurearm'
  | 'gcpdeployment'
  | 'kubernetes'
  | 'serverless'
  | 'database'
  | 'storage'
  | 'networking';

// ...existing interfaces and types...

export interface ProviderResourceTypes {
  aws: ResourceType[];
  azure: ResourceType[];
  gcp: ResourceType[];
}

export const PROVIDER_RESOURCE_MAPPING: Record<CloudProvider, ResourceType[]> = {
  aws: [
    'terraform',
    'cloudformation',
    'kubernetes',
    'serverless',
    'database',
    'storage',
    'networking'
  ],
  azure: [
    'terraform',
    'azurearm',
    'kubernetes',
    'serverless',
    'database',
    'storage',
    'networking'
  ],
  gcp: [
    'terraform',
    'gcpdeployment',
    'kubernetes',
    'serverless',
    'database',
    'storage',
    'networking'
  ]
};

// Add provider-specific display names
export const PROVIDER_SPECIFIC_NAMES: Record<CloudProvider, Record<ResourceType, string>> = {
  aws: {
    terraform: 'Terraform',
    cloudformation: 'CloudFormation',
    kubernetes: 'Kubernetes Resources',
    serverless: 'Serverless Resources',
    database: 'Database Resources',
    storage: 'Storage Resources',
    networking: 'Network Resources'
  },
  azure: {
    terraform: 'Terraform',
    azurearm: 'Azure ARM Templates',
    kubernetes: 'AKS Resources',
    serverless: 'Azure Functions',
    database: 'Azure Database',
    storage: 'Azure Storage',
    networking: 'Azure Network'
  },
  gcp: {
    terraform: 'Terraform',
    gcpdeployment: 'Cloud Deployment Manager',
    kubernetes: 'GKE Resources',
    serverless: 'Cloud Functions',
    database: 'Cloud SQL',
    storage: 'Cloud Storage',
    networking: 'VPC Network'
  }
};

export type ProgressCallback = (
  progress: Record<string, CloudProgress>,
  output?: string
) => void;