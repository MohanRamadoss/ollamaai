export type PromptCategory = 'code' | 'conversion' | 'documentation' | 'testing' | 'optimization' | 'custom';
export type ComplexityLevel = 'basic' | 'intermediate' | 'advanced';

export type ProgrammingLanguage = 
  // Standard Programming Languages
  | 'javascript'
  | 'python'
  | 'java'
  | 'typescript'
  | 'julia'
  | 'go'
  | 'rust'
  | 'csharp'
  | 'swift'
  | 'cpp'
  | 'r'
  | 'php'
  | 'ruby'
  | 'perl'
  // Infrastructure & Automation
  | 'ansible'
  | 'terraform'
  | 'cloudformation'
  | 'arm'
  | 'pulumi'
  | 'powershell'
  | 'bash'
  | 'shell'
  | 'docker'
  | 'kubernetes'
  | 'helm'
  | 'puppet'
  | 'chef'
  | 'bicep'
  | 'serverless'
  | 'gitlab-ci'
  | 'github-actions';

export interface PromptModel {
  id: string;
  name: string;
  provider: 'google' | 'ollama';
  description: string;
  maxTokens: number;
  defaultParams: PromptGenerationParams;
}

export interface PromptGenerationParams {
  temperature: number;
  topP: number;
  topK: number;
  maxTokens: number;
}

export interface PromptTemplate {
  id: string;
  title: string;
  description: string;
  category: PromptCategory;
  template: string;
  language?: ProgrammingLanguage;
  complexity?: ComplexityLevel;
  variables: PromptVariable[];
}

export interface PromptVariable {
  name: string;
  description: string;
  required: boolean;
  defaultValue?: string;
}

export interface PromptProgress {
  modelId: string;
  status: 'idle' | 'generating' | 'completed' | 'failed';
  progress: number;
  error?: string;
}
