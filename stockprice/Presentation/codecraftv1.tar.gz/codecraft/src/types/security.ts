export interface SecurityIssue {
  type: 'critical' | 'high' | 'medium' | 'low' | 'info';
  category: string;
  title: string;
  description: string;
  line?: number;
  recommendation?: string;
  cwe?: string;
  cvss?: number;
}

export type SecurityScanType = 'quick' | 'full' | 'deep';
export type SecurityCategory = 'vulnerabilities' | 'dependencies' | 'secrets' | 'compliance' | 'bestPractices';

export interface SecurityMetrics {
  score: number;
  criticalIssues: number;
  highIssues: number;
  mediumIssues: number;
  lowIssues: number;
  passedChecks: number;
  failedChecks: number;
}

export interface SecurityScanSummary {
  critical: number;
  high: number;
  medium: number;
  low: number;
  info: number;
}

export interface SecurityScanResult {
  issues: SecurityIssue[];
  summary: SecurityScanSummary;
  scanDuration: number;
}

export interface CodeExample {
  name: string;
  description: string;
  code: string;
  securityContext?: {
    riskLevel: 'critical' | 'high' | 'medium' | 'low';
    vulnerabilityType: string;
  };
}

export type AnalysisProgress = {
  modelId: string;
  status: 'pending' | 'analyzing' | 'completed' | 'failed';
  progress: number;
  result?: {
    issues: SecurityIssue[];
    metrics: SecurityMetrics;
  };
  error?: string;
};
