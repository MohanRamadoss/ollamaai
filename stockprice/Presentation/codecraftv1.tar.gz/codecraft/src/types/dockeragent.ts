export type ComplexityLevel = 'basic' | 'intermediate' | 'advanced';

export type DockerAgentStatus = 'idle' | 'running' | 'completed' | 'failed';

export interface DockerOperation {
  id: string;
  name: string;
  description: string;
  complexity: ComplexityLevel;
}

export interface DockerAgentProgress {
  modelId: string;
  status: DockerAgentStatus;
  progress: number;
  result?: string;
  error?: string;
}

export interface DockerAgentConfig {
  modelId: string;
  operation: string;
  containerName: string;
  imageName: string;
  dockerCompose?: string;
  options?: {
    temperature?: number;
    maxTokens?: number;
  };
}

export interface DockerAgentResult {
  output: string;
  status: 'success' | 'error';
  error?: string;
  metrics?: {
    executionTime: number;
    resourceUsage: {
      cpu: string;
      memory: string;
    };
  };
}

export interface DockerPromptParams {
  host: string;
  port: number;
  containerName?: string;
  yaml?: string;
}

export interface DockerAgentOptions {
  modelIds: string[];
  operation: string;
  containerName: string;
  imageName: string;
  dockerCompose?: string;
  complexity: ComplexityLevel;
  host?: string;
  port?: number;
}

// Add new interface for Docker version info
export interface DockerVersionInfo {
  Version: string;
  ApiVersion: string;
  Platform?: {
    Name: string;
  };
  Components?: Array<{
    Name: string;
    Version: string;
    Details?: {
      ApiVersion?: string;
      Arch?: string;
      BuildTime?: string;
      Os?: string;
    };
  }>;
  Os?: string;
  Arch?: string;
  BuildTime?: string;
}
