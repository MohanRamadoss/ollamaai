import { Model } from './index';

// Core type definitions
export type Platform = 'github' | 'gitlab' | 'azure-devops' | 'jenkins';
export type PipelineType = 'build' | 'test' | 'deploy' | 'monitor';
export type PipelineFormat = 'yaml' | 'groovy';

// Progress and options interfaces
export interface CICDProgress {
  modelId: string;
  status: 'pending' | 'generating' | 'completed' | 'failed';
  progress: number;
  result?: string;
  error?: string;
}

export interface CICDOptions {
  temperature?: number;
  topP?: number;
  topK?: number;
  maxTokens?: number;
  stream?: boolean;
}

export interface CICDRequest {
  modelIds: string[];
  platform: Platform;
  pipelineType: PipelineType;
  complexity: string;
  requirements: string;
  options?: CICDOptions;
}

// Platform and Pipeline interfaces
export interface PlatformConfig {
  name: string;
  fileFormat: PipelineFormat;
  templates: Record<PipelineType, string>;
}

export interface PipelineResource {
  platform: Platform;
  type: PipelineType;
  name: string;
  description: string;
}

// Generation request and result interfaces
export interface CICDGenerationRequest {
  platform: Platform;
  pipelineType: PipelineType;
  requirements: string;
  model: Model;
  complexity: ComplexityLevel;
  format?: PipelineFormat;
}

export interface CICDGenerationResult {
  code: string;
  explanation: string;
  bestPractices: string[];
  securityChecks: string[];
  automationSteps: string[];
  validationResults?: {
    passed: string[];
    warnings: string[];
    failed: string[];
  };
  performanceMetrics?: {
    estimatedDuration: number;
    resourceUsage: {
      cpu?: string;
      memory?: string;
      storage?: string;
    };
    concurrency: number;
  };
}

export interface CICDGenerationParams {
  platform: Platform;
  pipelineType: PipelineType;
  requirements: string;
  model: string;
}

// Complexity descriptions
export const COMPLEXITY_DESCRIPTIONS: Record<ComplexityLevel, string> = {
  basic: 'Single-stage pipelines with essential steps (e.g., basic build and test)',
  intermediate: 'Multi-stage pipelines with environments and basic security checks',
  advanced: 'Enterprise-grade pipelines with advanced features, security, and monitoring'
};