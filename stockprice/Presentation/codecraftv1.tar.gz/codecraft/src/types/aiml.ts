export type AIMLModel = 
  | 'falcon3:10b'
  | 'deepseek-coder:33b'
  | 'llama3.3:latest';

export type AIMLLanguage = 
  | 'python'
  | 'r'
  | 'sql'
  | 'java'
  | 'julia'
  | 'scala'
  | 'cpp'
  | 'javascript'
  | 'swift'
  | 'go'
  | 'matlab'
  | 'sas';

export type AIMLTask = keyof typeof import('../config/aiml').AIML_TASKS;

export type ComplexityLevel = 'basic' | 'intermediate' | 'advanced';

export interface AIMLRequest {
  model: AIMLModel;
  language: AIMLLanguage;
  task: AIMLTask;
  code: string;
  requirements?: string[];
  datasetInfo?: {
    type: string;
    size: string;
    features: string[];
  };
  complexity: ComplexityLevel;
}

export interface AIMLResponse {
  code: string;
  explanation: string;
  performance?: {
    timeComplexity: string;
    spaceComplexity: string;
    optimizationTips: string[];
  };
  modelArchitecture?: {
    layers: string[];
    parameters: number;
    framework: string;
  };
}

export interface AIMLGenerateParams {
  model: string;
  language: AIMLLanguage;
  task: string;
  complexity: ComplexityLevel;
  prompt: string;
  parameters: {
    temperature: number;
    topP: number;
    maxTokens: number;
  };
}