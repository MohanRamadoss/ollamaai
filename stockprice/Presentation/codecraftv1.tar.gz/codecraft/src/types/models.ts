export interface AIModel {
  id: string;
  name: string;
  provider: string;
  features: string[];
  maxTokens?: number; // Add maxTokens property
  supportsStreaming?: boolean;
  priority?: number;
  description?: string;
  modelIdentifier?: string; // Add modelIdentifier property
}

export type ProgrammingLanguage = {
  id: string;
  name: string;
  features: string[];
  extension: string;
  icon: string;
  category?: 'config' | 'programming';
};

export type ComplexityLevel = 'basic' | 'intermediate' | 'advanced';

export type AnalysisType = 
  | 'analyze'
  | 'test'
  | 'debug'
  | 'optimize'
  | 'refactor'
  | 'document'
  | 'best-practices'
  | 'style-check';

export interface AnalysisRequest extends GenerationRequest {
  action: AnalysisType;
  complexity: ComplexityLevel;
}

export interface AnalysisResult {
  type: 'error' | 'warning' | 'info' | 'success';
  message: string;
  line?: number;
  suggestion?: string;
}

export interface GenerationRequest {
  modelIds: string[];
  sourceLanguage: string;
  targetLanguage: string;
  prompt: string;
  complexity: ComplexityLevel;
  temperature?: number;
  maxTokens?: number;
  topP?: number;
  topK?: number;
}

export interface GenerationResult {
  code: string;
  modelProgress: Record<string, GenerationProgress>;
}

export type User = {
  id: string;
  email: string;
  name: string;
  avatar_url?: string;
};