export const SUPPORTED_LANGUAGES = {
  // Web Development
  javascript: { name: 'JavaScript', extensions: ['.js', '.jsx', '.mjs'], ace: 'javascript' },
  typescript: { name: 'TypeScript', extensions: ['.ts', '.tsx'], ace: 'typescript' },
  html: { name: 'HTML', extensions: ['.html', '.htm', '.xhtml'], ace: 'html' },
  css: { name: 'CSS', extensions: ['.css', '.scss', '.sass', '.less'], ace: 'css' },
  
  // Backend Languages
  python: { name: 'Python', extensions: ['.py', '.pyw', '.pyx'], ace: 'python' },
  java: { name: 'Java', extensions: ['.java', '.jar'], ace: 'java' },
  php: { name: 'PHP', extensions: ['.php', '.phtml', '.php3'], ace: 'php' },
  ruby: { name: 'Ruby', extensions: ['.rb', '.rbw', '.rake', '.gemspec'], ace: 'ruby' },
  go: { name: 'Go', extensions: ['.go'], ace: 'golang' },
  rust: { name: 'Rust', extensions: ['.rs', '.rlib'], ace: 'rust' },
  
  // Systems Programming
  cpp: { name: 'C++', extensions: ['.cpp', '.cc', '.cxx', '.hpp'], ace: 'c_cpp' },
  c: { name: 'C', extensions: ['.c', '.h'], ace: 'c_cpp' },
  csharp: { name: 'C#', extensions: ['.cs'], ace: 'csharp' },
  
  // Data & Config
  sql: { name: 'SQL', extensions: ['.sql'], ace: 'sql' },
  json: { name: 'JSON', extensions: ['.json'], ace: 'json' },
  yaml: { name: 'YAML', extensions: ['.yml', '.yaml'], ace: 'yaml' },
  xml: { name: 'XML', extensions: ['.xml', '.xsl', '.xsd'], ace: 'xml' },
  
  // Shell Scripting
  shell: { name: 'Shell Script', extensions: ['.sh', '.bash', '.zsh'], ace: 'sh' },
  powershell: { name: 'PowerShell', extensions: ['.ps1', '.psm1', '.psd1'], ace: 'powershell' },
  batch: { name: 'Batch', extensions: ['.bat', '.cmd'], ace: 'batchfile' },
  
  // Mobile Development
  kotlin: { name: 'Kotlin', extensions: ['.kt', '.kts'], ace: 'kotlin' },
  swift: { name: 'Swift', extensions: ['.swift'], ace: 'swift' },
  objectivec: { name: 'Objective-C', extensions: ['.m', '.mm'], ace: 'objectivec' },
  
  // Cloud & DevOps
  terraform: { name: 'Terraform', extensions: ['.tf', '.tfvars'], ace: 'terraform' },
  docker: { name: 'Dockerfile', extensions: ['Dockerfile', '.dockerfile'], ace: 'dockerfile' },
  kubernetes: { name: 'Kubernetes', extensions: ['.yaml', '.yml'], ace: 'yaml' },
  
  // Documentation
  markdown: { name: 'Markdown', extensions: ['.md', '.markdown'], ace: 'markdown' },
  tex: { name: 'LaTeX', extensions: ['.tex', '.sty', '.dtx'], ace: 'latex' },
  
  // Other Languages
  scala: { name: 'Scala', extensions: ['.scala', '.sc'], ace: 'scala' },
  perl: { name: 'Perl', extensions: ['.pl', '.pm', '.t'], ace: 'perl' },
  r: { name: 'R', extensions: ['.r', '.R'], ace: 'r' },
  dart: { name: 'Dart', extensions: ['.dart'], ace: 'dart' },
  lua: { name: 'Lua', extensions: ['.lua'], ace: 'lua' },
  julia: { name: 'Julia', extensions: ['.jl'], ace: 'julia' },
  
  // Frameworks & Templates
  vue: { name: 'Vue', extensions: ['.vue'], ace: 'vue' },
  svelte: { name: 'Svelte', extensions: ['.svelte'], ace: 'svelte' },
  handlebars: { name: 'Handlebars', extensions: ['.hbs', '.handlebars'], ace: 'handlebars' },
  
  // General Purpose
  plaintext: { name: 'Plain Text', extensions: ['.txt'], ace: 'text' }
} as const;

export type SupportedLanguage = keyof typeof SUPPORTED_LANGUAGES;

export interface LanguageInfo {
  name: string;
  extensions: string[];
  ace: string;
}

export function getLanguageByExtension(extension: string): SupportedLanguage | undefined {
  const normalizedExt = extension.toLowerCase().startsWith('.') ? extension : `.${extension}`;
  return Object.entries(SUPPORTED_LANGUAGES).find(([_, info]) => 
    info.extensions.includes(normalizedExt)
  )?.[0] as SupportedLanguage | undefined;
}

export function getLanguageInfo(language: SupportedLanguage): LanguageInfo {
  return SUPPORTED_LANGUAGES[language];
}

export function isValidLanguage(language: string): language is SupportedLanguage {
  return language in SUPPORTED_LANGUAGES;
}
