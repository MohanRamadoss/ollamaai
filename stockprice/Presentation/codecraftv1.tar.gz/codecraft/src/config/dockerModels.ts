import { AI_MODELS } from './models';

export const DOCKER_MODELS = [
  {
    id: 'gemini-pro-code',
    name: 'Gemini Pro Code',
    provider: 'google',
    description: 'Advanced code generation model from Google',
    contextWindow: 32768,
    similarities: ['codellama:13b'],
    maxOutputTokens: 8192,
    type: 'chat',
    modelIdentifier: 'gemini-pro',
    defaultParams: {
      temperature: 0.7,
      topP: 0.95,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'gemini-1.5-flash',
    name: 'Gemini 1.5 Flash',
    provider: 'google',
    description: 'Fast and efficient code conversion',
    contextWindow: 16384,
    similarities: ['codellama:13b'],
    maxOutputTokens: 4096,
    type: 'chat',
    modelIdentifier: 'gemini-1.5-pro',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/codellama:13b',
    name: 'CodeLlama 13B',
    provider: 'ollama',
    description: 'Meta\'s CodeLlama optimized for code generation',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/codellama:latest',
    name: 'CodeLlama Latest',
    provider: 'ollama',
    description: 'Latest version of Meta\'s CodeLlama optimized for code generation',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/deepseek-coder:6.7b',
    name: 'DeepSeek Coder 6.7B',
    provider: 'ollama',
    description: 'Fast and efficient code generation model',
    contextWindow: 8192,
    similarities: ['codellama:13b'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/deepseek-coder:33b',
    name: 'DeepSeek Coder 33B',
    provider: 'ollama',
    description: 'Advanced code generation and architecture design',
    contextWindow: 16384,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 8192,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 8192
    }
  },
  {
    id: 'ollama/deepseek-r1:14b',
    name: 'DeepSeek R1 14B',
    provider: 'ollama',
    description: 'Advanced code generation model',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/phi4:latest',
    name: 'Phi-4',
    provider: 'ollama',
    description: 'Efficient code generation with low resource usage',
    contextWindow: 4096,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/codeqwen:latest',
    name: 'CodeQwen',
    provider: 'ollama',
    description: 'Multilingual code generation model',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/codestral:latest',
    name: 'Codestral',
    provider: 'ollama',
    description: 'Code optimization focused model',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/codegemma:latest',
    name: 'CodeGemma',
    provider: 'ollama',
    description: 'Specialized code generation model',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/granite-code:8b',
    name: 'Granite Code 8B',
    provider: 'ollama',
    description: 'Lightweight code generation model',
    contextWindow: 4096,
    similarities: ['codellama:13b'],
    maxOutputTokens: 2048,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 2048
    }
  },
  {
    id: 'ollama/granite-code:20b',
    name: 'Granite Code 20B',
    provider: 'ollama',
    description: 'Advanced code generation and review',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/llama3.2:latest',
    name: 'Llama 3.2',
    provider: 'ollama',
    description: 'Stable Llama model for code generation',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/llama3.3:latest',
    name: 'Llama 3.3',
    provider: 'ollama',
    description: 'Latest Llama model optimized for code generation',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/mistral-small:latest',
    name: 'Mistral Small',
    provider: 'ollama',
    description: 'Efficient and compact Mistral model for code tasks',
    contextWindow: 8192,
    similarities: ['codellama:13b'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/mistral-nemo:latest',
    name: 'Mistral Nemo',
    provider: 'ollama',
    description: 'Optimized Mistral model for code generation',
    contextWindow: 8192,
    similarities: ['codellama:13b', 'mistral-small:latest'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  }
];

export const DEFAULT_DOCKER_MODEL = DOCKER_MODELS[0];

export const DOCKER_OPERATIONS = {
  LIST_CONTAINERS: 'List Containers',
  CONTAINER_STATUS: 'Container Status',
  VIEW_LOGS: 'View Logs',
  DEPLOY_CONTAINER: 'Deploy Container',
  CONTAINER_STATS: 'Container Stats'
} as const;

export const LOG_SEVERITY_PATTERNS = {
  error: [
    'ERROR',
    'Error:',
    'Failed',
    'Exception',
    'fatal',
    'panic'
  ],
  warning: [
    'WARN',
    'Warning:',
    'deprecated',
    'timeout',
    'retry'
  ],
  info: [
    'INFO',
    'Starting',
    'Started',
    'Listening',
    'Connected'
  ]
} as const;
