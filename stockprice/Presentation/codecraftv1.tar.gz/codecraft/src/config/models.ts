import type { AIModel } from '../types/models';

export interface ModelConfig {
  fallbacks: string[];
  timeout: number;
  temperature: number;
  provider: 'ollama' | 'google';
  modelName?: string; // Add optional modelName for Gemini models
  maxTokens?: number;
  contextTokens?: number;
}

export const MODEL_CONFIGS: Record<string, ModelConfig> = {
  "codellama": {
    fallbacks: ["codellama:13b", "codegemma"],
    timeout: 30,
    temperature: 0.7,
    provider: 'ollama'
  },
  "llama3.3:latest": {
    fallbacks: ["llama3.2:latest", "codellama"],
    timeout: 30,
    temperature: 0.3,
    provider: 'ollama',
    maxTokens: 4096,
    contextTokens: 16384
  },
  "llama3.2:latest": {
    fallbacks: ["codellama", "granite-code:20b"],
    timeout: 30,
    temperature: 0.3,
    provider: 'ollama',
    maxTokens: 4096,
    contextTokens: 8192
  },
  "codellama:13b": {
    fallbacks: ["granite-code:20b"],
    timeout: 30,
    temperature: 0.3,
    provider: 'ollama',
    maxTokens: 4096,
    contextTokens: 8192
  },
  "granite-code:8b": {
    fallbacks: ["codellama", "codegemma"],
    timeout: 30,
    temperature: 0.7,
    provider: 'ollama'
  },
  "granite-code:20b": {
    fallbacks: [],
    timeout: 30,
    temperature: 0.3,
    provider: 'ollama',
    maxTokens: 4096,
    contextTokens: 12288
  },
  "codegemma": {
    fallbacks: ["codellama", "codestral"],
    timeout: 30,
    temperature: 0.7,
    provider: 'ollama'
  },
  "codestral": {
    fallbacks: ["codellama", "codegemma"],
    timeout: 30,
    temperature: 0.7,
    provider: 'ollama'
  },
  "gemini-pro-code": {
    fallbacks: ["codellama:13b"],
    timeout: 30,
    temperature: 0.7,
    provider: 'google',
    maxTokens: 8192,
    modelName: 'gemini-pro', // Correct model name
    contextTokens: 32768
  },
  "gemini-pro": {
    fallbacks: ["gemini-1.5-pro-001", "codellama"],
    timeout: 30,
    temperature: 0.7,
    provider: 'google',
    modelName: 'gemini-pro', // Correct model name
  },
  "gemini-1.5-pro-001": {
    fallbacks: ["gemini-pro", "codellama"],
    timeout: 20,
    temperature: 0.7,
    provider: 'google',
    modelName: 'gemini-1.5-pro-001' // Correct model name
  },
  "gemini-1.5-flash": {
    fallbacks: ["gemini-pro", "codellama"],
    timeout: 20,
    temperature: 0.7,
    provider: 'google',
    modelName: 'gemini-1.5-flash' // Correct model name
  },
  "gemini-2.0-flash": {
    fallbacks: ["gemini-1.5-flash", "gemini-pro"],
    timeout: 20,
    temperature: 0.7,
    provider: 'google',
    modelName: 'gemini-2.0-flash', // Correct model name
    maxTokens: 16384,
    contextTokens: 65536
  },
  "phi4:latest": {
    fallbacks: ["codellama", "granite-code:20b"],
    timeout: 30,
    temperature: 0.7,
    provider: 'ollama'
  },
  "mistral-small:latest": {
    fallbacks: ["mistral-nemo:latest", "codellama:13b"],
    timeout: 30,
    temperature: 0.3,
    provider: 'ollama',
    maxTokens: 8192,
    contextTokens: 16384
  },
  "mistral-nemo:latest": {
    fallbacks: ["codellama:13b", "granite-code:20b"],
    timeout: 30,
    temperature: 0.3,
    provider: 'ollama',
    maxTokens: 4096,
    contextTokens: 8192
  }
};

export const AI_MODELS: AIModel[] = [
  {
    id: 'gemini-pro-code',
    name: 'Gemini Pro Code',
    description: 'Advanced code conversion model',
    features: ['High accuracy', 'Supports multiple languages'],
    provider: 'Google',
    modelIdentifier: 'gemini-pro' // Add explicit model identifier for API
  },
  {
    id: 'codellama',
    name: 'CodeLlama',
    provider: 'ollama',
    features: ['Code Generation', 'Code Analysis'],
    maxTokens: 8192,
    supportsStreaming: true,
    priority: 1
  },
  {
    id: 'codellama:13b',
    name: 'CodeLlama 13B',
    provider: 'Meta/Ollama',
    features: ['Code Generation', 'Code Analysis', 'Multi-language Support'],
    maxTokens: 4096,
    supportsStreaming: true,
    priority: 2
  },
  {
    id: 'llama3.3:latest',
    name: 'Llama 3.3',
    provider: 'Meta/Ollama',
    features: ['Advanced Code Generation', 'Technical Writing', 'Architecture Design'],
    maxTokens: 4096,
    supportsStreaming: true,
    priority: 1
  },
  {
    id: 'llama3.2:latest',
    name: 'Llama 3.2',
    provider: 'Meta/Ollama',
    features: ['Code Generation', 'Analysis', 'Documentation'],
    maxTokens: 4096,
    supportsStreaming: true,
    priority: 2
  },
  {
    id: 'granite-code:8b',
    name: 'Granite Code 8B',
    provider: 'ollama',
    features: ['Fast Generation', 'Code Completion'],
    maxTokens: 4096,
    supportsStreaming: true,
    priority: 2
  },
  {
    id: 'granite-code:20b',
    name: 'Granite Code 20B',
    provider: 'Granite/Ollama',
    features: ['Code Generation', 'Code Review', 'Best Practices'],
    maxTokens: 8192,
    supportsStreaming: true,
    priority: 1
  },
  {
    id: 'codegemma',
    name: 'CodeGemma',
    provider: 'ollama',
    features: ['Code Generation', 'Code Review'],
    maxTokens: 8192,
    supportsStreaming: true,
    priority: 1
  },
  {
    id: 'codestral',
    name: 'Codestral',
    provider: 'ollama',
    features: ['Code Generation', 'Code Optimization'],
    maxTokens: 8192,
    supportsStreaming: true,
    priority: 1
  },
  {
    id: 'gemini-2.0-flash',
    name: 'Gemini 2.0 Flash',
    provider: 'Google',
    description: 'Latest generation fast code conversion model',
    features: ['Enhanced speed', 'Improved accuracy', 'Larger context window'],
    maxTokens: 16384,
    supportsStreaming: true,
    priority: 1,
    modelName: 'gemini-2.0-flash' // Correct model name
  },
  {
    id: 'gemini-1.5-flash',
    name: 'Gemini 1.5 Flash',
    provider: 'Google',
    description: 'Fast and efficient code conversion',
    features: ['Quick conversion', 'Optimized for speed'],
    maxTokens: 4096,
    supportsStreaming: true,
    priority: 2,
    modelName: 'gemini-1.5-flash' // Correct model name
  },
  {
    id: 'gpt-4',
    name: 'GPT-4',
    provider: 'openai',
    features: ['Advanced Reasoning', 'Complex Tasks'],
    maxTokens: 8192,
    supportsStreaming: true,
    priority: 1
  },
  {
    id: 'gpt-4-turbo',
    name: 'GPT-4 Turbo',
    provider: 'openai',
    features: ['Fast Processing', 'Latest Knowledge'],
    maxTokens: 4096,
    supportsStreaming: true,
    priority: 2
  },
  {
    id: 'phi4:latest',
    name: 'Phi-4',
    provider: 'ollama',
    features: ['Code Generation', 'Fast Inference', 'Low Resource'],
    maxTokens: 4096,
    supportsStreaming: true,
    priority: 2
  },
  {
    id: 'mistral-small:latest',
    name: 'Mistral Small 14GB',
    provider: 'Mistral/Ollama',
    features: ['Advanced Code Generation', 'Technical Writing', 'Large Context Window'],
    maxTokens: 8192,
    supportsStreaming: true,
    priority: 1
  },
  {
    id: 'mistral-nemo:latest',
    name: 'Mistral Nemo 7.1GB',
    provider: 'Mistral/Ollama',
    features: ['Efficient Code Generation', 'Fast Processing', 'Resource Efficient'],
    maxTokens: 4096,
    supportsStreaming: true,
    priority: 2
  },
  {
    id: 'gemini-1.5-pro-001',
    name: 'Gemini 1.5 Pro',
    provider: 'Google',
    description: 'High-performance code conversion model',
    features: ['High accuracy', 'Supports multiple languages'],
    maxTokens: 8192,
    supportsStreaming: true,
    priority: 1,
    modelName: 'gemini-1.5-pro-001' // Correct model name
  }
];

export const RATE_LIMIT = 60;

// Model capabilities and preferences
export const MODEL_CAPABILITIES = {
  'gemini-pro-code': {
    languages: ['javascript', 'python', 'java', 'typescript', 'go', 'rust'],
    strengths: ['Documentation', 'Testing', 'Modern Frameworks']
  },
  'codellama:13b': {
    languages: ['python', 'javascript', 'java', 'cpp', 'rust', 'go'],
    strengths: ['System Programming', 'Algorithms', 'Performance']
  },
  'granite-code:20b': {
    languages: ['python', 'javascript', 'typescript', 'java', 'php', 'ruby'],
    strengths: ['Web Development', 'API Design', 'Database Integration']
  },
  'mistral-small:latest': {
    languages: ['python', 'javascript', 'typescript', 'java', 'cpp', 'rust', 'go'],
    strengths: ['Large Context Processing', 'Technical Documentation', 'Code Analysis']
  },
  'mistral-nemo:latest': {
    languages: ['python', 'javascript', 'typescript', 'java', 'php'],
    strengths: ['Fast Code Generation', 'Efficient Processing', 'Resource Optimization']
  },
  'gemini-1.5-pro-001': {
    languages: ['javascript', 'python', 'java', 'typescript', 'go', 'rust'],
    strengths: ['Documentation', 'Testing', 'Modern Frameworks'],
    contextLength: 8192,
    bestFor: ['Modern Programming Languages', 'Web Development', 'Testing']
  },
  'gemini-1.5-flash': {
    languages: ['javascript', 'python', 'java', 'typescript', 'go', 'rust'],
    strengths: ['Fast Conversion', 'Optimized for Speed'],
    contextLength: 4096,
    bestFor: ['Quick Conversion', 'Speed Optimization']
  },
  'gemini-2.0-flash': {
    languages: ['javascript', 'python', 'java', 'typescript', 'go', 'rust'],
    strengths: ['Enhanced Speed', 'Improved Accuracy', 'Larger Context Window'],
    contextLength: 16384,
    bestFor: ['Fast Conversion', 'High Accuracy', 'Large Contexts']
  }
} as const;