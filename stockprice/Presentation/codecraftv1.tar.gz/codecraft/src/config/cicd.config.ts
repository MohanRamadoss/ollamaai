import { Platform, PipelineType } from '../types/cicd';

export const CICD_EXAMPLES: Record<Platform, Partial<Record<PipelineType, string[]>>> = {
  github: {
    build: [
      'Build a Node.js application with npm, including testing and deployment steps',
      'Create a multi-stage Docker build pipeline with caching',
      'Set up a Java Maven build with unit tests and artifact publishing'
    ],
    test: [
      'Configure Jest and React Testing Library for frontend tests',
      'Set up end-to-end testing with Cypress including artifact storage',
      'Implement integration tests with database containers'
    ],
    deploy: [
      'Deploy a Node.js application to AWS ECS with blue-green deployment',
      'Set up continuous deployment to Kubernetes using Helm',
      'Configure multi-environment deployment to Azure Web Apps'
    ],
    monitor: [
      'Configure application monitoring with Datadog',
      'Set up error tracking with Sentry',
      'Implement performance monitoring with New Relic'
    ]
  },
  gitlab: {
    build: [
      'Create a Python FastAPI application build with poetry, pytest, and code quality checks',
      'Set up a Ruby on Rails pipeline with bundler, rspec, and asset compilation',
      'Configure a Go microservices build with modules, testing, and Docker multi-stage builds',
      'Build a Vue.js application with npm, Jest, and end-to-end testing',
      'Create a Java Spring Boot pipeline with Gradle and JUnit tests',
      'Set up a PHP Laravel build with Composer and PHPUnit',
      'Configure a .NET Core build with NuGet and MSTest',
      'Build a React Native app with yarn and Jest',
      'Create a Rust application build with Cargo and integration tests',
      'Set up an Elixir Phoenix build with mix and ExUnit'
    ],
    test: [
      'Configure GitLab CI for full-stack JavaScript testing with Jest and Cypress',
      'Set up integration testing with TestContainers and API tests',
      'Implement security scanning with SAST, DAST, and dependency checks',
      'Create performance testing pipeline with k6 and Artillery',
      'Set up cross-browser testing with Selenium Grid',
      'Configure accessibility testing with Pa11y and axe',
      'Implement contract testing with Pact',
      'Set up mutation testing with Stryker',
      'Create visual regression testing with Percy',
      'Configure load testing with Apache JMeter'
    ],
    deploy: [
      'Deploy to GitLab Kubernetes cluster with Auto DevOps and review apps',
      'Set up GitLab Pages deployment with custom domains and SSL certificates',
      'Configure container registry deployment with vulnerability scanning',
      'Implement GitLab environments with dynamic environments per branch',
      'Create deployment to AWS ECS with GitLab CI/CD variables and secrets',
      'Set up deployment to Google Cloud Platform with GitLab integration',
      'Configure auto-scaling deployments with custom metrics',
      'Implement feature flags and progressive rollouts',
      'Deploy with ArgoCD GitOps workflow and sync policies',
      'Set up multi-cloud deployment strategy with fallback options'
    ],
    monitor: [
      'Set up GitLab metrics dashboard with Prometheus and Grafana',
      'Configure error tracking with Sentry integration',
      'Implement log aggregation with ELK Stack',
      'Set up uptime monitoring with Pingdom',
      'Create performance monitoring with New Relic',
      'Configure APM with Datadog integration',
      'Set up container monitoring with cAdvisor',
      'Implement trace analysis with Jaeger',
      'Create custom metrics collection with StatsD',
      'Configure alert management with PagerDuty'
    ]
  },
  'azure-devops': {
    build: [
      'Create a .NET microservices build pipeline with NuGet and multi-stage Docker builds',
      'Set up an Angular monorepo build with nx and parallel execution',
      'Configure a Java enterprise build with Maven and SonarQube integration',
      'Implement a Python data science pipeline with conda and ML model testing',
      'Create a mobile app build pipeline for iOS and Android',
      'Set up a Scala build with SBT and Scala test',
      'Configure a TypeScript library build with API documentation',
      'Build a Unity game with automated builds for multiple platforms',
      'Create a C++ build pipeline with CMake and Conan',
      'Set up a Node.js monorepo build with Lerna and Jest'
    ],
    test: [
      'Set up comprehensive testing with Selenium Grid and Azure Test Plans',
      'Configure load testing with Azure Load Testing',
      'Implement UI testing with Playwright and reporting',
      'Create API testing pipeline with Postman and Newman',
      'Set up security scanning with Azure Security Center',
      'Configure integration testing with TestContainers',
      'Implement BDD testing with SpecFlow',
      'Set up performance profiling with dotTrace',
      'Create accessibility testing pipeline',
      'Configure chaos testing with Chaos Studio'
    ],
    deploy: [
      'Deploy to Azure App Service with deployment slots and auto-swap',
      'Set up Azure Kubernetes Service deployment with KEDA auto-scaling',
      'Configure Azure Container Apps deployment with revisions and traffic splitting',
      'Implement Azure Static Web Apps with API integration',
      'Deploy Azure Functions with application settings and scaling rules',
      'Set up Azure SQL Database deployment with schema migrations',
      'Configure Azure Service Fabric deployment with rolling updates',
      'Implement Azure DevOps release pipelines with approvals and gates',
      'Deploy to multiple Azure regions with Traffic Manager',
      'Set up Azure Container Registry with vulnerability scanning'
    ],
    monitor: [
      'Set up Application Insights with custom metrics',
      'Configure Azure Monitor with Log Analytics',
      'Implement container monitoring with AKS insights',
      'Create custom dashboards with Azure Monitor',
      'Set up cost monitoring and budgets',
      'Configure network monitoring with Network Watcher',
      'Implement database monitoring with Azure SQL insights',
      'Set up security monitoring with Microsoft Defender',
      'Create availability testing with URL ping tests',
      'Configure event monitoring with Event Grid'
    ]
  },
  jenkins: {
    build: [
      'Create a Java Spring Boot build pipeline with Maven, JUnit 5, and SonarQube integration',
      'Set up a Node.js monorepo build using Yarn workspaces and parallel execution',
      'Configure a Python microservices build with poetry, tox, and multiple Python versions',
      'Implement a .NET Core build pipeline with NuGet restore and multi-targeted frameworks',
      'Create a Gradle-based Android app build with unit tests and APK signing',
      'Set up a C++ build pipeline with CMake, Conan package manager, and GTest',
      'Build a Scala application with SBT and ScalaTest integration',
      'Configure a Ruby on Rails build with RVM, Bundler, and RSpec',
      'Create a Go project build with modules, golangci-lint, and test coverage',
      'Set up a multi-module Maven project with dependency caching and artifact publishing'
    ],
    test: [
      'Configure end-to-end testing with Selenium Grid and parallel test execution',
      'Set up performance testing pipeline with JMeter, reporting, and trend analysis',
      'Implement security scanning with OWASP ZAP, SonarQube, and dependency checks',
      'Create API testing suite with Postman, Newman, and environment-specific configs',
      'Set up browser compatibility testing with BrowserStack integration',
      'Configure mutation testing pipeline with PIT for Java projects',
      'Implement integration testing with TestContainers and database seeding',
      'Set up UI testing with Cypress including video recording and screenshots',
      'Create load testing pipeline with Gatling and performance thresholds',
      'Configure contract testing with Pact Broker and consumer-driven contracts'
    ],
    deploy: [
      'Create a production deployment pipeline with canary releases and automatic rollback',
      'Set up multi-environment deployment with approval gates and slack notifications',
      'Implement blue-green deployment for Spring Boot applications on Kubernetes',
      'Configure Docker Swarm deployment with rolling updates and health checks',
      'Create a deployment pipeline for AWS ECS with service discovery and auto-scaling',
      'Set up database deployment with Flyway migrations and backup verification',
      'Implement GitOps deployment using Argo CD and Helm charts',
      'Configure multi-region deployment with Route 53 failover setup',
      'Create a deployment pipeline for serverless applications using AWS SAM',
      'Set up hybrid cloud deployment with VMware and public cloud integration'
    ],
    monitor: [
      'Configure comprehensive monitoring with Prometheus, Grafana, and AlertManager',
      'Set up distributed tracing with Jaeger and OpenTelemetry integration',
      'Implement log aggregation using ELK Stack with Filebeat agents',
      'Create application performance monitoring with New Relic and custom dashboards',
      'Set up infrastructure monitoring with Nagios and custom check scripts',
      'Configure uptime monitoring with Pingdom and incident management',
      'Implement container monitoring with cAdvisor and Prometheus integration',
      'Set up database performance monitoring with PMM for MySQL/PostgreSQL',
      'Create custom metrics collection with StatsD and Graphite',
      'Configure alert management with PagerDuty and escalation policies'
    ]
  }
};
