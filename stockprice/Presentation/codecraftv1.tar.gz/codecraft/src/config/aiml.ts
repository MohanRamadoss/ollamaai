import { AIMLModel, AIMLLanguage } from '../types/aiml';

export const AIML_MODELS: Record<AIMLModel, string> = {
  'falcon3:10b': 'Falcon 3 10B',
  'phi4:latest': 'Phi-4 (34B)',
  'mistral-small:latest': 'Mistral Small',
  'llama3.3:latest': 'Llama3.3 70b',
  'gemini-pro': 'Gemini Pro',
  'gemini-1.5-pro-001': 'Gemini 1.5 Pro',
  'gemini-2.0-flash': 'Gemini 2.0 Flash'
} as const;

export const AIML_TASKS = {
  modelTraining: 'Model Training',
  dataPreprocessing: 'Data Preprocessing',
  evaluation: 'Model Evaluation',
  deployment: 'Model Deployment',
  optimization: 'Performance Optimization'
} as const;

export const AIML_LANGUAGES: Record<AIMLLanguage, {
  name: string;
  extension: string;
  capabilities: string[];
}> = {
  python: {
    name: 'Python',
    extension: 'py',
    capabilities: ['Data Analysis', 'Machine Learning', 'Deep Learning', 'Scientific Computing']
  },
  tensorflow: {
    name: 'TensorFlow',
    extension: 'py',
    capabilities: ['Keras API', 'Distributed Training', 'TF.js', 'TF Lite']
  },
  pytorch: {
    name: 'PyTorch',
    extension: 'py',
    capabilities: ['Dynamic Graphs', 'TorchScript', 'Distributed Training']
  },
  keras: {
    name: 'Keras',
    extension: 'py',
    capabilities: ['Sequential API', 'Functional API', 'Model Subclassing']
  }
} as const;

export const MODEL_CAPABILITIES = {
  'falcon3:10b': ['Advanced ML', 'Neural Networks', 'Deep Learning', 'Model Training'],
  'phi4:latest': ['Code Generation', 'Code Analysis', 'ML Pipeline Design', 'Optimization'],
  'mistral-small:latest': ['Algorithm Design', 'Code Optimization', 'Documentation', 'Testing'],
  'llama3.3:latest': ['Algorithm Implementation', 'Code Optimization', 'Documentation', 'Testing'],
  'gemini-pro': ['Advanced ML', 'Code Generation', 'Multi-Language Support'],
  'gemini-1.5-pro-001': ['Advanced ML', 'Code Generation', 'Multi-Language Support'],
  'gemini-2.0-flash': ['Advanced ML', 'Code Generation', 'Multi-Language Support', 'Fast Inference']
} as const;

export const COMPLEXITY_LEVELS = {
  basic: {
    name: 'Basic',
    description: 'Simple implementations with minimal complexity',
    features: ['Standard Libraries', 'Basic Error Handling', 'Simple Documentation']
  },
  intermediate: {
    name: 'Intermediate',
    description: 'Balanced complexity with good practices',
    features: ['Custom Functions', 'Error Management', 'Detailed Documentation']
  },
  advanced: {
    name: 'Advanced',
    description: 'Complex implementations with best practices',
    features: ['Advanced Patterns', 'Comprehensive Error Handling', 'Full Documentation']
  }
};
