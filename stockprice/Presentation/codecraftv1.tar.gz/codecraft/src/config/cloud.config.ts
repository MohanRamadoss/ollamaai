import type { CloudProvider, ResourceType } from '../types/cloud';

export const CLOUD_PROVIDERS = {
  aws: {
    name: 'Amazon Web Services',
    resourceTypes: [
      'terraform',
      'cloudformation',
      'kubernetes',
      'serverless',
      'database',
      'storage',
      'networking'
    ],
    defaultResourceType: 'terraform',
    features: ['Auto Scaling', 'Load Balancing', 'Managed Services', 'High Availability']
  },
  azure: {
    name: 'Microsoft Azure',
    resourceTypes: [
      'terraform',
      'azurearm',
      'kubernetes',
      'serverless',
      'database',
      'storage',
      'networking'
    ],
    defaultResourceType: 'terraform',
    features: ['Cloud Native', 'Hybrid Cloud', 'Enterprise Integration', 'DevOps']
  },
  gcp: {
    name: 'Google Cloud Platform',
    resourceTypes: [
      'terraform',
      'gcpdeployment',
      'kubernetes',
      'serverless',
      'database',
      'storage',
      'networking'
    ],
    defaultResourceType: 'terraform',
    features: ['Global Network', 'AI/ML Integration', 'Container Optimized', 'Serverless']
  }
} as const;

export const CLOUD_EXAMPLES: Record<CloudProvider, Record<ResourceType, string[]>> = {
  aws: {
    terraform: [
      'Create a VPC with public and private subnets across 3 AZs, including NAT Gateways and proper routing',
      'Set up an ECS Fargate cluster with Application Load Balancer and Auto Scaling',
      'Deploy an RDS instance in a private subnet with security groups and monitoring',
      'Create an S3 bucket with versioning, encryption, and lifecycle policies',
      'Set up an EC2 instance with EBS volumes and security groups'
    ],
    cloudformation: [
      'Deploy an EKS cluster with managed node groups and auto-scaling',
      'Create a serverless application with Lambda and API Gateway',
      'Set up a multi-tier web application with ElastiCache',
      'Configure CloudFront distribution with S3 origin',
      'Create a VPC with multiple AZs using CloudFormation',
      'Deploy an ECS service with load balancing using CloudFormation',
      'Set up a serverless application with API Gateway and Lambda using CloudFormation'
    ],
    kubernetes: [
      'Create an EKS cluster with managed node groups, spot instances, and cluster autoscaling across multiple AZs',
      'Deploy Istio service mesh with Prometheus, Grafana, and Jaeger for observability',
      'Configure AWS Load Balancer Controller with ingress and ALB/NLB integration',
      'Set up EKS with Calico for network policies and Cilium for enhanced security',  
      'Deploy a containerized application on EKS',
      'Set up AWS Load Balancer Controller',
      'Configure cluster autoscaling on EKS',
      'Deploy AWS EFS CSI driver'
    ],
    serverless: [
      'Create a serverless API with Lambda and API Gateway',
      'Set up event-driven processing with SQS and Lambda',
      'Deploy a serverless web application with S3 and CloudFront',
      'Set up S3 event triggers for Lambda functions',
      'Deploy DynamoDB streams with Lambda',
      'Configure Step Functions workflow'
    ],
    database: [
      'Create an Aurora PostgreSQL cluster with read replicas and auto-scaling',
      'Set up an RDS MySQL instance with Multi-AZ and automated backups',
      'Deploy an Aurora Serverless v2 cluster with data API enabled',
      'Configure an RDS instance with enhanced monitoring and performance insights',
      'Set up a cross-region Aurora Global Database'
    ],
    storage: [
        'Configure S3 buckets with versioning and lifecycle policies',
      'Set up cross-region replication with encryption',
      'Create a static website hosting with CloudFront',
      'Implement S3 bucket policies and access controls',
      'Configure S3 event notifications'
    ],
    networking: [
      'Design a Transit Gateway with multiple VPCs',
      'Set up VPC peering with proper routing',
      'Configure Site-to-Site VPN with redundancy',
      'Implement VPC endpoints for AWS services',
      'Create a multi-region network architecture'
    ]
  
  },
  azure: {
    terraform: [
      'Create a Virtual Network with multiple subnets, NSGs, and Azure Firewall',
      'Set up an AKS cluster with RBAC and managed identities',
      'Deploy an Azure SQL Database with geo-replication and private endpoints',
      'Create an App Service with staging slots and Application Insights',
      'Set up Azure Storage Account with private endpoints and lifecycle management',  
      'Deploy AKS cluster with virtual nodes and RBAC',
      'Set up Azure App Service with staging slots and SSL',
      'Create Azure SQL Database with geo-replication',
      'Configure Virtual Network with network security groups'
    ],
    azurearm: [
      'Create a complete Azure networking setup using ARM templates',
      'Deploy Azure Container Instances with monitoring using ARM',
      'Set up Azure SQL Database with failover using ARM templates',   
      'Deploy Azure Container Apps with Dapr integration',
      'Set up Azure Functions with premium hosting',
      'Create Cosmos DB with multi-region writes',
      'Configure Application Gateway with WAF'
    ],
    kubernetes: [
      'Create AKS cluster with system and user node pools, Azure CNI, and pod security policies',
      'Deploy Azure Service Mesh with Prometheus, Grafana, and distributed tracing',
      'Configure AKS with Application Gateway Ingress and WAF protection',
      'Set up AKS with Azure Policy and Azure Key Vault integration',  
      'Deploy applications on AKS with AGIC',
      'Set up Azure CNI networking',
      'Configure AKS cluster autoscaling',
      'Deploy Azure Files CSI driver'
    ],
    serverless: [
      'Create Azure Functions with HTTP triggers',
      'Set up event processing with Event Grid',
      'Deploy a serverless web app with Static Web Apps',
      'Create a Durable Functions workflow',
      'Set up Azure Functions with Cosmos DB'
    ],
    database: [
      'Create an Azure SQL Database with geo-replication and auto-scaling',
      'Set up a PostgreSQL Flexible Server with high availability',
      'Deploy a MySQL cluster with read replicas across regions',
      'Configure a SQL Managed Instance with AlwaysOn availability',
      'Set up Azure Database for PostgreSQL with hyperscale'   
    ],
    storage: [
     'Configure Storage Account with private endpoints',
      'Set up Blob Storage with lifecycle management',
      'Create File Shares with backup policies',
      'Implement Storage Account replication',
      'Configure CDN with Blob Storage'   
    ],
    networking: [
     'Design hub-spoke network topology',
      'Set up Azure Firewall with routing',
      'Configure ExpressRoute with redundancy',
      'Implement Azure Private Link',
      'Create a global network architecture'   
    ]
    
  },
  gcp: {
    terraform: [
      'Create a VPC network with subnets, Cloud NAT, and Cloud Router',
      'Set up a GKE cluster with node pools and workload identity',
      'Deploy a Cloud SQL instance with private IP and backups',
      'Create a Cloud Storage bucket with versioning and lifecycle policies',
      'Set up a Cloud Run service with Cloud SQL connectivity',  
      'Deploy GKE autopilot cluster with Cloud CDN',
      'Set up Cloud Run with Cloud SQL and Secret Manager',
      'Create Cloud Storage with lifecycle management',
      'Configure Load Balancer with Cloud Armor'
    ],
    gcpdeployment: [
      'Create a complete GCP networking setup using Deployment Manager',
      'Deploy GKE cluster with auto-scaling using Deployment Manager',
      'Set up Cloud SQL with replication using Deployment Manager',  
      'Deploy Cloud Functions with event triggers',
      'Set up Cloud Spanner with multi-region configuration',
      'Create Pub/Sub topic with dead letter queues',
      'Configure VPC with cloud NAT and firewall rules'
    ],
    kubernetes: [
      'Create GKE autopilot cluster with workload identity and binary authorization',
      'Deploy Anthos Service Mesh with Cloud Monitoring and Cloud Trace integration',
      'Configure GKE with Cloud Armor and Container-Optimized OS',
      'Set up GKE with Cloud DNS, Certificate Manager, and Cloud KMS',
      'Implement GKE with Cloud Build and Artifact Registry integration',  
      'Deploy applications on GKE with Ingress',
      'Set up GKE cluster autoscaling',
      'Configure GKE workload identity',
      'Deploy Cloud Storage CSI driver'
    ],
    serverless: [
    'Create Cloud Functions with HTTP triggers',
    'Set up event-driven processing with Pub/Sub',
    'Deploy a serverless app with Cloud Run',
    'Create a serverless API with API Gateway',
    'Set up Cloud Functions with Firebase'    
    ],
    database: [
    'Create a Cloud SQL PostgreSQL instance with high availability',
    'Set up a MySQL instance with read replicas and automated backups',
    'Deploy a SQL Server instance with high availability configuration',
    'Configure a Cloud SQL instance with private IP and VPC peering',
    'Set up a Cloud SQL instance with cross-region replication'
    ],
    
    storage: [
      'Configure Cloud Storage with lifecycle policies',
      'Set up cross-region replication',
      'Create a CDN-enabled bucket',
      'Implement IAM policies for buckets',
      'Configure Object Lifecycle Management'
    ],
    
    networking: [
      'Design Shared VPC architecture',
      'Set up Cloud Interconnect with routing',
      'Configure Cloud NAT and Cloud Router',
      'Implement VPC Service Controls',
      'Create a global load balancing setup'   
    ],
 
  }
};

export const complexityLevels = {
  basic: 'Simple, single-resource configurations with standard settings',
  intermediate: 'Multi-resource configurations with networking and security best practices',
  advanced: 'Production-ready configurations with high availability, scaling, and advanced security'
} as const;

export const resourceCategories = {
  compute: ['EC2', 'ECS', 'Lambda', 'AKS', 'GKE'],
  storage: ['S3', 'EBS', 'Blob Storage', 'Cloud Storage'],
  database: ['RDS', 'DynamoDB', 'Cosmos DB', 'Cloud SQL'],
  networking: ['VPC', 'Virtual Network', 'Cloud VPC'],
  security: ['IAM', 'KMS', 'Key Vault', 'Cloud KMS']
} as const;

export const DEFAULT_CLOUD_PROVIDER: CloudProvider = 'aws';
export const DEFAULT_RESOURCE_TYPE: ResourceType = 'terraform';
