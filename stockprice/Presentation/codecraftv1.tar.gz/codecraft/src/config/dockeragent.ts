interface DockerConfig {
  API_URL: string;
  DEFAULT_TIMEOUT: number;
  RETRY_ATTEMPTS: number;
  RETRY_DELAY: number;
  API_VERSION: string;  // Add API version
  MIN_API_VERSION: string;  // Add minimum supported version
}

const DOCKER_CONFIG: DockerConfig = {
  API_URL: '/docker-api',  // Using proxied URL from Vite config
  DEFAULT_TIMEOUT: 10000,  // Increased timeout
  RETRY_ATTEMPTS: 3,
  RETRY_DELAY: 1000,
  API_VERSION: '1.47',  // Add API version
  MIN_API_VERSION: '1.24',  // Add minimum supported version
} as const;

// Update return type of checkDockerConnection
export async function checkDockerConnection(): Promise<{
  isConnected: boolean;
  version?: string;
  error?: string;
  versionInfo?: DockerVersionInfo;
}> {
  for (let attempt = 1; attempt <= DOCKER_CONFIG.RETRY_ATTEMPTS; attempt++) {
    try {
      console.log(`Checking Docker connection (Attempt ${attempt})`);
      
      const response = await fetch(`${DOCKER_CONFIG.API_URL}/version`, {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'X-Docker-API-Version': DOCKER_CONFIG.API_VERSION,
        },
        mode: 'cors',
        cache: 'no-store'
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log('Docker connection successful:', data);
      
      // Validate API version compatibility
      if (data.ApiVersion < DOCKER_CONFIG.MIN_API_VERSION) {
        throw new Error(`Docker API version ${data.ApiVersion} is not supported. Minimum required version is ${DOCKER_CONFIG.MIN_API_VERSION}`);
      }
      
      return {
        isConnected: true,
        version: `${data.Version}`,
        versionInfo: data
      };

    } catch (error) {
      console.error(`Connection attempt ${attempt} failed:`, error);
      
      if (attempt === DOCKER_CONFIG.RETRY_ATTEMPTS) {
        return {
          isConnected: false,
          error: error instanceof Error 
            ? `Connection failed: ${error.message}` 
            : 'Failed to connect to Docker daemon'
        };
      }
      
      // Wait before retrying
      await new Promise(resolve => 
        setTimeout(resolve, DOCKER_CONFIG.RETRY_DELAY * attempt)
      );
    }
  }

  return {
    isConnected: false,
    error: 'Maximum retry attempts reached'
  };
}

export { DOCKER_CONFIG };