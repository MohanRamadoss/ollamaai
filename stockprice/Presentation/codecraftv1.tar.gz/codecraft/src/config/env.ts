import { z } from 'zod';

const EnvConfig = z.object({
  OLLAMA_API_URL: z.string().url().default('http://216.81.248.200:11434'),
  GOOGLE_API_KEY: z.string().min(1).default(''),
  GOOGLE_API_URL: z.string().url().default('https://generativelanguage.googleapis.com/v1beta'),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  API_TIMEOUT: z.number().default(60000),
  DEBUG: z.boolean().default(true),  // Add debug flag
});

type EnvConfigType = z.infer<typeof EnvConfig>;

function loadConfig(): EnvConfigType {
  // Ensure Vite loads environment variables
  const env = {
    OLLAMA_API_URL: import.meta.env.VITE_OLLAMA_API_URL,
    GOOGLE_API_KEY: import.meta.env.VITE_GOOGLE_API_KEY,
    GOOGLE_API_URL: import.meta.env.VITE_GOOGLE_API_URL,
    NODE_ENV: import.meta.env.MODE,
    API_TIMEOUT: Number(import.meta.env.VITE_API_TIMEOUT),
    DEBUG: import.meta.env.MODE === 'development',
  };

  // Always log in development or if DEBUG is true
  if (env.DEBUG || import.meta.env.MODE === 'development') {
    console.log('[Config] Loading environment variables:', {
      OLLAMA_API_URL: env.OLLAMA_API_URL || 'not set',
      GOOGLE_API_KEY: env.GOOGLE_API_KEY ? '[REDACTED]' : 'not set',
      GOOGLE_API_URL: env.GOOGLE_API_URL || 'not set',
      NODE_ENV: env.NODE_ENV || 'not set',
      API_TIMEOUT: env.API_TIMEOUT || 'not set',
      DEBUG: env.DEBUG,
    });
  }

  try {
    // Parse and validate environment
    const config = EnvConfig.parse(env);
    
    // Additional validation for critical values
    if (!config.OLLAMA_API_URL) {
      throw new Error('VITE_OLLAMA_API_URL is required but not set in .env file');
    }
    
    return config;
  } catch (error) {
    console.error('Environment configuration error:', error);
    throw new Error('Environment configuration is invalid. Check your .env file.');
  }
}

export const ENV_CONFIG = {
  ...loadConfig(),
  DEBUG: process.env.NODE_ENV === 'development' && false, // Set to false to hide debug info
  OPENAI_API_KEY: import.meta.env.VITE_OPENAI_API_KEY,
  OPENAI_API_URL: import.meta.env.VITE_OPENAI_API_URL || 'https://api.openai.com/v1',
  GOOGLE_API_KEY: import.meta.env.VITE_GOOGLE_API_KEY,
} as const;
