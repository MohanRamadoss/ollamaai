export const SQL_MODEL_CONFIGS = {
  'mistral-small:latest': {
    name: 'Mistral SQL',
    description: 'Fast SQL query generation and optimization',
    capabilities: [
      'Query generation',
      'Performance optimization',
      'Index recommendations',
      'Basic query tuning'
    ],
    parameters: {
      size: '14GB', // Updated from 4.1GB to match actual size
      context: '8K',
      speed: 'fast',
      optimizationLevel: 'standard'
    }
  },
  'mistral:latest': {
    name: 'Mistral Advanced SQL',
    description: 'Advanced SQL optimization and analysis',
    capabilities: [
      'Complex query generation',
      'Advanced optimization',
      'Partitioning strategies',
      'Replication configuration'
    ],
    parameters: {
      size: '4.1GB', // Updated from 7GB to match actual size
      context: '16K',
      speed: 'medium',
      optimizationLevel: 'advanced'
    }
  },
  'gemini-pro': {
    name: 'Gemini Pro SQL',
    description: 'Advanced SQL generation with Google Gemini Pro',
    capabilities: [
      'Query generation',
      'Performance optimization',
      'Multi-dialect support'
    ],
    parameters: {
      context: '32K',
      speed: 'fast',
      optimizationLevel: 'advanced'
    }
  },
  'gemini-1.5-pro-001': {
    name: 'Gemini 1.5 Pro SQL',
    description: 'Advanced SQL generation with Google Gemini 1.5 Pro',
    capabilities: [
      'Query generation',
      'Performance optimization',
      'Multi-dialect support'
    ],
    parameters: {
      context: '128K',
      speed: 'fast',
      optimizationLevel: 'advanced'
    }
  },
  'gemini-2.0-flash': {
    name: 'Gemini 2.0 Flash SQL',
    description: 'Fast SQL generation with Google Gemini 2.0 Flash',
    capabilities: [
      'Query generation',
      'Performance optimization',
      'Multi-dialect support'
    ],
    parameters: {
      context: '64K',
      speed: 'fast',
      optimizationLevel: 'standard'
    }
  }
} as const;

export const DEFAULT_SQL_MODEL = 'mistral-small:latest';
