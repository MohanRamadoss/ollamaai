import type { ModelConfig } from '../types/models';

export interface SecurityModelConfig {
  name: string;
  description: string;
  capabilities: string[];
  parameters: {
    size: string;
    context: string;
    speed: 'fast' | 'medium' | 'slow';
    securityLevel: 'basic' | 'advanced' | 'enterprise';
  };
}

export const SECURITY_MODEL_CONFIGS = {
  'mistral:latest': {
    name: 'Mistral Standard',
    description: 'Balanced security analysis with broad coverage',
    capabilities: [
      'Comprehensive scanning',
      'Security best practices',
      'Dependency analysis',
      'Code review automation'
    ],
    parameters: {
      size: '4.1GB',
      context: '8K',
      speed: 'medium',
      securityLevel: 'advanced'
    }
  },
  'mistral-small:latest': {
    name: 'Mistral Small',
    description: 'Fast, lightweight security checks',
    capabilities: [
      'Basic vulnerability scanning',
      'Quick security assessment',
      'Common issue detection'
    ],
    parameters: {
      size: '12GB',
      context: '4K',
      speed: 'fast',
      securityLevel: 'basic'
    }
  },
  'mistral-nemo:latest': {
    name: 'Mistral Nemo',
    description: 'Enhanced security analysis with Nemo optimizations',
    capabilities: [
      'Advanced vulnerability detection',
      'Pattern recognition',
      'Security best practices'
    ],
    parameters: {
      size: '7.1GB',
      context: '8K',
      speed: 'medium',
      securityLevel: 'advanced'
    }
  },
  'granite-code:8b': {
    name: 'Granite Code 8B',
    description: 'Specialized security analysis model',
    capabilities: [
      'Static code analysis',
      'Vulnerability scanning',
      'Best practices',
      'Code optimization'
    ],
    parameters: {
      size: '8B',
      context: '8K',
      speed: 'medium',
      securityLevel: 'enterprise'
    }
  },
  'granite-code:20b': {
    name: 'Granite Code 20B',
    description: 'Enterprise-grade code security analysis',
    capabilities: [
      'Advanced static analysis',
      'Complex pattern detection',
      'Deep security scanning'
    ],
    parameters: {
      size: '11GB',
      context: '16K',
      speed: 'slow',
      securityLevel: 'enterprise'
    }
  },
  'gemini-pro': {
    name: 'Gemini Pro',
    description: 'High-performance security analysis model',
    capabilities: [
      'Advanced vulnerability detection',
      'Security best practices',
      'Code review automation'
    ],
    parameters: {
      size: '32GB',
      context: '32K',
      speed: 'medium',
      securityLevel: 'enterprise'
    }
  },
  'gemini-1.5-pro-001': {
    name: 'Gemini 1.5 Pro (Disabled)',
    description: 'Temporarily disabled due to stability issues',
    capabilities: [
      'Currently unavailable',
      'Please use Gemini 2.0 Flash instead'
    ],
    parameters: {
      size: '16GB',
      context: '8K',
      speed: 'medium',
      securityLevel: 'enterprise',
      status: 'disabled'  // Add status field
    }
  },
  'gemini-2.0-flash': {
    name: 'Gemini 2.0 Flash',
    description: 'Latest generation fast security analysis model',
    capabilities: [
      'Enhanced speed',
      'Improved accuracy',
      'Larger context window'
    ],
    parameters: {
      size: '64GB',
      context: '64K',
      speed: 'fast',
      securityLevel: 'enterprise'
    }
  }
} as const;

export const DEFAULT_SECURITY_MODEL: Model = 'mistral:latest';
