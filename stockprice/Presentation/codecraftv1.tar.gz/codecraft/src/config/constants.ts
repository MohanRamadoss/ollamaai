export const FILE_EXTENSIONS = {
  // Programming Languages
  javascript: 'js',
  typescript: 'ts',
  python: 'py',
  java: 'java',
  cpp: 'cpp',
  'c++': 'cpp',
  rust: 'rs',
  go: 'go',
  ruby: 'rb',
  php: 'php',
  csharp: 'cs',
  swift: 'swift',
  kotlin: 'kt',
  
  // Shell and Scripts
  shell: 'sh',
  bash: 'sh',
  powershell: 'ps1',
  batch: 'bat',
  
  // Configuration and IaC
  yaml: 'yml',
  yml: 'yml',
  ansible: 'yml',
  terraform: 'tf',
  hcl: 'tf',
  docker: 'Dockerfile',
  dockerfile: 'Dockerfile',
  kubernetes: 'yaml',
  
  // Data Formats
  json: 'json',
  xml: 'xml',
  toml: 'toml',
  ini: 'ini',
} as const;

export const ACCEPTED_FILE_EXTENSIONS = [
  // Programming Languages
  '.js', '.ts', '.py', '.java', '.cpp', '.go', '.rb', '.php', '.cs', '.rs', '.swift', '.kt',
  
  // Configuration Management
  '.yml', '.yaml', '.sh', '.ps1', '.tf', 
  'Dockerfile', // Special case for Dockerfiles
  
  // Other
  '.json', '.sql', '.md'
];

export const MIME_TYPES = {
  // Programming Languages
  javascript: 'application/javascript',
  typescript: 'application/typescript',
  python: 'text/x-python',
  java: 'text/x-java-source',
  cpp: 'text/x-c++src',
  'c++': 'text/x-c++src',
  rust: 'text/rust',
  go: 'text/x-go',
  ruby: 'text/x-ruby',
  php: 'application/x-httpd-php',
  csharp: 'text/x-csharp',
  
  // Shell and Scripts
  shell: 'text/x-shellscript',
  bash: 'text/x-shellscript',
  powershell: 'text/plain',
  batch: 'text/plain',
  
  // Configuration and IaC
  yaml: 'text/yaml',
  yml: 'text/yaml',
  ansible: 'text/yaml',
  terraform: 'application/x-terraform',
  hcl: 'application/x-terraform',
  docker: 'text/plain',
  dockerfile: 'text/plain',
  kubernetes: 'text/yaml',
  
  // Data Formats
  json: 'application/json',
  xml: 'application/xml',
  toml: 'application/toml',
  ini: 'text/plain',
} as const;

export const FILE_NAMING_PATTERNS = {
  // Special file naming patterns
  terraform: {
    main: (code: string) => code.includes('terraform {'),
    variables: (code: string) => code.includes('variable "'),
    outputs: (code: string) => code.includes('output "'),
    providers: (code: string) => code.toLowerCase().includes('provider'),
    backend: (code: string) => code.includes('backend "'),
  },
  ansible: {
    playbook: (code: string) => code.includes('hosts:') || code.includes('tasks:'),
    inventory: (code: string) => code.includes('[') && !code.includes('tasks:'),
    vars: (code: string) => code.includes('vars:') && !code.includes('tasks:'),
  },
  kubernetes: {
    deployment: (code: string) => code.includes('kind: Deployment'),
    service: (code: string) => code.includes('kind: Service'),
    configmap: (code: string) => code.includes('kind: ConfigMap'),
    secret: (code: string) => code.includes('kind: Secret'),
  },
  docker: {
    dockerfile: () => true,
    compose: (code: string) => code.includes('version:') && code.includes('services:'),
  }
} as const;