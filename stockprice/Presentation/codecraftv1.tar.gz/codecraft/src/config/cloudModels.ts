import { Model } from '../types/models';

// Rename CICD_MODELS to CLOUD_MODELS and export it
export const CLOUD_MODELS: Model[] = [
  {
    id: 'gemini-pro-code',
    name: 'Gemini Pro Code',
    provider: 'google',
    description: 'Advanced code generation model from Google',
    contextWindow: 32768,
    similarities: ['codellama:13b'],
    maxOutputTokens: 8192,
    type: 'chat',
    modelIdentifier: 'gemini-pro',
    defaultParams: {
      temperature: 0.7,
      topP: 0.95,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'gemini-1.5-flash',
    name: 'Gemini 1.5 Flash',
    provider: 'google',
    description: 'Fast and efficient code conversion',
    contextWindow: 16384,
    similarities: ['codellama:13b'],
    maxOutputTokens: 4096,
    type: 'chat',
    modelIdentifier: 'gemini-1.5-pro',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/codellama:13b',
    name: 'CodeLlama 13B',
    provider: 'ollama',
    description: 'Meta\'s CodeLlama optimized for code generation',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/codellama:latest',
    name: 'CodeLlama Latest',
    provider: 'ollama',
    description: 'Latest version of Meta\'s CodeLlama optimized for code generation',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/deepseek-coder:6.7b',
    name: 'DeepSeek Coder 6.7B',
    provider: 'ollama',
    description: 'Fast and efficient code generation model',
    contextWindow: 8192,
    similarities: ['codellama:13b'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/deepseek-coder:33b',
    name: 'DeepSeek Coder 33B',
    provider: 'ollama',
    description: 'Advanced code generation and architecture design',
    contextWindow: 16384,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 8192,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 8192
    }
  },
  {
    id: 'ollama/deepseek-r1:14b',
    name: 'DeepSeek R1 14B',
    provider: 'ollama',
    description: 'Advanced code generation model',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/phi4:latest',
    name: 'Phi-4',
    provider: 'ollama',
    description: 'Efficient code generation with low resource usage',
    contextWindow: 4096,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/codeqwen:latest',
    name: 'CodeQwen',
    provider: 'ollama',
    description: 'Multilingual code generation model',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/codestral:latest',
    name: 'Codestral',
    provider: 'ollama',
    description: 'Code optimization focused model',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/codegemma:latest',
    name: 'CodeGemma',
    provider: 'ollama',
    description: 'Specialized code generation model',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/granite-code:8b',
    name: 'Granite Code 8B',
    provider: 'ollama',
    description: 'Lightweight code generation model',
    contextWindow: 4096,
    similarities: ['codellama:13b'],
    maxOutputTokens: 2048,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 2048
    }
  },
  {
    id: 'ollama/granite-code:20b',
    name: 'Granite Code 20B',
    provider: 'ollama',
    description: 'Advanced code generation and review',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/llama3.2:latest',
    name: 'Llama 3.2',
    provider: 'ollama',
    description: 'Stable Llama model for code generation',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/llama3.3:latest',
    name: 'Llama 3.3',
    provider: 'ollama',
    description: 'Latest Llama model optimized for code generation',
    contextWindow: 8192,
    similarities: ['gemini-pro-code'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'ollama/mistral-small:latest',
    name: 'Mistral Small (12GB)',
    provider: 'ollama',
    description: 'Powerful 12GB Mistral model optimized for code generation',
    contextWindow: 16384, // increased context window
    similarities: ['codellama:13b'],
    maxOutputTokens: 8192, // increased output tokens
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 8192
    }
  },
  {
    id: 'ollama/mistral-nemo:latest',
    name: 'Mistral Nemo (7.1GB)',
    provider: 'ollama',
    description: 'Efficient 7.1GB Mistral model for code generation',
    contextWindow: 8192,
    similarities: ['codellama:13b', 'mistral-small:latest'],
    maxOutputTokens: 4096,
    type: 'completion',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'gemini-pro',
    name: 'Gemini Pro',
    provider: 'google',
    description: 'High-performance code conversion model',
    contextWindow: 32768,
    similarities: ['gemini-1.5-pro-001', 'codellama'],
    maxOutputTokens: 8192,
    type: 'chat',
    modelIdentifier: 'gemini-pro',
    defaultParams: {
      temperature: 0.7,
      topP: 0.95,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'gemini-1.5-pro-001',
    name: 'Gemini 1.5 Pro',
    provider: 'google',
    description: 'High-performance code conversion model',
    contextWindow: 8192,
    similarities: ['gemini-pro', 'codellama'],
    maxOutputTokens: 8192,
    type: 'chat',
    modelIdentifier: 'gemini-1.5-pro-001',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  },
  {
    id: 'gemini-2.0-flash',
    name: 'Gemini 2.0 Flash',
    provider: 'google',
    description: 'Latest generation fast code conversion model',
    contextWindow: 65536,
    similarities: ['gemini-1.5-flash', 'gemini-pro'],
    maxOutputTokens: 16384,
    type: 'chat',
    modelIdentifier: 'gemini-2.0-flash',
    defaultParams: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxTokens: 4096
    }
  }
];

export const getDefaultCloudModel = () => CLOUD_MODELS[0];
export const getCloudModel = (id: string) => CLOUD_MODELS.find(model => model.id === id);
