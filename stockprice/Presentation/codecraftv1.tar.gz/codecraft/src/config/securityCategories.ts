export const SECURITY_CATEGORIES = {
  // OWASP Top 10 2021
  BROKEN_ACCESS_CONTROL: 'broken_access_control',
  CRYPTOGRAPHIC_FAILURES: 'cryptographic_failures',
  INJECTION: 'injection',
  INSECURE_DESIGN: 'insecure_design',
  SECURITY_MISCONFIGURATION: 'security_misconfiguration',
  VULNERABLE_COMPONENTS: 'vulnerable_components',
  AUTH_FAILURES: 'authentication_failures',
  DATA_INTEGRITY_FAILURES: 'data_integrity_failures',
  SECURITY_LOGGING_MONITORING: 'security_logging_monitoring',
  SSRF: 'server_side_request_forgery',

  // Additional Categories
  CODE_QUALITY: 'code_quality',
  COMPLIANCE: 'compliance',
  CONTAINER_SECURITY: 'container_security',
  SECRETS_MANAGEMENT: 'secrets_management',
  SUPPLY_CHAIN: 'supply_chain',
  API_SECURITY: 'api_security',
  CLOUD_SECURITY: 'cloud_security'
} as const;

// Add CWE mappings
export const CWE_MAPPINGS = {
  'sql_injection': 'CWE-89',
  'xss': 'CWE-79',
  'broken_auth': 'CWE-287',
  'sensitive_data': 'CWE-200',
  'xxe': 'CWE-611',
  'broken_access': 'CWE-285',
  'security_misconfig': 'CWE-1021',
  'insecure_deserialization': 'CWE-502',
  'vulnerable_components': 'CWE-1104',
  'insufficient_logging': 'CWE-778'
};

// CVSS Score calculator
export function calculateCVSSScore(severity: string): number {
  const baseScores = {
    critical: 9.8,
    high: 7.5,
    medium: 5.0,
    low: 2.5,
    info: 0.0
  };
  return baseScores[severity as keyof typeof baseScores] || 0;
}
