import React from 'react';
import { encode } from 'gpt-tokenizer';

interface TokenCounterProps {
  code: string;
  maxTokens: number;
}

export function TokenCounter({ code, maxTokens }: TokenCounterProps) {
  const tokenCount = React.useMemo(() => encode(code).length, [code]);
  const percentage = (tokenCount / maxTokens) * 100;
  
  return (
    <div className="text-xs text-gray-500">
      {tokenCount.toLocaleString()} / {maxTokens.toLocaleString()} tokens
      {percentage > 90 && (
        <span className="ml-2 text-amber-600">
          ({Math.round(percentage)}% of limit)
        </span>
      )}
    </div>
  );
}
