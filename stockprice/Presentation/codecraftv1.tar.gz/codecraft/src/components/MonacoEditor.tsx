import React, { useRef, useEffect, useState } from 'react';
import * as monaco from 'monaco-editor';
import { Copy, Download, Settings } from 'lucide-react';
import { SUPPORTED_LANGUAGES, type SupportedLanguage } from '../types/supported-languages';

// Convert our language mappings to Monaco format
const languageMap: Record<string, string> = {
  javascript: 'javascript',
  typescript: 'typescript',
  html: 'html',
  css: 'css',
  python: 'python',
  java: 'java',
  cpp: 'cpp',
  csharp: 'csharp',
  go: 'go',
  rust: 'rust',
  php: 'php',
  ruby: 'ruby',
  sql: 'sql',
  yaml: 'yaml',
  json: 'json',
  xml: 'xml',
  markdown: 'markdown',
  shell: 'shell',
  powershell: 'powershell',
  kotlin: 'kotlin',
  swift: 'swift',
  perl: 'perl',
  r: 'r',
  dart: 'dart',
  lua: 'lua',
  julia: 'julia',
  plaintext: 'plaintext'
};

interface MonacoEditorProps {
  value: string;
  onChange?: (value: string) => void;
  language?: string;
  readOnly?: boolean;
  height?: string;
  theme?: 'vs-dark' | 'vs-light';
  fontSize?: number;
  filename?: string;
}

export function MonacoEditor({
  value,
  onChange,
  language = 'javascript',
  readOnly = false,
  height = '400px',
  theme = 'vs-dark',
  fontSize = 14,
  filename
}: MonacoEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const [editor, setEditor] = useState<monaco.editor.IStandaloneCodeEditor | null>(null);
  const [isCopied, setIsCopied] = useState(false);

  // Initialize Monaco Editor
  useEffect(() => {
    if (editorRef.current) {
      const editor = monaco.editor.create(editorRef.current, {
        value,
        language: languageMap[language] || 'plaintext',
        theme,
        fontSize,
        automaticLayout: true,
        minimap: { enabled: true },
        scrollBeyondLastLine: false,
        readOnly,
        scrollbar: {
          useShadows: false,
          verticalScrollbarSize: 10,
          horizontalScrollbarSize: 10
        },
        lineNumbers: 'on',
        glyphMargin: true,
        folding: true,
        bracketPairColorization: { enabled: true },
        formatOnPaste: true,
        formatOnType: true,
        suggest: {
          showMethods: true,
          showFunctions: true,
          showConstructors: true,
          showFields: true,
          showVariables: true,
          showClasses: true,
          showStructs: true,
          showInterfaces: true,
          showModules: true,
          showProperties: true,
          showEvents: true,
          showOperators: true,
          showUnits: true,
          showValues: true,
          showConstants: true,
          showEnums: true,
          showEnumMembers: true,
          showKeywords: true,
          showWords: true,
          showColors: true,
          showFiles: true,
          showReferences: true,
          showFolders: true,
          showTypeParameters: true,
          showSnippets: true,
          showUsers: true
        },
        quickSuggestions: {
          other: true,
          comments: true,
          strings: true
        }
      });

      editor.onDidChangeModelContent(() => {
        onChange?.(editor.getValue());
      });

      setEditor(editor);

      return () => {
        editor.dispose();
      };
    }
  }, []);

  // Update editor options when props change
  useEffect(() => {
    if (editor) {
      editor.updateOptions({
        theme,
        fontSize,
        readOnly
      });
    }
  }, [theme, fontSize, readOnly]);

  // Update language when it changes
  useEffect(() => {
    if (editor) {
      monaco.editor.setModelLanguage(
        editor.getModel()!,
        languageMap[language] || 'plaintext'
      );
    }
  }, [language]);

  // Handle file download
  const handleDownload = () => {
    if (editor) {
      const content = editor.getValue();
      const blob = new Blob([content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename || `code.${SUPPORTED_LANGUAGES[language as SupportedLanguage]?.extensions[0] || 'txt'}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  // Handle copy to clipboard
  const handleCopy = async () => {
    if (editor) {
      const content = editor.getValue();
      await navigator.clipboard.writeText(content);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  return (
    <div className="relative w-full" style={{ height }}>
      {/* Toolbar */}
      <div className="absolute top-2 right-2 z-10 flex gap-2 bg-gray-800/90 p-1 rounded-lg border border-gray-700">
        <button
          onClick={handleCopy}
          className="p-2 rounded hover:bg-gray-700 transition-colors text-gray-300 hover:text-white flex items-center gap-2"
          title="Copy code"
        >
          <Copy className="w-4 h-4" />
          <span className="text-sm">{isCopied ? 'Copied!' : 'Copy'}</span>
        </button>
        <button
          onClick={handleDownload}
          className="p-2 rounded hover:bg-gray-700 transition-colors text-gray-300 hover:text-white flex items-center gap-2"
          title="Download code"
        >
          <Download className="w-4 h-4" />
          <span className="text-sm">Download</span>
        </button>
      </div>

      {/* Editor container */}
      <div 
        ref={editorRef} 
        className="w-full h-full border border-gray-700 rounded-lg overflow-hidden"
      />
    </div>
  );
}
