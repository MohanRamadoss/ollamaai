import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card';
import { Progress } from '../ui/progress';
import { Cpu, HardDrive, Network, Activity } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string;
  icon: any;
  percentage?: number;
  status?: 'normal' | 'warning' | 'critical';
  subValue?: string;
}

const MetricCard = ({ 
  title, 
  value, 
  icon: Icon, 
  percentage, 
  status = 'normal',
  subValue 
}: MetricCardProps) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between pb-2">
      <CardTitle className="text-sm font-medium">
        {title}
      </CardTitle>
      <Icon className="h-4 w-4 text-gray-500" />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      {percentage !== undefined && (
        <Progress 
          value={percentage} 
          className={`h-2 mt-2 ${
            percentage > 80 ? 'bg-red-100' : 
            percentage > 60 ? 'bg-yellow-100' : 
            'bg-green-100'
          }`}
        />
      )}
      {subValue && (
        <p className="text-xs text-gray-500 mt-1">{subValue}</p>
      )}
    </CardContent>
  </Card>
);

export const ContainerStatsDisplay = ({ stats }: { stats: any }) => {
  if (!stats) return null;

  const { resources, summary, alerts } = stats;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="CPU Usage"
          value={`${resources.cpu.usagePercent}%`}
          icon={Cpu}
          percentage={resources.cpu.usagePercent}
          subValue={`Limit: ${resources.cpu.limit}`}
        />
        
        <MetricCard
          title="Memory Usage"
          value={resources.memory.usage}
          icon={HardDrive}
          percentage={resources.memory.usagePercent}
          subValue={`Limit: ${resources.memory.limit}`}
        />
        
        <MetricCard
          title="Network I/O"
          value={`↓${resources.network.rxBytes} ↑${resources.network.txBytes}`}
          icon={Network}
          subValue={`${resources.network.rxPackets + resources.network.txPackets} packets`}
        />
        
        <MetricCard
          title="Disk I/O"
          value={`R: ${resources.io.read} W: ${resources.io.write}`}
          icon={Activity}
          subValue={`Ops: R${resources.io.readOps} W${resources.io.writeOps}`}
        />
      </div>

      {alerts && Object.keys(alerts).length > 0 && (
        <Card className="mt-4">
          <CardHeader>
            <CardTitle>Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {Object.entries(alerts).map(([category, messages]) => (
                messages && messages.length > 0 && (
                  <div key={category} className="space-y-1">
                    <h4 className="font-medium capitalize">{category}</h4>
                    <ul className="list-disc list-inside text-sm text-gray-600">
                      {messages.map((message: string, idx: number) => (
                        <li key={idx}>{message}</li>
                      ))}
                    </ul>
                  </div>
                )
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
