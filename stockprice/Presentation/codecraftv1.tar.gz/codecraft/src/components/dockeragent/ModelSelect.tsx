import React from 'react';
import { AI_MODELS } from '../../config/models';

interface ModelSelectProps {
  selectedModels: string[];
  onChange: (models: string[]) => void;
}

export function ModelSelect({ selectedModels, onChange }: ModelSelectProps) {
  return (
    <div className="space-y-4">
      <label className="block text-sm font-medium text-gray-700">AI Models</label>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {AI_MODELS.map((model) => (
          <label
            key={model.id}
            className={`relative flex items-center p-4 border rounded-lg cursor-pointer transition-colors ${
              selectedModels.includes(model.id)
                ? 'border-indigo-500 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-300'
            }`}
          >
            <input
              type="checkbox"
              checked={selectedModels.includes(model.id)}
              onChange={(e) => {
                const newModels = e.target.checked
                  ? [...selectedModels, model.id]
                  : selectedModels.filter((id) => id !== model.id);
                onChange(newModels);
              }}
              className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
            />
            <div className="ml-3">
              <span className="block text-sm font-medium text-gray-900">{model.name}</span>
              <span className="block text-sm text-gray-500">{model.description}</span>
            </div>
          </label>
        ))}
      </div>
    </div>
  );
}
