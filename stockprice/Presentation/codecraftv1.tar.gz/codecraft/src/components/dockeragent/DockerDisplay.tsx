import React from 'react';
import { AlertTriangle, CheckCircle2 } from 'lucide-react';

interface DockerDisplayProps {
  output: string;
  error: string | null;
  isProcessing: boolean;
}

export function DockerDisplay({ output, error, isProcessing }: DockerDisplayProps) {
  if (error) {
    return (
      <div className="rounded-lg border border-red-200 bg-red-50 p-4">
        <div className="flex items-start gap-2 text-red-600">
          <AlertTriangle className="w-5 h-5" />
          <span>{error}</span>
        </div>
      </div>
    );
  }

  if (!output && !isProcessing) {
    return null;
  }

  return (
    <div className="rounded-lg border border-gray-200 bg-gray-50 p-4">
      <div className="font-mono text-sm whitespace-pre-wrap">
        {output && (
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-5 h-5 text-green-500" />
            <pre>{output}</pre>
          </div>
        )}
      </div>
    </div>
  );
}
