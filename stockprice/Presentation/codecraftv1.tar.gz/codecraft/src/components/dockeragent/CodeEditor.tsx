import React, { useCallback, useState } from 'react';
import { Copy, Check } from 'lucide-react';
import Editor from '@monaco-editor/react';

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  language?: string;
}

export function CodeEditor({ value, onChange, language }: CodeEditorProps) {
  const [isCopied, setIsCopied] = useState(false);

  const handleCopy = useCallback(async () => {
    try {
      // Use clipboard API with error handling
      await navigator.clipboard.writeText(value);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  }, [value]);

  return (
    <div className="relative">
      <div className="absolute right-2 top-2 z-10">
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            handleCopy();
          }}
          className="p-2 rounded bg-white/90 hover:bg-gray-100 border border-gray-200 
                     shadow-sm transition-colors duration-200 focus:outline-none 
                     focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          title="Copy code"
        >
          {isCopied ? (
            <Check className="w-4 h-4 text-green-600" />
          ) : (
            <Copy className="w-4 h-4 text-gray-600" />
          )}
        </button>
      </div>
      
      <Editor
        height="400px"
        defaultLanguage={language || 'plaintext'}
        language={language || 'plaintext'}
        value={value}
        onChange={(newValue) => onChange(newValue || '')}
        options={{
          minimap: { enabled: false },
          scrollBeyondLastLine: false,
          fontSize: 14,
          lineNumbers: 'on',
          renderLineHighlight: 'all',
          wordWrap: 'on',
          tabSize: 2,
          glyphMargin: false,
        }}
        className="border rounded-lg overflow-hidden"
      />
    </div>
  );
}