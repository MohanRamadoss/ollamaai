import React, { useState } from 'react';
import { Code, ChevronRight } from 'lucide-react';
import type { CodeExample } from '../../types/security';

interface CodeExamplesProps {
  examples: CodeExample[];
  onSelect: (code: string) => void;
}

export function CodeExamples({ examples, onSelect }: CodeExamplesProps) {
  if (!examples || examples.length === 0) return null;

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <Code className="w-5 h-5 text-indigo-600" />
          <h3 className="text-sm font-medium text-gray-900">Sample Code</h3>
        </div>
      </div>
      <div className="divide-y divide-gray-200">
        {examples.map((example, index) => (
          <button
            key={index}
            onClick={() => onSelect(example.code)}
            className="w-full text-left p-4 hover:bg-gray-50 flex items-center justify-between group transition-colors"
          >
            <div>
              <h4 className="text-sm font-medium text-gray-900">{example.name}</h4>
              <p className="text-sm text-gray-500">{example.description}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-indigo-600" />
          </button>
        ))}
      </div>
    </div>
  );
}

export function CodeSecurityPage() {
  const [selectedCode, setSelectedCode] = useState<string | null>(null);

  const examples: CodeExample[] = [
    {
      name: 'Example 1',
      description: 'This is the first example.',
      code: 'console.log("Example 1");',
    },
    {
      name: 'Example 2',
      description: 'This is the second example.',
      code: 'console.log("Example 2");',
    },
  ];

  return (
    <div>
      <h1>Code Security Page</h1>
      <CodeExamples examples={examples} onSelect={setSelectedCode} />
      {selectedCode && (
        <div className="mt-4">
          <h2>Selected Code</h2>
          <pre className="bg-gray-100 p-4 rounded-lg">{selectedCode}</pre>
        </div>
      )}
    </div>
  );
}