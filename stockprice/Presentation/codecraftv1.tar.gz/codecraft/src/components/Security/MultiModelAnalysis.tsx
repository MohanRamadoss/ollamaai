import React from 'react';
import { Shield, AlertTriangle, CheckCircle2, Loader2 } from 'lucide-react';
import type { SecurityScanProgress } from '../../lib/api/security';
import type { SecurityIssue, SecurityMetrics } from '../../types/security';

interface MultiModelAnalysisProps {
  modelProgress: Record<string, SecurityScanProgress>;
  onValidate?: () => void;
  isValidating?: boolean;
}

export function MultiModelAnalysis({ 
  modelProgress,
  onValidate,
  isValidating
}: MultiModelAnalysisProps) {
  const models = Object.values(modelProgress);
  const totalProgress = models.reduce((sum, m) => sum + m.progress, 0) / models.length;

  return (
    <div className="space-y-6">
      {/* Overall Progress */}
      <div className="bg-white p-4 rounded-lg border border-gray-200">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-sm font-medium text-gray-900">Overall Analysis Progress</h3>
          <span className="text-sm text-gray-500">{Math.round(totalProgress)}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
            style={{ width: `${totalProgress}%` }}
          />
        </div>
      </div>

      {/* Individual Model Progress */}
      <div className="grid grid-cols-1 gap-4">
        {models.map((model) => (
          <div key={model.modelId} className="bg-white p-4 rounded-lg border border-gray-200">
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center gap-2">
                {model.status === 'completed' ? (
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                ) : model.status === 'failed' ? (
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                ) : (
                  <Loader2 className="w-4 h-4 text-indigo-500 animate-spin" />
                )}
                <span className="font-medium text-gray-900">{model.modelId}</span>
              </div>
              <span className="text-sm text-gray-500">{model.progress}%</span>
            </div>

            <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
              <div
                className={`h-2 rounded-full transition-all duration-500 ${
                  model.status === 'completed' ? 'bg-green-500' :
                  model.status === 'failed' ? 'bg-red-500' :
                  'bg-indigo-500'
                }`}
                style={{ width: `${model.progress}%` }}
              />
            </div>

            {model.error && (
              <p className="mt-2 text-sm text-red-600 flex items-center gap-1">
                <AlertTriangle className="w-4 h-4" />
                {model.error}
              </p>
            )}

            {model.result && (
              <div className="mt-2 grid grid-cols-4 gap-2 text-sm">
                <div className="p-2 bg-red-50 rounded">
                  <div className="text-red-600">Critical</div>
                  <div className="font-medium">{model.result.metrics.criticalIssues}</div>
                </div>
                <div className="p-2 bg-orange-50 rounded">
                  <div className="text-orange-600">High</div>
                  <div className="font-medium">{model.result.metrics.highIssues}</div>
                </div>
                <div className="p-2 bg-yellow-50 rounded">
                  <div className="text-yellow-600">Medium</div>
                  <div className="font-medium">{model.result.metrics.mediumIssues}</div>
                </div>
                <div className="p-2 bg-blue-50 rounded">
                  <div className="text-blue-600">Low</div>
                  <div className="font-medium">{model.result.metrics.lowIssues}</div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Validation Button */}
      {onValidate && (
        <button
          onClick={onValidate}
          disabled={isValidating || totalProgress < 100}
          className="w-full flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isValidating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Validating Results...
            </>
          ) : (
            <>
              <Shield className="w-4 h-4 mr-2" />
              Validate Results
            </>
          )}
        </button>
      )}
    </div>
  );
}