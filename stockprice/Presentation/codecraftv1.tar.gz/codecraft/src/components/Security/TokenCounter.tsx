import React from 'react';
import { MessageCircle } from 'lucide-react';

interface TokenCounterProps {
  code: string;
  maxTokens?: number;
}

export function TokenCounter({ code, maxTokens = 8192 }: TokenCounterProps) {
  // Simple token estimation (4 characters per token on average)
  const estimateTokens = (text: string): number => {
    return Math.ceil(text.length / 4);
  };

  const tokenCount = estimateTokens(code);
  const isOverLimit = maxTokens && tokenCount > maxTokens;

  return (
    <div className="flex items-center gap-2">
      <MessageCircle className={`w-4 h-4 ${isOverLimit ? 'text-red-500' : 'text-gray-400'}`} />
      <span className={`text-sm ${isOverLimit ? 'text-red-500 font-medium' : 'text-gray-500'}`}>
        {tokenCount.toLocaleString()} / {maxTokens.toLocaleString()} tokens
      </span>
    </div>
  );
}
