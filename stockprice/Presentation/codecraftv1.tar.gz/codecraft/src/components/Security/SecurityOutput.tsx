import React from 'react';
import { Shield, AlertTriangle } from 'lucide-react';
import type { SecurityIssue } from '../../types/security';
import { SECURITY_CATEGORIES } from '../../config/securityCategories';

interface SecurityOutputProps {
  issues: SecurityIssue[];
  isScanning: boolean;
  progress: number;
}

export function SecurityOutput({ issues, isScanning, progress }: SecurityOutputProps) {
  const getSeverityColor = (type: SecurityIssue['type']) => {
    switch (type) {
      case 'critical': return 'text-red-600 bg-red-50 border-red-200';
      case 'high': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case SECURITY_CATEGORIES.INJECTION:
        return <AlertTriangle className="w-4 h-4" />;
      case SECURITY_CATEGORIES.BROKEN_ACCESS_CONTROL:
        return <Shield className="w-4 h-4" />;
      // Add more icons as needed
      default:
        return <AlertTriangle className="w-4 h-4" />;
    }
  };

  const getCategoryBadge = (category: string) => {
    const categoryName = Object.entries(SECURITY_CATEGORIES)
      .find(([_, value]) => value === category)?.[0] || category;
    
    return (
      <span className="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800">
        {categoryName.replace(/_/g, ' ')}
      </span>
    );
  };

  return (
    <div className="space-y-4">
      {issues.map((issue, index) => (
        <div
          key={index}
          className={`p-4 rounded-lg border ${getSeverityColor(issue.type)}`}
        >
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2">
                {getCategoryIcon(issue.category)}
                <h3 className="font-medium">{issue.title}</h3>
                {getCategoryBadge(issue.category)}
                {issue.cvss && (
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">
                    CVSS: {issue.cvss}
                  </span>
                )}
                {issue.cwe && (
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                    {issue.cwe}
                  </span>
                )}
              </div>
              <p className="mt-1 text-sm">{issue.description}</p>
              {issue.recommendation && (
                <div className="mt-2 p-2 bg-white rounded border border-gray-200">
                  <span className="font-medium">Recommendation:</span>{' '}
                  {issue.recommendation}
                </div>
              )}
            </div>
          </div>
        </div>
      ))}

      {!issues.length && !isScanning && (
        <div className="text-center py-8 text-gray-500">
          <Shield className="w-12 h-12 mx-auto mb-3 text-gray-400" />
          <p>No security issues found</p>
        </div>
      )}
    </div>
  );
}
