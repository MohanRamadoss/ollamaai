import React from 'react';
import { Shield, AlertTriangle, CheckCircle2, Loader2 } from 'lucide-react';
import type { SecurityScanProgress } from '../../lib/api/security';
import { TokenCounter } from './TokenCounter';
import { AnalysisProgress } from '../../types/security';

interface MultiModelOutputProps {
  results: Record<string, AnalysisProgress>;
  maxTokens: number;
  language: string;
  scanType: string;
}

export function MultiModelOutput({
  results,
  maxTokens,
  language,
  scanType
}: MultiModelOutputProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default:
        return <Loader2 className="w-4 h-4 text-indigo-500 animate-spin" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-green-700 bg-green-50 border-green-200';
      case 'failed':
        return 'text-red-700 bg-red-50 border-red-200';
      default:
        return 'text-gray-700 bg-gray-50 border-gray-200';
    }
  };

  const formatResult = (result: any) => {
    if (typeof result === 'string') {
      try {
        return JSON.parse(result);
      } catch {
        return result;
      }
    }
    return result;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-indigo-600" />
          <h3 className="text-sm font-medium text-gray-900">Security Analysis Results</h3>
        </div>
        <TokenCounter code={JSON.stringify(results)} maxTokens={maxTokens} />
      </div>

      <div className="grid grid-cols-1 gap-4">
        {Object.values(results).map((result) => (
          <div
            key={result.modelId}
            className={`rounded-lg border p-4 ${getStatusColor(result.status)}`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                {getStatusIcon(result.status)}
                <h4 className="font-medium">{result.modelId}</h4>
              </div>
              <span className="text-sm">
                Progress: {result.progress}%
              </span>
            </div>

            {result.error ? (
              <div className="mt-2 text-sm text-red-600 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                {result.error}
              </div>
            ) : (
              <div className="mt-4 space-y-4">
                {result.status === 'completed' && result.result && (
                  <>
                    <div className="bg-white rounded-lg p-4 border border-gray-200">
                      <pre className="text-sm overflow-auto">
                        <code>
                          {JSON.stringify(formatResult(result.result), null, 2)}
                        </code>
                      </pre>
                    </div>
                    {formatResult(result.result).metrics && (
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="p-2 bg-red-50 rounded text-center">
                          <div className="text-xs text-red-700">Critical</div>
                          <div className="font-medium text-red-900">
                            {formatResult(result.result).metrics.criticalIssues}
                          </div>
                        </div>
                        <div className="p-2 bg-orange-50 rounded text-center">
                          <div className="text-xs text-orange-700">High</div>
                          <div className="font-medium text-orange-900">
                            {formatResult(result.result).metrics.highIssues}
                          </div>
                        </div>
                        <div className="p-2 bg-yellow-50 rounded text-center">
                          <div className="text-xs text-yellow-700">Medium</div>
                          <div className="font-medium text-yellow-900">
                            {formatResult(result.result).metrics.mediumIssues}
                          </div>
                        </div>
                        <div className="p-2 bg-blue-50 rounded text-center">
                          <div className="text-xs text-blue-700">Low</div>
                          <div className="font-medium text-blue-900">
                            {formatResult(result.result).metrics.lowIssues}
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}
                {result.status === 'analyzing' && (
                  <div className="text-sm text-gray-500 flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Analyzing code...
                  </div>
                )}
                {result.status === 'pending' && (
                  <div className="text-sm text-gray-500">
                    Waiting to start...
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
