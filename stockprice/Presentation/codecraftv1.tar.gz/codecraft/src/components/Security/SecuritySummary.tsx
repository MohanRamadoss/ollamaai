import React from 'react';
import { Shield, AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import type { SecurityIssue, SecurityMetrics } from '../../types/security';

interface SecuritySummaryProps {
  issues: SecurityIssue[];
  metrics: SecurityMetrics;
  modelResults: Record<string, {
    issues: SecurityIssue[];
    metrics: SecurityMetrics;
  }>;
}

export function SecuritySummary({ issues, metrics, modelResults }: SecuritySummaryProps) {
  const modelNames = Object.keys(modelResults);

  const getAgreementLevel = (issue: SecurityIssue): number => {
    let agreementCount = 0;
    modelNames.forEach(model => {
      if (modelResults[model].issues.some(i => 
        i.title === issue.title && 
        i.type === issue.type &&
        i.category === issue.category
      )) {
        agreementCount++;
      }
    });
    return (agreementCount / modelNames.length) * 100;
  };

  const getSeverityColor = (type: SecurityIssue['type']) => {
    switch (type) {
      case 'critical': return 'text-red-600 bg-red-50 border-red-200';
      case 'high': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Overall Metrics */}
      <div className="bg-white p-4 rounded-lg border border-gray-200">
        <div className="flex items-center gap-2 mb-4">
          <Shield className="w-5 h-5 text-indigo-600" />
          <h3 className="text-lg font-medium text-gray-900">Security Analysis Summary</h3>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-3 bg-red-50 rounded-lg">
            <div className="text-xs text-red-600">Critical</div>
            <div className="text-2xl font-bold text-red-700">{metrics.criticalIssues}</div>
          </div>
          <div className="p-3 bg-orange-50 rounded-lg">
            <div className="text-xs text-orange-600">High</div>
            <div className="text-2xl font-bold text-orange-700">{metrics.highIssues}</div>
          </div>
          <div className="p-3 bg-yellow-50 rounded-lg">
            <div className="text-xs text-yellow-600">Medium</div>
            <div className="text-2xl font-bold text-yellow-700">{metrics.mediumIssues}</div>
          </div>
          <div className="p-3 bg-blue-50 rounded-lg">
            <div className="text-xs text-blue-600">Low</div>
            <div className="text-2xl font-bold text-blue-700">{metrics.lowIssues}</div>
          </div>
        </div>

        <div className="mt-4">
          <div className="flex justify-between text-sm text-gray-600 mb-1">
            <span>Security Score</span>
            <span>{metrics.score}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all duration-300 ${
                metrics.score > 80 ? 'bg-green-500' :
                metrics.score > 60 ? 'bg-yellow-500' :
                'bg-red-500'
              }`}
              style={{ width: `${metrics.score}%` }}
            />
          </div>
        </div>
      </div>

      {/* Model Agreement */}
      <div className="bg-white p-4 rounded-lg border border-gray-200">
        <div className="flex items-center gap-2 mb-4">
          <CheckCircle2 className="w-5 h-5 text-indigo-600" />
          <h3 className="text-lg font-medium text-gray-900">Model Agreement</h3>
        </div>

        <div className="space-y-4">
          {issues.map((issue, index) => {
            const agreement = getAgreementLevel(issue);
            return (
              <div
                key={index}
                className={`p-4 rounded-lg border ${getSeverityColor(issue.type)}`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium">{issue.title}</h4>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        agreement > 80 ? 'bg-green-100 text-green-800' :
                        agreement > 50 ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {Math.round(agreement)}% Agreement
                      </span>
                    </div>
                    <p className="mt-1 text-sm">{issue.description}</p>
                  </div>
                  <span className="px-2 py-1 text-xs font-medium rounded-full capitalize">
                    {issue.type}
                  </span>
                </div>

                {/* Model Breakdown */}
                <div className="mt-2 space-y-1">
                  {modelNames.map(model => {
                    const found = modelResults[model].issues.some(i => 
                      i.title === issue.title && 
                      i.type === issue.type &&
                      i.category === issue.category
                    );
                    return (
                      <div key={model} className="flex items-center gap-2 text-sm">
                        {found ? (
                          <CheckCircle2 className="w-4 h-4 text-green-500" />
                        ) : (
                          <AlertTriangle className="w-4 h-4 text-red-500" />
                        )}
                        <span className="text-gray-600">{model}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}