import React, { useCallback } from 'react';
import { Upload, File, AlertTriangle } from 'lucide-react';
import { useDropzone } from 'react-dropzone';

interface FileAttachmentProps {
  onFileSelect: (content: string) => void;
  maxSize?: number;
}

export function FileAttachment({ onFileSelect, maxSize = 5242880 }: FileAttachmentProps) {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        onFileSelect(content);
      };
      reader.readAsText(file);
    }
  }, [onFileSelect]);

  const { getRootProps, getInputProps, isDragActive, fileRejections } = useDropzone({
    onDrop,
    maxSize,
    multiple: false,
    accept: {
      'text/*': ['.js', '.jsx', '.ts', '.tsx', '.py', '.java', '.cpp', '.c', '.go', '.rs', '.php']
    }
  });

  return (
    <div className="space-y-2">
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors
          ${isDragActive 
            ? 'border-indigo-500 bg-indigo-50' 
            : 'border-gray-300 hover:border-indigo-400'}`}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center gap-2">
          <Upload className="w-8 h-8 text-gray-400" />
          <p className="text-sm text-gray-600">
            Drag & drop a file here, or click to select
          </p>
          <p className="text-xs text-gray-500">
            Supported files: JavaScript, TypeScript, Python, Java, C++, Go, etc.
          </p>
        </div>
      </div>

      {fileRejections.length > 0 && (
        <div className="flex items-center gap-2 text-sm text-red-600">
          <AlertTriangle className="w-4 h-4" />
          <span>File too large or unsupported format</span>
        </div>
      )}
    </div>
  );
}
