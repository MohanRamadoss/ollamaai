import React from 'react';
import { Loader2, CheckCircle2, AlertTriangle } from 'lucide-react';
import type { SecurityScanProgress } from '../../lib/api/security';

interface SecurityProgressProps {
  progress: Record<string, SecurityScanProgress>;
}

export function SecurityProgress({ progress }: SecurityProgressProps) {
  const models = Object.values(progress);
  const totalProgress = models.reduce((sum, m) => sum + m.progress, 0) / models.length;

  return (
    <div className="space-y-4">
      {/* Overall Progress */}
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-gray-700">Overall Progress</span>
        <span className="text-sm text-gray-500">{Math.round(totalProgress)}%</span>
      </div>
      
      {/* Model-specific Progress */}
      <div className="space-y-3">
        {models.map((model) => (
          <div key={model.modelId} className="space-y-1">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                {model.status === 'completed' ? (
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                ) : model.status === 'failed' ? (
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                ) : (
                  <Loader2 className="w-4 h-4 text-indigo-500 animate-spin" />
                )}
                <span className="text-sm text-gray-700">{model.modelId}</span>
              </div>
              <span className="text-sm text-gray-500">{model.progress}%</span>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className={`h-2 rounded-full transition-all duration-500 ${
                  model.status === 'completed' ? 'bg-green-500' :
                  model.status === 'failed' ? 'bg-red-500' :
                  'bg-indigo-500'
                }`}
                style={{ width: `${model.progress}%` }}
              />
            </div>

            {model.error && (
              <p className="text-sm text-red-600 flex items-center gap-1 mt-1">
                <AlertTriangle className="w-4 h-4" />
                {model.error}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
