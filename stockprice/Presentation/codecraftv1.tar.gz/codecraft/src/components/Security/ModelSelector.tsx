import React from 'react';
import { CheckCircle2, Zap, Shield, Check } from 'lucide-react';
import { SECURITY_MODEL_CONFIGS } from '../../config/securityModels';

interface ModelSelectorProps {
  selectedModels: string[];
  onChange: (models: string[]) => void;
}

export function ModelSelector({ selectedModels, onChange }: ModelSelectorProps) {
  const handleModelSelect = (modelId: string, event: React.MouseEvent) => {
    // Prevent button click from triggering form submission
    event.preventDefault();
    event.stopPropagation();

    let newSelectedModels: string[];
    
    if (selectedModels.includes(modelId)) {
      if (selectedModels.length > 1) {
        newSelectedModels = selectedModels.filter(id => id !== modelId);
      } else {
        return; // Prevent deselecting the last model
      }
    } else {
      newSelectedModels = [...selectedModels, modelId];
    }

    console.log('Updating selected models:', newSelectedModels);
    onChange(newSelectedModels);
  };

  // Helper function to get model speed icon
  const getSpeedIcon = (speed: 'fast' | 'medium' | 'slow') => {
    switch (speed) {
      case 'fast': return <Zap className="w-4 h-4 text-green-500" />;
      case 'medium': return <Zap className="w-4 h-4 text-yellow-500" />;
      case 'slow': return <Zap className="w-4 h-4 text-red-500" />;
    }
  };

  // Helper function to get security level badge
  const getSecurityLevelBadge = (level: 'basic' | 'advanced' | 'enterprise') => {
    const colors = {
      basic: 'bg-blue-100 text-blue-700',
      advanced: 'bg-purple-100 text-purple-700',
      enterprise: 'bg-indigo-100 text-indigo-700'
    };
    return (
      <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full ${colors[level]}`}>
        {level}
      </span>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-indigo-600" />
          <h3 className="text-sm font-medium text-gray-700">Security AI Models</h3>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500">
            Selected: {selectedModels.length} / {Object.keys(SECURITY_MODEL_CONFIGS).length}
          </span>
          <button
            onClick={() => onChange(Object.keys(SECURITY_MODEL_CONFIGS))}
            className="text-xs text-indigo-600 hover:text-indigo-800"
          >
            Select All
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {Object.entries(SECURITY_MODEL_CONFIGS).map(([modelId, model]) => (
          <button
            key={modelId}
            type="button" // Add type="button" to prevent form submission
            onClick={(e) => handleModelSelect(modelId, e)}
            className={`relative flex flex-col p-4 text-left rounded-lg border transition-all ${
              selectedModels.includes(modelId)
                ? 'border-indigo-500 bg-indigo-50 ring-2 ring-indigo-200'
                : 'border-gray-200 hover:border-indigo-300 hover:bg-indigo-50/50'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="space-y-1 flex-1">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={selectedModels.includes(modelId)}
                    onChange={() => handleModelSelect(modelId)}
                    className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    onClick={(e) => e.stopPropagation()}
                  />
                  <h4 className="font-medium text-gray-900">{model.name}</h4>
                </div>
                <p className="text-sm text-gray-500 line-clamp-2">{model.description}</p>
              </div>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {model.capabilities.slice(0, 3).map((capability) => (
                <span
                  key={capability}
                  className="inline-flex items-center px-2 py-1 text-xs font-medium rounded-full bg-indigo-100 text-indigo-700"
                >
                  <Check className="w-3 h-3 mr-1" />
                  {capability}
                </span>
              ))}
              {model.capabilities.length > 3 && (
                <span className="text-xs text-gray-500">
                  +{model.capabilities.length - 3} more
                </span>
              )}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
