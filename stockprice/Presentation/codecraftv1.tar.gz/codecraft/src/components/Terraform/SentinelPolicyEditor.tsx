import React, { Suspense } from 'react';
import { Download, Copy, Check, Shield } from 'lucide-react';
import CodeMirror from '@uiw/react-codemirror';
import { vscodeDark } from '@uiw/codemirror-theme-vscode';
import { StreamLanguage } from '@codemirror/language';

interface SentinelPolicyEditorProps {
  value: string;
  onChange: (value: string) => void;
  readOnly?: boolean;
  isGenerating?: boolean;
  progress?: number;
  showValidation?: boolean;
}

// Basic Sentinel syntax definition
const sentinel = {
  name: 'sentinel',
  token: function(stream: any, state: any) {
    if (stream.eatSpace()) return null;

    // Comments
    if (stream.match('#') || stream.match('//')) {
      stream.skipToEnd();
      return 'comment';
    }

    // Strings
    if (stream.match(/"(?:[^"\\]|\\.)*"/)) return 'string';
    if (stream.match(/'(?:[^'\\]|\\.)*'/)) return 'string';

    // Keywords
    if (stream.match(/\b(import|rule|policy|main|print|as|for|in|if|else|return)\b/))
      return 'keyword';

    // Functions
    if (stream.match(/\b(all|any|filter|map|contains|length)\b/))
      return 'builtin';

    // Numbers
    if (stream.match(/\b\d+(\.\d+)?\b/)) return 'number';

    // Operators
    if (stream.match(/[=!<>]=?|[-+*/%|&]|\b(and|or|not)\b/)) return 'operator';

    stream.next();
    return null;
  },
  startState: function() {
    return {};
  },
};

export function SentinelPolicyEditor({
  value,
  onChange,
  readOnly = false,
  isGenerating = false,
  progress = 0,
  showValidation = true,
}: SentinelPolicyEditorProps) {
  const [copied, setCopied] = React.useState(false);
  const [downloading, setDownloading] = React.useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const blob = new Blob([value], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'policy.sentinel';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-2">
      {/* Progress Bar */}
      {isGenerating && (
        <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
          <div 
            className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}

      {/* Code Editor */}
      <div className="relative">
        <div className="h-[500px] border border-gray-200 rounded-lg overflow-hidden">
          <Suspense fallback={<div className="p-4 text-gray-500">Loading editor...</div>}>
            <CodeMirror
              value={value}
              height="100%"
              theme={vscodeDark}
              extensions={[StreamLanguage.define(sentinel)]}
              onChange={onChange}
              editable={!readOnly}
              basicSetup={{
                lineNumbers: true,
                highlightActiveLineGutter: true,
                highlightSpecialChars: true,
                history: true,
                foldGutter: true,
                drawSelection: true,
                dropCursor: true,
                allowMultipleSelections: true,
                indentOnInput: true,
                syntaxHighlighting: true,
                bracketMatching: true,
                closeBrackets: true,
                autocompletion: true,
                rectangularSelection: true,
                crosshairCursor: true,
                highlightActiveLine: true,
                highlightSelectionMatches: true,
                closeBracketsKeymap: true,
                defaultKeymap: true,
                searchKeymap: true,
                historyKeymap: true,
                foldKeymap: true,
                completionKeymap: true,
                lintKeymap: true,
              }}
            />
          </Suspense>
        </div>

        {/* Action Buttons */}
        <div className="absolute top-2 right-2 flex space-x-2">
          <button
            onClick={handleCopy}
            className="p-2 rounded-md bg-gray-800 text-white hover:bg-gray-700 transition-colors"
            title="Copy policy"
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
          </button>
          <button
            onClick={handleDownload}
            disabled={!value || downloading}
            className={`p-2 rounded-md bg-gray-800 text-white transition-colors ${
              value && !downloading ? 'hover:bg-gray-700' : 'opacity-50 cursor-not-allowed'
            }`}
            title="Download policy"
          >
            <Download size={16} className={downloading ? 'animate-bounce' : ''} />
          </button>
        </div>
      </div>
    </div>
  );
}