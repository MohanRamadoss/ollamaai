import React from 'react';
import { TERRAFORM_RESOURCE_TYPES, CATEGORY_ICONS, PROVIDER_ICONS, CloudProvider, ResourceCategory, ResourceType } from '../../config/terraform';

interface ResourceTypeSelectorProps {
  provider: CloudProvider;
  selectedType: string;
  onChange: (type: string) => void;
  onProviderChange: (provider: CloudProvider) => void;
}

export function ResourceTypeSelector({ 
  provider, 
  selectedType, 
  onChange,
  onProviderChange 
}: ResourceTypeSelectorProps) {
  const [selectedCategory, setSelectedCategory] = React.useState<ResourceCategory>('compute');

  const handleProviderChange = (newProvider: CloudProvider) => {
    onProviderChange(newProvider);
    // Reset category to compute and select first resource type
    setSelectedCategory('compute');
    const firstType = TERRAFORM_RESOURCE_TYPES[newProvider].compute[0];
    onChange(firstType.value);
  };

  const handleCategoryChange = (category: ResourceCategory) => {
    setSelectedCategory(category);
    // Select the first resource type in the category by default
    const firstType = TERRAFORM_RESOURCE_TYPES[provider][category][0];
    onChange(firstType.value);
  };

  const handleTypeChange = (type: ResourceType) => {
    onChange(type.value);
  };

  return (
    <div className="space-y-6">
      {/* Cloud Provider Selection */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Cloud Provider</label>
        <div className="grid grid-cols-3 gap-4">
          {Object.entries(PROVIDER_ICONS).map(([key, Icon]) => (
            <button
              key={key}
              onClick={() => handleProviderChange(key as CloudProvider)}
              className={`flex items-center justify-center p-4 rounded-lg border transition-colors ${
                provider === key
                  ? 'border-indigo-500 bg-indigo-50'
                  : 'border-gray-200 hover:border-indigo-300'
              }`}
            >
              <div className="flex flex-col items-center">
                <Icon className={`w-8 h-8 ${provider === key ? 'text-indigo-600' : 'text-gray-400'}`} />
                <span className="mt-2 text-sm font-medium">{key.toUpperCase()}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Category Selection */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Resource Category</label>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {(Object.keys(TERRAFORM_RESOURCE_TYPES[provider]) as ResourceCategory[]).map((category) => {
            const Icon = CATEGORY_ICONS[category];
            return (
              <button
                key={category}
                onClick={() => handleCategoryChange(category)}
                className={`flex flex-col items-center p-4 rounded-lg border transition-colors ${
                  selectedCategory === category
                    ? 'border-indigo-500 bg-indigo-50'
                    : 'border-gray-200 hover:border-indigo-300'
                }`}
              >
                <div className={selectedCategory === category ? 'text-indigo-600' : 'text-gray-400'}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="mt-2 text-sm font-medium capitalize">{category}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Resource Type Selection */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Resource Type</label>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {TERRAFORM_RESOURCE_TYPES[provider][selectedCategory].map((type) => (
            <button
              key={type.value}
              onClick={() => handleTypeChange(type)}
              className={`flex items-center p-4 rounded-lg border transition-colors ${
                selectedType === type.value
                  ? 'border-indigo-500 bg-indigo-50'
                  : 'border-gray-200 hover:border-indigo-300'
              }`}
            >
              <div className="flex-1">
                <div className="font-medium text-gray-900">{type.label}</div>
                <div className="text-sm text-gray-500">{type.value}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Example Resources */}
      <div className="bg-gray-50 p-4 rounded-lg">
        <h3 className="text-sm font-medium text-gray-700 mb-3">Example Resources</h3>
        <div className="space-y-2">
          {selectedCategory === 'containers' && (
            <>
              {provider === 'aws' && (
                <div className="text-sm text-gray-600">
                  <strong>EKS Example:</strong>
                  <pre className="mt-1 text-xs bg-gray-100 p-2 rounded">
                    {`resource "aws_eks_cluster" "example" {
  name     = "example"
  role_arn = aws_iam_role.eks_cluster.arn
  vpc_config {
    subnet_ids = aws_subnet.example[*].id
  }
  
  # Enable control plane logging
  enabled_cluster_log_types = ["api", "audit", "authenticator"]
  
  # Enable encryption
  encryption_config {
    resources = ["secrets"]
    provider {
      key_arn = aws_kms_key.eks.arn
    }
  }
}`}
                  </pre>
                </div>
              )}
              
              {provider === 'azure' && (
                <div className="text-sm text-gray-600">
                  <strong>AKS Example:</strong>
                  <pre className="mt-1 text-xs bg-gray-100 p-2 rounded">
                    {`resource "azurerm_kubernetes_cluster" "example" {
  name                = "example"
  location            = azurerm_resource_group.example.location
  resource_group_name = azurerm_resource_group.example.name
  dns_prefix          = "exampleaks"
  
  default_node_pool {
    name                = "default"
    node_count          = 1
    vm_size            = "Standard_D2_v2"
    enable_auto_scaling = true
    min_count          = 1
    max_count          = 3
  }
  
  network_profile {
    network_plugin     = "azure"
    network_policy     = "calico"
    load_balancer_sku = "standard"
  }
  
  identity {
    type = "SystemAssigned"
  }
}`}
                  </pre>
                </div>
              )}
              
              {provider === 'gcp' && (
                <div className="text-sm text-gray-600">
                  <strong>GKE Example:</strong>
                  <pre className="mt-1 text-xs bg-gray-100 p-2 rounded">
                    {`resource "google_container_cluster" "example" {
  name     = "example"
  location = "us-central1"
  
  # Enable Autopilot for fully managed nodes
  enable_autopilot = true
  
  # Use VPC-native networking
  networking_mode = "VPC_NATIVE"
  network        = google_compute_network.example.name
  subnetwork     = google_compute_subnetwork.example.name
  
  # Enable Workload Identity
  workload_identity_config {
    workload_pool = "\${data.google_project.project.project_id}.svc.id.goog"
  }
  
  # Enable Binary Authorization
  binary_authorization {
    evaluation_mode = "PROJECT_SINGLETON_POLICY_ENFORCE"
  }
}`}
                  </pre>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}