import React from 'react';
import { Shield, AlertTriangle, DollarSign } from 'lucide-react';
import { Switch } from '../ui/switch';

interface PolicyFeaturesProps {
  features: {
    sentinelPolicy: boolean;
    terraformAnalyzer: boolean;
  };
  onFeaturesChange: (features: { sentinelPolicy: boolean; terraformAnalyzer: boolean }) => void;
}

export function PolicyFeatures({ features, onFeaturesChange }: PolicyFeaturesProps) {
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900">Policy Features</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Sentinel Policy */}
        <div className="flex items-start space-x-4 p-4 bg-white rounded-lg border border-gray-200">
          <div className="flex-shrink-0">
            <Shield className="w-6 h-6 text-indigo-600" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h4 className="text-base font-medium text-gray-900">Sentinel Policy</h4>
              <Switch
                checked={features.sentinelPolicy}
                onCheckedChange={(checked) =>
                  onFeaturesChange({ ...features, sentinelPolicy: checked })
                }
              />
            </div>
            <p className="mt-1 text-sm text-gray-500">
              Generate Sentinel policies to enforce infrastructure compliance and security rules
            </p>
            <ul className="mt-2 text-sm text-gray-600 space-y-1">
              <li>• Security constraints</li>
              <li>• Cost controls</li>
              <li>• Compliance rules</li>
              <li>• Resource standards</li>
            </ul>
          </div>
        </div>

        {/* Terraform Analyzer */}
        <div className="flex items-start space-x-4 p-4 bg-white rounded-lg border border-gray-200">
          <div className="flex-shrink-0">
            <AlertTriangle className="w-6 h-6 text-yellow-600" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h4 className="text-base font-medium text-gray-900">Terraform Analyzer</h4>
              <Switch
                checked={features.terraformAnalyzer}
                onCheckedChange={(checked) =>
                  onFeaturesChange({ ...features, terraformAnalyzer: checked })
                }
              />
            </div>
            <p className="mt-1 text-sm text-gray-500">
              Analyze Terraform code for security, compliance, and best practices
            </p>
            <ul className="mt-2 text-sm text-gray-600 space-y-1">
              <li>• Security analysis</li>
              <li>• Best practices</li>
              <li>• Cost optimization</li>
              <li>• Resource validation</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Feature Examples */}
      <div className="bg-gray-50 p-4 rounded-lg">
        <h4 className="text-sm font-medium text-gray-700 mb-3">Example Policies</h4>
        <div className="space-y-3">
          <div className="text-sm text-gray-600">
            <strong>Sentinel Policy Example:</strong>
            <pre className="mt-1 text-xs bg-gray-100 p-2 rounded">
              {`# Rule to enforce container security
import "tfplan"

required_security_context = rule {
  all tfplan.resources.kubernetes_pod as _, pods {
    all pods.applied.spec as _, spec {
      spec.security_context != null
    }
  }
}`}
            </pre>
          </div>
          <div className="text-sm text-gray-600">
            <strong>Analysis Example:</strong>
            <pre className="mt-1 text-xs bg-gray-100 p-2 rounded">
              {`# Security Analysis Results
✓ RBAC policies configured correctly
⚠ Consider enabling network policies
✗ Pod security policies not enforced
ℹ Resource quotas recommended`}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}