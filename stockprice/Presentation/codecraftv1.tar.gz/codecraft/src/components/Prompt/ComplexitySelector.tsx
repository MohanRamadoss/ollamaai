import React from 'react';
import { Layers } from 'lucide-react';
import type { ComplexityLevel } from '../../types/prompt';

const COMPLEXITY_LEVELS = [
  { id: 'basic', name: 'Basic', description: 'Simple implementation' },
  { id: 'intermediate', name: 'Intermediate', description: 'Moderate complexity' },
  { id: 'advanced', name: 'Advanced', description: 'Complex implementation' }
];

interface ComplexitySelectorProps {
  value: ComplexityLevel;
  onChange: (complexity: ComplexityLevel) => void;
}

export function ComplexitySelector({ value, onChange }: ComplexitySelectorProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Layers className="w-5 h-5 text-indigo-600" />
        <h3 className="text-sm font-medium text-gray-900">Complexity Level</h3>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {COMPLEXITY_LEVELS.map((level) => (
          <button
            key={level.id}
            onClick={() => onChange(level.id as ComplexityLevel)}
            className={`p-4 rounded-lg border text-left ${
              value === level.id
                ? 'border-indigo-600 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-300'
            }`}
          >
            <div className="font-medium text-sm text-gray-900">{level.name}</div>
            <div className="text-xs text-gray-500 mt-1">{level.description}</div>
          </button>
        ))}
      </div>
    </div>
  );
}
