import React from 'react';
import { Code2 } from 'lucide-react';
import type { ProgrammingLanguage } from '../../types/prompt';

interface LanguageOption {
  id: ProgrammingLanguage;
  name: string;
  icon: string;
  category: 'programming' | 'infrastructure' | 'automation';
}

const PROGRAMMING_LANGUAGES: LanguageOption[] = [
  // Programming Languages
  { id: 'javascript', name: 'JavaScript', icon: 'js', category: 'programming' },
  { id: 'python', name: 'Python', icon: 'py', category: 'programming' },
  { id: 'typescript', name: 'TypeScript', icon: 'ts', category: 'programming' },
  { id: 'java', name: 'Java', icon: 'java', category: 'programming' },
  { id: 'go', name: 'Go', icon: 'go', category: 'programming' },
  { id: 'rust', name: 'Rust', icon: 'rs', category: 'programming' },
  { id: 'csharp', name: 'C#', icon: 'cs', category: 'programming' },
  
  // Infrastructure as Code
  { id: 'terraform', name: 'Terraform', icon: 'tf', category: 'infrastructure' },
  { id: 'cloudformation', name: 'CloudFormation', icon: 'cf', category: 'infrastructure' },
  { id: 'arm', name: 'ARM Templates', icon: 'arm', category: 'infrastructure' },
  { id: 'pulumi', name: 'Pulumi', icon: 'pulumi', category: 'infrastructure' },
  { id: 'bicep', name: 'Bicep', icon: 'bicep', category: 'infrastructure' },
  
  // Automation & DevOps
  { id: 'ansible', name: 'Ansible', icon: 'ansible', category: 'automation' },
  { id: 'powershell', name: 'PowerShell', icon: 'ps1', category: 'automation' },
  { id: 'bash', name: 'Bash', icon: 'sh', category: 'automation' },
  { id: 'shell', name: 'Shell Script', icon: 'shell', category: 'automation' },
  { id: 'docker', name: 'Dockerfile', icon: 'docker', category: 'automation' },
  { id: 'kubernetes', name: 'Kubernetes', icon: 'k8s', category: 'automation' },
  { id: 'helm', name: 'Helm', icon: 'helm', category: 'automation' },
  { id: 'gitlab-ci', name: 'GitLab CI', icon: 'gitlab', category: 'automation' },
  { id: 'github-actions', name: 'GitHub Actions', icon: 'github', category: 'automation' },
].sort((a, b) => a.name.localeCompare(b.name));

const LANGUAGE_CATEGORIES = {
  programming: 'Programming Languages',
  infrastructure: 'Infrastructure as Code',
  automation: 'Automation & DevOps'
};

interface LanguageSelectorProps {
  value: string;
  onChange: (language: string) => void;
}

export function LanguageSelector({ value, onChange }: LanguageSelectorProps) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700">
        Language / Framework
      </label>
      <div className="mt-1">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
        >
          {Object.entries(LANGUAGE_CATEGORIES).map(([category, label]) => (
            <optgroup key={category} label={label}>
              {PROGRAMMING_LANGUAGES
                .filter(lang => lang.category === category)
                .map((lang) => (
                  <option key={lang.id} value={lang.id}>
                    {lang.name}
                  </option>
                ))}
            </optgroup>
          ))}
        </select>
      </div>
    </div>
  );
}
