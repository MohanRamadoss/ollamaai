import React from 'react';
import { Check, Server } from 'lucide-react';
import { PROMPT_MODELS } from '../../config/promptModels';

interface ModelMultiSelectProps {
  selectedModels: string[];
  onChange: (models: string[]) => void;
}

export function ModelMultiSelect({ selectedModels, onChange }: ModelMultiSelectProps) {
  const handleModelToggle = (modelId: string) => {
    if (selectedModels.includes(modelId)) {
      onChange(selectedModels.filter(id => id !== modelId));
    } else {
      onChange([...selectedModels, modelId]);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-4">
        <Server className="w-5 h-5 text-indigo-600" />
        <h3 className="text-sm font-medium text-gray-900">Select AI Models</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {PROMPT_MODELS.map((model) => (
          <button
            key={model.id}
            onClick={() => handleModelToggle(model.id)}
            className={`flex items-center justify-between p-4 rounded-lg border ${
              selectedModels.includes(model.id)
                ? 'border-indigo-600 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-300'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0">
                <div className={`w-2 h-2 rounded-full ${
                  model.provider === 'google' ? 'bg-blue-500' : 'bg-green-500'
                }`} />
              </div>
              <div className="text-left">
                <div className="text-sm font-medium text-gray-900">{model.name}</div>
                <div className="text-xs text-gray-500">{model.description}</div>
              </div>
            </div>
            {selectedModels.includes(model.id) && (
              <Check className="w-5 h-5 text-indigo-600" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
