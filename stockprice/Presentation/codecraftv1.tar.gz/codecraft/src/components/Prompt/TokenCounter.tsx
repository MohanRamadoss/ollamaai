import React from 'react';
import { Hash } from 'lucide-react';

interface TokenCounterProps {
  code: string;
  maxTokens: number;
}

export function TokenCounter({ code, maxTokens }: TokenCounterProps) {
  // Simple estimation: ~4 characters per token
  const estimatedTokens = Math.ceil(code.length / 4);
  const percentage = (estimatedTokens / maxTokens) * 100;
  const isNearLimit = percentage > 80;
  const isOverLimit = percentage > 100;

  return (
    <div className="flex items-center gap-2">
      <Hash className="w-4 h-4 text-gray-400" />
      <span className={`text-sm ${
        isOverLimit 
          ? 'text-red-600' 
          : isNearLimit 
            ? 'text-yellow-600' 
            : 'text-gray-500'
      }`}>
        {estimatedTokens.toLocaleString()} tokens
        <span className="text-gray-400"> / {maxTokens.toLocaleString()}</span>
      </span>
    </div>
  );
}
