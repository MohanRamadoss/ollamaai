import React from 'react';
import { User } from 'lucide-react';

interface AvatarProps {
  name: string;
  imageUrl?: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const sizeClasses = {
  sm: 'h-8 w-8',
  md: 'h-10 w-10',
  lg: 'h-12 w-12',
};

export function Avatar({ name, imageUrl, size = 'md', className = '' }: AvatarProps) {
  const sizeClass = sizeClasses[size];

  if (!imageUrl) {
    // Create background color based on name
    const colors = [
      'bg-indigo-500',
      'bg-blue-500',
      'bg-green-500',
      'bg-yellow-500',
      'bg-red-500',
      'bg-purple-500',
    ];
    const colorIndex = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) % colors.length;
    const bgColor = colors[colorIndex];

    // Get initials
    const initials = name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);

    return (
      <div
        className={`${sizeClass} ${bgColor} rounded-full flex items-center justify-center text-white font-medium ${className}`}
        title={name}
      >
        {initials}
      </div>
    );
  }

  return (
    <div className={`${sizeClass} relative rounded-full overflow-hidden ${className}`}>
      <img
        src={imageUrl}
        alt={name}
        className="h-full w-full object-cover"
        onError={(e) => {
          e.currentTarget.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(
            name
          )}&background=6366f1&color=ffffff`;
        }}
      />
    </div>
  );
}