import React from 'react';
import { Loader2 } from 'lucide-react';
import type { AnalysisProgress } from '../../lib/api/analyze';

interface CodeAnalysisProgressProps {
  progress: Record<string, AnalysisProgress>;
}

export function CodeAnalysisProgress({ progress }: CodeAnalysisProgressProps) {
  const models = Object.values(progress);
  const completed = models.filter(m => m.status === 'completed').length;
  const total = models.length;
  const percentage = total > 0 ? (completed / total) * 100 : 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-sm text-gray-600">
        <div className="flex items-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin" />
          Analyzing with {total} models...
        </div>
        <span>{Math.round(percentage)}%</span>
      </div>

      <div className="w-full bg-gray-200 rounded-full h-2">
        <div
          className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
          style={{ width: `${percentage}%` }}
        />
      </div>

      <div className="space-y-2">
        {models.map((model) => (
          <div
            key={model.modelId}
            className="flex items-center justify-between text-sm"
          >
            <span className="text-gray-600">{model.modelId}</span>
            <span className={
              model.status === 'failed' ? 'text-red-500' :
              model.status === 'completed' ? 'text-green-500' :
              'text-gray-500'
            }>
              {model.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
