import React, { useState } from 'react';
import { AlertCircle, CheckCircle, Info, ChevronDown, ChevronUp } from 'lucide-react';
import { CodeEditor } from '../CodeEditor';
import '../../styles/codeAnalysis.css';

interface AnalysisResult {
  type: 'error' | 'warning' | 'info' | 'success';
  message: string;
  line?: number;
  suggestion?: string;
}

interface AnalysisOutputProps {
  results: AnalysisResult[];
  isAnalyzing: boolean;
  progress: number;
}

const typeIcons = {
  error: <AlertCircle className="w-5 h-5 text-red-500" />,
  warning: <AlertCircle className="w-5 h-5 text-yellow-500" />,
  info: <Info className="w-5 h-5 text-blue-500" />,
  success: <CheckCircle className="w-5 h-5 text-green-500" />
};

const typeColors = {
  error: 'bg-red-50 border-red-200',
  warning: 'bg-yellow-50 border-yellow-200',
  info: 'bg-blue-50 border-blue-200',
  success: 'bg-green-50 border-green-200'
};

export function AnalysisOutput({ results, isAnalyzing, progress }: AnalysisOutputProps) {
  const [expandedType, setExpandedType] = useState<string | null>(null);

  if (isAnalyzing) {
    return (
      <div className="space-y-4">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          <div className="h-4 bg-gray-200 rounded w-5/6"></div>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div 
            className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    );
  }

  if (!results.length) {
    return (
      <div className="text-center py-8 text-gray-500">
        No analysis results yet. Submit your code to begin analysis.
      </div>
    );
  }

  // Group results by type and organize by line numbers
  const groupedResults = results.reduce((acc, result) => {
    const type = result.type;
    if (!acc[type]) {
      acc[type] = {
        items: [],
        count: 0
      };
    }
    
    // Group related items by line numbers if they exist
    const existingItem = acc[type].items.find(item => 
      item.line === result.line || 
      (item.message.includes('Line') && result.message.includes('Line'))
    );

    if (existingItem) {
      existingItem.details = existingItem.details || [];
      existingItem.details.push(result.message);
    } else {
      acc[type].items.push({
        message: result.message,
        line: result.line,
        suggestion: result.suggestion
      });
    }
    
    acc[type].count++;
    return acc;
  }, {} as Record<string, { items: any[], count: number }>);

  function formatAnalysisContent(items: any[]): string {
    return items.map(item => {
      let content = item.message;
      if (item.line) {
        content = `[Line ${item.line}] ${content}`;
      }
      if (item.details) {
        content += '\n' + item.details.map((d: string) => `  - ${d}`).join('\n');
      }
      if (item.suggestion) {
        content += `\n  Suggestion: ${item.suggestion}`;
      }
      return content;
    }).join('\n\n');
  }

  const handleTypeClick = (e: React.MouseEvent, type: string) => {
    e.preventDefault();
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();
    setExpandedType(expandedType === type ? null : type);
  };

  const handleContentClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();
  };

  return (
    <div className="space-y-6" onClick={handleContentClick}>
      {Object.entries(groupedResults).map(([type, { items, count }]) => (
        <div 
          key={type} 
          className="rounded-lg border border-gray-200 overflow-hidden"
          onClick={handleContentClick}
        >
          <button
            type="button"
            onClick={(e) => handleTypeClick(e, type)}
            onMouseDown={(e) => e.preventDefault()}
            className={`w-full p-4 flex items-center justify-between ${
              type === 'error' ? 'bg-red-50' :
              type === 'warning' ? 'bg-yellow-50' :
              type === 'info' ? 'bg-blue-50' :
              'bg-green-50'
            } hover:bg-opacity-75 transition-colors`}
          >
            <div className="flex items-center gap-2">
              {typeIcons[type as keyof typeof typeIcons]}
              <span className="font-medium capitalize">{type} ({count})</span>
            </div>
            {expandedType === type ? (
              <ChevronUp className="w-5 h-5 text-gray-500" />
            ) : (
              <ChevronDown className="w-5 h-5 text-gray-500" />
            )}
          </button>

          {expandedType === type && (
            <div 
              className="border-t"
              onClick={handleContentClick}
              onMouseDown={(e) => e.preventDefault()}
              style={{ maxHeight: 'calc(100vh - 300px)', position: 'relative' }}
            >
              <CodeEditor
                value={formatAnalysisContent(items)}
                language="markdown"
                theme="vs-dark"
                className="analysis-editor overflow-auto"
                height="300px"
                options={{
                  readOnly: true,
                  minimap: { enabled: true },
                  lineNumbers: 'on',
                  scrollBeyondLastLine: false,
                  wordWrap: 'on',
                  wrappingStrategy: 'advanced',
                  renderLineHighlight: 'all',
                  folding: true,
                  foldingHighlight: true,
                  renderIndentGuides: true,
                  scrollbar: {
                    vertical: 'visible',
                    horizontal: 'visible',
                    verticalScrollbarSize: 14,
                    horizontalScrollbarSize: 14,
                    alwaysConsumeMouseWheel: true
                  },
                  overviewRulerLanes: 3,
                  overviewRulerBorder: true,
                  hideCursorInOverviewRuler: true,
                  lineDecorationsWidth: 10,
                  renderValidationDecorations: 'on',
                  formatOnPaste: true,
                  formatOnType: true,
                  links: true,
                  padding: { top: 8, bottom: 8 },
                  contextmenu: false,
                  mouseWheelZoom: false,
                  quickSuggestions: false,
                }}
                decorations={[
                  {
                    range: {
                      startLineNumber: 1,
                      endLineNumber: 1,
                      startColumn: 1,
                      endColumn: 1
                    },
                    options: {
                      isWholeLine: true,
                      className: type === 'error' ? 'bg-red-900/10' :
                                type === 'warning' ? 'bg-yellow-900/10' :
                                type === 'info' ? 'bg-blue-900/10' :
                                'bg-green-900/10'
                    }
                  }
                ]}
                onMouseDown={(e) => e.preventDefault()}
                onClick={handleContentClick}
              />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}