import React, { useState } from 'react';
import { Loader2, AlertTriangle, CheckCircle, Copy, Download, ChevronDown, ChevronUp } from 'lucide-react';
import { CodeEditor } from '../CodeEditor';
import { TokenCounter } from '../TokenCounter';
import type { AnalysisProgress } from '../../lib/api/analyze';
import '../../styles/codeAnalysis.css';

interface MultiModelOutputProps {
  results: Record<string, AnalysisProgress>;
  maxTokens?: number;
  language?: string; // Add language prop
  analysisType: string; // Add this prop
}

const languageExtensions: Record<string, string> = {
  'python': 'py',
  'javascript': 'js',
  'typescript': 'ts',
  'java': 'java',
  'cpp': 'cpp',
  'c++': 'cpp',
  'go': 'go',
  'ruby': 'rb',
  'php': 'php',
  'csharp': 'cs',
  'c#': 'cs',
  'rust': 'rs',
  'swift': 'swift',
  'kotlin': 'kt',
  'shell': 'sh',
  'powershell': 'ps1',
  'sql': 'sql',
  'yaml': 'yml',
  'json': 'json',
  'markdown': 'md',
  'terraform': 'tf',
  'ansible': 'yml',
  'dockerfile': 'Dockerfile'
};

export function MultiModelOutput({ results, maxTokens = 2048, language = 'plaintext', analysisType }: MultiModelOutputProps) {
  const [expandedModel, setExpandedModel] = useState<string | null>(null);
  const [copiedModel, setCopiedModel] = useState<string | null>(null);

  if (!Object.keys(results).length) return null;

  const handleCopy = async (event: React.MouseEvent, result: string, modelId: string) => {
    event.preventDefault();
    event.stopPropagation();
    event.nativeEvent.stopImmediatePropagation();

    try {
      await navigator.clipboard.writeText(result);
      setCopiedModel(modelId);
      setTimeout(() => setCopiedModel(null), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const handleDownload = (result: string, modelId: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation(); // Add this line
    const extension = languageExtensions[language.toLowerCase()] || 'txt';
    const filename = modelId.toLowerCase() === 'dockerfile' ? 'Dockerfile' : `${modelId}_output.${extension}`;
    const blob = new Blob([result], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleButtonClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();
    return false;
  };

  const handleContentClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();
  };

  const handleModelClick = (e: React.MouseEvent, modelId: string) => {
    e.preventDefault();
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();
    setExpandedModel(expandedModel === modelId ? null : modelId);
  };

  function formatAnalysisOutput(result: string): string {
    if (!result) return '';

    // Split content by sections and clean up
    const lines = result.split('\n');
    const sections: Record<string, string[]> = {
      'CODE QUALITY': [],
      'POTENTIAL ISSUES': [],
      'SECURITY': [],
      'PERFORMANCE': [],
      'MAINTAINABILITY': [],
      'OTHER': []
    };

    let currentSection = 'OTHER';

    lines.forEach(line => {
      const trimmed = line.trim();
      if (!trimmed) return;

      // Check for section headers
      if (trimmed.match(/^#{2,3}\s+[A-Z\s]+/)) {
        const sectionName = trimmed.replace(/^#{2,3}\s+/, '').trim().toUpperCase();
        if (!sections[sectionName]) {
          sections[sectionName] = [];
        }
        currentSection = sectionName;
        return;
      }

      // Handle content lines
      let content = trimmed;
      if (content.startsWith('* ')) {
        content = content.substring(2);
      }

      // Clean up prefixes
      ['ERROR:', 'WARNING:', 'SUGGESTION:', 'INFO:'].forEach(prefix => {
        if (content.toUpperCase().startsWith(prefix)) {
          content = content.substring(prefix.length).trim();
        }
      });

      if (content) {
        sections[currentSection].push(`* ${content}`);
      }
    });

    // Format output
    return Object.entries(sections)
      .filter(([_, items]) => items.length > 0)
      .map(([section, items]) => {
        const uniqueItems = Array.from(new Set(items)); // Remove duplicates
        return `## ${section}\n\n${uniqueItems.join('\n')}`;
      })
      .join('\n\n');
  }

  return (
    <div className="space-y-4 mt-6" onClick={handleContentClick}>
      {Object.entries(results).map(([modelId, output]) => (
        <div key={modelId} className="border rounded-lg overflow-hidden" onClick={handleContentClick}>
          <button
            type="button"
            onClick={(e) => handleModelClick(e, modelId)}
            className="w-full flex items-center justify-between p-4 bg-gray-50 cursor-pointer hover:bg-gray-100"
          >
            <div className="flex items-center gap-4">
              <span className="font-medium">{modelId}</span>
              {output.status === 'analyzing' && (
                <div className="flex items-center text-indigo-600">
                  <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                  <span className="text-sm">Analyzing...</span>
                </div>
              )}
              {output.status === 'completed' && (
                <div className="flex items-center gap-4">
                  <div className="flex items-center text-green-500">
                    <CheckCircle className="w-4 h-4 mr-1" />
                    <span className="text-sm">Completed</span>
                  </div>
                  {output.result && (
                    <TokenCounter 
                      code={output.result} 
                      maxTokens={maxTokens}
                      className="text-sm text-gray-500"
                    />
                  )}
                </div>
              )}
              {output.status === 'failed' && (
                <div className="flex items-center text-red-500">
                  <AlertTriangle className="w-4 h-4 mr-1" />
                  <span className="text-sm">{output.error || 'Analysis failed'}</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2" onClick={handleButtonClick}>
              {output.status === 'completed' && output.result && (
                <>
                  <button
                    type="button"
                    onClick={(e) => handleCopy(e, output.result!, modelId)}
                    onMouseDown={e => e.preventDefault()}
                    className="p-2 rounded hover:bg-gray-200"
                    title={copiedModel === modelId ? 'Copied!' : 'Copy'}
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => handleDownload(output.result!, modelId, e)}
                    className="p-2 rounded hover:bg-gray-200"
                    title="Download"
                    onMouseDown={handleButtonClick}
                    onMouseUp={handleButtonClick}
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </>
              )}
              {expandedModel === modelId ? (
                <ChevronUp className="w-5 h-5" />
              ) : (
                <ChevronDown className="w-5 h-5" />
              )}
            </div>
          </button>

          {expandedModel === modelId && output.status === 'completed' && output.result && (
            <div 
              className="p-4 bg-gray-900"
              onClick={handleContentClick}
              onMouseDown={(e) => e.preventDefault()}
              style={{ maxHeight: 'calc(100vh - 300px)', position: 'relative' }}
            >
              <div className="border rounded overflow-hidden bg-gray-800" style={{ height: '100%' }}>
                <CodeEditor
                  value={formatAnalysisOutput(output.result)}
                  language="markdown"
                  readOnly
                  showLineNumbers
                  height="300px"
                  theme="vs-dark"
                  className="analysis-editor overflow-auto"
                  options={{
                    minimap: { enabled: false },
                    scrollBeyondLastLine: false,
                    wordWrap: 'on',
                    wrappingStrategy: 'advanced',
                    lineNumbers: 'on',
                    renderLineHighlight: 'all',
                    readOnly: true,
                    contextmenu: false,
                    quickSuggestions: false,
                    folding: true,
                    foldingStrategy: 'indentation',
                    renderFoldingHighlight: true,
                    showFoldingControls: 'always',
                    scrollbar: {
                      vertical: 'visible',
                      horizontal: 'visible',
                      verticalScrollbarSize: 14,
                      horizontalScrollbarSize: 14,
                      alwaysConsumeMouseWheel: true
                    }
                  }}
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={handleContentClick}
                />
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
