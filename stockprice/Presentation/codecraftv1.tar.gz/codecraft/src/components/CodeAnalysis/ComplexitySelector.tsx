import React from 'react';
import { Zap } from 'lucide-react';
import type { ComplexityLevel } from '../../types/models';

const COMPLEXITY_LEVELS: Array<{
  id: ComplexityLevel;
  name: string;
  description: string;
}> = [
  {
    id: 'basic',
    name: 'Basic',
    description: 'Quick surface-level analysis'
  },
  {
    id: 'intermediate',
    name: 'Intermediate',
    description: 'Balanced depth and performance'
  },
  {
    id: 'advanced',
    name: 'Advanced',
    description: 'Deep, thorough analysis'
  }
];

interface ComplexitySelectorProps {
  value: ComplexityLevel;
  onChange: (value: ComplexityLevel) => void;
}

export function ComplexitySelector({ value, onChange }: ComplexitySelectorProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Zap className="w-5 h-5 text-indigo-600" />
        <label className="block text-sm font-medium text-gray-700">
          Analysis Complexity
        </label>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {COMPLEXITY_LEVELS.map((level) => (
          <button
            key={level.id}
            onClick={() => onChange(level.id)}
            className={`flex flex-col p-4 rounded-lg border transition-colors ${
              value === level.id
                ? 'border-indigo-500 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-300'
            }`}
          >
            <span className="font-medium text-gray-900">{level.name}</span>
            <span className="mt-1 text-sm text-gray-500">
              {level.description}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
