import React from 'react';
import { AIML_TASKS } from '../../config/aiml';

interface Props {
  selectedTask: string;
  onChange: (task: string) => void;
}

export function AIMLTaskSelector({ selectedTask, onChange }: Props) {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">Task Type</label>
      <select
        value={selectedTask}
        onChange={(e) => onChange(e.target.value)}
        className="w-full p-2 border rounded-md"
      >
        {Object.entries(AIML_TASKS).map(([key, value]) => (
          <option key={key} value={key}>{value}</option>
        ))}
      </select>
    </div>
  );
}
