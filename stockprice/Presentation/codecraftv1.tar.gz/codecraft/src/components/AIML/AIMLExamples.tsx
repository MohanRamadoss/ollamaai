import React from 'react';
import { Lightbulb } from 'lucide-react';
import type { AIMLLanguage, AIMLTask } from '../../types/aiml';

interface Example {
  title: string;
  description: string;
  language: AIMLLanguage;
  task: AIMLTask;
  prompt: string;
}

const EXAMPLES: Example[] = [
  {
    title: 'Image Classification Model',
    description: 'Train a CNN for image classification',
    language: 'python',
    task: 'modelTraining',
    prompt: 'Create a CNN model using TensorFlow for image classification with transfer learning. Include data augmentation, early stopping, and model checkpointing.'
  },
  {
    title: 'Time Series Preprocessing',
    description: 'Prepare time series data for analysis',
    language: 'python',
    task: 'dataPreprocessing',
    prompt: 'Create a data preprocessing pipeline for time series data including handling missing values, resampling, and feature engineering for temporal data.'
  },
  {
    title: 'Model Performance Analysis',
    description: 'Comprehensive model evaluation',
    language: 'python',
    task: 'evaluation',
    prompt: 'Create an evaluation suite that includes confusion matrix, ROC curves, precision-recall curves, and cross-validation for a classification model.'
  },
  {
    title: 'Model Deployment API',
    description: 'REST API for model serving',
    language: 'python',
    task: 'deployment',
    prompt: 'Create a FastAPI service for model deployment with input validation, request logging, and performance monitoring.'
  },
  {
    title: 'Hyperparameter Tuning',
    description: 'Optimize model performance',
    language: 'python',
    task: 'optimization',
    prompt: 'Implement hyperparameter optimization using Bayesian optimization with proper logging and visualization of results.'
  },
  {
    title: 'Statistical Analysis Pipeline',
    description: 'Advanced statistical analysis workflow',
    language: 'r',
    task: 'dataPreprocessing',
    prompt: 'Create an R script for comprehensive statistical analysis including data cleaning, normality tests, parametric/non-parametric tests, and publication-ready visualizations using ggplot2.'
  },
  {
    title: 'Bioinformatics Workflow',
    description: 'Gene expression analysis',
    language: 'r',
    task: 'dataPreprocessing',
    prompt: 'Develop a pipeline for RNA-seq data analysis including quality control, normalization, differential expression analysis, and pathway analysis using Bioconductor packages.'
  },
  {
    title: 'Data Warehouse ETL',
    description: 'Complex ETL operations',
    language: 'sql',
    task: 'dataPreprocessing',
    prompt: 'Create an ETL process with incremental loading, slowly changing dimensions, and data quality checks for a data warehouse.'
  }
];

interface Props {
  onSelect: (example: Example) => void;
}

export function AIMLExamples({ onSelect }: Props) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 text-gray-600">
        <Lightbulb className="w-5 h-5" />
        <h3 className="text-sm font-medium">Example Tasks</h3>
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {EXAMPLES.map((example, index) => (
          <button
            key={index}
            onClick={() => onSelect(example)}
            className="p-4 text-left border rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors"
          >
            <h4 className="font-medium text-gray-900">{example.title}</h4>
            <p className="mt-1 text-sm text-gray-500">{example.description}</p>
            <div className="mt-2 flex items-center gap-2">
              <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                {example.language}
              </span>
              <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                {example.task}
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
