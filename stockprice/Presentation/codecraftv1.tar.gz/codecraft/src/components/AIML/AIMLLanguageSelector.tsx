import React from 'react';
import { Code2 } from 'lucide-react';
import type { AIMLLanguage } from '../../types/aiml';

const LANGUAGES: Record<AIMLLanguage, string> = {
  python: 'Python',
  r: 'R',
  sql: 'SQL',
  java: 'Java',
  julia: 'Julia',
  scala: 'Scala',
  cpp: 'C++',
  javascript: 'JavaScript',
  swift: 'Swift',
  go: 'Go',
  matlab: 'MATLAB',
  sas: 'SAS'
};

interface Props {
  selectedLanguage: AIMLLanguage;
  onChange: (language: AIMLLanguage) => void;
}

export function AIMLLanguageSelector({ selectedLanguage, onChange }: Props) {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">Programming Language</label>
      <div className="grid grid-cols-4 gap-3">
        {Object.entries(LANGUAGES).map(([key, name]) => (
          <button
            key={key}
            onClick={() => onChange(key as AIMLLanguage)}
            className={`flex items-center p-3 border rounded-lg transition-colors ${
              selectedLanguage === key
                ? 'border-blue-500 bg-blue-50 text-blue-700'
                : 'border-gray-200 hover:border-blue-300 text-gray-700'
            }`}
          >
            <Code2 className={`w-4 h-4 mr-2 ${
              selectedLanguage === key ? 'text-blue-600' : 'text-gray-500'
            }`} />
            <span className="font-medium">{name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
