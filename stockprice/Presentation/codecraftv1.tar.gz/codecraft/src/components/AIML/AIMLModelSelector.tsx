import React from 'react';
import { Brain } from 'lucide-react';
import { AIML_MODELS } from '../../config/aiml';

interface Props {
  selectedModel: string;
  onChange: (model: string) => void;
}

export function AIMLModelSelector({ selectedModel, onChange }: Props) {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">Model</label>
      <div className="grid grid-cols-2 gap-4">
        {Object.entries(AIML_MODELS).map(([id, name]) => (
          <button
            key={id}
            onClick={() => onChange(id)}
            className={`flex items-center p-4 border rounded-lg transition-colors ${
              selectedModel === id
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-blue-300'
            }`}
          >
            <Brain className="w-5 h-5 text-blue-600 mr-3" />
            <div className="text-left">
              <div className="font-medium text-gray-900">{name}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
