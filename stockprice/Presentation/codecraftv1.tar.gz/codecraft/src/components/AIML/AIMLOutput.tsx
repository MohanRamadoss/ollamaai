import React, { useState, useMemo } from 'react';
import { AlertTriangle, Loader2, Code2, Copy, Download, ChevronUp, ChevronDown } from 'lucide-react';
import { CodeEditor } from '../CodeEditor'; // Import CodeEditor
import type { AIMLProgress } from '../../lib/api/aiml';
import { SUPPORTED_LANGUAGES, type SupportedLanguage } from '../../types/supported-languages';

interface Props {
  result?: string;
  error?: Error | null;
  isGenerating: boolean;
  progress: AIMLProgress;
  language?: string; // Add language prop
}

export function AIMLOutput({ result, error, isGenerating, progress, language = 'python' }: Props) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (result) {
      await navigator.clipboard.writeText(result);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (result) {
      const blob = new Blob([result], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `generated-code.${language || 'txt'}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    }
  };

  const handleToggleExpand = () => {
    setIsExpanded(!isExpanded);
  };

  // Memoize the language to prevent unnecessary re-renders
  const languageForEditor = useMemo(() => language, [language]);

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-md flex items-center gap-2 text-red-700">
        <AlertTriangle className="w-5 h-5" />
        {error.message}
      </div>
    );
  }

  if (isGenerating) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-blue-600">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span>{progress.status}</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all duration-500"
            style={{ width: `${progress.progress}%` }}
          />
        </div>
      </div>
    );
  }

  if (!result) {
    return null;
  }

  return (
    <div className="space-y-4">
      <button
        onClick={handleToggleExpand}
        className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-t-lg border border-gray-200"
      >
        <div className="flex items-center gap-2">
          <Code2 className="w-5 h-5 text-gray-600" />
          <h3 className="text-sm font-medium text-gray-700">Generated Code</h3>
        </div>
        <div className="flex items-center gap-2">
          {result && (
            <>
              <button
                onClick={handleCopy}
                className="p-2 rounded hover:bg-gray-200"
                title={isCopied ? 'Copied!' : 'Copy to Clipboard'}
              >
                <Copy className="w-4 h-4" />
              </button>
              <button
                onClick={handleDownload}
                className="p-2 rounded hover:bg-gray-200"
                title="Download Code"
              >
                <Download className="w-4 h-4" />
              </button>
            </>
          )}
          {isExpanded ? (
            <ChevronUp className="w-5 h-5" />
          ) : (
            <ChevronDown className="w-5 h-5" />
          )}
        </div>
      </button>

      <div className={`transition-all duration-200 ${isExpanded ? 'block' : 'hidden'}`}>
        <div className="border rounded-b-lg overflow-hidden bg-gray-900">
          <CodeEditor
            value={result}
            language={languageForEditor} // Use the language prop
            readOnly={true}
            height="400px"
          />
        </div>
      </div>
    </div>
  );
}
