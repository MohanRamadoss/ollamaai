import React from 'react';
import { Layers } from 'lucide-react';
import type { ComplexityLevel } from '../../types/aiml';

const COMPLEXITY_INFO = {
  basic: {
    title: 'Basic',
    description: 'Simple implementation with fundamental concepts',
    features: ['Standard libraries', 'Basic error handling', 'Simple documentation']
  },
  intermediate: {
    title: 'Intermediate - Production Ready',
    description: 'Production-grade code with best practices',
    features: ['Error management', 'Performance optimization', 'Detailed documentation']
  },
  advanced: {
    title: 'Advanced',
    description: 'Complex implementation with advanced patterns',
    features: ['Advanced patterns', 'Extensive error handling', 'Complete documentation']
  }
};

interface Props {
  value: ComplexityLevel;
  onChange: (level: ComplexityLevel) => void;
}

export function ComplexitySelector({ value, onChange }: Props) {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">
        Complexity Level
      </label>
      <div className="grid grid-cols-3 gap-4">
        {Object.entries(COMPLEXITY_INFO).map(([level, info]) => (
          <button
            key={level}
            onClick={() => onChange(level as ComplexityLevel)}
            className={`flex flex-col p-4 border rounded-lg transition-all ${
              value === level
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-blue-300'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <Layers className={`w-5 h-5 ${
                value === level ? 'text-blue-600' : 'text-gray-500'
              }`} />
              <span className="font-medium text-gray-900">{info.title}</span>
            </div>
            <p className="text-sm text-gray-500 mb-2">{info.description}</p>
            <ul className="text-xs text-gray-600 space-y-1">
              {info.features.map((feature, i) => (
                <li key={i} className="flex items-center gap-1">
                  <span>•</span>
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </button>
        ))}
      </div>
    </div>
  );
}
