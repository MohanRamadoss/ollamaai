import React from 'react';
import { CloudCodeEditor } from './CloudCodeEditor';
import { Loader2, AlertTriangle, CheckCircle } from 'lucide-react';
import { TokenCounter } from '../TokenCounter';
import type { CloudProvider, ResourceType, CloudProgress, CloudGenerationResult } from '../../types/cloud';

interface MultiModelOutputProps {
  modelOutputs: Record<string, CloudGenerationResult>;
  modelProgress: Record<string, CloudProgress>;
  provider: CloudProvider;
  resourceType: ResourceType;
  maxTokens: number;
  currentTokens: number;
  showTokenCount?: boolean;
}

export function MultiModelOutput({
  modelOutputs,
  modelProgress,
  provider,
  resourceType,
  maxTokens,
  currentTokens,
  showTokenCount = true
}: MultiModelOutputProps) {
  const [selectedTab, setSelectedTab] = React.useState<string | null>(null);

  // Update to select first completed model or first generating model
  React.useEffect(() => {
    if (!selectedTab || !modelProgress[selectedTab]) {
      // First try to find a completed model
      const firstCompleted = Object.entries(modelProgress).find(
        ([_, progress]) => progress.status === 'completed'
      );
      
      // If no completed model, find the first generating model
      const firstGenerating = Object.entries(modelProgress).find(
        ([_, progress]) => progress.status === 'generating'
      );
      
      if (firstCompleted) {
        setSelectedTab(firstCompleted[0]);
      } else if (firstGenerating) {
        setSelectedTab(firstGenerating[0]);
      }
    }
  }, [modelProgress, selectedTab]);

  // Show partial results for generating models
  const getModelOutput = (modelId: string) => {
    if (modelOutputs[modelId]) {
      return modelOutputs[modelId];
    }
    // Return partial results if available
    return modelProgress[modelId]?.partialOutput || null;
  };

  const handleTabClick = (e: React.MouseEvent, modelId: string) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedTab(modelId);
  };

  return (
    <div className="space-y-4">
      {/* Live Progress Section - Always show when there's any progress */}
      {Object.keys(modelProgress).length > 0 && (
        <div className="space-y-2 bg-gray-50 p-4 rounded-lg shadow-sm">
          <h3 className="text-sm font-medium text-gray-700 mb-3">Live Progress</h3>
          {Object.entries(modelProgress).map(([modelId, progress]) => (
            <div key={modelId} className="bg-white rounded-lg p-3 border border-gray-100">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {progress.status === 'generating' && (
                    <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
                  )}
                  {progress.status === 'completed' && (
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  )}
                  <span className="text-sm font-medium">{modelId}</span>
                </div>
                <span className={`text-sm ${
                  progress.status === 'completed' ? 'text-green-600' : 
                  progress.status === 'failed' ? 'text-red-600' : 
                  'text-indigo-600'
                }`}>
                  {progress.status === 'completed' ? 'Completed' : `${progress.progress}%`}
                </span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-2">
                <div
                  className={`h-2 rounded-full transition-all duration-300 ${
                    progress.status === 'completed' ? 'bg-green-500' : 
                    progress.status === 'failed' ? 'bg-red-500' : 
                    'bg-indigo-600'
                  }`}
                  style={{ 
                    width: `${progress.progress}%`,
                    transition: 'width 0.5s ease-in-out'
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Show outputs section if there's any progress or outputs */}
      {(Object.keys(modelProgress).length > 0 || Object.keys(modelOutputs).length > 0) && (
        <>
          {/* Token Counter */}
          {showTokenCount && (
            <div className="flex justify-end items-center gap-2 text-sm text-gray-500">
              <TokenCounter code={currentTokens.toString()} maxTokens={maxTokens} />
            </div>
          )}

          {/* Model Tabs - Show all models with any progress */}
          <div className="flex space-x-2 border-b">
            {Object.entries(modelProgress).map(([modelId, progress]) => (
              <button
                key={modelId}
                type="button"
                onClick={(e) => handleTabClick(e, modelId)}
                className={`px-4 py-2 flex items-center gap-2 text-sm font-medium ${
                  selectedTab === modelId
                    ? 'border-b-2 border-indigo-500 text-indigo-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {progress.status === 'generating' && (
                  <Loader2 className="w-3 h-3 animate-spin" />
                )}
                {progress.status === 'completed' && (
                  <CheckCircle className="w-3 h-3 text-green-500" />
                )}
                {progress.status === 'failed' && (
                  <AlertTriangle className="w-3 h-3 text-red-500" />
                )}
                {modelId}
              </button>
            ))}
          </div>

          {/* Output Display - Show partial or complete results */}
          <div className="min-h-[600px]" onClick={(e) => e.stopPropagation()}> {/* Added min-height */}
            {selectedTab && (getModelOutput(selectedTab) || modelProgress[selectedTab]) && (
              <div className="space-y-6">
                {/* Code Section */}
                <div className="space-y-2">
                  <h3 className="text-sm font-medium text-gray-700">
                    Infrastructure Code 
                    {modelProgress[selectedTab]?.status === 'generating' && ' (Generating...)'}
                  </h3>
                  <div className="h-full min-h-[500px]"> {/* Added container with height */}
                    <CloudCodeEditor
                      value={getModelOutput(selectedTab)?.code || ''}
                      onChange={() => {}}
                      resourceType={resourceType}
                      readOnly
                      isGenerating={modelProgress[selectedTab]?.status === 'generating'}
                      progress={modelProgress[selectedTab]?.progress}
                    />
                  </div>
                </div>

                {/* Show other sections only for completed outputs */}
                {modelProgress[selectedTab]?.status === 'completed' && getModelOutput(selectedTab) && (
                  <>
                    {/* Explanation Section */}
                    {getModelOutput(selectedTab).explanation && (
                      <div className="space-y-2">
                        <h3 className="text-sm font-medium text-gray-700">Explanation</h3>
                        <div className="prose prose-sm max-w-none">
                          <p>{getModelOutput(selectedTab).explanation}</p>
                        </div>
                      </div>
                    )}

                    {/* Best Practices */}
                    {getModelOutput(selectedTab).bestPractices?.length > 0 && (
                      <div className="space-y-2">
                        <h3 className="text-sm font-medium text-gray-700">Best Practices</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          {getModelOutput(selectedTab).bestPractices.map((practice, idx) => (
                            <li key={idx} className="text-sm text-gray-600">{practice}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Security Checks */}
                    {getModelOutput(selectedTab).securityChecks?.length > 0 && (
                      <div className="space-y-2">
                        <h3 className="text-sm font-medium text-gray-700">Security Checks</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          {getModelOutput(selectedTab).securityChecks.map((check, idx) => (
                            <li key={idx} className="text-sm text-gray-600">{check}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Automation Steps */}
                    {getModelOutput(selectedTab).automationSteps?.length > 0 && (
                      <div className="space-y-2">
                        <h3 className="text-sm font-medium text-gray-700">Automation Steps</h3>
                        <ol className="list-decimal pl-5 space-y-1">
                          {getModelOutput(selectedTab).automationSteps.map((step, idx) => (
                            <li key={idx} className="text-sm text-gray-600">{step}</li>
                          ))}
                        </ol>
                      </div>
                    )}
                  </>
                )}
              </div>
            )}
          </div>

          {/* Error Display - Fixed syntax */}
          {selectedTab && modelProgress[selectedTab]?.error && (
            <div className="p-4 bg-red-50 text-red-600 rounded-lg flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              <p>{modelProgress[selectedTab].error}</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
