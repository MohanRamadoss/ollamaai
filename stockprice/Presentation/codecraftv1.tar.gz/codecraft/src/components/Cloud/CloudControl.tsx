import React from 'react';
import { Cloud, Server, Database, HardDrive, Network } from 'lucide-react';
import type { CloudProvider, ResourceType } from '../../types/cloud';
import { PROVIDER_RESOURCE_MAPPING, PROVIDER_SPECIFIC_NAMES } from '../../types/cloud';

const CLOUD_PROVIDERS: Record<CloudProvider, { name: string; icon: JSX.Element }> = {
  aws: { name: 'Amazon Web Services', icon: <Cloud className="w-5 h-5" /> },
  azure: { name: 'Microsoft Azure', icon: <Cloud className="w-5 h-5" /> },
  gcp: { name: 'Google Cloud Platform', icon: <Cloud className="w-5 h-5" /> }
};

const RESOURCE_TYPE_DETAILS: Record<ResourceType, { name: string; icon: JSX.Element }> = {
  terraform: { name: 'Terraform', icon: <Server className="w-5 h-5" /> },
  cloudformation: { name: 'CloudFormation', icon: <Server className="w-5 h-5" /> },
  azurearm: { name: 'Azure ARM', icon: <Server className="w-5 h-5" /> },
  gcpdeployment: { name: 'GCP Deployment Manager', icon: <Server className="w-5 h-5" /> },
  kubernetes: { name: 'Kubernetes Resources', icon: <Server className="w-5 h-5" /> },
  serverless: { name: 'Serverless Resources', icon: <Server className="w-5 h-5" /> },
  database: { name: 'Database Resources', icon: <Database className="w-5 h-5" /> },
  storage: { name: 'Storage Resources', icon: <HardDrive className="w-5 h-5" /> },
  networking: { name: 'Network Resources', icon: <Network className="w-5 h-5" /> }
};

interface CloudControlProps {
  provider: string;
  resourceType: string;
  onProviderChange: (provider: CloudProvider) => void;
  onResourceTypeChange: (type: ResourceType) => void;
}

export function CloudControl({
  provider,
  resourceType,
  onProviderChange,
  onResourceTypeChange
}: CloudControlProps) {
  const currentProvider = provider as CloudProvider;
  const availableResourceTypes = PROVIDER_RESOURCE_MAPPING[currentProvider] || [];

  const handleProviderChange = (newProvider: CloudProvider) => {
    onProviderChange(newProvider);
    // Select first available resource type for new provider
    const defaultResourceType = PROVIDER_RESOURCE_MAPPING[newProvider][0];
    onResourceTypeChange(defaultResourceType);
  };

  return (
    <div className="space-y-6">
      {/* Cloud Provider Selection */}
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-700">Cloud Provider</label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Object.entries(CLOUD_PROVIDERS).map(([key, value]) => (
            <button
              key={key}
              onClick={() => handleProviderChange(key as CloudProvider)}
              className={`flex items-center space-x-3 p-4 rounded-lg border transition-colors ${
                provider === key
                  ? 'border-indigo-500 bg-indigo-50'
                  : 'border-gray-200 hover:border-indigo-300'
              }`}
            >
              <div className={`${provider === key ? 'text-indigo-500' : 'text-gray-400'}`}>
                {value.icon}
              </div>
              <span className="font-medium">{value.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Resource Type Selection */}
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-700">Resource Type</label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {availableResourceTypes.map((type) => {
            const displayName = PROVIDER_SPECIFIC_NAMES[currentProvider][type];
            if (!displayName) return null; // Skip if not applicable for current provider
            
            return (
              <button
                key={type}
                onClick={() => onResourceTypeChange(type)}
                className={`flex items-center space-x-3 p-4 rounded-lg border transition-colors ${
                  resourceType === type
                    ? 'border-indigo-500 bg-indigo-50'
                    : 'border-gray-200 hover:border-indigo-300'
                }`}
              >
                <div className={`${resourceType === type ? 'text-indigo-500' : 'text-gray-400'}`}>
                  {getResourceTypeIcon(type)}
                </div>
                <span className="font-medium">{displayName}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function getResourceTypeIcon(type: ResourceType): JSX.Element {
  switch (type) {
    case 'database':
      return <Database className="w-5 h-5" />;
    case 'storage':
      return <HardDrive className="w-5 h-5" />;
    case 'networking':
      return <Network className="w-5 h-5" />;
    default:
      return <Server className="w-5 h-5" />;
  }
}