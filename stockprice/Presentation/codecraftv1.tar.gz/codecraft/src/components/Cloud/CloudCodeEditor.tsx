import React, { useState, useRef } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Download, Copy, Check, ChevronUp, ChevronDown, Edit, View } from 'lucide-react';
import type { ResourceType } from '../../types/cloud';

interface CloudCodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  resourceType: ResourceType;
  readOnly?: boolean;
  isGenerating?: boolean;
  progress?: number;
}

export function CloudCodeEditor({
  value,
  onChange,
  resourceType,
  readOnly = false,
  isGenerating = false,
  progress = 0
}: CloudCodeEditorProps) {
  const [copied, setCopied] = React.useState(false);
  const [downloading, setDownloading] = React.useState(false);
  const [isEditMode, setIsEditMode] = useState(!readOnly);
  const [isExpanded, setIsExpanded] = useState(true);
  const editorRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const getLanguage = (resourceType: ResourceType): string => {
    switch (resourceType) {
      case 'terraform':
        return 'hcl';
      case 'cloudformation':
      case 'kubernetes':
      case 'serverless':
        return 'yaml';
      case 'azurearm':
        return 'json';
      default:
        return 'yaml';
    }
  };

  const handleCopy = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const handleDownload = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDownloading(true);
    try {
      const extension = getLanguage(resourceType);
      const blob = new Blob([value], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `infrastructure.${extension}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } finally {
      setDownloading(false);
    }
  };

  const handleScroll = (direction: 'up' | 'down') => {
    if (!editorRef.current) return;
    const scrollAmount = 300;
    const currentScroll = editorRef.current.scrollTop;
    const newScroll = direction === 'up' 
      ? currentScroll - scrollAmount 
      : currentScroll + scrollAmount;
    
    editorRef.current.scrollTo({
      top: newScroll,
      behavior: 'smooth'
    });
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onChange(e.target.value);
  };

  return (
    <div className="space-y-2 h-full" onClick={(e) => e.stopPropagation()}>
      {/* Progress Bar */}
      {isGenerating && (
        <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
          <div 
            className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}

      {/* Header Controls */}
      <div className="flex items-center justify-between p-2 bg-gray-800 rounded-t-lg">
        <div className="flex items-center gap-2">
          {!readOnly && (
            <button
              onClick={() => setIsEditMode(!isEditMode)}
              className="p-1.5 rounded text-white hover:bg-gray-700"
              title={isEditMode ? "View mode" : "Edit mode"}
            >
              {isEditMode ? <View size={16} /> : <Edit size={16} />}
            </button>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="p-1.5 rounded text-white hover:bg-gray-700"
            title={copied ? "Copied!" : "Copy code"}
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
          </button>
          <button
            onClick={handleDownload}
            disabled={!value || downloading}
            className={`p-1.5 rounded text-white hover:bg-gray-700 ${
              !value || downloading ? 'opacity-50 cursor-not-allowed' : ''
            }`}
            title="Download code"
          >
            <Download size={16} className={downloading ? 'animate-bounce' : ''} />
          </button>
        </div>
      </div>

      {/* Editor Content */}
      <div className="relative border border-gray-700 rounded-b-lg bg-[#1E1E1E]" ref={editorRef}>
        {isEditMode ? (
          <textarea
            ref={textareaRef}
            value={value}
            onChange={handleTextareaChange}
            className="w-full h-[600px] p-4 font-mono text-sm text-white bg-[#1E1E1E] focus:outline-none resize-none"
            spellCheck="false"
          />
        ) : (
          <div className="h-[600px] overflow-auto">
            <SyntaxHighlighter
              language={getLanguage(resourceType)}
              style={vscDarkPlus}
              showLineNumbers={true}
              customStyle={{
                margin: 0,
                padding: '1rem',
                backgroundColor: '#1E1E1E',
                fontSize: '0.875rem',
              }}
            >
              {value}
            </SyntaxHighlighter>
          </div>
        )}

        {/* Scroll Controls */}
        <div className="absolute right-4 top-1/2 transform -translate-y-1/2 flex flex-col gap-2">
          <button
            type="button"
            onClick={() => handleScroll('up')}
            className="p-1.5 rounded-full bg-gray-700 text-white hover:bg-gray-600 transition-colors"
          >
            <ChevronUp size={16} />
          </button>
          <button
            type="button"
            onClick={() => handleScroll('down')}
            className="p-1.5 rounded-full bg-gray-700 text-white hover:bg-gray-600 transition-colors"
          >
            <ChevronDown size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}