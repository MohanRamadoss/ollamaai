import React from 'react';
import { Loader2, AlertTriangle, CheckCircle } from 'lucide-react';
import type { CloudProgressType } from '../../types/cloud';

interface CloudProgressProps {
  modelId: string;
  progress: CloudProgressType;
}

export function CloudProgress({ modelId, progress }: CloudProgressProps) {
  const getStatusIcon = () => {
    switch (progress.status) {
      case 'generating':
        return <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default:
        return <Loader2 className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = () => {
    switch (progress.status) {
      case 'generating':
        return 'bg-indigo-600';
      case 'completed':
        return 'bg-green-500';
      case 'failed':
        return 'bg-red-500';
      default:
        return 'bg-gray-200';
    }
  };

  const getProgressBarColor = () => {
    switch (progress.status) {
      case 'generating':
        return 'bg-indigo-600';
      case 'completed':
        return 'bg-green-500';
      case 'failed':
        return 'bg-red-500';
      default:
        return 'bg-gray-200';
    }
  };

  const getProgressTextColor = () => {
    switch (progress.status) {
      case 'completed':
        return 'text-green-600';
      case 'failed':
        return 'text-red-600';
      case 'generating':
        return 'text-indigo-600';
      default:
        return 'text-gray-500';
    }
  };

  return (
    <div className="mb-4 bg-gray-50 rounded-lg p-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          {getStatusIcon()}
          <span className="text-sm font-medium">{modelId}</span>
        </div>
        <span className={`text-sm ${getProgressTextColor()}`}>
          {progress.status === 'completed' ? 'Completed' : `${progress.progress}%`}
        </span>
      </div>
      
      <div className="w-full bg-gray-200 rounded-full h-1.5">
        <div
          className={`h-1.5 rounded-full transition-all duration-500 ${getProgressBarColor()}`}
          style={{ 
            width: `${progress.progress}%`,
            transitionProperty: 'width, background-color'
          }}
        />
      </div>

      {progress.error && (
        <p className="mt-2 text-sm text-red-600 flex items-center gap-1">
          <AlertTriangle className="w-3 h-3" />
          {progress.error}
        </p>
      )}
    </div>
  );
}