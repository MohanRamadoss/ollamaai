import React from 'react';
import { GitBranch, TestTube2, Rocket, Activity } from 'lucide-react';
import type { Platform, PipelineType } from '../../types/cicd';

const PLATFORMS: Record<Platform, { name: string; icon: JSX.Element }> = {
  github: { name: 'GitHub Actions', icon: <GitBranch className="w-5 h-5" /> },
  gitlab: { name: 'GitLab CI', icon: <GitBranch className="w-5 h-5" /> },
  'azure-devops': { name: 'Azure DevOps', icon: <GitBranch className="w-5 h-5" /> },
  jenkins: { name: 'Jenkins', icon: <GitBranch className="w-5 h-5" /> }
};

const PIPELINE_TYPES: Record<PipelineType, { name: string; icon: JSX.Element }> = {
  build: { name: 'Build Pipeline', icon: <GitBranch className="w-5 h-5" /> },
  test: { name: 'Test Automation', icon: <TestTube2 className="w-5 h-5" /> },
  deploy: { name: 'Deployment Pipeline', icon: <Rocket className="w-5 h-5" /> },
  monitor: { name: 'Monitoring Setup', icon: <Activity className="w-5 h-5" /> }
};

interface CICDControlProps {
  platform: Platform;
  pipelineType: PipelineType;
  onPlatformChange: (platform: Platform) => void;
  onPipelineTypeChange: (type: PipelineType) => void;
}

export function CICDControl({
  platform,
  pipelineType,
  onPlatformChange,
  onPipelineTypeChange
}: CICDControlProps) {
  return (
    <div className="space-y-6">
      {/* Platform Selection */}
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-700">CI/CD Platform</label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Object.entries(PLATFORMS).map(([key, value]) => (
            <button
              key={key}
              onClick={() => onPlatformChange(key as Platform)}
              className={`flex items-center space-x-3 p-4 rounded-lg border transition-colors ${
                platform === key
                  ? 'border-indigo-500 bg-indigo-50'
                  : 'border-gray-200 hover:border-indigo-300'
              }`}
            >
              <div className={`${platform === key ? 'text-indigo-500' : 'text-gray-400'}`}>
                {value.icon}
              </div>
              <span className="font-medium">{value.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Pipeline Type Selection */}
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-700">Pipeline Type</label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Object.entries(PIPELINE_TYPES).map(([key, value]) => (
            <button
              key={key}
              onClick={() => onPipelineTypeChange(key as PipelineType)}
              className={`flex items-center space-x-3 p-4 rounded-lg border transition-colors ${
                pipelineType === key
                  ? 'border-indigo-500 bg-indigo-50'
                  : 'border-gray-200 hover:border-indigo-300'
              }`}
            >
              <div className={`${pipelineType === key ? 'text-indigo-500' : 'text-gray-400'}`}>
                {value.icon}
              </div>
              <span className="font-medium">{value.name}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}