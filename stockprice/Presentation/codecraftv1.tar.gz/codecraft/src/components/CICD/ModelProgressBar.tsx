import { useState, useEffect } from 'react';
import { Loader2, CheckCircle, XCircle } from 'lucide-react';
import { CICDProgress } from '../../types/cicd';

interface ModelProgressBarProps {
  modelProgress: Record<string, CICDProgress>;
  onModelClick: (modelId: string) => void;
  selectedModelId: string | null;
}

export function ModelProgressBar({ modelProgress, onModelClick, selectedModelId }: ModelProgressBarProps) {
  return (
    <div className="mb-6 space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {Object.entries(modelProgress).map(([modelId, progress]) => (
          <button
            key={modelId}
            onClick={(e) => {
              e.preventDefault(); // Prevent form submission
              if (progress.status === 'completed') {
                onModelClick(modelId);
              }
            }}
            disabled={progress.status !== 'completed'}
            className={`
              flex items-center gap-3 p-4 rounded-lg border transition-all
              ${selectedModelId === modelId ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200'}
              ${progress.status === 'completed' 
                ? 'hover:border-green-500 cursor-pointer' 
                : 'cursor-default opacity-75'
              }
            `}
          >
            <div className="flex-1">
              <div className="flex items-center gap-2">
                {progress.status === 'generating' && (
                  <Loader2 className="w-4 h-4 text-indigo-500 animate-spin" />
                )}
                {progress.status === 'completed' && (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                )}
                {progress.status === 'failed' && (
                  <XCircle className="w-4 h-4 text-red-500" />
                )}
                <span className="font-medium">{modelId}</span>
              </div>
              
              <div className="mt-2 h-2 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-500 ${
                    progress.status === 'completed' ? 'bg-green-500' : 'bg-indigo-500'
                  }`}
                  style={{ width: `${progress.progress}%` }}
                />
              </div>
              <div className="mt-1 text-xs text-gray-500">
                {progress.status === 'generating' && 'Generating...'}
                {progress.status === 'completed' && 'Generation complete'}
                {progress.status === 'failed' && progress.error}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
