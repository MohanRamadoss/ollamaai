import { CICD_MODELS } from '../../config/cicdModels';

interface ModelMultiSelectProps {
  selectedModels: string[];
  onChange: (models: string[]) => void;
}

export function ModelMultiSelect({ selectedModels, onChange }: ModelMultiSelectProps) {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">Models</label>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
        {CICD_MODELS.map((model) => (
          <button
            key={model.id}
            type="button"
            onClick={() => {
              const newSelection = selectedModels.includes(model.id)
                ? selectedModels.filter(id => id !== model.id)
                : [...selectedModels, model.id];
              onChange(newSelection);
            }}
            className={`
              p-4 rounded-lg border text-left transition-colors
              ${selectedModels.includes(model.id)
                ? 'bg-indigo-600 border-indigo-500 text-white'
                : 'bg-white border-gray-300 hover:border-indigo-500'
              }
            `}
          >
            <div className="space-y-1">
              <div className="font-medium">{model.name}</div>
              <div className="text-xs opacity-75">{model.description}</div>
              <div className="text-xs">
                Provider: {model.provider}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
