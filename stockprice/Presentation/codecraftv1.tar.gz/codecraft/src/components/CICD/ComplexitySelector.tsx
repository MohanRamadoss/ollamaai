import { ComplexityLevel } from '../../types/models';

interface ComplexitySelectorProps {
  value: ComplexityLevel;
  onChange: (complexity: ComplexityLevel) => void;
}

export function ComplexitySelector({ value, onChange }: ComplexitySelectorProps) {
  const complexityLevels: ComplexityLevel[] = ['basic', 'intermediate', 'advanced'];

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">Complexity Level</label>
      <div className="grid grid-cols-3 gap-2">
        {complexityLevels.map((level) => (
          <button
            key={level}
            type="button"
            onClick={() => onChange(level)}
            className={`
              p-3 rounded-lg border transition-colors
              ${value === level
                ? 'bg-indigo-600 border-indigo-500 text-white'
                : 'bg-white border-gray-300 hover:border-indigo-500'
              }
            `}
          >
            <span className="text-sm font-medium capitalize">{level}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
