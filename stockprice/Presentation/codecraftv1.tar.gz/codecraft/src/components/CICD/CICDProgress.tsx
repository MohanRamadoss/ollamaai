import React from 'react';
import { Loader2 } from 'lucide-react';

interface CICDProgressProps {
  isGenerating: boolean;
  progress: number;
}

export function CICDProgress({ isGenerating, progress }: CICDProgressProps) {
  if (!isGenerating) return null;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm text-gray-500">
        <div className="flex items-center">
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          <span>Generating pipeline configuration...</span>
        </div>
        <span>{progress}%</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div
          className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}