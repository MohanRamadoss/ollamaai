import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp, Copy, Check, AlertCircle, Loader2 } from 'lucide-react';
import { CodeEditor } from '../CodeEditor';
import { Platform, PipelineType, CICDProgress } from '../../types/cicd';
import { AnimatePresence, motion } from 'framer-motion';
import { TokenCounter } from '../TokenCounter';
import { ModelProgressBar } from './ModelProgressBar';

interface MultiModelOutputProps {
  modelOutputs: Record<string, {
    code: string;
    explanation?: string;
    bestPractices?: string[];
    securityChecks?: string[];
    automationSteps?: string[];
  }>;
  modelProgress: Record<string, CICDProgress>;
  platform: Platform;
  pipelineType: PipelineType;
}

export function MultiModelOutput({ modelOutputs, modelProgress, platform, pipelineType }: MultiModelOutputProps) {
  const [selectedModelId, setSelectedModelId] = useState<string | null>(null);
  const [expandedModels, setExpandedModels] = useState<Record<string, boolean>>({});
  const [copiedStates, setCopiedStates] = useState<Record<string, boolean>>({});

  // Update effect to handle completed outputs
  useEffect(() => {
    const completedModelIds = Object.keys(modelOutputs);
    
    // Auto-expand all completed models with outputs
    const newExpandedState = completedModelIds.reduce((acc, modelId) => ({
      ...acc,
      [modelId]: true
    }), {});
    setExpandedModels(prev => ({ ...prev, ...newExpandedState }));

    // Select the first model with output if none selected
    if (completedModelIds.length > 0 && !selectedModelId) {
      setSelectedModelId(completedModelIds[0]);
    }
  }, [modelOutputs, selectedModelId]);

  const handleModelSelect = (modelId: string) => {
    // Only change selection, don't trigger regeneration
    if (modelOutputs[modelId]) {
      setSelectedModelId(modelId);
      setExpandedModels(prev => ({
        ...prev,
        [modelId]: true
      }));
    }
  };

  const toggleExpand = (modelId: string, event: React.MouseEvent) => {
    // Prevent event bubbling
    event.stopPropagation();
    
    if (modelProgress[modelId]?.status === 'completed') {
      setExpandedModels(prev => ({
        ...prev,
        [modelId]: !prev[modelId]
      }));
    }
  };

  const handleCopy = async (modelId: string, code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedStates(prev => ({ ...prev, [modelId]: true }));
      setTimeout(() => {
        setCopiedStates(prev => ({ ...prev, [modelId]: false }));
      }, 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  // Filter to show only completed models with outputs
  const completedOutputs = Object.entries(modelOutputs).filter(
    ([modelId]) => modelProgress[modelId]?.status === 'completed'
  );

  return (
    <div className="space-y-6">
      {/* Progress Bars */}
      <ModelProgressBar
        modelProgress={modelProgress}
        onModelClick={handleModelSelect}
        selectedModelId={selectedModelId}
      />

      {/* Output Sections */}
      <div className="space-y-4">
        {completedOutputs.map(([modelId, output]) => (
          <div 
            key={modelId}
            className={`border rounded-lg overflow-hidden transition-all duration-300 ${
              selectedModelId === modelId ? 'border-indigo-500 shadow-lg' : 'border-gray-200'
            }`}
          >
            {/* Model Header */}
            <div 
              className="flex items-center justify-between p-4 bg-gray-50 cursor-pointer"
              onClick={(e) => toggleExpand(modelId, e)}
            >
              <div className="flex items-center gap-3">
                <ModelStatusIcon status={modelProgress[modelId]?.status} />
                <div>
                  <h3 className="font-medium">{modelId}</h3>
                  <p className="text-sm text-gray-500">
                    {getModelStatusText(modelProgress[modelId]?.status)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                {modelProgress[modelId]?.status === 'generating' && (
                  <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-indigo-600 transition-all duration-300"
                      style={{ width: `${modelProgress[modelId]?.progress ?? 0}%` }}
                    />
                  </div>
                )}
                {expandedModels[modelId] ? <ChevronUp /> : <ChevronDown />}
              </div>
            </div>

            {/* Model Content */}
            <AnimatePresence>
              {expandedModels[modelId] && output && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="border-t border-gray-200"
                >
                  <div className="p-4 space-y-4">
                    {/* Code Section */}
                    {output.code && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-medium">Generated Code</h4>
                          <div className="flex items-center gap-2">
                            <TokenCounter code={output.code} maxTokens={8192} />
                            <button
                              onClick={() => handleCopy(modelId, output.code)}
                              className="p-1 hover:bg-gray-100 rounded"
                            >
                              {copiedStates[modelId] ? (
                                <Check className="w-4 h-4 text-green-500" />
                              ) : (
                                <Copy className="w-4 h-4" />
                              )}
                            </button>
                          </div>
                        </div>
                        <CodeEditor
                          value={output.code}
                          language={platform === 'jenkins' ? 'groovy' : 'yaml'}
                          readOnly
                        />
                      </div>
                    )}

                    {/* Additional Sections */}
                    {output.explanation && (
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">Explanation</h4>
                        <p className="text-sm text-gray-600">{output.explanation}</p>
                      </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {output.bestPractices && output.bestPractices.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="text-sm font-medium">Best Practices</h4>
                          <ul className="text-sm space-y-1">
                            {output.bestPractices.map((practice, i) => (
                              <li key={i} className="flex items-start gap-2">
                                <span className="text-indigo-500">•</span>
                                <span>{practice}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Similar sections for securityChecks and automationSteps */}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  );
}

function ModelStatusIcon({ status }: { status?: string }) {
  switch (status) {
    case 'generating':
      return <Loader2 className="w-5 h-5 text-indigo-600 animate-spin" />;
    case 'completed':
      return <Check className="w-5 h-5 text-green-500" />;
    case 'failed':
      return <AlertCircle className="w-5 h-5 text-red-500" />;
    default:
      return null;
  }
}

function getModelStatusText(status?: string): string {
  switch (status) {
    case 'generating':
      return 'Generating pipeline...';
    case 'completed':
      return 'Generation complete';
    case 'failed':
      return 'Generation failed';
    default:
      return 'Pending';
  }
}
