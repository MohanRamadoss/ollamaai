import React from 'react';
import { Info } from 'lucide-react';
import type { Platform, PipelineType } from '../../types/cicd';

interface CICDExampleProps {
  platform: Platform;
  pipelineType: PipelineType;
  onExampleSelect: (example: string) => void;
}

const PIPELINE_EXAMPLES: Record<Platform, Record<PipelineType, { description: string; example: string }>> = {
  github: {
    build: {
      description: 'Basic Node.js build pipeline',
      example: `name: Node.js Build\non:\n  push:\n    branches: [ main ]\njobs:\n  build:\n    runs-on: ubuntu-latest\n    steps:\n    - uses: actions/checkout@v2\n    - name: Use Node.js\n      uses: actions/setup-node@v2\n      with:\n        node-version: '16.x'\n    - run: npm ci\n    - run: npm run build`
    },
    test: {
      description: 'Automated testing with Jest',
      example: `name: Tests\non:\n  pull_request:\n    branches: [ main ]\njobs:\n  test:\n    runs-on: ubuntu-latest\n    steps:\n    - uses: actions/checkout@v2\n    - name: Test\n      run: |\n        npm ci\n        npm test`
    },
    deploy: {
      description: 'Deploy to Azure Web App',
      example: `name: Deploy\non:\n  push:\n    branches: [ main ]\njobs:\n  deploy:\n    runs-on: ubuntu-latest\n    steps:\n    - uses: actions/checkout@v2\n    - uses: azure/webapps-deploy@v2\n      with:\n        app-name: my-app\n        publish-profile: \${{ secrets.AZURE_WEBAPP_PUBLISH_PROFILE }}`
    },
    monitor: {
      description: 'Application monitoring setup',
      example: `name: Monitor\non:\n  schedule:\n    - cron: '*/15 * * * *'\njobs:\n  health-check:\n    runs-on: ubuntu-latest\n    steps:\n    - name: Check health\n      run: curl -sSf https://my-app.com/health`
    }
  },
  // Add examples for other platforms...
  gitlab: {
    build: {
      description: 'Basic GitLab CI build pipeline',
      example: `image: node:16\n\ncache:\n  paths:\n    - node_modules/\n\nbuild:\n  script:\n    - npm ci\n    - npm run build`
    },
    // Add other GitLab examples...
  },
  'azure-devops': {
    build: {
      description: 'Azure Pipeline build configuration',
      example: `trigger:\n- main\n\npool:\n  vmImage: 'ubuntu-latest'\n\nsteps:\n- task: NodeTool@0\n  inputs:\n    versionSpec: '16.x'\n- script: |\n    npm ci\n    npm run build`
    },
    // Add other Azure examples...
  },
  jenkins: {
    build: {
      description: 'Jenkinsfile build pipeline',
      example: `pipeline {\n  agent any\n  stages {\n    stage('Build') {\n      steps {\n        sh 'npm ci'\n        sh 'npm run build'\n      }\n    }\n  }\n}`
    },
    // Add other Jenkins examples...
  }
};

export function CICDExamples({ platform, pipelineType, onExampleSelect }: CICDExampleProps) {
  const example = PIPELINE_EXAMPLES[platform]?.[pipelineType];
  
  if (!example) return null;

  return (
    <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
      <div className="flex items-center gap-2 mb-3">
        <Info className="w-5 h-5 text-blue-600" />
        <h4 className="text-sm font-medium text-blue-900">Example: {example.description}</h4>
      </div>
      <div className="space-y-2">
        <pre className="p-3 bg-blue-100 rounded text-sm text-blue-800 overflow-auto">
          {example.example}
        </pre>
        <button
          onClick={() => onExampleSelect(example.example)}
          className="text-sm text-blue-600 hover:text-blue-700 font-medium"
        >
          Use this example
        </button>
      </div>
    </div>
  );
}
