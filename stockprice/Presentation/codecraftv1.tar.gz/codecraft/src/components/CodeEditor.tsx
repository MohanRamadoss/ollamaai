import React, { useCallback, useState, useRef, useEffect, memo } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { 
  vscDarkPlus,
  dracula,
  materialDark,
  atomDark,
  oneDark,
  okaidia
} from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Copy, Check, Download, Edit2, Eye, FileCode, Settings } from 'lucide-react';
import { SUPPORTED_LANGUAGES, type SupportedLanguage } from '../types/supported-languages';
import { getLanguageByExtension, getLanguageSettings } from '../lib/editor/languageUtils';
import { MonacoEditor } from './MonacoEditor'; // Import the new MonacoEditor component

// Add new theme options
const EDITOR_THEMES = {
  vscode: vscDarkPlus,
  dracula: dracula,
  material: materialDark,
  atom: atomDark,
  oneDark: oneDark,
  okaidia: okaidia
} as const;

type ThemeKey = keyof typeof EDITOR_THEMES;

interface CodeEditorProps {
  value: string;
  onChange?: (value: string) => void;
  language?: string;
  readOnly?: boolean;
  height?: string;
  showLineNumbers?: boolean;
  theme?: ThemeKey;
  fontSize?: number;
  lineHeight?: number;
  filename?: string;
}

// Wrap editor components with memo to prevent unnecessary re-renders
const MonacoEditorWrapper = memo(({ value, onChange, ...props }) => (
  <MonacoEditor
    value={value}
    onChange={onChange}
    {...props}
  />
));

const SyntaxHighlighterWrapper = memo(({ value, language, ...props }) => (
  <SyntaxHighlighter
    language={language}
    {...props}
  >
    {value || '// Enter your code here...'}
  </SyntaxHighlighter>
));

export function CodeEditor({ 
  value, 
  onChange, 
  language = 'javascript',
  readOnly = false,
  height = '400px',
  showLineNumbers = true,
  theme = 'vscode',
  fontSize = 14,
  lineHeight = 1.5,
  filename
}: CodeEditorProps) {
  const [isCopied, setIsCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(!readOnly);
  const [localValue, setLocalValue] = useState(value);
  const [selectedTheme, setSelectedTheme] = useState<ThemeKey>(theme);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [detectedLanguage, setDetectedLanguage] = useState<SupportedLanguage | undefined>(
    language as SupportedLanguage
  );
  const [useMonaco, setUseMonaco] = useState(() => {
    // Get the stored value from localStorage or default to false
    const storedValue = localStorage.getItem('useMonaco');
    return storedValue === 'true' ? true : false;
  }); // New state variable to toggle between editors
  const [editorError, setEditorError] = useState<Error | null>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [copiedText, setCopiedText] = useState<string>(''); // Add this new state

  // Update localValue when value prop changes
  useEffect(() => {
    setLocalValue(value);
  }, [value]);

  // Auto-detect language from filename
  useEffect(() => {
    if (filename) {
      const extension = filename.split('.').pop();
      if (extension) {
        const detected = getLanguageByExtension(extension);
        if (detected) setDetectedLanguage(detected);
      }
    }
  }, [filename]);

  const getPrismLanguage = (lang: string): string => {
    const languageInfo = SUPPORTED_LANGUAGES[lang as SupportedLanguage];
    if (languageInfo) {
      const prismMap: Record<string, string> = {
        'c_cpp': 'cpp',
        'golang': 'go',
        'text': 'plaintext',
        'sh': 'bash',
        'batchfile': 'batch',
        'objectivec': 'objectivec',
        'latex': 'tex'
      };
      return prismMap[languageInfo.ace] || languageInfo.ace;
    }
    return 'plaintext';
  };

  const handleCopy = useCallback(async (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
      e.nativeEvent.stopImmediatePropagation();
    }
    
    try {
      const textToCopy = isEditing ? textareaRef.current?.value || value : value;
      setCopiedText(textToCopy); // Store the copied text
      await navigator.clipboard.writeText(textToCopy);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 3000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  }, [value, isEditing]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    const settings = getLanguageSettings(detectedLanguage || 'javascript');
    
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = textareaRef.current?.selectionStart || 0;
      const spaces = ' '.repeat(settings.tabSize);
      const newValue = localValue.substring(0, start) + spaces + localValue.substring(start);
      setLocalValue(newValue);
      onChange?.(newValue);
    }

    // Auto-closing brackets
    const brackets: Record<string, string> = {
      '(': ')', '[': ']', '{': '}', '"': '"', "'": "'"
    };
    
    if (settings.autoClosingBrackets && e.key in brackets) {
      e.preventDefault();
      const start = textareaRef.current?.selectionStart || 0;
      const newValue = `${localValue.substring(0, start)}${e.key}${brackets[e.key]}${localValue.substring(start)}`;
      setLocalValue(newValue);
      onChange?.(newValue);
    }
  };

  const handleDownload = useCallback(() => {
    try {
      const blob = new Blob([value], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `code.${language || 'txt'}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to download:', error);
    }
  }, [value, language]);

  // Modify handleChange to ensure both local and parent state are updated
  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    setLocalValue(newValue);
    onChange?.(newValue);
  };

  const toggleEditMode = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!readOnly) {
      setIsEditing(!isEditing);
    }
  };

  // Enhanced editor styles with better scrolling and font fallbacks
  const editorStyles = {
    fontSize: `${fontSize}px`,
    lineHeight: lineHeight,
    fontFamily: 'inherit', // This will inherit from the code-font class
    backgroundColor: '#1E1E1E',
    padding: '1rem',
    margin: 0,
    borderRadius: '4px',
    height: height,
    maxHeight: '100%',
    tabSize: 2,
    overflowX: 'auto',
    overflowY: 'auto',
    WebkitOverflowScrolling: 'touch', // Smooth scrolling on iOS
    msOverflowStyle: 'scrollbar', // Better scrollbars on Windows
    scrollbarWidth: 'thin',
  };

  // Add custom scrollbar styles
  const scrollbarStyles = `
    .code-editor-container ::-webkit-scrollbar {
      width: 12px;
      height: 12px;
    }
    .code-editor-container ::-webkit-scrollbar-track {
      background: #1E1E1E;
    }
    .code-editor-container ::-webkit-scrollbar-thumb {
      background-color: #424242;
      border-radius: 6px;
      border: 3px solid #1E1E1E;
    }
    .code-editor-container ::-webkit-scrollbar-thumb:hover {
      background-color: #525252;
    }
  `;

  const lineNumberStyles = {
    minWidth: '3.5em',
    paddingRight: '1em',
    paddingLeft: '0.5em',
    textAlign: 'right' as const,
    backgroundColor: '#1E1E1E',
    color: '#858585',
    userSelect: 'none' as const,
  };

  // Add force refresh method
  const forceRefresh = () => {
    if (textareaRef.current) {
      textareaRef.current.value = value;
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  };

  // Force refresh when value or language changes
  useEffect(() => {
    forceRefresh();
  }, [value, language]);

  // Update editor type with error handling
  const handleEditorTypeChange = useCallback(() => {
    try {
      setIsTransitioning(true);
      const newValue = !useMonaco;
      
      // Store current scroll position and cursor position
      const editorElement = textareaRef.current;
      const scrollPos = editorElement?.scrollTop || 0;
      const cursorPos = editorElement?.selectionStart || 0;

      // Update editor type
      setUseMonaco(newValue);
      localStorage.setItem('useMonaco', String(newValue));

      // Schedule state updates for next frame
      requestAnimationFrame(() => {
        if (editorElement) {
          editorElement.scrollTop = scrollPos;
          editorElement.setSelectionRange(cursorPos, cursorPos);
        }
        setIsTransitioning(false);
      });
    } catch (error) {
      console.error('Editor switch failed:', error);
      setEditorError(error instanceof Error ? error : new Error('Failed to switch editors'));
      setIsTransitioning(false);
    }
  }, [useMonaco]);

  // Reset error state when value or language changes
  useEffect(() => {
    setEditorError(null);
  }, [value, language]);

  // Prevent interaction during transition
  if (isTransitioning) {
    return <div className="w-full h-full flex items-center justify-center">Switching editors...</div>;
  }

  // Show error state if something went wrong
  if (editorError) {
    return (
      <div className="w-full h-full flex flex-col items-center justify-center text-red-500 p-4">
        <p>Failed to load editor: {editorError.message}</p>
        <button 
          onClick={() => setEditorError(null)}
          className="mt-4 px-4 py-2 bg-red-100 text-red-700 rounded hover:bg-red-200"
        >
          Try Again
        </button>
      </div>
    );
  }

  const StatusBar = () => {
    const langInfo = detectedLanguage ? SUPPORTED_LANGUAGES[detectedLanguage] : null;
    const lines = value.split('\n').length;
    const chars = value.length;
    
    return (
      <div className="absolute bottom-0 left-0 right-0 h-6 bg-gray-800 text-gray-300 
                    flex items-center justify-between px-2 text-xs border-t border-gray-700">
        <div className="flex items-center gap-2">
          <FileCode className="w-4 h-4" />
          <span>{langInfo?.name || 'Plain Text'}</span>
          <span className="text-gray-500">|</span>
          <span>{lines} lines</span>
          <span className="text-gray-500">|</span>
          <span>{chars} characters</span>
        </div>
        <div className="flex items-center gap-2">
          <span>{`${getLanguageSettings(detectedLanguage || 'javascript').tabSize} spaces`}</span>
          <span className="text-gray-500">|</span>
          <span>UTF-8</span>
        </div>
      </div>
    );
  };

  // Add these styles to ensure proper scrolling behavior
  const containerStyles = {
    height: height,
    maxHeight: '100%',
    position: 'relative' as const,
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column' as const
  };

  return (
    <>
      <style>{scrollbarStyles}</style>
      <div className="relative group code-editor-container code-font code-editor" style={containerStyles}>
        <div className="absolute right-2 top-2 z-10 flex gap-2 transition-opacity duration-200 bg-gray-800/90 p-1 rounded-lg border border-gray-700 backdrop-blur">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 rounded hover:bg-gray-700 transition-colors duration-200 
                      text-gray-300 hover:text-white"
            title="Editor Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
          {/* Add theme selector */}
          <select
            value={selectedTheme}
            onChange={(e) => setSelectedTheme(e.target.value as ThemeKey)}
            className="text-sm bg-gray-700 text-gray-200 rounded px-2 py-1 border-0
                    focus:ring-1 focus:ring-indigo-500"
          >
            {Object.keys(EDITOR_THEMES).map((themeName) => (
              <option key={themeName} value={themeName}>
                {themeName.charAt(0).toUpperCase() + themeName.slice(1)}
              </option>
            ))}
          </select>

          {/* Add toggle for Monaco Editor */}
          <button
            onClick={handleEditorTypeChange}
            disabled={isTransitioning}
            className={`p-2 rounded transition-colors duration-200 
                      text-gray-300 hover:text-white ${
                        isTransitioning ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-700'
                      }`}
            title={useMonaco ? "Switch to CodeMirror Editor" : "Switch to Monaco Editor"}
          >
            {isTransitioning ? (
              "Switching..."
            ) : useMonaco ? (
              "CodeMirror"
            ) : (
              "Monaco"
            )}
          </button>

          {!readOnly && (
            <button
              onClick={toggleEditMode}
              className="p-2 rounded hover:bg-gray-700 transition-colors duration-200 
                      text-gray-300 hover:text-white"
              title={isEditing ? "Switch to view mode" : "Switch to edit mode"}
            >
              {isEditing ? (
                <Eye className="w-4 h-4" />
              ) : (
                <Edit2 className="w-4 h-4" />
              )}
            </button>
          )}
          <button
            onClick={handleCopy}
            onMouseDown={(e) => e.stopPropagation()} // Add this
            className={`p-2 rounded transition-all duration-200 flex items-center gap-2
                      ${isCopied 
                        ? 'bg-green-600 text-white' 
                        : 'hover:bg-gray-700 text-gray-300 hover:text-white'}`}
            title={isCopied ? "Copied!" : "Copy code"}
          >
            {isCopied ? (
              <>
                <Check className="w-4 h-4" />
                <span className="text-sm">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span className="text-sm">Copy</span>
              </>
            )}
          </button>
          <button
            onClick={handleDownload}
            className="p-2 rounded hover:bg-gray-700 transition-colors duration-200 
                    text-gray-300 hover:text-white flex items-center gap-2"
            title="Download code"
          >
            <Download className="w-4 h-4" />
            <span className="text-sm">Download</span>
          </button>
        </div>

        {showSettings && (
          <div className="absolute right-2 top-12 z-20 bg-gray-800 rounded-lg shadow-lg 
                      border border-gray-700 p-4 w-64">
            {/* ...settings panel content... */}
          </div>
        )}

        {/* Remove or modify the copy overlay section */}
        {/* Only show copy overlay in view mode when hovering the copy button */}
        {!isEditing && isCopied && (
          <div 
            className="absolute right-2 top-14 z-20 bg-gray-800 rounded-lg px-3 py-2 
                      text-sm text-white border border-gray-700"
          >
            Copied to clipboard!
          </div>
        )}

        <div className="h-full overflow-hidden rounded-lg border border-gray-200">
          {useMonaco ? (
            <MonacoEditorWrapper
              key="monaco-editor"
              value={localValue}
              onChange={onChange}
              language={language}
              readOnly={readOnly}
              height="100%"
              theme={theme === 'vscode' ? 'vs-dark' : 'vs-light'}
              fontSize={fontSize}
              filename={filename}
            />
          ) : (
            isEditing ? (
              <textarea
                key="textarea-editor"
                ref={textareaRef}
                value={localValue}
                onChange={handleChange}
                onKeyDown={handleKeyDown}
                className="w-full h-full resize-none focus:outline-none focus:ring-1 
                        focus:ring-indigo-500 bg-[#1E1E1E] text-gray-100 overflow-auto"
                style={{
                  ...editorStyles,
                  caretColor: '#569CD6',
                  paddingRight: '70px', // Account for minimap
                  minHeight: '100%', // Ensure minimum height
                }}
                spellCheck="false"
                wrap="off" // Prevent soft wrapping
              />
            ) : (
              <SyntaxHighlighterWrapper
                key="syntax-highlighter"
                value={value}
                language={getPrismLanguage(language)}
                style={EDITOR_THEMES[selectedTheme]}
                showLineNumbers={showLineNumbers}
                customStyle={{
                  ...editorStyles,
                  paddingRight: '70px', // Account for minimap
                }}
                lineNumberStyle={lineNumberStyles}
                wrapLines={true}
                wrapLongLines={false}
                lineProps={(lineNumber) => ({
                  style: {
                    display: 'block',
                    backgroundColor: lineNumber % 2 === 0 ? '#1E1E1E' : '#252525',
                    paddingRight: '1rem',
                    paddingLeft: '1rem',
                  }
                })}
                className="h-full selection:bg-gray-500/30 overflow-auto"
                PreTag={({ children, ...props }) => (
                  <pre {...props} style={{ margin: 0, height: '100%' }}>
                    {children}
                  </pre>
                )}
              />
            )
          )}
        </div>

        {/* Improved minimap */}
        <div className="absolute right-0 top-0 bottom-0 w-[60px] bg-[#1E1E1E]/90 
                      border-l border-gray-700 hidden lg:block pointer-events-none">
          <div 
            className="w-full h-full opacity-30"
            style={{
              backgroundImage: `linear-gradient(#404040 1px, transparent 1px)`,
              backgroundSize: '100% 5px',
              backgroundPosition: 'top',
            }} 
          />
        </div>
        <StatusBar />
      </div>
    </>
  );
}