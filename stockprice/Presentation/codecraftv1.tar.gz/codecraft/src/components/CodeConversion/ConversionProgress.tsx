import React from 'react';
import { Loader2, CheckCircle } from 'lucide-react';
import type { ConversionProgress as ProgressType } from '../../lib/api/convert';

interface ConversionProgressProps {
  isConverting: boolean;
  modelProgress: Record<string, ProgressType>;
}

export function ConversionProgress({ isConverting, modelProgress }: ConversionProgressProps) {
  if (!isConverting && Object.keys(modelProgress).length === 0) return null;

  const overallProgress = Math.floor(
    Object.values(modelProgress).reduce((sum, curr) => sum + (curr.progress || 0), 0) / 
    Math.max(Object.keys(modelProgress).length, 1)
  );

  const getProgressBarColor = (status: string, progress: number) => {
    if (status === 'failed') return 'bg-red-500';
    if (status === 'completed' && progress === 100) return 'bg-green-500';
    return 'bg-indigo-600';
  };

  const getStatusIcon = (status: string, progress: number) => {
    if (status === 'converting') {
      return <Loader2 className="w-3 h-3 animate-spin text-indigo-600" />;
    }
    if (status === 'completed' && progress === 100) {
      return <CheckCircle className="w-3 h-3 text-green-500" />;
    }
    return null;
  };

  return (
    <div className="space-y-4 mb-6">
      <div className="flex items-center justify-between text-sm text-gray-500">
        <div className="flex items-center">
          {isConverting ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
          )}
          <span>
            {isConverting ? 'Converting code...' : 'Conversion Complete'}
          </span>
        </div>
        <span className={overallProgress === 100 ? 'text-green-500 font-medium' : ''}>
          {overallProgress}%
        </span>
      </div>
      
      {Object.entries(modelProgress).map(([modelId, progress]) => (
        <div key={modelId} className="space-y-1">
          <div className="flex justify-between text-xs text-gray-500">
            <span className="flex items-center gap-2">
              {modelId}
              {getStatusIcon(progress.status, progress.progress)}
            </span>
            <span className={progress.progress === 100 ? 'text-green-500 font-medium' : ''}>
              {progress.progress}%
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-1.5">
            <div
              className={`h-1.5 rounded-full transition-all duration-500 ${
                getProgressBarColor(progress.status, progress.progress)
              }`}
              style={{ width: `${progress.progress}%` }}
            />
          </div>
          {progress.error && (
            <p className="text-xs text-red-500 mt-1">{progress.error}</p>
          )}
        </div>
      ))}
    </div>
  );
}