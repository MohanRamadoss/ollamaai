import React from 'react';
import { Check, Code2 } from 'lucide-react';
import { AI_MODELS } from '../../config/models';

interface ModelSelectProps {
  selectedModels: string[];
  onChange: (models: string[]) => void;
}

export function ModelSelect({ selectedModels, onChange }: ModelSelectProps) {
  const getModelFeatures = (modelId: string) => {
    const model = AI_MODELS.find(m => m.id === modelId);
    return model?.features || [];
  };

  return (
    <div className="space-y-4">
      <label className="block text-sm font-medium text-gray-700">
        Select AI Models
      </label>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {AI_MODELS.map((model) => (
          <button
            type="button" // Add this to prevent form submission
            key={model.id}
            onClick={() => {
              const isSelected = selectedModels.includes(model.id);
              if (isSelected) {
                onChange(selectedModels.filter(id => id !== model.id));
              } else {
                onChange([...selectedModels, model.id]);
              }
            }}
            className={`flex flex-col p-4 rounded-lg border ${
              selectedModels.includes(model.id)
                ? 'border-indigo-500 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-300'
            }`}
          >
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <h3 className="text-sm font-medium">{model.name}</h3>
                <p className="text-xs text-gray-500 mt-1">{model.description}</p>
              </div>
              {selectedModels.includes(model.id) && (
                <Check className="w-5 h-5 text-indigo-500 ml-4" />
              )}
            </div>
            
            {/* Add features display */}
            {model.features && model.features.length > 0 && (
              <div className="mt-3 pt-3 border-t border-gray-200">
                <ul className="space-y-2">
                  {model.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-xs text-gray-600">
                      <Code2 className="w-3 h-3 mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
