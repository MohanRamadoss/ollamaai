import React from 'react';
import { Loader2, AlertTriangle } from 'lucide-react';
import { CodeBlock } from '../shared/CodeBlock';
import { TokenCounter } from './TokenCounter'; // Updated import path

interface CodeDisplayProps {
  code: string;
  language: string;
  isGenerating: boolean;
  error?: Error | null;
  maxTokens: number;
}

export function CodeDisplay({
  code,
  language,
  isGenerating,
  error,
  maxTokens
}: CodeDisplayProps) {
  if (error) {
    return (
      <div className="p-4 bg-red-50 rounded-lg border border-red-200">
        <div className="flex items-center gap-2 text-red-600">
          <AlertTriangle className="w-5 h-5" />
          <p className="text-sm font-medium">{error.message}</p>
        </div>
      </div>
    );
  }

  if (isGenerating) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (!code) {
    return (
      <div className="p-8 text-center text-gray-500">
        No code generated yet
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <TokenCounter code={code} maxTokens={maxTokens} />
      </div>
      <CodeBlock
        code={code}
        language={language}
        showLineNumbers
        className="max-h-[600px] overflow-auto"
      />
    </div>
  );
}
