import React from 'react';
import { Check } from 'lucide-react';

type ComplexityLevel = 'basic' | 'intermediate' | 'advanced';

interface ComplexitySelectorProps {
  value: ComplexityLevel;
  onChange: (value: ComplexityLevel) => void;
}

export function ComplexitySelector({ value, onChange }: ComplexitySelectorProps) {
  const options = [
    { id: 'basic', label: 'Basic', description: 'Simple code conversion with basic patterns' },
    { id: 'intermediate', label: 'Intermediate', description: 'Standard code with common patterns' },
    { id: 'advanced', label: 'Advanced', description: 'Complex code with advanced patterns' },
  ] as const;

  return (
    <div className="space-y-4"></div>
      <label className="block text-sm font-medium text-gray-700">
        Code Complexity Level
      </label>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {options.map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => onChange(option.id)}
            className={`flex items-center justify-between p-4 rounded-lg border ${
              value === option.id
                ? 'border-indigo-500 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-300'
            }`}
          >
            <div className="flex-1">
              <h3 className="text-sm font-medium">{option.label}</h3>
              <p className="text-xs text-gray-500 mt-1">{option.description}</p>
            </div>
            {value === option.id && (
              <Check className="w-5 h-5 text-indigo-500 ml-4" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
