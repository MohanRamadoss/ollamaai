import React from 'react';
import { ArrowRight } from 'lucide-react';
import { LanguageSelector } from '../LanguageSelector';

interface LanguageConverterProps {
  sourceLanguage: string;
  targetLanguage: string;
  onSourceChange: (language: string) => void;
  onTargetChange: (language: string) => void;
}

export function LanguageConverter({
  sourceLanguage,
  targetLanguage,
  onSourceChange,
  onTargetChange,
}: LanguageConverterProps) {
  const handleSourceChange = (language: string) => {
    onSourceChange(language);
    // Only reset target if changing from shell and current target is ansible
    if (language !== 'shell' && targetLanguage === 'ansible') {
      onTargetChange('python');
    }
  };

  const handleTargetChange = (language: string) => {
    // Allow ansible selection without restrictions
    onTargetChange(language);
  };

  // Get available target languages based on source
  const getTargetLanguages = () => {
    // Include ansible in all available languages
    return ['ansible', 'python', 'javascript', 'typescript'];
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
      <LanguageSelector 
        value={sourceLanguage}
        onChange={handleSourceChange}
        label="Source Language"
      />
      <div className="flex justify-center">
        <ArrowRight className="w-6 h-6 text-gray-400" />
      </div>
      <LanguageSelector 
        value={targetLanguage}
        onChange={handleTargetChange}
        label="Target Language"
        availableLanguages={getTargetLanguages()}
      />
    </div>
  );
}