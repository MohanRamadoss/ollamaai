import React, { useState } from 'react';
import { CodeBlock } from '../shared/CodeBlock';
import { TokenCounter } from './TokenCounter';
import { Loader2, AlertTriangle, ChevronDown, ChevronUp, Download } from 'lucide-react';
import { AI_MODELS } from '../../config/models';
import { AnimatePresence, motion } from 'framer-motion';

interface MultiModelOutputProps {
  outputs: Array<{
    modelId: string;
    code: string;
    status: 'pending' | 'converting' | 'completed' | 'failed';
    error?: string;
  }>;
  language: string;
  maxTokens: number;
}

export function MultiModelOutput({ outputs, language, maxTokens }: MultiModelOutputProps) {
  const [expandedModel, setExpandedModel] = useState<string | null>(outputs[0]?.modelId || null);

  if (!outputs.length) return null;

  const getModelDisplayName = (modelId: string) => {
    const model = AI_MODELS.find(m => m.id === modelId);
    return model?.name || modelId;
  };

  const languageExtensions: Record<string, string> = {
    'python': 'py',
    'javascript': 'js',
    'typescript': 'ts',
    'java': 'java',
    'cpp': 'cpp',
    'c++': 'cpp',
    'go': 'go',
    'ruby': 'rb',
    'php': 'php',
    'csharp': 'cs',
    'c#': 'cs',
    'rust': 'rs',
    'swift': 'swift',
    'kotlin': 'kt',
    'shell': 'sh',
    'powershell': 'ps1',
    'sql': 'sql',
    'yaml': 'yml',
    'json': 'json',
    'markdown': 'md',
    'terraform': 'tf',
    'ansible': 'yml',
    'dockerfile': 'Dockerfile'
  };

  const handleDownload = (code: string, modelId: string) => {
    const extension = languageExtensions[language.toLowerCase()] || 'txt';
    const filename = modelId.toLowerCase() === 'dockerfile' ? 'Dockerfile' : `${modelId}_output.${extension}`;
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const variants = {
    hidden: { 
      height: 0,
      opacity: 0,
      transition: {
        height: { duration: 0.2, ease: [0.04, 0.62, 0.23, 0.98] },
        opacity: { duration: 0.15 }
      }
    },
    visible: { 
      height: "auto",
      opacity: 1,
      transition: {
        height: { 
          duration: 0.3, 
          ease: [0.04, 0.62, 0.23, 0.98]
        },
        opacity: { 
          duration: 0.25, 
          delay: 0.05 
        }
      }
    }
  };

  return (
    <div className="space-y-4">
      {outputs.map(({ modelId, code, status, error }) => (
        <div key={modelId} className="border rounded-lg overflow-hidden bg-white shadow-sm">
          <button
            onClick={() => setExpandedModel(expandedModel === modelId ? null : modelId)}
            className="w-full bg-gray-50 px-4 py-3 border-b flex justify-between items-center cursor-pointer hover:bg-gray-100 transition-colors duration-200"
            type="button"
          >
            <div className="flex items-center gap-2">
              <span className="font-medium text-gray-900">{getModelDisplayName(modelId)}</span>
              {status === 'converting' && (
                <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
              )}
              {status === 'failed' && (
                <AlertTriangle className="w-4 h-4 text-red-500" />
              )}
              {status === 'completed' && code && (
                <span className="text-xs text-gray-500">
                  <TokenCounter code={code} maxTokens={maxTokens} />
                </span>
              )}
            </div>
            {expandedModel === modelId ? (
              <ChevronUp className="w-4 h-4 text-gray-500" />
            ) : (
              <ChevronDown className="w-4 h-4 text-gray-500" />
            )}
          </button>

          <AnimatePresence initial={false} mode="sync">
            {expandedModel === modelId && (
              <motion.div
                variants={variants}
                initial="hidden"
                animate="visible"
                exit="hidden"
                className="bg-gray-900"
              >
                <motion.div className="p-4">
                  {error ? (
                    <div className="text-red-400 p-4 bg-red-900/10 rounded-lg">
                      {error}
                    </div>
                  ) : (
                    code ? (
                      <>
                        <CodeBlock
                          code={code}
                          language={language}
                          showLineNumbers
                          className="max-h-[600px] overflow-auto"
                        />
                        <button
                          type="button"
                          onClick={() => handleDownload(code, modelId)}
                          className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                        >
                          <Download className="w-4 h-4 mr-2" />
                          Download Code
                        </button>
                      </>
                    ) : (
                      <div className="text-gray-400 text-center py-4">
                        {status === 'pending' ? 'Waiting to start...' : 'No code generated yet'}
                      </div>
                    )
                  )}
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  );
}
