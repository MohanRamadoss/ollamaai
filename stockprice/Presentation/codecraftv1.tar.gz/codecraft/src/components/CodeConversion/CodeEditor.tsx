import React, { useState, useRef } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Copy, Edit2, Eye, Check, Loader2 } from 'lucide-react';

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  language: string;
  readOnly?: boolean;
}

export function CodeEditor({
  value,
  onChange,
  language,
  readOnly = false
}: CodeEditorProps) {
  const [isEditing, setIsEditing] = useState(!readOnly);
  const [isCopied, setIsCopied] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Map common language names to Prism language IDs
  const getPrismLanguage = (lang: string): string => {
    const languageMap: Record<string, string> = {
      'python': 'python',
      'javascript': 'javascript',
      'typescript': 'typescript',
      'java': 'java',
      'cpp': 'cpp',
      'c++': 'cpp',
      'go': 'go',
      'ruby': 'ruby',
      'php': 'php',
      'csharp': 'csharp',
      'c#': 'csharp',
      'rust': 'rust',
      'swift': 'swift',
      'kotlin': 'kotlin',
      'shell': 'shell',
      'powershell': 'powershell',
      'sql': 'sql',
      'yaml': 'yaml',
      'json': 'json',
      'markdown': 'markdown',
      'terraform': 'hcl',
      'ansible': 'yaml',
      'dockerfile': 'dockerfile'
    };
    return languageMap[lang.toLowerCase()] || 'plaintext';
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy code:', err);
    }
  };

  const handleChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    onChange(event.target.value);
  };

  const toggleEditMode = () => {
    if (!readOnly) {
      setIsEditing(!isEditing);
      // Focus textarea when switching to edit mode
      if (!isEditing && textareaRef.current) {
        setTimeout(() => textareaRef.current?.focus(), 0);
      }
    }
  };

  return (
    <div className="border rounded-lg overflow-hidden bg-[#1E1E1E]">
      <div className="flex items-center justify-between px-4 py-2 bg-[#2D2D2D] border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-400">{language.toUpperCase()}</span>
        </div>
        <div className="flex items-center space-x-2">
          {!readOnly && (
            <button
              onClick={toggleEditMode}
              className="p-1.5 rounded-md text-gray-400 hover:text-white hover:bg-gray-700"
              title={isEditing ? "View mode" : "Edit mode"}
            >
              {isEditing ? <Eye size={16} /> : <Edit2 size={16} />}
            </button>
          )}
          <button
            onClick={handleCopy}
            className="p-1.5 rounded-md text-gray-400 hover:text-white hover:bg-gray-700"
            title="Copy code"
          >
            {isCopied ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
          </button>
        </div>
      </div>

      <div className="relative h-[400px] overflow-auto">
        {isEditing ? (
          <textarea
            ref={textareaRef}
            value={value}
            onChange={handleChange}
            className="w-full h-full p-4 bg-[#1E1E1E] text-gray-300 font-mono text-sm resize-none focus:outline-none"
            spellCheck="false"
            style={{ 
              tabSize: 2,
              lineHeight: '1.5',
              caretColor: '#fff'
            }}
          />
        ) : (
          <SyntaxHighlighter
            language={getPrismLanguage(language)}
            style={vscDarkPlus}
            customStyle={{
              margin: 0,
              padding: '1rem',
              height: '100%',
              fontSize: '14px',
              background: '#1E1E1E',
            }}
            showLineNumbers
            wrapLines
            wrapLongLines
          >
            {value || '// Enter your code here'}
          </SyntaxHighlighter>
        )}
      </div>
    </div>
  );
}
