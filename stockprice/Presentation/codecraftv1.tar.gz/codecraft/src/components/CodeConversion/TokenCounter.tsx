import React from 'react';

interface TokenCounterProps {
  code: string;
  maxTokens: number;
}

export function TokenCounter({ code, maxTokens }: TokenCounterProps) {
  const tokenCount = React.useMemo(() => {
    try {
      // Simple approximation of token count based on character length
      // This is a basic implementation - you might want to use a more accurate method
      return Math.ceil(code.length / 4);
    } catch (error) {
      console.error('Error counting tokens:', error);
      return 0;
    }
  }, [code]);
  
  const percentage = (tokenCount / maxTokens) * 100;
  
  return (
    <div className="text-xs text-gray-500">
      {tokenCount.toLocaleString()} / {maxTokens.toLocaleString()} tokens
      {percentage > 90 && (
        <span className="ml-2 text-amber-600">
          ({Math.round(percentage)}% of limit)
        </span>
      )}
    </div>
  );
}
