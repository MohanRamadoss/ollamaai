import React from 'react';
import { AlertCircle } from 'lucide-react';

interface TokenCounterProps {
  code: string;
  maxTokens?: number;
  modelId?: string;
}

export function TokenCounter({ code, maxTokens, modelId }: TokenCounterProps) {
  const tokenCount = Math.ceil(code.length / 4); // Simple approximation

  return (
    <div className="flex items-center gap-2 text-sm">
      {modelId && <span className="text-gray-500">{modelId}:</span>}
      <span className="text-gray-600">{tokenCount.toLocaleString()} tokens</span>
      {maxTokens && (
        <span className="text-gray-400">/ {maxTokens.toLocaleString()}</span>
      )}
    </div>
  );
}