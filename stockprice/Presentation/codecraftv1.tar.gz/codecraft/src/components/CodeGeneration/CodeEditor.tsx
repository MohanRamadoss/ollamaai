import React, { useState } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Copy, Check, Edit2, Eye } from 'lucide-react';

interface CodeEditorProps {
  code: string;
  language: string;
  readOnly?: boolean;
  showLineNumbers?: boolean;
  maxHeight?: string;
  onChange?: (value: string) => void;
}

export function CodeEditor({
  code,
  language,
  readOnly = true,
  showLineNumbers = true,
  maxHeight = 'none',
  onChange
}: CodeEditorProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const [editableCode, setEditableCode] = useState(code);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (err) {
      console.error('Failed to copy code:', err);
    }
  };

  const handleEdit = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newCode = event.target.value;
    setEditableCode(newCode);
    onChange?.(newCode);
  };

  const toggleEditMode = () => {
    if (!readOnly) {
      setIsEditing(!isEditing);
    }
  };

  return (
    <div className="relative group">
      <div className="absolute right-2 top-2 flex gap-2 z-10">
        <button
          onClick={handleCopy}
          className="p-1.5 rounded bg-gray-800 text-gray-300 hover:bg-gray-700 transition-colors"
          title="Copy code"
        >
          {copySuccess ? <Check size={16} /> : <Copy size={16} />}
        </button>
        {!readOnly && (
          <button
            onClick={toggleEditMode}
            className="p-1.5 rounded bg-gray-800 text-gray-300 hover:bg-gray-700 transition-colors"
            title={isEditing ? "View mode" : "Edit mode"}
          >
            {isEditing ? <Eye size={16} /> : <Edit2 size={16} />}
          </button>
        )}
      </div>

      {isEditing ? (
        <textarea
          value={editableCode}
          onChange={handleEdit}
          className="w-full h-full min-h-[200px] p-4 font-mono text-sm bg-gray-900 text-gray-100 border border-gray-700 rounded-md focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
          style={{ maxHeight }}
        />
      ) : (
        <div style={{ maxHeight, overflow: 'auto' }}>
          <SyntaxHighlighter
            language={language.toLowerCase()}
            style={vscDarkPlus}
            showLineNumbers={showLineNumbers}
            customStyle={{ 
              margin: 0, 
              borderRadius: '4px',
              fontSize: '14px',
            }}
            wrapLines
            wrapLongLines
          >
            {isEditing ? editableCode : code}
          </SyntaxHighlighter>
        </div>
      )}
    </div>
  );
}
