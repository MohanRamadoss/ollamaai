import React, { useState } from 'react';
import { Loader2, AlertTriangle, CheckCircle, Copy, Download, ChevronDown, ChevronUp } from 'lucide-react';
import { CodeEditor } from './CodeEditor';
import { getFileInfo } from '../../utils/fileNaming';
import { TokenCounter } from '../TokenCounter';

interface ModelOutput {
  modelId: string;
  code: string;
  status: 'completed' | 'failed' | 'generating';
  error?: string;
}

interface MultiModelOutputProps {
  outputs: ModelOutput[];
  language: string;
}

const FILE_EXTENSIONS: { [key: string]: string } = {
  javascript: 'js',
  typescript: 'ts',
  python: 'py',
  // Add more language extensions as needed
};

const MIME_TYPES: { [key: string]: string } = {
  javascript: 'application/javascript',
  typescript: 'application/typescript',
  python: 'application/x-python-code',
  // Add more MIME types as needed
};

export function MultiModelOutput({ outputs, language }: MultiModelOutputProps) {
  const [expandedModel, setExpandedModel] = useState<string | null>(null);
  const [copiedModel, setCopiedModel] = useState<string | null>(null);

  if (!outputs?.length) return null;

  const handleCopy = async (code: string, modelId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await navigator.clipboard.writeText(code);
    setCopiedModel(modelId);
    setTimeout(() => setCopiedModel(null), 2000);
  };

  const handleDownload = (code: string, modelId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const { mimeType, filename } = getFileInfo(language, code);
    const modelPrefix = filename.includes('-') ? filename.replace('-', `-${modelId}-`) : `${modelId}-${filename}`;
    
    const blob = new Blob([code], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = modelPrefix;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {outputs.map(({ modelId, code, status, error }) => (
        <div key={modelId} className="border rounded-lg overflow-hidden">
          <div 
            className="flex items-center justify-between p-4 bg-gray-50 cursor-pointer hover:bg-gray-100"
            onClick={() => setExpandedModel(expandedModel === modelId ? null : modelId)}
          >
            <div className="flex items-center gap-4">
              <span className="font-medium">{modelId}</span>
              {status === 'generating' && (
                <div className="flex items-center text-indigo-600">
                  <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                  <span className="text-sm">Generating...</span>
                </div>
              )}
              {status === 'completed' && (
                <>
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <TokenCounter code={code} modelId={modelId} />
                </>
              )}
              {status === 'failed' && (
                <div className="flex items-center text-red-500">
                  <AlertTriangle className="w-4 h-4 mr-1" />
                  <span className="text-sm">{error}</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              {status === 'completed' && code && (
                <>
                  <button
                    onClick={(e) => handleCopy(code, modelId, e)}
                    className="p-2 rounded hover:bg-gray-200"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                  <button
                    onClick={(e) => handleDownload(code, modelId, e)}
                    className="p-2 rounded hover:bg-gray-200"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </>
              )}
              {expandedModel === modelId ? (
                <ChevronUp className="w-5 h-5" />
              ) : (
                <ChevronDown className="w-5 h-5" />
              )}
            </div>
          </div>

          {expandedModel === modelId && status === 'completed' && code && (
            <div className="p-4 bg-gray-900">
              <div className="mb-2 flex justify-end">
                <TokenCounter code={code} modelId={modelId} />
              </div>
              <CodeEditor
                code={code}
                language={language}
                readOnly
                showLineNumbers
              />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
