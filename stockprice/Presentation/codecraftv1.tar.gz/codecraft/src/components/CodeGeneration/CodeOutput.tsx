import React, { Suspense } from 'react';
import { Download, Copy, Check, Loader2 } from 'lucide-react';
import CodeMirror from '@uiw/react-codemirror';
import { vscodeDark } from '@uiw/codemirror-theme-vscode';
import { javascript } from '@codemirror/lang-javascript';
import { python } from '@codemirror/lang-python';
import { yaml } from '@codemirror/lang-yaml';
import { json } from '@codemirror/lang-json';
import { FILE_EXTENSIONS } from '../../config/constants';
import { TokenCounter } from '../TokenCounter';
import { ENV_CONFIG } from '../../config/env';
import { getFileInfo } from '../../utils/fileNaming';

interface CodeOutputProps {
  code: string;
  language: string;
  isGenerating: boolean;
  progress: number;
  maxTokens: number;
  error?: Error | null;
}

const getLanguageExtension = (language: string) => {
  switch (language) {
    case 'javascript':
    case 'typescript':
      return javascript();
    case 'python':
      return python();
    case 'yaml':
    case 'yml':
      return yaml();
    case 'json':
      return json();
    default:
      return javascript();
  }
};

// Fallback component for code editor loading
const EditorFallback = () => (
  <div className="h-[500px] flex items-center justify-center bg-gray-900 rounded-lg">
    <div className="flex flex-col items-center text-gray-400">
      <Loader2 className="w-8 h-8 animate-spin mb-2" />
      <span>Loading editor...</span>
    </div>
  </div>
);

// Error boundary component
class CodeEditorErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="h-[500px] flex items-center justify-center bg-gray-900 rounded-lg">
          <div className="text-gray-400 text-center">
            <p>Error loading code editor.</p>
            <button
              onClick={() => this.setState({ hasError: false })}
              className="mt-2 text-indigo-400 hover:text-indigo-300"
            >
              Try again
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export function CodeOutput({ code, language, isGenerating, progress, maxTokens, error }: CodeOutputProps) {
  const [copied, setCopied] = React.useState(false);
  const [downloading, setDownloading] = React.useState(false);
  const [editorKey, setEditorKey] = React.useState(0); // Add key for force re-render

  // Handle editor reset when language changes
  React.useEffect(() => {
    setEditorKey(prev => prev + 1);
  }, [language]);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const { mimeType, filename } = getFileInfo(language, code);
      const blob = new Blob([code], { type: mimeType });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } finally {
      setDownloading(false);
    }
  };

  // Add code cleanup
  const displayCode = React.useMemo(() => {
    if (!code) return '';
    
    // Remove any markdown code block syntax
    let cleaned = code.replace(/```\w*\n?/g, '').trim();
    
    // Remove common AI response prefixes
    cleaned = cleaned.replace(/^(Here is|This is|Here's).*?\n/, '');
    
    return cleaned;
  }, [code]);

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-medium text-gray-900">Generated Code</h2>
          <TokenCounter code={code} maxTokens={maxTokens} />
        </div>

        {/* Progress Bar */}
        {isGenerating && (
          <div className="space-y-2 mb-4">
            <div className="flex justify-between text-sm text-gray-500">
              <div className="flex items-center">
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                <span>Generating code...</span>
              </div>
              <span>{progress}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {/* Code Editor */}
        <div className="relative bg-gray-900 rounded-lg overflow-hidden">
          <CodeEditorErrorBoundary>
            <Suspense fallback={<EditorFallback />}>
              <div className="relative min-h-[500px]">
                <CodeMirror
                  key={editorKey}
                  value={displayCode}
                  height="500px"
                  theme={vscodeDark}
                  extensions={[getLanguageExtension(language)]}
                  editable={false}
                  basicSetup={{
                    lineNumbers: true,
                    highlightActiveLineGutter: true,
                    highlightSpecialChars: true,
                    history: true,
                    foldGutter: true,
                    drawSelection: true,
                    dropCursor: true,
                    allowMultipleSelections: true,
                    indentOnInput: true,
                    syntaxHighlighting: true,
                    bracketMatching: true,
                    closeBrackets: true,
                    autocompletion: true,
                    rectangularSelection: true,
                    crosshairCursor: true,
                    highlightActiveLine: true,
                    highlightSelectionMatches: true,
                    closeBracketsKeymap: true,
                    defaultKeymap: true,
                    searchKeymap: true,
                    historyKeymap: true,
                    foldKeymap: true,
                    completionKeymap: true,
                    lintKeymap: true,
                  }}
                />

                {/* Action Buttons */}
                <div className="absolute top-2 right-2 flex space-x-2">
                  <button
                    onClick={handleCopy}
                    className="p-2 rounded-md bg-gray-800 text-white hover:bg-gray-700 transition-colors"
                    title="Copy code"
                  >
                    {copied ? <Check size={16} /> : <Copy size={16} />}
                  </button>
                  <button
                    onClick={handleDownload}
                    disabled={!code || downloading}
                    className={`p-2 rounded-md bg-gray-800 text-white transition-colors ${
                      code && !downloading ? 'hover:bg-gray-700' : 'opacity-50 cursor-not-allowed'
                    }`}
                    title="Download code"
                  >
                    <Download size={16} className={downloading ? 'animate-bounce' : ''} />
                  </button>
                </div>
              </div>
            </Suspense>
          </CodeEditorErrorBoundary>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
            <h3 className="text-sm font-medium text-red-800">Generation Error</h3>
            <p className="mt-1 text-sm text-red-700">{error.message}</p>
          </div>
        )}

        {/* Remove or comment out the Debug Information section */}
        {/* ENV_CONFIG.DEBUG && debug info section removed */}
      </div>
    </div>
  );
}