import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Wand2, Sparkles, Brain, Zap } from 'lucide-react';
import { TokenCounter } from './TokenCounter';
import { ModelSelector } from './ModelSelector';
import { ComplexityLevel } from '../types/models';
import { PromptGenerator as PromptGeneratorService } from '../lib/promptGenerator';
import type { PromptTemplate } from '../lib/promptTemplates';

const promptGeneratorSchema = z.object({
  templateId: z.string().min(1, 'Please select a template'),
  complexity: z.enum(['basic', 'intermediate', 'advanced']),
  variables: z.record(z.string()),
  modelIds: z.array(z.string()),
});

type PromptGeneratorForm = z.infer<typeof promptGeneratorSchema>;

const complexityGuides = {
  basic: {
    icon: <Zap className="w-5 h-5" />,
    description: 'Simple, straightforward implementations with basic functionality',
    examples: ['Basic CRUD operations', 'Simple form validation', 'Static layouts']
  },
  intermediate: {
    icon: <Sparkles className="w-5 h-5" />,
    description: 'More sophisticated features with error handling and best practices',
    examples: ['Authentication flows', 'Data visualization', 'API integration']
  },
  advanced: {
    icon: <Brain className="w-5 h-5" />,
    description: 'Complex systems with advanced patterns and optimizations',
    examples: ['Real-time features', 'Complex state management', 'Performance optimization']
  }
};

export function PromptGenerator() {
  const [generatedPrompt, setGeneratedPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [templates, setTemplates] = useState<PromptTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<PromptTemplate | null>(null);
  const [progress, setProgress] = useState(0);

  const promptGenerator = PromptGeneratorService.getInstance();

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<PromptGeneratorForm>({
    resolver: zodResolver(promptGeneratorSchema),
    defaultValues: {
      complexity: 'intermediate' as ComplexityLevel,
      variables: {},
      modelIds: ['gemini-pro-code'],
    }
  });

  const selectedComplexity = watch('complexity') as keyof typeof complexityGuides;
  const selectedTemplateId = watch('templateId');
  const selectedModels = watch('modelIds');

  useEffect(() => {
    const templates = promptGenerator.getTemplatesByComplexity(selectedComplexity);
    setTemplates(templates);
  }, [selectedComplexity]);

  useEffect(() => {
    if (selectedTemplateId) {
      const template = promptGenerator.getTemplateById(selectedTemplateId);
      setSelectedTemplate(template || null);
    }
  }, [selectedTemplateId]);

  const onSubmit = async (data: PromptGeneratorForm) => {
    setIsGenerating(true);
    setProgress(0);
    
    try {
      // Start progress animation
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      const prompt = await promptGenerator.generatePrompt(
        data.templateId,
        data.variables,
        data.modelIds
      );
      
      setGeneratedPrompt(prompt);
      setProgress(100);
    } catch (error) {
      console.error('Failed to generate prompt:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">AI Prompt Generator</h2>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <ModelSelector 
            selectedModels={selectedModels} 
            onChange={(models) => setValue('modelIds', models)} 
          />

          {/* Complexity Selection */}
          <div className="space-y-4">
            <label className="block text-sm font-medium text-gray-700">Complexity Level</label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {(Object.keys(complexityGuides) as Array<keyof typeof complexityGuides>).map((level) => (
                <label
                  key={level}
                  className={`relative flex flex-col p-4 cursor-pointer rounded-lg border ${
                    selectedComplexity === level
                      ? 'border-indigo-500 bg-indigo-50'
                      : 'border-gray-200 hover:border-indigo-200'
                  }`}
                >
                  <input
                    type="radio"
                    {...register('complexity')}
                    value={level}
                    className="sr-only"
                  />
                  <div className="flex items-center mb-2">
                    {complexityGuides[level].icon}
                    <span className="ml-2 font-medium capitalize">{level}</span>
                  </div>
                  <p className="text-sm text-gray-600">{complexityGuides[level].description}</p>
                  <div className="mt-2">
                    <ul className="text-xs text-gray-500 list-disc list-inside">
                      {complexityGuides[level].examples.map((example, index) => (
                        <li key={index}>{example}</li>
                      ))}
                    </ul>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Template Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700">Template</label>
            <select
              {...register('templateId')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            >
              <option value="">Select a template</option>
              {templates.map(template => (
                <option key={template.id} value={template.id}>
                  {template.name}
                </option>
              ))}
            </select>
            {errors.templateId && (
              <p className="mt-1 text-sm text-red-600">{errors.templateId.message}</p>
            )}
          </div>

          {/* Template Variables */}
          {selectedTemplate && (
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-700">Template Variables</h3>
              {selectedTemplate.variables.map(variable => (
                <div key={variable.name}>
                  <label className="block text-sm font-medium text-gray-700">
                    {variable.name}
                    {variable.required && <span className="text-red-500 ml-1">*</span>}
                    <span className="text-gray-500 text-xs ml-2">
                      ({variable.description})
                    </span>
                  </label>
                  <input
                    type="text"
                    {...register(`variables.${variable.name}`)}
                    defaultValue={variable.defaultValue}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                  />
                </div>
              ))}
            </div>
          )}

          <button
            type="submit"
            disabled={isGenerating}
            className="w-full flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
          >
            <Wand2 className="w-4 h-4 mr-2" />
            {isGenerating ? 'Generating...' : 'Generate Prompt'}
          </button>
        </form>
      </div>

      {/* Generated Prompt Display */}
      {(generatedPrompt || isGenerating) && (
        <div className="bg-white p-6 rounded-lg shadow-lg">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-gray-900">Generated Prompt</h3>
            <TokenCounter code={generatedPrompt} maxTokens={2048} />
          </div>
          
          {isGenerating && (
            <div className="mb-4">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="text-sm text-gray-500 mt-2">
                Enhancing prompt with selected AI models...
              </p>
            </div>
          )}
          
          <div className="bg-gray-50 rounded-md p-4 font-mono text-sm whitespace-pre-wrap">
            {isGenerating ? 'Generating...' : generatedPrompt}
          </div>
        </div>
      )}
    </div>
  );
}