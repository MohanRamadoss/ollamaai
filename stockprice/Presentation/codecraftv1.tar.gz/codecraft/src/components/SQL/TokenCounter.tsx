import React from 'react';
import { Hash } from 'lucide-react';

interface TokenCounterProps {
  query: string;
  maxTokens?: number;
}

export function TokenCounter({ query, maxTokens = 2048 }: TokenCounterProps) {
  // Simple token estimation (can be improved with actual tokenizer)
  const estimatedTokens = Math.ceil(query.length / 4);
  const percentage = Math.min((estimatedTokens / maxTokens) * 100, 100);

  return (
    <div className="flex items-center gap-2 text-sm text-gray-500">
      <Hash className="w-4 h-4" />
      <span>{estimatedTokens}</span>
      <div className="w-20 h-1.5 bg-gray-200 rounded-full">
        <div
          className="h-full bg-indigo-600 rounded-full"
          style={{ width: `${percentage}%` }}
        />
      </div>
      <span>{maxTokens}</span>
    </div>
  );
}
