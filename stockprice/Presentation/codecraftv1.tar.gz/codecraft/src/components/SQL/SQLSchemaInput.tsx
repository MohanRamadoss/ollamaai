import React from 'react';
import { CodeEditor } from '../CodeEditor';

interface SQLSchemaInputProps {
  value: string;
  onChange: (value: string) => void;
}

export function SQLSchemaInput({ value, onChange }: SQLSchemaInputProps) {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <label className="block text-sm font-medium text-gray-700">Table Schema (Optional)</label>
        <span className="text-xs text-gray-500">
          Provide existing table schemas for better query generation
        </span>
      </div>
      <CodeEditor
        value={value}
        onChange={onChange}
        language="sql"
        height="200px"
      />
    </div>
  );
}