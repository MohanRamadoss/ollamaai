import React, { useState, useRef } from 'react';
import { Download, Copy, Check, Edit2, Eye } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

interface SQLCodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  readOnly?: boolean;
  isGenerating?: boolean;
  progress?: number;
}

export function SQLCodeEditor({
  value,
  onChange,
  readOnly = false,
  isGenerating = false,
  progress = 0
}: SQLCodeEditorProps) {
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const handleDownload = () => {
    setDownloading(true);
    try {
      const blob = new Blob([value], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      a.href = url;
      a.download = `sql-query-${timestamp}.sql`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Failed to download:', error);
    } finally {
      setDownloading(false);
    }
  };

  const handleEditToggle = () => {
    setIsEditing(!isEditing);
    if (!isEditing) {
      // Focus textarea when switching to edit mode
      setTimeout(() => {
        textareaRef.current?.focus();
      }, 0);
    }
  };

  return (
    <div className="space-y-2">
      {/* Progress Bar */}
      {isGenerating && (
        <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
          <div
            className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}

      {/* Editor Container */}
      <div className="relative border border-gray-200 rounded-lg overflow-hidden bg-[#1E1E1E]">
        {/* Action Buttons */}
        <div className="absolute top-2 right-2 flex space-x-2 z-10">
          {!readOnly && (
            <button
              onClick={handleEditToggle}
              className="p-2 rounded-md bg-gray-800 text-white hover:bg-gray-700 transition-colors"
              title={isEditing ? "View mode" : "Edit mode"}
            >
              {isEditing ? <Eye size={16} /> : <Edit2 size={16} />}
            </button>
          )}
          <button
            onClick={handleCopy}
            className="p-2 rounded-md bg-gray-800 text-white hover:bg-gray-700 transition-colors"
            title="Copy code"
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
          </button>
          <button
            onClick={handleDownload}
            disabled={!value || downloading}
            className={`p-2 rounded-md bg-gray-800 text-white transition-colors ${
              value && !downloading ? 'hover:bg-gray-700' : 'opacity-50 cursor-not-allowed'
            }`}
            title="Download code"
          >
            <Download size={16} className={downloading ? 'animate-bounce' : ''} />
          </button>
        </div>

        {/* Editor/Viewer */}
        <div className="h-[500px] overflow-auto">
          {isEditing && !readOnly ? (
            <textarea
              ref={textareaRef}
              value={value}
              onChange={(e) => onChange(e.target.value)}
              className="w-full h-full p-4 bg-[#1E1E1E] text-white font-mono text-sm focus:outline-none resize-none"
              spellCheck="false"
            />
          ) : (
            <SyntaxHighlighter
              language="sql"
              style={vscDarkPlus}
              showLineNumbers
              customStyle={{
                margin: 0,
                padding: '1rem',
                height: '100%',
                fontSize: '0.875rem',
              }}
              codeTagProps={{
                style: {
                  fontFamily: 'var(--font-mono)',
                  lineHeight: '1.5',
                }
              }}
            >
              {value || '-- Enter your SQL query here...'}
            </SyntaxHighlighter>
          )}
        </div>
      </div>
    </div>
  );
}