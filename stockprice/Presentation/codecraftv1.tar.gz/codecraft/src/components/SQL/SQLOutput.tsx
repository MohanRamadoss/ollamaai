import React, { useState, useCallback } from 'react';
import { Copy, Check, Database, Sparkles, Info, BarChart2 } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import type { SQLDialect } from '../../types/sql';

interface SQLOutputProps {
  query: string;
  dialect: SQLDialect;
  explanation?: string;
  optimizations?: {
    indexRecommendations?: string[];
    queryPlan?: string;
    partitioningStrategy?: string;
    replicationSetup?: string;
  };
}

export function SQLOutput({ query, dialect, explanation, optimizations }: SQLOutputProps) {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'query' | 'explanation' | 'optimizations'>('query');

  const dialectNames = {
    postgresql: 'PostgreSQL',
    mysql: 'MySQL',
    sqlite: 'SQLite',
    mssql: 'SQL Server',
    oracle: 'Oracle'
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(query);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  // Memoize the check for optimizations
  const hasOptimizations = useCallback(() => {
    return optimizations && (
      (optimizations.indexRecommendations && optimizations.indexRecommendations.length > 0) ||
      optimizations.queryPlan ||
      optimizations.partitioningStrategy ||
      optimizations.replicationSetup
    );
  }, [optimizations]);

  // Handle tab change with validation
  const handleTabChange = (tab: 'query' | 'explanation' | 'optimizations') => {
    if (tab === 'optimizations' && !hasOptimizations()) {
      return; // Don't switch to optimizations if there aren't any
    }
    setActiveTab(tab);
  };

  const formatQuery = (query: string, dialect: SQLDialect): string => {
    if (dialect === 'mssql' && !query.trim().toUpperCase().startsWith('--')) {
      return `-- SQL Server Query\n-- Generated for performance analysis\nSET NOCOUNT ON;\n\n${query}`;
    }
    return query;
  };

  return (
    <div className="space-y-4">
      {/* Tab Navigation */}
      <div className="flex space-x-2 border-b border-gray-200">
        <button
          onClick={() => handleTabChange('query')}
          className={`px-4 py-2 flex items-center gap-2 ${
            activeTab === 'query' 
              ? 'border-b-2 border-indigo-500 text-indigo-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <Database className="w-4 h-4" />
          Query
        </button>
        {explanation && (
          <button
            onClick={() => handleTabChange('explanation')}
            className={`px-4 py-2 flex items-center gap-2 ${
              activeTab === 'explanation'
                ? 'border-b-2 border-indigo-500 text-indigo-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Info className="w-4 h-4" />
            Explanation
          </button>
        )}
        {hasOptimizations() && (
          <button
            onClick={() => handleTabChange('optimizations')}
            className={`px-4 py-2 flex items-center gap-2 ${
              activeTab === 'optimizations'
                ? 'border-b-2 border-indigo-500 text-indigo-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            Optimizations
          </button>
        )}
      </div>

      {/* Content Area */}
      <div className="min-h-[200px]">
        {activeTab === 'query' && (
          <div className="relative">
            <div className="absolute right-2 top-2 z-10">
              <button
                onClick={handleCopy}
                className="p-2 rounded-lg bg-gray-800 text-white hover:bg-gray-700 transition-colors"
                title="Copy to clipboard"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
            <div className="flex items-center gap-2 mb-2">
              <Database className="w-5 h-5 text-indigo-600" />
              <span className="text-sm font-medium text-gray-700">
                {dialectNames[dialect]} Query
              </span>
            </div>
            <SyntaxHighlighter
              language="sql"
              style={oneDark}
              customStyle={{
                margin: 0,
                borderRadius: '0.5rem',
                padding: '1rem'
              }}
            >
              {formatQuery(query, dialect)}
            </SyntaxHighlighter>
          </div>
        )}

        {activeTab === 'explanation' && explanation && (
          <div className="prose max-w-none">
            <div className="flex items-center gap-2 mb-4">
              <Info className="w-5 h-5 text-indigo-600" />
              <h3 className="text-lg font-medium m-0">Query Explanation</h3>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              {explanation.split('\n').map((line, i) => (
                <p key={i} className="text-gray-700 mb-2 last:mb-0">
                  {line}
                </p>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'optimizations' && hasOptimizations() && (
          <div className="space-y-6">
            <div className="flex items-center gap-2 mb-2">
              <BarChart2 className="w-5 h-5 text-indigo-600" />
              <h3 className="text-lg font-medium">Optimization Details</h3>
            </div>
            
            {optimizations?.indexRecommendations && optimizations.indexRecommendations.length > 0 && (
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Index Recommendations</h4>
                <ul className="list-disc pl-5 space-y-1">
                  {optimizations.indexRecommendations.map((rec, i) => (
                    <li key={i} className="text-gray-700">{rec}</li>
                  ))}
                </ul>
              </div>
            )}

            {optimizations?.queryPlan && (
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Query Plan</h4>
                <pre className="text-sm text-gray-700 whitespace-pre-wrap">
                  {optimizations.queryPlan}
                </pre>
              </div>
            )}

            {optimizations?.partitioningStrategy && (
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Partitioning Strategy</h4>
                <p className="text-gray-700">{optimizations.partitioningStrategy}</p>
              </div>
            )}

            {optimizations?.replicationSetup && (
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Replication Setup</h4>
                <p className="text-gray-700">{optimizations.replicationSetup}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}