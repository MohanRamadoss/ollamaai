import React from 'react';
import { Book } from 'lucide-react';
import type { SQLExample, SQLDialect } from '../../types/sql';

interface SQLExamplesProps {
  examples: SQLExample[];
  currentDialect: SQLDialect;
  onSelectExample: (example: SQLExample) => void;
}

export function SQLExamples({ examples, currentDialect, onSelectExample }: SQLExamplesProps) {
  const dialectNames = {
    postgresql: 'PostgreSQL',
    mysql: 'MySQL',
    sqlite: 'SQLite',
    mssql: 'SQL Server',
    oracle: 'Oracle'
  };

  const complexityColors = {
    basic: 'bg-green-100 text-green-800',
    intermediate: 'bg-blue-100 text-blue-800',
    advanced: 'bg-purple-100 text-purple-800'
  };

  if (!examples || examples.length === 0) {
    return (
      <div className="text-center p-4">
        <p className="text-gray-500">No examples available for {dialectNames[currentDialect]}</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <Book className="w-5 h-5 text-indigo-600" />
        <h3 className="text-lg font-medium">
          {dialectNames[currentDialect]} Examples
        </h3>
      </div>

      <div className="space-y-3">
        {examples.map((example, index) => (
          <button
            key={index}
            onClick={() => onSelectExample(example)}
            className="w-full text-left p-4 rounded-lg border border-gray-200 hover:border-indigo-500 transition-colors"
          >
            <div className="flex justify-between items-start mb-2">
              <span className="font-medium text-gray-900">{example.title}</span>
              <span className={`text-xs px-2 py-1 rounded-full ${complexityColors[example.complexity]}`}>
                {example.complexity}
              </span>
            </div>
            <p className="text-sm text-gray-600">{example.description}</p>
          </button>
        ))}
      </div>
    </div>
  );
}