export const PROGRAMMING_SECURITY_PROMPTS = {
  'javascript': {
    base: 'Analyze this JavaScript code for security vulnerabilities...',
    features: {
      xss: 'Check for Cross-Site Scripting vulnerabilities...',
      injection: 'Identify SQL/NoSQL injection risks...',
      // Add more language-specific security checks
    }
  },
  // Add more languages
};

export const CONFIG_SECURITY_PROMPTS = {
  quick: {
    description: 'Basic security scan focusing on common vulnerabilities',
    prompt: 'Perform a quick security analysis...'
  },
  full: {
    description: 'Comprehensive security assessment',
    prompt: 'Conduct a full security audit...'
  },
  deep: {
    description: 'In-depth security analysis with detailed recommendations',
    prompt: 'Execute a deep security scan...'
  }
};
