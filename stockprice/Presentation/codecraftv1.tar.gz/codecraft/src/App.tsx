import React, { Suspense, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Header } from './components/Header';
import { MainScreen } from './pages/MainScreen';
import { LoginPage } from './pages/LoginPage';
import { GeneratePage } from './pages/GeneratePage';
import { ConvertPage } from './pages/ConvertPage';
import { CodeAnalysisPage } from './pages/CodeAnalysisPage';
import { CloudPage } from './pages/CloudPage';
import { CICDPage } from './pages/CICDPage';
import { SQLPage } from './pages/SQLPage';
import { PromptsPage } from './pages/PromptsPage';
import { TerraformRAGPage } from './pages/TerraformRAGPage';
import { AddonsPage } from './pages/AddonsPage';
import { FullStackCategoryPage } from './pages/FullStackCategoryPage';
import { BlockchainCategoryPage } from './pages/BlockchainCategoryPage';
import { AssistantCategoryPage } from './pages/AssistantCategoryPage';
import { DockerCategoryPage } from './pages/DockerCategoryPage';
import { APIManagementPage } from './pages/APIManagementPage';
import { SQLQueryGeneratorPage } from './pages/SQLQueryGeneratorPage';
import { CodeSecurityPage } from './pages/CodeSecurityPage';
import { AimlGeneration } from './pages/AimlGeneration';
import { ModelDisplayPage } from './pages/ModelDisplayPage';
import { VersionControlPage } from './pages/VersionControlPage';
import { ProgrammingAgentPage } from './pages/ProgrammingAgentPage';
import { DockerAgentPage } from './pages/DockerAgentPage';
import { DocumentationPage } from './pages/DocumentationPage';
import { CodeGenerationDoc } from './pages/docs/CodeGenerationDoc';
import { CodeConversionDoc } from './pages/docs/CodeConversionDoc';
import { useAuth } from './hooks/useAuth';
import { ErrorBoundary } from './components/ErrorBoundary';

function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500" />
    </div>
  );
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  
  useEffect(() => {
    console.log('ProtectedRoute - Auth state:', { user, isLoading });
  }, [user, isLoading]);

  if (isLoading) {
    return <LoadingSpinner />;
  }
  
  if (!user) {
    console.log('No user found, redirecting to login');
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

export default function App() {
  useEffect(() => {
    console.log('App mounted');
  }, []);

  return (
    <ErrorBoundary fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600">Something went wrong</h1>
          <button 
            onClick={() => window.location.reload()}
            className="mt-4 px-4 py-2 bg-blue-500 text-white rounded"
          >
            Reload Application
          </button>
        </div>
      </div>
    }>
      <div className="min-h-screen bg-gray-50">
        <Suspense fallback={<LoadingSpinner />}>
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route
                path="/*"
                element={
                  <ProtectedRoute>
                    <>
                      <Header />
                      <Routes>
                        <Route path="/" element={<MainScreen />} />
                        <Route path="/generate" element={<GeneratePage />} />
                        <Route path="/convert" element={<ConvertPage />} />
                        <Route path="/analyze" element={<CodeAnalysisPage />} />
                        <Route path="/security" element={<CodeSecurityPage />} />
                        <Route path="/cloud" element={<CloudPage />} />
                        <Route path="/cicd" element={<CICDPage />} />
                        <Route path="/sql" element={<SQLPage />} />
                        <Route path="/aiml" element={<AimlGeneration />} />
                        <Route path="/prompts" element={<PromptsPage />} />
                        <Route path="/terraform-rag" element={<TerraformRAGPage />} />
                        <Route path="/addons" element={<AddonsPage />} />
                        <Route path="/addons/fullstack" element={<FullStackCategoryPage />} />
                        <Route path="/addons/blockchain" element={<BlockchainCategoryPage />} />
                        <Route path="/addons/assistant" element={<AssistantCategoryPage />} />
                        <Route path="/addons/docker" element={<DockerCategoryPage />} />
                        <Route path="/addons/api" element={<APIManagementPage />} />
                        <Route path="/addons/sql-generator" element={<SQLQueryGeneratorPage />} />
                        <Route path="/addons/models" element={<ModelDisplayPage />} />
                        <Route path="/addons/version-control" element={<VersionControlPage />} />
                        <Route path="/addons/programming-agent" element={<ProgrammingAgentPage />} />
                        <Route path="/addons/docker-agent" element={<DockerAgentPage />} />
                        <Route path="/docs" element={<DocumentationPage />} />
                        <Route path="/docs/code-generation" element={<CodeGenerationDoc />} />
                        <Route path="/docs/code-conversion" element={<CodeConversionDoc />} />
                        <Route path="*" element={<Navigate to="/" replace />} />
                      </Routes>
                    </>
                  </ProtectedRoute>
                }
              />
            </Routes>
          </BrowserRouter>
        </Suspense>
      </div>
    </ErrorBoundary>
  );
}