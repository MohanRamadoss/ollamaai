export const logger = {
  info: (message: string, ...args: any[]) => {
    console.log(`[Docker Agent] ${message}`, ...args);
  },
  error: (message: string, error: any) => {
    console.error(`[Docker Agent Error] ${message}`, error);
  },
  warn: (message: string, ...args: any[]) => {
    console.warn(`[Docker Agent Warning] ${message}`, ...args);
  },
  debug: (message: string, ...args: any[]) => {
    console.debug(`[Docker Agent Debug] ${message}`, ...args);
  }
};
