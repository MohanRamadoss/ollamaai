import { FILE_EXTENSIONS, MIME_TYPES, FILE_NAMING_PATTERNS } from '../config/constants';

export function getFileInfo(language: string, code: string) {
  const normalizedLang = language.toLowerCase();
  let extension = FILE_EXTENSIONS[normalizedLang as keyof typeof FILE_EXTENSIONS] || 'txt';
  let mimeType = MIME_TYPES[normalizedLang as keyof typeof MIME_TYPES] || 'text/plain';
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  let filename = `generated-code-${timestamp}.${extension}`;

  // Handle special cases
  switch (normalizedLang) {
    case 'terraform':
    case 'hcl':
    case 'tf':
      if (FILE_NAMING_PATTERNS.terraform.main(code)) filename = 'main.tf';
      else if (FILE_NAMING_PATTERNS.terraform.variables(code)) filename = 'variables.tf';
      else if (FILE_NAMING_PATTERNS.terraform.outputs(code)) filename = 'outputs.tf';
      else if (FILE_NAMING_PATTERNS.terraform.providers(code)) filename = 'providers.tf';
      else if (FILE_NAMING_PATTERNS.terraform.backend(code)) filename = 'backend.tf';
      else filename = `terraform-${timestamp}.tf`;
      break;

    case 'ansible':
    case 'yaml':
    case 'yml':
      if (FILE_NAMING_PATTERNS.ansible.playbook(code)) filename = `playbook-${timestamp}.yml`;
      else if (FILE_NAMING_PATTERNS.ansible.inventory(code)) filename = `inventory-${timestamp}.yml`;
      else if (FILE_NAMING_PATTERNS.ansible.vars(code)) filename = `vars-${timestamp}.yml`;
      break;

    case 'kubernetes':
      if (FILE_NAMING_PATTERNS.kubernetes.deployment(code)) filename = `deployment-${timestamp}.yaml`;
      else if (FILE_NAMING_PATTERNS.kubernetes.service(code)) filename = `service-${timestamp}.yaml`;
      else if (FILE_NAMING_PATTERNS.kubernetes.configmap(code)) filename = `configmap-${timestamp}.yaml`;
      else if (FILE_NAMING_PATTERNS.kubernetes.secret(code)) filename = `secret-${timestamp}.yaml`;
      break;

    case 'docker':
    case 'dockerfile':
      if (FILE_NAMING_PATTERNS.docker.compose(code)) filename = 'docker-compose.yml';
      else filename = 'Dockerfile';
      break;
  }

  return { extension, mimeType, filename };
}
