import type { SQLDialect } from '../types/sql';

const DIALECT_FORMATTING = {
  postgresql: {
    commentPrefix: '-- ',
    statementSeparator: ';',
    identifierQuotes: '"',
    stringQuotes: "'",
    dateFormat: "'YYYY-MM-DD'",
  },
  mysql: {
    commentPrefix: '-- ',
    statementSeparator: ';',
    identifierQuotes: '`',
    stringQuotes: "'",
    dateFormat: "'%Y-%m-%d'",
  },
  sqlite: {
    commentPrefix: '-- ',
    statementSeparator: ';',
    identifierQuotes: '"',
    stringQuotes: "'",
    dateFormat: "'YYYY-MM-DD'",
  },
  mssql: {
    commentPrefix: '-- ',
    statementSeparator: 'GO',
    identifierQuotes: '[]',
    stringQuotes: "'",
    dateFormat: "'YYYY-MM-DD'",
  },
  oracle: {
    commentPrefix: '-- ',
    statementSeparator: ';',
    identifierQuotes: '"',
    stringQuotes: "'",
    dateFormat: "'YYYY-MM-DD'",
  },
};

export function formatSQLOutput(
  query: string,
  dialect: SQLDialect,
  includeHeader = true
): string {
  const formatting = DIALECT_FORMATTING[dialect];
  const timestamp = new Date().toISOString();
  
  const header = includeHeader ? [
    `${formatting.commentPrefix}Generated ${dialectToName(dialect)} Query`,
    `${formatting.commentPrefix}Generated at: ${timestamp}`,
    `${formatting.commentPrefix}Dialect: ${dialectToName(dialect)}`,
    ''
  ].join('\n') : '';

  // Format the query
  const formattedQuery = query
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .join('\n');

  // Add statement separator if missing
  const separator = formatting.statementSeparator;
  const withSeparator = formattedQuery.trim().endsWith(separator) 
    ? formattedQuery 
    : `${formattedQuery}${separator}`;

  return `${header}${withSeparator}`;
}

export function dialectToName(dialect: SQLDialect): string {
  const names: Record<SQLDialect, string> = {
    postgresql: 'PostgreSQL',
    mysql: 'MySQL',
    sqlite: 'SQLite',
    mssql: 'SQL Server',
    oracle: 'Oracle'
  };
  return names[dialect];
}

export function formatExplanation(explanation: string): string {
  if (!explanation) return '';
  
  return explanation
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .join('\n\n');
}

export function formatOptimizations(optimizations: any): string {
  if (!optimizations) return '';

  const sections = [];

  if (optimizations.indexRecommendations?.length) {
    sections.push(
      'Index Recommendations:',
      ...optimizations.indexRecommendations.map((rec: string) => `- ${rec}`)
    );
  }

  if (optimizations.queryPlan) {
    sections.push(
      '\nQuery Plan:',
      optimizations.queryPlan
    );
  }

  if (optimizations.partitioningStrategy) {
    sections.push(
      '\nPartitioning Strategy:',
      optimizations.partitioningStrategy
    );
  }

  if (optimizations.replicationSetup) {
    sections.push(
      '\nReplication Setup:',
      optimizations.replicationSetup
    );
  }

  return sections.join('\n');
}
