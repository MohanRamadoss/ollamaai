import { useState, useCallback } from 'react';
import { generateCode, GenerationProgress } from '../lib/api/generate';
import type { GenerationRequest } from '../types/models';

export function useCodeGeneration() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [progress, setProgress] = useState<Record<string, GenerationProgress>>({});

  const generate = useCallback(async (request: GenerationRequest) => {
    setIsGenerating(true);
    setError(null);
    
    try {
      const result = await generateCode(request, (modelProgress) => {
        setProgress(modelProgress);
      });
      
      return result;
    } catch (err) {
      setError(err as Error);
      throw err;
    } finally {
      setIsGenerating(false);
    }
  }, []);

  return {
    generate,
    isGenerating,
    error,
    progress,
    modelProgress: progress
  };
}
