import type { Platform, PipelineType } from '../../types/cicd';
import type { ComplexityLevel } from '../../types/models';

export function getPipelinePrompt(
  platform: Platform,
  pipelineType: PipelineType,
  requirements: string,
  complexity: ComplexityLevel
): string {
  const platformSpecific = getPlatformSpecificPrompt(platform);
  const typeSpecific = getPipelineTypePrompt(pipelineType);
  const complexityGuidelines = getComplexityGuidelines(complexity);

  return `
Generate a CI/CD pipeline configuration for ${platform}.
Pipeline Type: ${pipelineType}
Complexity Level: ${complexity}

Requirements:
${requirements}

${platformSpecific}
${typeSpecific}
${complexityGuidelines}

The response should include:
1. Pipeline configuration code
2. Brief explanation
3. Best practices implemented
4. Security checks included
5. Automation steps

Format the response with appropriate sections using markdown headers.
`.trim();
}

function getPlatformSpecificPrompt(platform: Platform): string {
  switch (platform) {
    case 'github':
      return 'Use GitHub Actions yaml syntax. Include workflow triggers, jobs, and steps.';
    case 'gitlab':
      return 'Use GitLab CI yaml syntax. Include stages, jobs, and proper artifacts handling.';
    case 'azure-devops':
      return 'Use Azure Pipelines yaml syntax. Include proper triggers, stages, and tasks.';
    case 'jenkins':
      return 'Use Jenkinsfile syntax with proper pipeline or declarative syntax.';
    default:
      return '';
  }
}

function getPipelineTypePrompt(type: PipelineType): string {
  switch (type) {
    case 'build':
      return 'Focus on building, testing, and creating artifacts. Include proper caching and optimization strategies.';
    case 'deploy':
      return 'Focus on deployment strategies, environments, and rollback procedures. Include proper safety checks.';
    case 'test':
      return 'Focus on different types of testing (unit, integration, e2e). Include test reporting and coverage.';
    case 'monitor':
      return 'Focus on monitoring, alerting, and observability. Include metrics collection and reporting.';
    default:
      return '';
  }
}

function getComplexityGuidelines(complexity: ComplexityLevel): string {
  switch (complexity) {
    case 'basic':
      return 'Keep the pipeline simple with essential steps and minimal configuration.';
    case 'intermediate':
      return 'Include moderate optimizations, caching, and basic security checks.';
    case 'advanced':
      return 'Include advanced features like matrix builds, parallel jobs, custom actions/scripts, and comprehensive security checks.';
    default:
      return '';
  }
}
