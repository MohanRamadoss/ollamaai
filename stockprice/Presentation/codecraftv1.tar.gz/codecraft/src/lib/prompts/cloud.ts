import type { CloudProvider, ResourceType } from '../../types/cloud';
import type { ComplexityLevel } from '../../types/models';

const PROVIDER_CONTEXT: Record<CloudProvider, string> = {
  aws: `You are an AWS infrastructure expert specializing in Infrastructure as Code (IaC).
Focus on AWS best practices, well-architected framework principles, and security standards.
Consider cost optimization, reliability, performance efficiency, and operational excellence.`,
  
  azure: `You are an Azure infrastructure expert specializing in Infrastructure as Code (IaC).
Focus on Azure best practices, Well-Architected Framework, and security standards.
Consider cost optimization, reliability, resiliency, and operational excellence.`,
  
  gcp: `You are a Google Cloud Platform expert specializing in Infrastructure as Code (IaC).
Focus on GCP best practices, architectural patterns, and security standards.
Consider cost optimization, reliability, scalability, and operational excellence.`
};

const RESOURCE_TEMPLATES: Record<ResourceType, string> = {
    terraform: `Generate a complete Terraform configuration following HashiCorp best practices:
  - Use proper provider configuration and state management
  - Implement resource naming conventions and tagging standards
  - Include necessary variables, outputs, and data sources
  - Structure the code with modules when appropriate
  - Add comprehensive comments and documentation`,
  
    cloudformation: `Generate an AWS CloudFormation template following AWS best practices:
  - Use proper YAML structure with clear resource definitions
  - Include necessary Parameters, Mappings, and Outputs
  - Implement proper IAM roles and security groups
  - Add comprehensive descriptions and metadata
  - Include relevant conditions and dependencies`,
  
    azurearm: `Generate an Azure ARM template following Microsoft best practices:
  - Use proper JSON structure with schema version
  - Include parameters, variables, and outputs
  - Implement proper RBAC and security configurations
  - Add comprehensive comments and descriptions
  - Include relevant dependencies and conditions`,
  
    gcpdeployment: `Generate a Google Cloud Deployment Manager configuration:
  - Use proper YAML structure with schema version
  - Include necessary properties and references
  - Implement proper IAM and security configurations
  - Add comprehensive descriptions and metadata
  - Include relevant dependencies`,
  
    kubernetes: `Generate Kubernetes manifests following cloud-native best practices:
  - Use proper YAML structure with apiVersion and kind
  - Include necessary labels and annotations
  - Implement proper RBAC and security contexts
  - Add comprehensive comments and documentation
  - Include relevant health checks and resource limits`,
  
    serverless: `Generate serverless framework configuration:
  - Use proper YAML structure with clear function definitions
  - Include necessary IAM roles and permissions
  - Implement proper event triggers and API configurations
  - Add comprehensive documentation
  - Include relevant environment variables and dependencies`,
  
    database: `Generate database infrastructure configuration:
  - Include proper backup and recovery settings
  - Implement high availability and failover
  - Configure proper networking and security
  - Add monitoring and alerting
  - Include performance optimization settings`,
  
    storage: `Generate storage infrastructure configuration:
  - Include proper access controls and encryption
  - Implement lifecycle policies and versioning
  - Configure proper networking and security
  - Add monitoring and metrics
  - Include data protection features`,
  
    networking: `Generate networking infrastructure configuration:
  - Include proper routing and security groups
  - Implement VPC/VNET configurations
  - Configure proper access controls and encryption
  - Add monitoring and logging
  - Include traffic management features`
  };

const COMPLEXITY_GUIDELINES: Record<ComplexityLevel, string> = {
  basic: `Create a simple, straightforward configuration:
- Single region/zone deployment
- Basic security configurations
- Essential monitoring
- Standard backup/recovery
- Basic high availability`,

intermediate: `Create a moderately complex configuration:
- Multi-zone deployment
- Advanced security configurations
- Detailed monitoring and alerting
- Automated backup/recovery
- Enhanced high availability
- Cost optimization features`,

  advanced: `Create a production-grade configuration:
- Multi-region deployment
- Enterprise-grade security
- Comprehensive monitoring and observability
- Automated disaster recovery
- Full high availability
- Advanced cost optimization
- Performance optimization
- Compliance features`

};

export function getCloudPrompt(
  provider: CloudProvider,
  resourceType: ResourceType,
  requirements: string,
  complexity: ComplexityLevel
): string {
  return `${PROVIDER_CONTEXT[provider]}

${RESOURCE_TEMPLATES[resourceType]}

${COMPLEXITY_GUIDELINES[complexity]}

Specific Requirements:
${requirements}

Please provide the following in your response:

1. Infrastructure Code:
   - Complete, production-ready code
   - Well-structured and properly formatted
   - Comprehensive comments and documentation

2. Explanation:
   - Detailed overview of the architecture
   - Key design decisions and trade-offs
   - Resource interactions and dependencies
   - Cost considerations and optimization opportunities

3. Best Practices:
   - Provider-specific recommendations
   - Industry standard practices
   - Performance optimization guidelines
   - Resource management recommendations

4. Security Checks:
   - Identity and access management
   - Network security configurations
   - Data protection measures
   - Compliance considerations
   - Security monitoring and auditing

5. Automation Steps:
   - Deployment prerequisites
   - CI/CD pipeline integration
   - Testing and validation procedures
   - Monitoring and alerting setup
   - Maintenance and update procedures

Format your response with clear sections using markdown headings.`;
}

export function getSpecializedPrompt(
  provider: CloudProvider,
  resourceType: ResourceType,
  requirements: string
): string {
  switch (resourceType) {
    case 'kubernetes':
      return getKubernetesPrompt(provider, requirements);
    case 'serverless':
      return getServerlessPrompt(provider, requirements);
    default:
      return '';
  }
}

/// For specific resource types, we can have additional specialized prompts
export function getKubernetesPrompt(provider: CloudProvider, requirements: string): string {
    const providerSpecific = {
      aws: 'EKS-specific configurations and AWS integrations',
      azure: 'AKS-specific configurations and Azure integrations',
      gcp: 'GKE-specific configurations and GCP integrations'
    };
  
    return `${PROVIDER_CONTEXT[provider]}
  Focus on ${providerSpecific[provider]}.
  
  Requirements:
  ${requirements}
  
  Please provide Kubernetes manifests with:
  - Deployment/StatefulSet configurations
  - Service and Ingress resources
  - ConfigMaps and Secrets
  - RBAC configurations
  - Resource quotas and limits
  - Network policies
  - Service mesh integration (if applicable)
  - Monitoring and logging configurations`;
  }
  
  export function getServerlessPrompt(provider: CloudProvider, requirements: string): string {
    const providerSpecific = {
      aws: 'AWS Lambda and API Gateway configurations',
      azure: 'Azure Functions and API Management configurations',
      gcp: 'Cloud Functions and Cloud Run configurations'
    };
  
    return `${PROVIDER_CONTEXT[provider]}
  Focus on ${providerSpecific[provider]}.
  
  Requirements:
  ${requirements}
  
  Please provide serverless configuration with:
  - Function definitions and triggers
  - API endpoint configurations
  - Authentication and authorization
  - Environment variables
  - Resource permissions
  - Monitoring and logging
  - Performance optimization
  - Cost optimization strategies`;
  }