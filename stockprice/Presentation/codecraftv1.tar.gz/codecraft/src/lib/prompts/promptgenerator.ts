import type { PromptTemplate, PromptCategory, ComplexityLevel, ProgrammingLanguage } from '../../types/prompt';
import type { PromptTemplate, PromptCategory, ComplexityLevel, ProgrammingLanguage } from '../../types/prompt';

const LANGUAGE_SPECIFIC_TEMPLATES: Record<string, string> = {
  'ansible': `
- Playbook organization and structure
- Role definitions and dependencies
- Variable management and precedence
- Host inventory requirements
- Handler configurations
- Module selection criteria
- Idempotency requirements
- Security best practices`,

  'terraform': `
- Provider configuration
- Resource organization
- State management
- Module structure
- Variable handling
- Output definitions
- Backend configuration
- Security considerations`,

  'kubernetes': `
- Resource definitions
- Namespace organization
- Service configurations
- Volume management
- Security contexts
- Network policies
- Resource limits
- Health checks`,

  // Add more languages as needed...
};

const COMPLEXITY_GUIDELINES: Record<ComplexityLevel, string> = {
  'basic': 'Focus on core functionality with straightforward implementation. Include essential error handling and basic security measures.',
  'intermediate': 'Include moderate complexity with proper abstraction, reusability, and comprehensive error handling. Consider scalability and performance optimization.',
  'advanced': 'Implement sophisticated features with advanced error handling, extensive security measures, high scalability, and complex system interactions.'
};

function generatePromptStructure(
  category: PromptCategory,
  task: string,
  language: string,
  complexity: ComplexityLevel,
  variables: string[]
): string {
  const languageSpecific = LANGUAGE_SPECIFIC_TEMPLATES[language.toLowerCase()] || 
    'Specify language-specific requirements and best practices';
  const complexityGuide = COMPLEXITY_GUIDELINES[complexity];

  return `
TASK OBJECTIVE:
Generate a detailed requirements specification for: ${task}

TECHNICAL CONTEXT:
${languageSpecific}

COMPLEXITY LEVEL (${complexity}):
${complexityGuide}

REQUIREMENTS SPECIFICATION:
1. Infrastructure Requirements:
   - Target environment specifications
   - Dependencies and prerequisites
   - Resource requirements

2. Implementation Requirements:
   - Core functionality specifications
   - Component interactions
   - Configuration management approach
   - Security considerations

3. Quality Requirements:
   - Performance expectations
   - Scalability considerations
   - Monitoring and logging requirements
   - Error handling and recovery procedures

4. Deployment Requirements:
   - Installation steps
   - Configuration requirements
   - Validation checks
   - Rollback procedures

${variables.length > 0 ? '\nDYNAMIC VARIABLES:\n' + variables.map(v => `- ${v}`).join('\n') : ''}

Expected Deliverables:
1. Detailed implementation plan
2. Configuration specifications
3. Testing requirements
4. Documentation requirements

Note: Focus on creating a prompt that will generate high-quality ${language} code, not the code itself.`;
}

export function getPromptTemplate(template: PromptTemplate): string {
  // Extract variables for the template
  const variableList = template.variables.map(v => 
    `${v.name}${v.required ? ' (Required)' : ''}: ${v.description}`
  );

  return generatePromptStructure(
    template.category,
    template.description,
    template.language || 'general',
    template.complexity || 'intermediate',
    variableList
  );
}

export function generatePromptVariables(
  category: PromptCategory,
  language?: ProgrammingLanguage,
  complexity?: ComplexityLevel
): Record<string, string> {
  const variables: Record<string, string> = {};
  
  if (language) {
    variables.language = language;
  }
  
  if (complexity) {
    variables.complexity = complexity;
  }
  
  return variables;
}

const CATEGORY_TEMPLATES: Record<PromptCategory, string> = {
  code: `Create a detailed prompt for generating {language} code with {complexity} complexity level.

Context:
{template}

The prompt should guide the AI to:
1. Understand the specific use case and requirements
2. Follow {language} best practices and conventions
3. Consider proper error handling and edge cases
4. Implement security measures where applicable
5. Include appropriate documentation
6. Consider scalability and maintainability

Key Areas to Address:
- Implementation approach
- Code structure and organization
- Error handling patterns
- Testing considerations
- Documentation requirements
- Performance considerations

Required Variables:
{variables}

Note: This should generate a prompt that will help create high-quality {language} code, not the code itself.`,

  conversion: `Create a prompt for converting code between languages:

Source Language: {sourceLanguage}
Target Language: {targetLanguage}

Context:
{template}

The prompt should guide the translation process focusing on:
1. Maintaining functionality and behavior
2. Utilizing idiomatic patterns in the target language
3. Handling language-specific differences
4. Preserving performance characteristics
5. Maintaining code readability

Consider:
- Language-specific features and limitations
- Standard library differences
- Error handling approaches
- Testing requirements
- Documentation needs

Required Variables:
{variables}`,

  documentation: `Create a prompt for generating comprehensive documentation:

Language: {language}
Context: {template}

The prompt should guide documentation generation covering:
1. Overview and purpose
2. API specifications
3. Usage examples
4. Implementation details
5. Error scenarios
6. Testing guidelines

Focus Areas:
- Technical accuracy
- Clarity and completeness
- Code examples
- Troubleshooting guides
- Integration guidelines

Required Variables:
{variables}`,

  testing: `Generate test cases for the following {language} code:
{code}

Include tests for:
- Unit tests
- Integration tests
- Infrastructure tests (if applicable)
- Security tests
- Performance tests
- Error handling`,

  optimization: `Optimize the following {language} code:
{code}

Focus on:
- Performance
- Resource usage
- Security
- Maintainability
- Infrastructure efficiency
- Cost optimization`,

  custom: '{template}',
};

export function getPromptTemplate(template: PromptTemplate): string {
  const baseTemplate = CATEGORY_TEMPLATES[template.category];
  
  // Format variables section
  const variablesList = template.variables
    .map(v => `- ${v.name}${v.required ? ' (Required)' : ''}: ${v.description}`)
    .join('\n');

  // Replace template variables
  return baseTemplate
    .replace('{template}', template.template)
    .replace('{language}', template.language || '')
    .replace('{complexity}', template.complexity || '')
    .replace('{variables}', variablesList);
}

export function generatePromptVariables(
  category: PromptCategory,
  language?: ProgrammingLanguage,
  complexity?: ComplexityLevel
): Record<string, string> {
  const variables: Record<string, string> = {};
  
  if (language) {
    variables.language = language;
  }
  
  if (complexity) {
    variables.complexity = complexity;
  }
  
  return variables;
}
