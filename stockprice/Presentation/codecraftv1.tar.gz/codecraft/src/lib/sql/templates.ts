import type { SQLDialect } from '../../types/sql';

export const DASHBOARD_TEMPLATES = {
  postgresql: {
    rollingAverage: `
WITH daily_sales AS (
  SELECT 
    sale_date,
    SUM(amount) as daily_total
  FROM sales
  GROUP BY sale_date
),
rolling_averages AS (
  SELECT 
    sale_date,
    daily_total,
    AVG(daily_total) OVER (
      ORDER BY sale_date 
      ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) as seven_day_avg
  FROM daily_sales
),
year_over_year AS (
  SELECT 
    curr.sale_date,
    curr.daily_total as current_year,
    prev.daily_total as previous_year,
    CASE 
      WHEN prev.daily_total > 0 
      THEN ((curr.daily_total - prev.daily_total) / prev.daily_total * 100)
      ELSE 0 
    END as yoy_change
  FROM daily_sales curr
  LEFT JOIN daily_sales prev ON 
    prev.sale_date = curr.sale_date - INTERVAL '1 year'
)`,
    
    salesDashboard: `
WITH daily_sales AS (
  SELECT 
    s.sale_date,
    p.category,
    s.region,
    SUM(s.amount) as total_sales,
    COUNT(*) as transaction_count
  FROM sales s
  JOIN products p ON p.id = s.product_id
  WHERE s.sale_date >= CURRENT_DATE - INTERVAL '1 year'
  GROUP BY s.sale_date, p.category, s.region
),
rolling_metrics AS (
  SELECT 
    sale_date,
    category,
    region,
    total_sales,
    transaction_count,
    AVG(total_sales) OVER (
      PARTITION BY category, region 
      ORDER BY sale_date 
      ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) as seven_day_avg_sales,
    AVG(transaction_count) OVER (
      PARTITION BY category, region 
      ORDER BY sale_date 
      ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) as seven_day_avg_transactions
  FROM daily_sales
),
year_over_year AS (
  SELECT 
    curr.sale_date,
    curr.category,
    curr.region,
    curr.total_sales as current_sales,
    prev.total_sales as previous_year_sales,
    CASE 
      WHEN prev.total_sales > 0 
      THEN ((curr.total_sales - prev.total_sales) / prev.total_sales * 100)
      ELSE 0 
    END as yoy_growth
  FROM daily_sales curr
  LEFT JOIN daily_sales prev ON 
    prev.sale_date = curr.sale_date - INTERVAL '1 year'
    AND prev.category = curr.category
    AND prev.region = curr.region
)
SELECT 
  rm.sale_date,
  rm.category,
  rm.region,
  rm.total_sales,
  rm.seven_day_avg_sales,
  rm.transaction_count,
  rm.seven_day_avg_transactions,
  yoy.previous_year_sales,
  yoy.yoy_growth
FROM rolling_metrics rm
JOIN year_over_year yoy ON 
  yoy.sale_date = rm.sale_date 
  AND yoy.category = rm.category
  AND yoy.region = rm.region
ORDER BY rm.sale_date DESC, rm.category, rm.region;`
  },
  
  mysql: {
    rollingAverage: `
WITH daily_sales AS (
  SELECT 
    sale_date,
    SUM(amount) as daily_total
  FROM sales
  GROUP BY sale_date
),
rolling_averages AS (
  SELECT 
    sale_date,
    daily_total,
    AVG(daily_total) OVER (
      ORDER BY sale_date 
      ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) as seven_day_avg
  FROM daily_sales
),
year_over_year AS (
  SELECT 
    curr.sale_date,
    curr.daily_total as current_year,
    prev.daily_total as previous_year,
    CASE 
      WHEN prev.daily_total > 0 
      THEN ((curr.daily_total - prev.daily_total) / prev.daily_total * 100)
      ELSE 0 
    END as yoy_change
  FROM daily_sales curr
  LEFT JOIN daily_sales prev ON 
    prev.sale_date = DATE_SUB(curr.sale_date, INTERVAL 1 YEAR)
)
SELECT 
  ra.sale_date,
  ra.daily_total as current_sales,
  ra.seven_day_avg,
  yoy.previous_year as last_year_sales,
  yoy.yoy_change as year_over_year_change
FROM rolling_averages ra
JOIN year_over_year yoy ON yoy.sale_date = ra.sale_date
ORDER BY ra.sale_date DESC;`
  }
};

export const MSSQL_TEMPLATES = {
  partitioning: {
    setup: `
-- Create partition function
CREATE PARTITION FUNCTION [PF_SalesDate] (datetime2)
AS RANGE RIGHT FOR VALUES (
    @startDate,  -- Historical partition
    @currentDate, -- Current partition
    @futureDate   -- Future partition
);

-- Create partition scheme
CREATE PARTITION SCHEME [PS_SalesDate]
AS PARTITION [PF_SalesDate] 
TO (
    [ArchiveFileGroup],  -- Historical data
    [PrimaryFileGroup],  -- Current data
    [FutureFileGroup]    -- Future data
);

-- Create partitioned table
CREATE TABLE [dbo].[Sales] (
    SaleID bigint IDENTITY(1,1) NOT NULL,
    OrderDate datetime2 NOT NULL,
    CustomerID int NOT NULL,
    Amount decimal(18,2) NOT NULL,
    -- Add other columns as needed
    CONSTRAINT PK_Sales PRIMARY KEY CLUSTERED (
        OrderDate ASC,
        SaleID ASC
    )
) ON PS_SalesDate(OrderDate);

-- Create archive table with same structure
CREATE TABLE [dbo].[Sales_Archive] (
    SaleID bigint NOT NULL,
    OrderDate datetime2 NOT NULL,
    CustomerID int NOT NULL,
    Amount decimal(18,2) NOT NULL,
    -- Add other columns as needed
    CONSTRAINT PK_Sales_Archive PRIMARY KEY CLUSTERED (
        OrderDate ASC,
        SaleID ASC
    )
);

-- Create archival stored procedure
CREATE PROCEDURE [dbo].[SP_ArchiveSales]
    @cutoffDate datetime2
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRANSACTION;
    
    -- Move data to archive
    INSERT INTO [dbo].[Sales_Archive] (
        SaleID, OrderDate, CustomerID, Amount
    )
    SELECT 
        SaleID, OrderDate, CustomerID, Amount
    FROM [dbo].[Sales]
    WHERE OrderDate < @cutoffDate;
    
    -- Delete archived data from main table
    DELETE FROM [dbo].[Sales]
    WHERE OrderDate < @cutoffDate;
    
    -- Merge empty partitions if needed
    ALTER PARTITION FUNCTION PF_SalesDate()
    MERGE RANGE (@cutoffDate);
    
    COMMIT TRANSACTION;
END;
`,
    maintenance: `
-- Create partition maintenance procedure
CREATE PROCEDURE [dbo].[SP_MaintainSalesPartitions]
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @futureDate datetime2 = DATEADD(MONTH, 3, GETDATE());
    
    -- Add new partition for future data
    ALTER PARTITION SCHEME [PS_SalesDate] 
    NEXT USED [FutureFileGroup];
    
    ALTER PARTITION FUNCTION [PF_SalesDate]()
    SPLIT RANGE (@futureDate);
    
    -- Archive old data
    DECLARE @archiveDate datetime2 = DATEADD(YEAR, -1, GETDATE());
    EXEC [dbo].[SP_ArchiveSales] @cutoffDate = @archiveDate;
END;
`,
    monitoring: `
-- Create partition monitoring view
CREATE VIEW [dbo].[VW_PartitionStats]
AS
SELECT 
    p.partition_number,
    OBJECT_SCHEMA_NAME(p.object_id) AS schema_name,
    OBJECT_NAME(p.object_id) AS table_name,
    ps.name AS partition_scheme,
    pf.name AS partition_function,
    r.boundary_id,
    r.value AS boundary_value,
    p.rows AS row_count,
    a.total_pages * 8 AS total_size_kb
FROM sys.partitions p
INNER JOIN sys.allocation_units a 
    ON p.hobt_id = a.container_id
INNER JOIN sys.indexes i 
    ON p.object_id = i.object_id 
    AND p.index_id = i.index_id
INNER JOIN sys.partition_schemes ps 
    ON i.data_space_id = ps.data_space_id
INNER JOIN sys.partition_functions pf 
    ON ps.function_id = pf.function_id
LEFT JOIN sys.partition_range_values r 
    ON pf.function_id = r.function_id 
    AND r.boundary_id = p.partition_number - 1
WHERE i.type_desc = 'CLUSTERED';
`
  }
};

export const POSTGRESQL_TEMPLATES = {
  partitioning: {
    setup: `
-- Create parent partitioned table
CREATE TABLE sales (
    sale_id BIGINT NOT NULL,
    sale_date TIMESTAMP NOT NULL,
    customer_id INTEGER NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    CONSTRAINT pk_sales PRIMARY KEY (sale_id, sale_date)
) PARTITION BY RANGE (sale_date);

-- Create partitions
CREATE TABLE sales_current PARTITION OF sales
    FOR VALUES FROM (CURRENT_DATE - INTERVAL '1 year') TO (CURRENT_DATE + INTERVAL '1 month');

CREATE TABLE sales_archive PARTITION OF sales
    FOR VALUES FROM (MINVALUE) TO (CURRENT_DATE - INTERVAL '1 year');

CREATE TABLE sales_future PARTITION OF sales
    FOR VALUES FROM (CURRENT_DATE + INTERVAL '1 month') TO (MAXVALUE);

-- Create indexes on each partition
CREATE INDEX idx_sales_current_date ON sales_current (sale_date);
CREATE INDEX idx_sales_archive_date ON sales_archive (sale_date);
CREATE INDEX idx_sales_future_date ON sales_future (sale_date);`,

    maintenance: `
-- Create partition maintenance function
CREATE OR REPLACE FUNCTION maintain_sales_partitions()
RETURNS void AS $$
DECLARE
    next_partition_date DATE;
    partition_name TEXT;
BEGIN
    -- Calculate next partition date
    next_partition_date := DATE_TRUNC('month', CURRENT_DATE + INTERVAL '2 months');
    partition_name := 'sales_' || TO_CHAR(next_partition_date, 'YYYY_MM');
    
    -- Create new partition if it doesn't exist
    EXECUTE format('
        CREATE TABLE IF NOT EXISTS %I PARTITION OF sales
        FOR VALUES FROM (%L) TO (%L)',
        partition_name,
        next_partition_date,
        next_partition_date + INTERVAL '1 month'
    );
    
    -- Create index on new partition
    EXECUTE format('
        CREATE INDEX IF NOT EXISTS idx_%s_date ON %I (sale_date)',
        partition_name,
        partition_name
    );
END;
$$ LANGUAGE plpgsql;`,

    monitoring: `
-- Create partition monitoring view
CREATE OR REPLACE VIEW vw_partition_stats AS
SELECT
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname || '.' || tablename)) as total_size,
    pg_total_relation_size(schemaname || '.' || tablename) as raw_size,
    n_live_tup as row_count,
    n_dead_tup as dead_rows,
    last_vacuum,
    last_autovacuum
FROM pg_stat_user_tables
WHERE tablename LIKE 'sales%'
ORDER BY raw_size DESC;`
  }
};

export const MYSQL_TEMPLATES = {
  partitioning: {
    setup: `
-- Create partitioned table
CREATE TABLE sales (
    sale_id BIGINT NOT NULL AUTO_INCREMENT,
    sale_date TIMESTAMP NOT NULL,
    customer_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (sale_id, sale_date)
)
PARTITION BY RANGE (UNIX_TIMESTAMP(sale_date)) (
    PARTITION p_archive VALUES LESS THAN (UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, INTERVAL 1 YEAR))),
    PARTITION p_current VALUES LESS THAN (UNIX_TIMESTAMP(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH))),
    PARTITION p_future VALUES LESS THAN MAXVALUE
);

-- Create archive table
CREATE TABLE sales_archive (
    sale_id BIGINT NOT NULL,
    sale_date TIMESTAMP NOT NULL,
    customer_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sale_id, sale_date)
);`,

    maintenance: `
DELIMITER //

CREATE PROCEDURE maintain_sales_partitions()
BEGIN
    DECLARE next_partition_timestamp BIGINT;
    DECLARE partition_name VARCHAR(32);
    
    -- Calculate next partition boundary
    SET next_partition_timestamp = UNIX_TIMESTAMP(
        DATE_ADD(CURRENT_DATE, INTERVAL 2 MONTH)
    );
    
    SET partition_name = CONCAT('p_', DATE_FORMAT(
        FROM_UNIXTIME(next_partition_timestamp),
        '%Y_%m'
    ));
    
    -- Add new partition
    SET @sql = CONCAT(
        'ALTER TABLE sales REORGANIZE PARTITION p_future INTO (',
        'PARTITION ', partition_name, 
        ' VALUES LESS THAN (', next_partition_timestamp, '),',
        'PARTITION p_future VALUES LESS THAN MAXVALUE)'
    );
    
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    -- Archive old data
    INSERT INTO sales_archive
    SELECT *, CURRENT_TIMESTAMP
    FROM sales
    WHERE sale_date < DATE_SUB(CURRENT_DATE, INTERVAL 1 YEAR);
    
    -- Delete archived data
    DELETE FROM sales
    WHERE sale_date < DATE_SUB(CURRENT_DATE, INTERVAL 1 YEAR);
END //

DELIMITER ;`,

    monitoring: `
-- Create partition monitoring view
CREATE OR REPLACE VIEW vw_partition_stats AS
SELECT 
    TABLE_SCHEMA,
    TABLE_NAME,
    PARTITION_NAME,
    PARTITION_ORDINAL_POSITION,
    PARTITION_METHOD,
    PARTITION_EXPRESSION,
    TABLE_ROWS,
    AVG_ROW_LENGTH,
    DATA_LENGTH,
    INDEX_LENGTH,
    MAX_VALUE
FROM information_schema.PARTITIONS
WHERE TABLE_NAME = 'sales';`
  }
};

export const ORACLE_TEMPLATES = {
  partitioning: {
    setup: `
-- Create tablespace for each partition
CREATE TABLESPACE sales_current
DATAFILE 'sales_current.dbf' SIZE 1G AUTOEXTEND ON;

CREATE TABLESPACE sales_archive
DATAFILE 'sales_archive.dbf' SIZE 2G AUTOEXTEND ON;

-- Create partitioned table
CREATE TABLE sales (
    sale_id NUMBER(19) NOT NULL,
    sale_date DATE NOT NULL,
    customer_id NUMBER(10) NOT NULL,
    amount NUMBER(12,2) NOT NULL,
    CONSTRAINT pk_sales PRIMARY KEY (sale_id, sale_date)
)
PARTITION BY RANGE (sale_date)
(
    PARTITION sales_archive VALUES LESS THAN (ADD_MONTHS(TRUNC(SYSDATE, 'YEAR'), -12))
        TABLESPACE sales_archive,
    PARTITION sales_current VALUES LESS THAN (ADD_MONTHS(TRUNC(SYSDATE, 'MONTH'), 1))
        TABLESPACE sales_current,
    PARTITION sales_future VALUES LESS THAN (MAXVALUE)
        TABLESPACE sales_current
);

-- Create local indexes
CREATE INDEX idx_sales_date
    ON sales (sale_date) LOCAL;`,

    maintenance: `
CREATE OR REPLACE PROCEDURE maintain_sales_partitions
IS
    v_next_partition_date DATE;
    v_partition_name VARCHAR2(30);
    v_sql VARCHAR2(4000);
BEGIN
    -- Calculate next partition date
    v_next_partition_date := ADD_MONTHS(TRUNC(SYSDATE, 'MONTH'), 2);
    v_partition_name := 'SALES_' || TO_CHAR(v_next_partition_date, 'YYYYMM');
    
    -- Create new partition
    v_sql := 'ALTER TABLE sales SPLIT PARTITION sales_future AT (' ||
             'TO_DATE(''' || TO_CHAR(v_next_partition_date, 'YYYY-MM-DD') || ''', ''YYYY-MM-DD'')) ' ||
             'INTO (PARTITION ' || v_partition_name || ', PARTITION sales_future)';
             
    EXECUTE IMMEDIATE v_sql;
    
    -- Move old data to archive partition
    v_sql := 'ALTER TABLE sales MERGE PARTITIONS ' ||
             'sales_archive, sales_' || TO_CHAR(ADD_MONTHS(SYSDATE, -13), 'YYYYMM') ||
             ' INTO PARTITION sales_archive';
             
    EXECUTE IMMEDIATE v_sql;
    
    -- Rebuild indexes
    EXECUTE IMMEDIATE 'ALTER INDEX idx_sales_date REBUILD PARTITION sales_archive';
END;
/`,

    monitoring: `
-- Create partition monitoring view
CREATE OR REPLACE VIEW vw_partition_stats AS
SELECT
    p.table_owner,
    p.table_name,
    p.partition_name,
    p.high_value,
    p.partition_position,
    s.num_rows,
    s.blocks,
    s.avg_row_len,
    s.last_analyzed
FROM all_tab_partitions p
JOIN all_tab_statistics s ON 
    p.table_owner = s.owner AND
    p.table_name = s.table_name AND
    p.partition_name = s.partition_name
WHERE p.table_name = 'SALES'
ORDER BY p.partition_position;`
  }
};

// Add new function to get specific dialect templates
export function getDialectTemplate(
  dialect: SQLDialect,
  templateType: 'partitioning' | 'maintenance' | 'monitoring'
): string {
  const templates = {
    postgresql: POSTGRESQL_TEMPLATES,
    mysql: MYSQL_TEMPLATES,
    mssql: MSSQL_TEMPLATES,
    oracle: ORACLE_TEMPLATES,
    sqlite: null
  };

  return templates[dialect]?.[templateType] || '';
}

export function getDashboardTemplate(dialect: SQLDialect): string {
  return DASHBOARD_TEMPLATES[dialect]?.salesDashboard || DASHBOARD_TEMPLATES.postgresql.salesDashboard;
}

export function getMSSQLTemplate(templateType: 'partitioning' | 'maintenance' | 'monitoring'): string {
    return MSSQL_TEMPLATES[templateType];
}
