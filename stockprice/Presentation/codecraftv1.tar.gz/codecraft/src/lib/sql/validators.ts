import type { SQLDialect } from '../../types/sql';

const POSTGRESQL_PATTERNS = {
  syntaxPatterns: [
    /WITH\s+[\w\s]+\s+AS\s*\(/i,           // CTEs
    /SELECT\s+[\s\S]+?FROM\s+[\w\s,]+/i,    // Basic SELECT
    /OVER\s*\([^)]*\)/i,                    // Window functions
    /CREATE\s+(?:TABLE|VIEW|INDEX)/i,       // CREATE statements
    /ALTER\s+TABLE/i,                       // ALTER statements
    /INSERT\s+INTO/i,                       // INSERT statements
    /UPDATE\s+[\w\s]+\s+SET/i,             // UPDATE statements
    /DELETE\s+FROM/i                        // DELETE statements
  ],
  specificFeatures: [
    /::/,                                   // Type casting
    /\$\d+/,                                // Parameter references
    /INTO\s+STRICT/i,                       // STRICT keyword
    /RETURNING/i,                           // RETURNING clause
    /USING/i,                               // USING clause
    /LATERAL/i,                             // LATERAL joins
    /ORDINALITY/i,                          // WITH ORDINALITY
    /PARTITION\s+BY/i                       // PARTITION BY
  ],
  aggregateFunctions: [
    /array_agg/i,
    /string_agg/i,
    /json_agg/i,
    /jsonb_agg/i,
    /json_object_agg/i,
    /jsonb_object_agg/i
  ]
};

const ORACLE_PATTERNS = {
  syntaxPatterns: [
    /SELECT\s+[\s\S]+?\s+FROM/i,           // Basic SELECT
    /WITH\s+[\w\s]+\s+AS\s*\(/i,           // CTEs
    /MERGE\s+INTO/i,                       // MERGE statements
    /CREATE\s+(?:TABLE|VIEW|INDEX)/i,      // CREATE statements
    /ALTER\s+(?:TABLE|VIEW|INDEX)/i,       // ALTER statements
    /DECLARE\s+[\w\s;]+BEGIN/i,            // PL/SQL blocks
    /CREATE\s+(?:PROCEDURE|FUNCTION|TRIGGER)/i // Database objects
  ],
  specificFeatures: [
    /CONNECT\s+BY/i,                       // Hierarchical queries
    /START\s+WITH/i,                       // Hierarchical queries start
    /PRIOR\s+\w+/i,                        // PRIOR operator
    /NOCYCLE/i,                            // NOCYCLE keyword
    /(:[\w\d]+)/,                          // Bind variables
    /LEVEL/i,                              // LEVEL pseudocolumn
    /ROWID/i,                              // ROWID pseudocolumn
    /ROWNUM/i                              // ROWNUM pseudocolumn
  ],
  plsqlFeatures: [
    /EXCEPTION\s+WHEN/i,                   // Exception handling
    /RAISE\s+\w+/i,                        // Exception raising
    /<<\w+>>/i,                           // Labels
    /BULK\s+COLLECT/i,                     // Bulk operations
    /FORALL/i                              // FORALL statement
  ]
};

const MYSQL_PATTERNS = {
  syntaxPatterns: [
    /SELECT\s+[\s\S]+?\s+FROM/i,           // Basic SELECT
    /INSERT\s+INTO/i,                      // INSERT statements
    /CREATE\s+(?:TABLE|VIEW|INDEX)/i,      // CREATE statements
    /ALTER\s+TABLE/i,                      // ALTER statements
    /UPDATE\s+[\w\s]+\s+SET/i,            // UPDATE statements
    /DELETE\s+FROM/i                       // DELETE statements
  ],
  specificFeatures: [
    /`[^`]+`/,                            // Backtick identifiers
    /LIMIT\s+\d+(?:\s*,\s*\d+)?/i,        // LIMIT clause
    /ENGINE\s*=\s*\w+/i,                   // Storage engine
    /ON\s+DUPLICATE\s+KEY\s+UPDATE/i,      // Duplicate key handling
    /STRAIGHT_JOIN/i,                      // STRAIGHT_JOIN hint
    /HIGH_PRIORITY|LOW_PRIORITY/i          // Priority hints
  ],
  functions: [
    /GROUP_CONCAT/i,                       // GROUP_CONCAT function
    /JSON_\w+/i,                          // JSON functions
    /DATE_FORMAT/i,                        // Date formatting
    /INTERVAL\s+\d+\s+\w+/i               // Interval syntax
  ]
};

const SQLITE_PATTERNS = {
  syntaxPatterns: [
    /SELECT\s+[\s\S]+?\s+FROM/i,           // Basic SELECT
    /CREATE\s+(?:TABLE|VIEW|INDEX)/i,      // CREATE statements
    /ALTER\s+TABLE/i,                      // ALTER statements
    /PRAGMA\s+\w+/i,                       // PRAGMA statements
    /ATTACH\s+DATABASE/i,                  // ATTACH DATABASE
    /DETACH\s+DATABASE/i                   // DETACH DATABASE
  ],
  specificFeatures: [
    /WITHOUT\s+ROWID/i,                    // WITHOUT ROWID tables
    /ON\s+CONFLICT/i,                      // Conflict resolution
    /RAISE\s*\(/i,                         // RAISE function
    /changes\(\)/i,                        // changes() function
    /last_insert_rowid\(\)/i              // last_insert_rowid()
  ],
  functions: [
    /date\(\s*'[^']+'\s*\)/i,             // Date function
    /time\(\s*'[^']+'\s*\)/i,             // Time function
    /datetime\(\s*'[^']+'\s*\)/i,         // DateTime function
    /random\(\)/i                          // Random function
  ]
};

export function isValidPostgreSQLQuery(query: string): boolean {
  if (!query || typeof query !== 'string') return false;

  // Check for basic SQL structure
  const hasSQLStructure = POSTGRESQL_PATTERNS.syntaxPatterns.some(pattern => 
    pattern.test(query)
  );

  if (!hasSQLStructure) return false;

  // Check for PostgreSQL-specific features
  const hasPostgreSQLFeatures = POSTGRESQL_PATTERNS.specificFeatures.some(pattern => 
    pattern.test(query)
  );

  // Check for invalid syntax patterns
  const hasInvalidSyntax = [
    /GO\s*$/mi,                            // SQL Server batch separator
    /DECLARE\s+@/i,                        // SQL Server variable declaration
    /`[^`]+`/,                            // MySQL backtick identifiers
    /\[\w+\]/                             // SQL Server bracket identifiers
  ].some(pattern => pattern.test(query));

  if (hasInvalidSyntax) return false;

  // Valid if it has basic SQL structure and either PostgreSQL features or aggregates
  return hasSQLStructure && (
    hasPostgreSQLFeatures || 
    POSTGRESQL_PATTERNS.aggregateFunctions.some(pattern => pattern.test(query))
  );
}

export function isValidOracleQuery(query: string): boolean {
  if (!query || typeof query !== 'string') return false;

  const hasSQLStructure = ORACLE_PATTERNS.syntaxPatterns.some(pattern => 
    pattern.test(query)
  );

  if (!hasSQLStructure) return false;

  const hasOracleFeatures = ORACLE_PATTERNS.specificFeatures.some(pattern => 
    pattern.test(query)
  );

  const hasPlSQLFeatures = ORACLE_PATTERNS.plsqlFeatures.some(pattern => 
    pattern.test(query)
  );

  // Check for invalid syntax patterns
  const hasInvalidSyntax = [
    /`[^`]+`/,                            // MySQL backticks
    /\[\w+\]/,                            // SQL Server brackets
    /\$\d+/,                              // PostgreSQL parameters
    /GO\s*$/mi                            // SQL Server batch separator
  ].some(pattern => pattern.test(query));

  if (hasInvalidSyntax) return false;

  return hasSQLStructure && (hasOracleFeatures || hasPlSQLFeatures);
}

export function isValidMySQLQuery(query: string): boolean {
  if (!query || typeof query !== 'string') return false;

  const hasSQLStructure = MYSQL_PATTERNS.syntaxPatterns.some(pattern => 
    pattern.test(query)
  );

  if (!hasSQLStructure) return false;

  const hasMySQLFeatures = MYSQL_PATTERNS.specificFeatures.some(pattern => 
    pattern.test(query)
  );

  const hasMySQLFunctions = MYSQL_PATTERNS.functions.some(pattern => 
    pattern.test(query)
  );

  // Check for invalid syntax patterns
  const hasInvalidSyntax = [
    /::\w+/,                              // PostgreSQL type cast
    /\[\w+\]/,                            // SQL Server brackets
    /CONNECT\s+BY/i,                      // Oracle hierarchical queries
    /BEGIN\s+TRANSACTION/i                // SQL Server transaction syntax
  ].some(pattern => pattern.test(query));

  if (hasInvalidSyntax) return false;

  return hasSQLStructure && (hasMySQLFeatures || hasMySQLFunctions);
}

export function isValidSQLiteQuery(query: string): boolean {
  if (!query || typeof query !== 'string') return false;

  const hasSQLStructure = SQLITE_PATTERNS.syntaxPatterns.some(pattern => 
    pattern.test(query)
  );

  if (!hasSQLStructure) return false;

  const hasSQLiteFeatures = SQLITE_PATTERNS.specificFeatures.some(pattern => 
    pattern.test(query)
  );

  const hasSQLiteFunctions = SQLITE_PATTERNS.functions.some(pattern => 
    pattern.test(query)
  );

  // Check for invalid syntax patterns
  const hasInvalidSyntax = [
    /DECLARE\s+@/i,                        // SQL Server variables
    /BEGIN\s+TRANSACTION/i,               // SQL Server transactions
    /CONNECT\s+BY/i,                      // Oracle hierarchical queries
    /MERGE\s+INTO/i                       // Oracle MERGE syntax
  ].some(pattern => pattern.test(query));

  if (hasInvalidSyntax) return false;

  return hasSQLStructure && (hasSQLiteFeatures || hasSQLiteFunctions);
}
