import type { SQLDialect } from '../../types/sql';

export const DIALECT_OPTIMIZERS = {
  postgresql: {
    rewriteQuery: (query: string) => {
      // PostgreSQL specific optimizations
      return query
        .replace(/SELECT \*/g, 'SELECT /* +PARALLEL(4) */')
        .replace(/ORDER BY/g, 'ORDER BY /* +INDEX_DESC */');
    },
    hints: [
      'PARALLEL',
      'MATERIALIZE',
      'MERGE',
      'INDEX_SCAN',
      'SEQSCAN'
    ]
  },
  mysql: {
    rewriteQuery: (query: string) => {
      // MySQL specific optimizations
      return query
        .replace(/SELECT/g, 'SELECT SQL_CALC_FOUND_ROWS')
        .replace(/JOIN/g, 'STRAIGHT_JOIN');
    },
    hints: [
      'BKA',
      'NO_BKA',
      'NO_ICP',
      'NO_MRR',
      'SEMIJOIN'
    ]
  },
  oracle: {
    rewriteQuery: (query: string) => {
      // Oracle specific optimizations
      return query
        .replace(/SELECT/g, 'SELECT /*+ PARALLEL(4) */')
        .replace(/JOIN/g, '/*+ USE_NL */ JOIN');
    },
    hints: [
      'PARALLEL',
      'USE_NL',
      'FULL',
      'CACHE',
      'NOCACHE'
    ]
  }
};
