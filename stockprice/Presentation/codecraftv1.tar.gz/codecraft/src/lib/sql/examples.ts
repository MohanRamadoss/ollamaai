import type { SQLExample } from '../../types/sql';

const SQL_EXAMPLES: Record<string, SQLExample[]> = {
  postgresql: [
    {
      title: 'Complex Join with Aggregations',
      description: 'Find top customers by order value with recent purchase dates',
      dialect: 'postgresql',
      complexity: 'intermediate',
      schema: `
CREATE TABLE customers (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(255)
);

CREATE TABLE orders (
  id SERIAL PRIMARY KEY,
  customer_id INTEGER REFERENCES customers(id),
  order_date TIMESTAMP,
  total_amount DECIMAL(10,2)
);`
    },
    {
      title: 'Window Functions',
      description: 'Calculate running totals and rankings for sales data',
      dialect: 'postgresql',
      complexity: 'advanced',
      schema: `
CREATE TABLE sales (
  id SERIAL PRIMARY KEY,
  product_id INTEGER,
  sale_date DATE,
  amount DECIMAL(10,2)
);`
    },
    {
      title: 'Advanced Analytics Dashboard',
      description: 'Create a dashboard showing sales performance with rolling averages and year-over-year comparison',
      dialect: 'postgresql',
      complexity: 'advanced',
      schema: `
CREATE TABLE sales (
  id SERIAL PRIMARY KEY,
  product_id INTEGER,
  sale_date DATE,
  amount DECIMAL(12,2),
  region VARCHAR(50)
);

CREATE TABLE products (
  id INTEGER PRIMARY KEY,
  name VARCHAR(100),
  category VARCHAR(50),
  unit_price DECIMAL(10,2)
);`
    },
    {
      title: 'Customer Segmentation',
      description: 'Segment customers based on purchase frequency, recency, and monetary value (RFM analysis)',
      dialect: 'postgresql',
      complexity: 'advanced',
      schema: `
CREATE TABLE customers (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(255)
);

CREATE TABLE orders (
  id SERIAL PRIMARY KEY,
  customer_id INTEGER REFERENCES customers(id),
  order_date TIMESTAMP,
  total_amount DECIMAL(12,2)
);`
    }
  ],
  mysql: [
    {
      title: 'Group Concatenation',
      description: 'List products with their categories as comma-separated values',
      dialect: 'mysql',
      complexity: 'basic',
      schema: `
CREATE TABLE products (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100),
  category VARCHAR(50)
);`
    },
    {
      title: 'Full-Text Search',
      description: 'Implement full-text search on product descriptions',
      dialect: 'mysql',
      complexity: 'intermediate',
      schema: `
CREATE TABLE products (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100),
  description TEXT,
  FULLTEXT INDEX idx_description (description)
);`
    },
    {
      title: 'Inventory Management',
      description: 'Track product inventory with automatic reorder points and stock alerts',
      dialect: 'mysql',
      complexity: 'intermediate',
      schema: `
CREATE TABLE products (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100),
  stock_level INT,
  reorder_point INT,
  unit_price DECIMAL(10,2)
);

CREATE TABLE inventory_movements (
  id INT PRIMARY KEY AUTO_INCREMENT,
  product_id INT,
  movement_type ENUM('in', 'out'),
  quantity INT,
  movement_date DATETIME,
  FOREIGN KEY (product_id) REFERENCES products(id)
);`
    },
    {
      title: 'Event Analytics',
      description: 'Analyze user engagement events with time-based aggregations',
      dialect: 'mysql',
      complexity: 'advanced',
      schema: `
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50),
  created_at DATETIME
);

CREATE TABLE events (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  event_type VARCHAR(50),
  event_data JSON,
  occurred_at DATETIME,
  FOREIGN KEY (user_id) REFERENCES users(id)
);`
    }
  ],
  oracle: [
    {
      title: 'Hierarchical Queries',
      description: 'Query employee hierarchy using CONNECT BY',
      dialect: 'oracle',
      complexity: 'advanced',
      schema: `
CREATE TABLE employees (
  employee_id NUMBER PRIMARY KEY,
  name VARCHAR2(100),
  manager_id NUMBER,
  department_id NUMBER,
  CONSTRAINT fk_manager FOREIGN KEY (manager_id) REFERENCES employees(employee_id)
);`
    },
    {
      title: 'Materialized Views',
      description: 'Create and refresh materialized views for sales reporting',
      dialect: 'oracle',
      complexity: 'intermediate',
      schema: `
CREATE TABLE sales (
  sale_id NUMBER PRIMARY KEY,
  product_id NUMBER,
  sale_date DATE,
  amount NUMBER(10,2)
);

CREATE MATERIALIZED VIEW sales_summary
BUILD IMMEDIATE
REFRESH ON COMMIT AS
SELECT product_id, 
       SUM(amount) total_sales,
       COUNT(*) transaction_count
FROM sales
GROUP BY product_id;`
    },
    {
      title: 'Employee Performance Analytics',
      description: 'Analyze employee performance metrics with hierarchical queries',
      dialect: 'oracle',
      complexity: 'advanced',
      schema: `
CREATE TABLE employees (
  employee_id NUMBER PRIMARY KEY,
  name VARCHAR2(100),
  manager_id NUMBER,
  department_id NUMBER,
  hire_date DATE,
  salary NUMBER(10,2)
);

CREATE TABLE performance_metrics (
  id NUMBER PRIMARY KEY,
  employee_id NUMBER,
  metric_date DATE,
  metric_type VARCHAR2(50),
  metric_value NUMBER(5,2),
  FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);`
    },
    {
      title: 'Financial Reporting',
      description: 'Generate financial reports with rolling totals and fiscal year calculations',
      dialect: 'oracle',
      complexity: 'advanced',
      schema: `
CREATE TABLE transactions (
  transaction_id NUMBER PRIMARY KEY,
  account_id NUMBER,
  transaction_date DATE,
  amount NUMBER(12,2),
  transaction_type VARCHAR2(10)
);

CREATE TABLE accounts (
  account_id NUMBER PRIMARY KEY,
  account_name VARCHAR2(100),
  account_type VARCHAR2(50),
  balance NUMBER(15,2)
);`
    }
  ],
  sqlite: [
    {
      title: 'Basic CRUD Operations',
      description: 'Create a contact management system with basic CRUD operations',
      dialect: 'sqlite',
      complexity: 'basic',
      schema: `
CREATE TABLE contacts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE,
  phone TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);`
    },
    {
      title: 'Full-Text Search',
      description: 'Implement full-text search functionality for documents',
      dialect: 'sqlite',
      complexity: 'intermediate',
      schema: `
-- Virtual FTS5 table for documents
CREATE VIRTUAL TABLE documents USING fts5(
  title,
  content,
  tags,
  tokenize='porter unicode61'
);

-- Metadata table for additional document info
CREATE TABLE document_metadata (
  doc_id INTEGER PRIMARY KEY,
  author TEXT,
  created_date TEXT DEFAULT CURRENT_TIMESTAMP,
  last_modified TEXT,
  size INTEGER
);`
    },
    {
      title: 'Hierarchical Data',
      description: 'Implement a hierarchical category system using recursive CTEs',
      dialect: 'sqlite',
      complexity: 'advanced',
      schema: `
CREATE TABLE categories (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  parent_id INTEGER,
  level INTEGER,
  path TEXT,
  FOREIGN KEY (parent_id) REFERENCES categories(id)
);

CREATE INDEX idx_categories_parent ON categories(parent_id);
CREATE INDEX idx_categories_path ON categories(path);`
    },
    {
      title: 'JSON Data Processing',
      description: 'Store and query JSON data in SQLite with proper indexing',
      dialect: 'sqlite',
      complexity: 'advanced',
      schema: `
CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  profile JSON,
  settings JSON,
  last_login TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE events (
  id INTEGER PRIMARY KEY,
  user_id INTEGER,
  event_type TEXT NOT NULL,
  event_data JSON,
  timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);`
    },
    {
      title: 'Blog Content Management',
      description: 'Manage blog posts with tags, categories, and full-text search',
      dialect: 'sqlite',
      complexity: 'intermediate',
      schema: `
CREATE TABLE posts (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT,
  author_id INTEGER,
  published_at TEXT,
  status TEXT
);

CREATE VIRTUAL TABLE post_search USING fts5(
  title, 
  content,
  content_rowid=id
);`
    },
    {
      title: 'Task Dependencies',
      description: 'Track project tasks with dependencies and completion status',
      dialect: 'sqlite',
      complexity: 'advanced',
      schema: `
CREATE TABLE tasks (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  status TEXT DEFAULT 'pending',
  start_date TEXT,
  end_date TEXT
);

CREATE TABLE task_dependencies (
  task_id INTEGER,
  depends_on_id INTEGER,
  PRIMARY KEY (task_id, depends_on_id),
  FOREIGN KEY (task_id) REFERENCES tasks(id),
  FOREIGN KEY (depends_on_id) REFERENCES tasks(id)
);`
    }
  ],
  mssql: [
    {
      title: 'Performance Monitoring',
      description: 'Query to analyze database performance metrics and blocking issues',
      dialect: 'mssql',
      complexity: 'advanced',
      schema: `
CREATE TABLE performance_logs (
    log_id INT IDENTITY(1,1) PRIMARY KEY,
    session_id INT,
    database_name NVARCHAR(128),
    cpu_time BIGINT,
    total_elapsed_time BIGINT,
    reads BIGINT,
    writes BIGINT,
    logical_reads BIGINT,
    captured_time DATETIME2 DEFAULT GETUTCDATE()
);

CREATE TABLE blocking_events (
    event_id INT IDENTITY(1,1) PRIMARY KEY,
    blocking_session_id INT,
    blocked_session_id INT,
    wait_time_ms INT,
    wait_type NVARCHAR(60),
    captured_time DATETIME2 DEFAULT GETUTCDATE()
);`
    },
    {
      title: 'Temporal Tables',
      description: 'Implement system-versioned temporal tables for audit history',
      dialect: 'mssql',
      complexity: 'intermediate',
      schema: `
CREATE TABLE employees (
    employee_id INT PRIMARY KEY,
    name NVARCHAR(100),
    department NVARCHAR(50),
    salary DECIMAL(12,2),
    valid_from DATETIME2 GENERATED ALWAYS AS ROW START,
    valid_to DATETIME2 GENERATED ALWAYS AS ROW END,
    PERIOD FOR SYSTEM_TIME (valid_from, valid_to)
)
WITH (SYSTEM_VERSIONING = ON);`
    },
    {
      title: 'Data Partitioning',
      description: 'Set up table partitioning for large tables with archival strategy',
      dialect: 'mssql',
      complexity: 'advanced',
      schema: `
-- Partition function
CREATE PARTITION FUNCTION OrderDateRangePF (datetime2)
AS RANGE RIGHT FOR VALUES ('2023-01-01', '2024-01-01');

-- Partition scheme
CREATE PARTITION SCHEME OrderDateRangePS
AS PARTITION OrderDateRangePF TO ([PRIMARY], [PRIMARY], [PRIMARY]);

-- Partitioned table
CREATE TABLE sales_orders (
    order_id INT IDENTITY(1,1),
    customer_id INT,
    order_date datetime2,
    total_amount DECIMAL(12,2),
    CONSTRAINT PK_sales_orders PRIMARY KEY (order_id, order_date)
)
ON OrderDateRangePS(order_date);`
    },
    {
      title: 'Indexed Views',
      description: 'Create and utilize indexed views for aggregation performance',
      dialect: 'mssql',
      complexity: 'intermediate',
      schema: `
CREATE TABLE products (
    product_id INT PRIMARY KEY,
    name NVARCHAR(100),
    category_id INT,
    unit_price DECIMAL(10,2)
);

CREATE TABLE sales (
    sale_id INT PRIMARY KEY,
    product_id INT,
    quantity INT,
    sale_date DATE,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Indexed view
CREATE VIEW product_sales_summary
WITH SCHEMABINDING
AS
SELECT 
    p.product_id,
    p.name,
    COUNT_BIG(*) as total_sales,
    SUM(s.quantity) as units_sold,
    SUM(s.quantity * p.unit_price) as revenue
FROM dbo.products p
JOIN dbo.sales s ON p.product_id = s.product_id
GROUP BY p.product_id, p.name;`
    }
  ]
};

// Add debugging to help track example loading
export async function getExamplesForDialect(dialect: string): Promise<SQLExample[]> {
  // Add debug logging
  console.log('Getting examples for dialect:', dialect);
  
  // Convert dialect to lowercase for consistent lookup
  const dialectKey = dialect.toLowerCase();
  const examples = SQL_EXAMPLES[dialectKey] || [];
  
  // Add debug logging
  console.log(`Found ${examples.length} examples for ${dialect}:`, examples);
  
  return examples;
}

export async function getAllDialects(): Promise<string[]> {
  return Object.keys(SQL_EXAMPLES);
}

// Add helper to get dialect display name
export function getDialectDisplayName(dialect: string): string {
  const dialectNames: Record<string, string> = {
    postgresql: 'PostgreSQL',
    mysql: 'MySQL',
    sqlite: 'SQLite',
    mssql: 'SQL Server',
    oracle: 'Oracle'
  };
  return dialectNames[dialect.toLowerCase()] || dialect;
}
