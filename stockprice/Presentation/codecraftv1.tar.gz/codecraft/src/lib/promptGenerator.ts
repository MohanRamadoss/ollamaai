import { ComplexityLevel } from '../types/models';
import { PROMPT_TEMPLATES, PromptTemplate } from './promptTemplates';
import { generateWithOpenAI } from './ai/openai';
import { generateWithGemini } from './ai/gemini';

type PromptVariables = Record<string, string>;

export class PromptGenerator {
  private static instance: PromptGenerator;
  private templates: PromptTemplate[];

  private constructor() {
    this.templates = PROMPT_TEMPLATES;
  }

  public static getInstance(): PromptGenerator {
    if (!PromptGenerator.instance) {
      PromptGenerator.instance = new PromptGenerator();
    }
    return PromptGenerator.instance;
  }

  public getTemplatesByComplexity(complexity: ComplexityLevel): PromptTemplate[] {
    return this.templates.filter(template => template.complexity === complexity);
  }

  public getTemplateById(id: string): PromptTemplate | undefined {
    return this.templates.find(template => template.id === id);
  }

  private async enhancePromptWithAI(prompt: string, modelIds: string[]): Promise<string> {
    const enhancementPrompt = `Enhance the following prompt to be more specific and detailed while maintaining its original intent:

${prompt}

Please provide an enhanced version that:
1. Adds more specific technical requirements
2. Includes best practices and patterns
3. Considers edge cases and error handling
4. Maintains clarity and structure`;

    const results = await Promise.all(
      modelIds.map(async (modelId) => {
        try {
          if (modelId.startsWith('gpt')) {
            return await generateWithOpenAI(enhancementPrompt, modelId, {
              temperature: 0.7,
              topP: 0.9,
              maxTokens: 2048,
            });
          } else if (modelId.startsWith('gemini')) {
            return await generateWithGemini(enhancementPrompt, modelId, {
              temperature: 0.7,
              topP: 0.9,
              topK: 40,
              maxTokens: 2048,
            });
          }
          return null;
        } catch (error) {
          console.error(`Error with model ${modelId}:`, error);
          return null;
        }
      })
    );

    // Filter out null results and combine the responses
    const validResults = results.filter((result): result is string => result !== null);
    
    if (validResults.length === 0) {
      return prompt; // Return original prompt if all models fail
    }

    // Combine insights from different models
    return this.combineModelResults(validResults);
  }

  private combineModelResults(results: string[]): string {
    // If only one result, return it
    if (results.length === 1) {
      return results[0];
    }

    // Combine multiple results by taking the most comprehensive parts
    const sections = results.map(result => result.split('\n\n'));
    const combinedSections = new Set<string>();

    sections.forEach(modelSections => {
      modelSections.forEach(section => {
        combinedSections.add(section.trim());
      });
    });

    return Array.from(combinedSections).join('\n\n');
  }

  public async generatePrompt(
    templateId: string, 
    variables: PromptVariables, 
    modelIds: string[] = []
  ): Promise<string> {
    const template = this.getTemplateById(templateId);
    if (!template) {
      throw new Error(`Template with id ${templateId} not found`);
    }

    // Validate required variables
    const missingVariables = template.variables
      .filter(v => v.required && !variables[v.name])
      .map(v => v.name);

    if (missingVariables.length > 0) {
      throw new Error(`Missing required variables: ${missingVariables.join(', ')}`);
    }

    // Replace variables in template
    let promptText = template.template;
    template.variables.forEach(variable => {
      const value = variables[variable.name] || variable.defaultValue || '';
      promptText = promptText.replace(
        new RegExp(`{${variable.name}}`, 'g'),
        value
      );
    });

    // If models are provided, enhance the prompt using AI
    if (modelIds.length > 0) {
      return this.enhancePromptWithAI(promptText, modelIds);
    }

    return promptText;
  }

  public validateVariables(templateId: string, variables: PromptVariables): string[] {
    const template = this.getTemplateById(templateId);
    if (!template) {
      return ['Template not found'];
    }

    const errors: string[] = [];

    template.variables.forEach(variable => {
      if (variable.required && !variables[variable.name]) {
        errors.push(`${variable.name} is required`);
      }
    });

    return errors;
  }
}