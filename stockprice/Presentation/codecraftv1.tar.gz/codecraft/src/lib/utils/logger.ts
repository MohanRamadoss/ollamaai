import { ENV_CONFIG } from '../../config/env';

type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LogMessage {
  timestamp: string;
  level: LogLevel;
  module: string;
  message: string;
  data?: any;
}

class Logger {
  private logs: LogMessage[] = [];
  private maxLogs = 1000;

  log(level: LogLevel, module: string, message: string, data?: any) {
    const logMessage: LogMessage = {
      timestamp: new Date().toISOString(),
      level,
      module,
      message,
      data
    };

    this.logs.push(logMessage);
    if (this.logs.length > this.maxLogs) {
      this.logs.shift();
    }

    if (ENV_CONFIG.DEBUG) {
      const color = {
        debug: '\x1b[36m', // cyan
        info: '\x1b[32m',  // green
        warn: '\x1b[33m',  // yellow
        error: '\x1b[31m'  // red
      }[level];
      
      const dataString = data ? `\nData: ${JSON.stringify(data, null, 2)}` : '';
      
      console.log(
        `${color}[${logMessage.timestamp}] [${level.toUpperCase()}] [${module}]: ${message}${dataString}\x1b[0m`
      );
    }
  }

  debug(module: string, message: string, data?: any) {
    this.log('debug', module, message, data);
  }

  info(module: string, message: string, data?: any) {
    this.log('info', module, message, data);
  }

  warn(module: string, message: string, data?: any) {
    this.log('warn', module, message, data);
  }

  error(module: string, message: string, data?: any) {
    this.log('error', module, message, data);
  }

  getLogs() {
    return this.logs;
  }

  clearLogs() {
    this.logs = [];
  }
}

export const logger = new Logger();
