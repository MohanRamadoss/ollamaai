import { SECURITY_CATEGORIES } from '../../config/securityCategories';
import { scanSecurity } from '../api/security';

export async function testSecurityCategory(
  code: string,
  language: string,
  category: string
) {
  try {
    const results = await scanSecurity({
      sourceCode: code,
      language,
      modelIds: ['mistral:latest'],
      scanType: 'full',
      features: {
        [category]: true
      },
      onProgress: (progress) => console.log('Scan progress:', progress)
    });

    return results['mistral:latest'].issues.filter(
      issue => issue.category === category
    );
  } catch (error) {
    console.error(`Failed to test category ${category}:`, error);
    throw error;
  }
}

export async function runSecurityTests() {
  const testCases = Object.entries(SECURITY_TEST_EXAMPLES);
  const results = [];

  for (const [category, examples] of testCases) {
    console.log(`Testing ${category}...`);
    
    for (const [language, code] of Object.entries(examples)) {
      const issues = await testSecurityCategory(code, language, category);
      results.push({
        category,
        language,
        issuesFound: issues.length,
        issues
      });
    }
  }

  return results;
}

// Usage example:
async function main() {
  try {
    const results = await runSecurityTests();
    console.log('Security Test Results:', JSON.stringify(results, null, 2));
  } catch (error) {
    console.error('Security testing failed:', error);
  }
}
