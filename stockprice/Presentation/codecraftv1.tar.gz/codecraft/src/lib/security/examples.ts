import fs from 'fs';
import path from 'path';
import { getExamplesForLanguage as getLanguageExamples } from '../../data/security/languages';
import type { CodeExample } from '../../types/security';
import { SECURITY_CATEGORIES } from '../../config/securityCategories';

const EXAMPLES_PATH = '../../../aicodecraft/src/data/codeQuality';

// Map language identifiers to example file paths
const LANGUAGE_EXAMPLES: Record<string, CodeExample[]> = {
  javascript: [
    {
      name: 'SQL Injection Example',
      description: 'Example showing vulnerable SQL query construction',
      code: `
const query = "SELECT * FROM users WHERE id = '" + userId + "'";
db.query(query); // Vulnerable to SQL injection
      `.trim()
    },
    {
      name: 'XSS Vulnerability',
      description: 'Example showing XSS vulnerability in React',
      code: `
function Comment({ data }) {
  return <div dangerouslySetInnerHTML={{ __html: data }} />; // XSS vulnerability
}
      `.trim()
    }
  ],
  typescript: [
    {
      name: 'TypeScript Example',
      description: 'Example showing TypeScript usage',
      code: `
interface User {
  id: number;
  name: string;
}

const getUser = (id: number): User => {
  return { id, name: 'John Doe' };
};
      `.trim()
    }
  ],
  python: [
    {
      name: 'Command Injection',
      description: 'Example showing command injection vulnerability',
      code: `
user_input = input("Enter filename: ")
os.system("cat " + user_input) # Command injection vulnerability
      `.trim()
    },
    {
      name: 'SQL Injection Example',
      description: 'Example showing vulnerable SQL query construction',
      code: `
import sqlite3

def get_user(user_id):
    conn = sqlite3.connect('example.db')
    cursor = conn.cursor()
    query = "SELECT * FROM users WHERE id = " + user_id
    cursor.execute(query) # Vulnerable to SQL injection
    return cursor.fetchall()
      `.trim()
    }
  ],
  java: [
    {
      name: 'Java Example',
      description: 'Example showing Java usage',
      code: `
public class HelloWorld {
  public static void main(String[] args) {
    System.out.println("Hello, World!");
  }
}
      `.trim()
    },
    {
      name: 'SQL Injection Example',
      description: 'Example showing vulnerable SQL query construction',
      code: `
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SQLInjectionExample {
  public static void main(String[] args) {
    String userId = "1 OR 1=1";
    String query = "SELECT * FROM users WHERE id = " + userId;
    try (Connection conn = DriverManager.getConnection("jdbc:sqlite:example.db");
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {
      while (rs.next()) {
        System.out.println(rs.getString("name"));
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
      `.trim()
    }
  ],
  cpp: [
    {
      name: 'C++ Example',
      description: 'Example showing C++ usage',
      code: `
#include <iostream>

int main() {
  std::cout << "Hello, World!" << std::endl;
  return 0;
}
      `.trim()
    },
    {
      name: 'Buffer Overflow Example',
      description: 'Example showing buffer overflow vulnerability',
      code: `
#include <iostream>
#include <cstring>

void vulnerableFunction(char *str) {
  char buffer[10];
  strcpy(buffer, str); // Buffer overflow vulnerability
}

int main() {
  char str[20] = "This is too long";
  vulnerableFunction(str);
  return 0;
}
      `.trim()
    }
  ],
  go: [
    {
      name: 'Go Example',
      description: 'Example showing Go usage',
      code: `
package main

import "fmt"

func main() {
  fmt.Println("Hello, World!")
}
      `.trim()
    },
    {
      name: 'SQL Injection Example',
      description: 'Example showing vulnerable SQL query construction',
      code: `
package main

import (
  "database/sql"
  "fmt"
  _ "github.com/mattn/go-sqlite3"
)

func getUser(userId string) {
  db, _ := sql.Open("sqlite3", "./example.db")
  query := "SELECT * FROM users WHERE id = " + userId
  rows, _ := db.Query(query) // Vulnerable to SQL injection
  defer rows.Close()
  for rows.Next() {
    var name string
    rows.Scan(&name)
    fmt.Println(name)
  }
}

func main() {
  getUser("1 OR 1=1")
}
      `.trim()
    }
  ],
  rust: [
    {
      name: 'Rust Example',
      description: 'Example showing Rust usage',
      code: `
fn main() {
  println!("Hello, World!");
}
      `.trim()
    },
    {
      name: 'Integer Overflow Example',
      description: 'Example showing integer overflow vulnerability',
      code: `
fn main() {
  let x: u8 = 255;
  let y = x + 1; // Integer overflow
  println!("y: {}", y);
}
      `.trim()
    }
  ],
  php: [
    {
      name: 'PHP Example',
      description: 'Example showing PHP usage',
      code: `
<?php
echo "Hello, World!";
?>
      `.trim()
    },
    {
      name: 'SQL Injection Example',
      description: 'Example showing vulnerable SQL query construction',
      code: `
<?php
$userId = $_GET['id'];
$query = "SELECT * FROM users WHERE id = " . $userId;
$result = mysqli_query($conn, $query); // Vulnerable to SQL injection
?>
      `.trim()
    }
  ]
};

export async function getExamplesForLanguage(language: string): Promise<CodeExample[]> {
  try {
    // Get examples for the selected language
    const examples = getLanguageExamples(language);
    
    // Add security-specific metadata
    return examples.map(example => ({
      ...example,
      securityContext: {
        riskLevel: example.securityContext?.riskLevel || 'medium',
        vulnerabilityType: example.securityContext?.vulnerabilityType || 'general',
      }
    }));
  } catch (error) {
    console.error('Error loading examples:', error);
    return [];
  }
}

export const SECURITY_TEST_EXAMPLES = {
  // Broken Access Control Examples
  [SECURITY_CATEGORIES.BROKEN_ACCESS_CONTROL]: {
    javascript: `
// Insecure direct object reference
app.get('/api/user/:id', (req, res) => {
  const userData = db.getUser(req.params.id);  // No authorization check!
  res.json(userData);
});

// Missing role validation
function deleteUser(userId) {
  db.users.delete(userId);  // No role/permission check!
}`,
    python: `
# Path traversal vulnerability
@app.route('/download')
def download_file():
    filename = request.args.get('file')
    return send_file(filename)  # No path validation!

# Insecure direct object reference
def get_user_data(user_id):
    return db.query(f"SELECT * FROM users WHERE id = {user_id}")  # No access control!`
  },

  // Cryptographic Failures Examples
  [SECURITY_CATEGORIES.CRYPTOGRAPHIC_FAILURES]: {
    javascript: `
// Weak cryptography
const crypto = require('crypto');
const password = 'user_password';
const hash = crypto.createHash('md5').update(password).digest('hex');  // MD5 is weak!

// Hardcoded encryption key
const encryptionKey = "1234567890abcdef";  // Never hardcode keys!
const cipher = crypto.createCipher('aes-128-cbc', encryptionKey);`,
    python: `
# Insecure password hashing
import hashlib
def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()  # MD5 is weak!

# Weak random number generation
import random
token = random.randint(1000, 9999)  # Not cryptographically secure!`
  },

  // Injection Examples
  [SECURITY_CATEGORIES.INJECTION]: {
    javascript: `
// SQL Injection
const query = \`SELECT * FROM users WHERE username = '\${username}' AND password = '\${password}'\`;  // Unsafe!

// Command Injection
const exec = require('child_process').exec;
exec('ping ' + userInput);  // Unsafe command execution!

// XSS
document.write('<div>' + userInput + '</div>');  // Unsafe HTML injection!`,
    python: `
# SQL Injection
cursor.execute(f"SELECT * FROM users WHERE username = '{username}'")  # Unsafe!

# Command Injection
import os
os.system('ping ' + user_input)  # Unsafe command execution!

# Template Injection
from flask import render_template_string
render_template_string(user_input)  # Unsafe template!`
  },

  // Insecure Design Examples
  [SECURITY_CATEGORIES.INSECURE_DESIGN]: {
    javascript: `
// Missing rate limiting
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  // No rate limiting or brute force protection!
  const user = await db.findUser(username, password);
  if (user) return res.json({ token: generateToken(user) });
});

// Insufficient process validation
function transferMoney(fromAccount, toAccount, amount) {
  // No balance check or transaction validation!
  fromAccount.balance -= amount;
  toAccount.balance += amount;
}`,
    python: `
# Race condition vulnerability
balance = get_balance()
if balance >= amount:
    # Race condition possible between check and deduction
    new_balance = balance - amount
    save_balance(new_balance)

# Missing business logic validation
def update_user_role(user_id, new_role):
    user.role = new_role  # No validation of role change authority!`
  },

  // Security Misconfiguration Examples
  [SECURITY_CATEGORIES.SECURITY_MISCONFIGURATION]: {
    javascript: `
// Development features in production
app.use(express.errorHandler({ dumpExceptions: true, showStack: true }));  // Unsafe in production!

// Default credentials
const dbConfig = {
  user: 'admin',
  password: 'admin',  // Default credentials!
  database: 'production_db'
};`,
    python: `
# Debug mode in production
app.debug = True  # Never enable in production!

# Insecure headers
@app.route('/')
def index():
    response = make_response()
    response.headers['X-Frame-Options'] = 'ALLOW'  # Insecure header!
    return response`
  },

  // Add more examples for other categories...
};

// Helper function to get examples for a specific language
export function getSecurityExamples(language: string, category: string) {
  return SECURITY_TEST_EXAMPLES[category]?.[language] || null;
}

// Example usage of test cases
export const SECURITY_TEST_CASES = {
  sqlInjection: {
    vulnerable: `const query = "SELECT * FROM users WHERE id = " + userId;`,
    fixed: `const query = "SELECT * FROM users WHERE id = ?";
const [rows] = await connection.execute(query, [userId]);`
  },
  xss: {
    vulnerable: `element.innerHTML = userInput;`,
    fixed: `element.textContent = userInput;`
  },
  commandInjection: {
    vulnerable: `exec('git ' + userInput);`,
    fixed: `exec('git', ['clone', validatedRepoUrl]);`
  }
};
