import { SecurityScanType, SecurityCategory } from '../../types/security';

interface SecurityPrompt {
  language: string;
  scanType: SecurityScanType;
  category: SecurityCategory;
  prompt: string;
  examples?: string[];
}

// Programming Languages Security Prompts
export const PROGRAMMING_SECURITY_PROMPTS: SecurityPrompt[] = [
  // JavaScript/TypeScript
  {
    language: 'javascript',
    scanType: 'quick',
    category: 'vulnerabilities',
    prompt: `Analyze this JavaScript/TypeScript code for common security vulnerabilities:
1. Check for XSS vulnerabilities in DOM manipulation
2. Identify potential prototype pollution
3. Look for unsafe eval() or Function usage
4. Check for insecure regular expressions
5. Identify potential ReDoS vulnerabilities`,
    examples: [
      'document.innerHTML = userInput',
      'eval(userCode)',
      'new RegExp(userPattern)'
    ]
  },
  {
    language: 'javascript',
    scanType: 'full',
    category: 'dependencies',
    prompt: `Perform a comprehensive dependency analysis:
1. Check package.json for vulnerable dependencies
2. Identify outdated packages with known CVEs
3. Analyze third-party script inclusions
4. Check for insecure package sources
5. Validate dependency tree integrity`,
  },
  {
    language: 'javascript',
    scanType: 'deep',
    category: 'bestPractices',
    prompt: `Deep analysis of JavaScript security best practices:
1. Validate Content Security Policy implementation
2. Check CORS configuration security
3. Analyze authentication mechanisms
4. Review session management
5. Examine API security measures
6. Validate input sanitization practices
7. Check for secure cookie configuration
8. Review WebSocket security
9. Analyze JWT implementation
10. Check for secure password handling`,
  },

  // Python
  {
    language: 'python',
    scanType: 'quick',
    category: 'vulnerabilities',
    prompt: `Quick security scan for Python code:
1. Check for SQL injection vulnerabilities
2. Identify command injection risks
3. Look for unsafe pickle usage
4. Check for hardcoded credentials
5. Identify unsafe yaml.load() usage`,
    examples: [
      'cursor.execute("SELECT * FROM users WHERE id = " + user_id)',
      'os.system(user_command)',
      'pickle.loads(user_data)'
    ]
  },
  {
    language: 'python',
    scanType: 'full',
    category: 'compliance',
    prompt: `Full compliance scan for Python applications:
1. Check GDPR compliance in data handling
2. Validate PII protection measures
3. Verify logging compliance
4. Check for proper error handling
5. Analyze data retention practices
6. Review access control mechanisms
7. Check for secure communication protocols
8. Validate input validation practices`,
  },
  {
    language: 'python',
    scanType: 'deep',
    category: 'secrets',
    prompt: `Deep secrets scanning in Python code:
1. Search for hardcoded API keys
2. Identify embedded credentials
3. Check for exposed tokens
4. Look for private keys
5. Identify hardcoded passwords
6. Check configuration files
7. Analyze environment variables
8. Review deployment scripts
9. Check git history
10. Scan documentation files`,
  },

  // Java
  {
    language: 'java',
    scanType: 'quick',
    category: 'vulnerabilities',
    prompt: `Quick Java security vulnerability scan:
1. Check for SQL injection in JDBC usage
2. Identify XXE vulnerabilities
3. Look for unsafe deserialization
4. Check for path traversal
5. Identify unsafe reflection usage`,
    examples: [
      'Statement.execute("SELECT * FROM users WHERE id = " + userId)',
      'XMLReader.parse(untrustedInput)',
      'ObjectInputStream.readObject()'
    ]
  },
  {
    language: 'java',
    scanType: 'full',
    category: 'bestPractices',
    prompt: `Full Java security best practices analysis:
1. Validate secure coding patterns
2. Check exception handling
3. Review access modifiers
4. Analyze synchronization practices
5. Check for proper resource cleanup
6. Validate input validation
7. Review logging practices
8. Check for secure random number generation
9. Analyze cryptographic implementations
10. Review authentication mechanisms`,
  },

  // Go
  {
    language: 'go',
    scanType: 'quick',
    category: 'vulnerabilities',
    prompt: `Quick Go security vulnerability scan:
1. Check for SQL injection in database/sql
2. Identify unsafe pointer usage
3. Look for race conditions
4. Check for unsafe concurrent access
5. Identify insecure random number generation`,
    examples: [
      'db.Query("SELECT * FROM users WHERE id = " + id)',
      'unsafe.Pointer(addr)',
      'math/rand.Seed(time.Now().UnixNano())'
    ]
  },
  {
    language: 'go',
    scanType: 'deep',
    category: 'bestPractices',
    prompt: `Deep Go security best practices analysis:
1. Review error handling patterns
2. Check for proper context usage
3. Analyze goroutine safety
4. Validate mutex usage
5. Check for memory leaks
6. Review cryptographic implementations
7. Analyze TLS configuration
8. Check for secure logging practices
9. Review input validation
10. Analyze API security`,
  }
];

// Configuration Management Security Prompts
export const CONFIG_SECURITY_PROMPTS: SecurityPrompt[] = [
  // Docker
  {
    language: 'docker',
    scanType: 'quick',
    category: 'vulnerabilities',
    prompt: `Quick Docker security scan:
1. Check for root user usage
2. Identify exposed ports
3. Look for sensitive environment variables
4. Check base image security
5. Identify unsafe volume mounts`,
    examples: [
      'USER root',
      'ENV AWS_SECRET_KEY=',
      'VOLUME /etc/passwords'
    ]
  },
  {
    language: 'docker',
    scanType: 'full',
    category: 'bestPractices',
    prompt: `Full Docker security best practices scan:
1. Validate multi-stage builds
2. Check for proper layer caching
3. Review COPY vs ADD usage
4. Analyze environment variables
5. Check for latest tag usage
6. Review exposed ports
7. Validate health checks
8. Check for proper cleanup
9. Review user permissions
10. Analyze volume configurations`,
  },

  // Kubernetes
  {
    language: 'kubernetes',
    scanType: 'quick',
    category: 'vulnerabilities',
    prompt: `Quick Kubernetes security scan:
1. Check for privileged containers
2. Identify exposed ports
3. Look for unsafe capabilities
4. Check resource limits
5. Identify insecure volume mounts`,
    examples: [
      'securityContext.privileged: true',
      'capabilities.add: ["ALL"]',
      'hostPath.path: "/"`'
    ]
  },
  {
    language: 'kubernetes',
    scanType: 'deep',
    category: 'compliance',
    prompt: `Deep Kubernetes compliance scan:
1. Validate PodSecurityPolicies
2. Check NetworkPolicies
3. Review RBAC configuration
4. Analyze service accounts
5. Check for proper namespaces
6. Review secret management
7. Validate resource quotas
8. Check container security context
9. Review admission controllers
10. Analyze audit logging`,
  },

  // Terraform
  {
    language: 'terraform',
    scanType: 'quick',
    category: 'vulnerabilities',
    prompt: `Quick Terraform security scan:
1. Check for public access
2. Identify unencrypted resources
3. Look for insecure protocols
4. Check IAM permissions
5. Identify exposed credentials`,
    examples: [
      'acl = "public-read"',
      'enable_encryption = false',
      '*:*'
    ]
  },
  {
    language: 'terraform',
    scanType: 'full',
    category: 'bestPractices',
    prompt: `Full Terraform security best practices scan:
1. Validate state file security
2. Check for proper tagging
3. Review access controls
4. Analyze network security
5. Check encryption settings
6. Review backup configurations
7. Validate monitoring setup
8. Check compliance settings
9. Review disaster recovery
10. Analyze cost controls`,
  },

  // Ansible
  {
    language: 'ansible',
    scanType: 'quick',
    category: 'vulnerabilities',
    prompt: `Quick Ansible security scan:
1. Check for unsafe commands
2. Identify exposed secrets
3. Look for insecure permissions
4. Check for unencrypted variables
5. Identify unsafe defaults`,
    examples: [
      'shell: "{{ user_input }}"',
      'mode: "0777"',
      'no_log: false'
    ]
  },
  {
    language: 'ansible',
    scanType: 'deep',
    category: 'bestPractices',
    prompt: `Deep Ansible security best practices scan:
1. Validate vault usage
2. Check for idempotency
3. Review privilege escalation
4. Analyze error handling
5. Check for proper templating
6. Review variable precedence
7. Validate file permissions
8. Check for secure defaults
9. Review role dependencies
10. Analyze task isolation`,
  },
  {
    language: 'ansible',
    scanType: 'quick',
    category: 'broken_access_control',
    prompt: `Analyze this Ansible playbook for access control issues:
    Focus on:
    - Privilege escalation
    - Role permissions
    - File permissions
    - Sensitive data access
    Return results in JSON format as specified.`
  },
  {
    language: 'ansible',
    scanType: 'full',
    category: 'broken_access_control',
    prompt: `Perform comprehensive access control analysis of this Ansible playbook:
    Focus on:
    - Permission models
    - Privilege management
    - Access restrictions
    - Security best practices
    - Role-based access control
    Return detailed results in JSON format as specified.`
  }
];

// Ansible Security Prompts
export const ANSIBLE_SECURITY_PROMPTS = {
  quick: `Perform a quick security analysis of this Ansible configuration:
    1. Check for basic security misconfigurations
    2. Identify obvious security risks
    3. Look for exposed secrets
    4. Validate basic role permissions`,
    
  full: `Perform a comprehensive security analysis of this Ansible configuration:
    1. Deep analysis of privilege escalation
    2. Complete secret scanning
    3. Role-based access control review
    4. Module security assessment
    5. Task-level security validation`,
    
  deep: `Perform an in-depth security audit of this Ansible configuration:
    1. Advanced privilege analysis
    2. Comprehensive secret detection
    3. Complete RBAC review
    4. Module security deep dive
    5. Task security analysis
    6. Variable scope security
    7. Template injection risks
    8. Command injection vulnerabilities`
};

// Security Response Templates
export const SECURITY_RESPONSE_TEMPLATES = {
  vulnerability: {
    critical: (details: any) => `CRITICAL Security Vulnerability [CVSS: ${details.cvss}]
Title: ${details.title}
CWE: ${details.cwe}
Location: Line ${details.line}

Description:
${details.description}

Impact:
${details.impact}

Recommendation:
${details.recommendation}

References:
${details.references}`,

    high: (details: any) => `HIGH Security Risk [CVSS: ${details.cvss}]
Title: ${details.title}
CWE: ${details.cwe}
Location: Line ${details.line}

Description:
${details.description}

Recommendation:
${details.recommendation}`,

    medium: (details: any) => `MEDIUM Security Issue
Title: ${details.title}
Location: Line ${details.line}

Description:
${details.description}

Recommendation:
${details.recommendation}`,

    low: (details: any) => `LOW Security Concern
Title: ${details.title}
Description: ${details.description}
Recommendation: ${details.recommendation}`
  },

  bestPractice: (details: any) => `Security Best Practice Recommendation
Title: ${details.title}
Category: ${details.category}

Description:
${details.description}

Suggestion:
${details.suggestion}

Benefits:
${details.benefits}`,

  compliance: (details: any) => `Compliance Issue
Standard: ${details.standard}
Requirement: ${details.requirement}

Finding:
${details.finding}

Impact:
${details.impact}

Remediation Steps:
${details.remediation}`
};