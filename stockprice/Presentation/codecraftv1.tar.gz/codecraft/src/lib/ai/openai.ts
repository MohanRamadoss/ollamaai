import OpenAI from 'openai';
import { env } from '../env';

const openai = new OpenAI({
  apiKey: env.OPENAI_API_KEY,
  dangerouslyAllowBrowser: true // Enable browser usage
});

export async function generateWithOpenAI(prompt: string, model: string, params: any) {
  const completion = await openai.chat.completions.create({
    model,
    messages: [{ role: 'user', content: prompt }],
    temperature: params.temperature,
    top_p: params.topP,
    max_tokens: params.maxTokens,
  });

  return completion.choices[0].message.content || '';
}