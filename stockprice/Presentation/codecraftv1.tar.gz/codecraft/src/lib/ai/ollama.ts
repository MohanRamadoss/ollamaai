import { ENV_CONFIG } from '../../config/env';
import { logger } from '../../utils/logger';

export async function generateWithOllama(prompt: string, modelId: string): Promise<string> {
  try {
    const response = await fetch(`${ENV_CONFIG.OLLAMA_API_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: modelId.replace('ollama/', ''),
        prompt,
        stream: false,
        options: {
          temperature: 0.3,
          top_p: 0.9,
        }
      })
    });

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.status}`);
    }

    const data = await response.json();
    if (!data.response) {
      throw new Error('Empty response from Ollama');
    }

    return data.response;
  } catch (error) {
    logger.error('Ollama generation failed', error);
    throw error;
  }
}
