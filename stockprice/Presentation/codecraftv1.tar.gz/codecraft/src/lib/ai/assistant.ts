import { generateWithOpenAI } from './openai';
import { generateWithGemini } from './gemini';

export class AIAssistant {
  async reviewCode(code: string, language: string) {
    const prompt = `Review this ${language} code and provide:
1. Code quality assessment
2. Potential improvements
3. Security concerns
4. Performance optimizations
5. Best practices suggestions

Code to review:
${code}`;

    try {
      // Try GPT-4 first for more accurate reviews
      const gptResult = await generateWithOpenAI(prompt, 'gpt-4', {
        temperature: 0.3,
        maxTokens: 2048,
      });

      if (gptResult) {
        return this.parseReviewResults(gptResult);
      }

      // Fallback to Gemini
      const geminiResult = await generateWithGemini(prompt, 'gemini-pro-code', {
        temperature: 0.3,
        maxTokens: 2048,
      });

      return this.parseReviewResults(geminiResult);
    } catch (error) {
      console.error('Code review failed:', error);
      throw error;
    }
  }

  async suggestChanges(code: string, language: string) {
    const prompt = `Suggest improvements for this ${language} code. Provide:
1. Specific code changes with explanations
2. Better alternatives for current implementations
3. Modern language features that could be used
4. Code organization improvements

Code to improve:
${code}`;

    try {
      const gptResult = await generateWithOpenAI(prompt, 'gpt-4', {
        temperature: 0.3,
        maxTokens: 2048,
      });

      if (gptResult) {
        return this.parseSuggestions(gptResult);
      }

      const geminiResult = await generateWithGemini(prompt, 'gemini-pro-code', {
        temperature: 0.3,
        maxTokens: 2048,
      });

      return this.parseSuggestions(geminiResult);
    } catch (error) {
      console.error('Code suggestions failed:', error);
      throw error;
    }
  }

  async explainCode(code: string, language: string) {
    const prompt = `Explain this ${language} code in detail:
1. Overall purpose and functionality
2. Key components and their roles
3. Important algorithms or patterns used
4. Dependencies and requirements
5. Potential edge cases or limitations

Code to explain:
${code}`;

    try {
      const result = await generateWithOpenAI(prompt, 'gpt-4', {
        temperature: 0.3,
        maxTokens: 2048,
      });

      return this.parseExplanation(result);
    } catch (error) {
      console.error('Code explanation failed:', error);
      throw error;
    }
  }

  private parseReviewResults(result: string) {
    // Parse the AI response into structured review data
    const sections = result.split('\n\n');
    return {
      quality: this.extractSection(sections, 'Code quality'),
      improvements: this.extractSection(sections, 'Potential improvements'),
      security: this.extractSection(sections, 'Security concerns'),
      performance: this.extractSection(sections, 'Performance optimizations'),
      bestPractices: this.extractSection(sections, 'Best practices'),
    };
  }

  private parseSuggestions(result: string) {
    // Parse the AI response into structured suggestions
    const sections = result.split('\n\n');
    return {
      changes: this.extractSection(sections, 'Specific code changes'),
      alternatives: this.extractSection(sections, 'Better alternatives'),
      modernFeatures: this.extractSection(sections, 'Modern language features'),
      organization: this.extractSection(sections, 'Code organization'),
    };
  }

  private parseExplanation(result: string) {
    // Parse the AI response into structured explanation
    const sections = result.split('\n\n');
    return {
      purpose: this.extractSection(sections, 'Overall purpose'),
      components: this.extractSection(sections, 'Key components'),
      patterns: this.extractSection(sections, 'Important algorithms'),
      dependencies: this.extractSection(sections, 'Dependencies'),
      limitations: this.extractSection(sections, 'Potential edge cases'),
    };
  }

  private extractSection(sections: string[], title: string) {
    const section = sections.find(s => s.toLowerCase().includes(title.toLowerCase()));
    return section ? section.split('\n').slice(1) : [];
  }
}