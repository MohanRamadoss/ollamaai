import { GoogleGenerativeAI } from '@google/generative-ai';
import { ENV_CONFIG } from '../../config/env';
import { logger } from '../../utils/logger';

export async function generateWithGemini(prompt: string, modelId: string): Promise<string> {
  if (!ENV_CONFIG.GOOGLE_API_KEY) {
    throw new Error('Google API key not configured');
  }

  try {
    const genAI = new GoogleGenerativeAI(ENV_CONFIG.GOOGLE_API_KEY);
    const model = genAI.getGenerativeModel({ 
      model: modelId === 'gemini-pro-code' ? 'gemini-pro' : modelId 
    });

    const result = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.8,
        maxOutputTokens: 8192,
      }
    });

    if (!result.response?.text()) {
      throw new Error('Empty response from Gemini');
    }

    return result.response.text();
  } catch (error) {
    logger.error('Gemini generation failed', error);
    throw error;
  }
}