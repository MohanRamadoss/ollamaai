import { SUPPORTED_LANGUAGES, type SupportedLanguage } from '../../types/supported-languages';

export function getLanguageByExtension(extension: string): SupportedLanguage | undefined {
  const extensionMap: Record<string, SupportedLanguage> = {
    'js': 'javascript',
    'jsx': 'javascript',
    'ts': 'typescript',
    'tsx': 'typescript',
    'py': 'python',
    'java': 'java',
    'cpp': 'cpp',
    'c': 'c',
    'go': 'golang',
    'rs': 'rust',
    'php': 'php'
  };
  
  return extensionMap[extension.toLowerCase()];
}

export function getLanguageSettings(language: SupportedLanguage) {
  const langInfo = SUPPORTED_LANGUAGES[language];
  return {
    tabSize: langInfo?.name === 'Python' ? 4 : 2,
    insertSpaces: true,
    bracketMatching: true,
    autoClosingBrackets: true,
    autoIndent: true
  };
}
