import { ENV_CONFIG } from '../../config/env';
import { SQL_MODEL_CONFIGS } from '../../config/sqlModels';
import type { SQLDialect, SQLGenerationResult, OptimizationFeatures } from '../../types/sql';
import _ from 'lodash';
import { getDashboardTemplate } from '../sql/templates';
import { DIALECT_OPTIMIZERS } from '../sql/optimizers';
import { isValidPostgreSQLQuery, isValidOracleQuery, isValidMySQLQuery, isValidSQLiteQuery } from '../sql/validators';
import { GoogleGenerativeAI } from '@google/generative-ai';

// Enhanced type definitions
export interface SQLAnalysisResult {
  complexity: 'simple' | 'moderate' | 'complex';
  estimatedCost: number;
  suggestedOptimizations: string[];
  riskFactors: string[];
}

export interface SQLValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  suggestions: string[];
}

export interface EnhancedSQLProgress extends SQLProgress {
  analysis?: SQLAnalysisResult;
  validation?: SQLValidationResult;
  estimatedTime?: number;
};

export type SQLProgress = {
  modelId: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  progress: number;
  result?: SQLGenerationResult;
  error?: string;
};

export type ProgressCallback = (progress: Record<string, SQLProgress>) => void;

// Add dialect-specific configurations
const DIALECT_CONFIGS = {
  oracle: {
    keywords: ['SELECT', 'FROM', 'WHERE', 'WITH', 'CREATE', 'ALTER', 'BEGIN', 'END', 'DECLARE'],
    identifierQuotes: '"',
    commentStyle: '-- ',
  },
  postgresql: {
    keywords: [
      'SELECT', 'FROM', 'WHERE', 'WITH', 'CREATE', 'ALTER', 'BEGIN',
      'OVER', 'PARTITION BY', 'LAG', 'LEAD', 'AVG', 'SUM', 'ROW_NUMBER',
      'DATE_TRUNC', 'EXTRACT', 'INTERVAL'
    ],
    identifierQuotes: '"',
    commentStyle: '-- ',
    specialFeatures: {
      windowFunctions: true,
      ctes: true,
      dateManipulation: true
    }
  },
  mysql: {
    keywords: ['SELECT', 'FROM', 'WHERE', 'CREATE', 'ALTER'],
    identifierQuotes: '`',
    commentStyle: '-- ',
  },
  mssql: {
    keywords: [
      'SELECT', 'FROM', 'WHERE', 'INSERT', 'UPDATE', 'DELETE',
      'EXEC', 'EXECUTE', 'PROCEDURE', 'CREATE', 'ALTER', 'DROP',
      'BEGIN', 'END', 'DECLARE', 'SET', 'WITH'
    ],
    identifierQuotes: '[]',
    commentStyle: '--',
    specialFeatures: {
      topClause: 'TOP',
      pagination: 'OFFSET-FETCH',
      temporalTables: true,
      windowFunctions: true
    }
  },
  sqlite: {
    keywords: ['SELECT', 'FROM', 'WHERE', 'CREATE', 'ALTER'],
    identifierQuotes: '"',
    commentStyle: '-- ',
  },
} as const;

// Add SQL patterns and features
const SQL_PATTERNS = {
  common: {
    basic: /^(?:SELECT|INSERT|UPDATE|DELETE|MERGE|WITH|CREATE|ALTER)/i,
    select: /SELECT\s+[\s\S]+?\s+FROM/i,
    insert: /INSERT\s+INTO/i,
    update: /UPDATE\s+\w+\s+SET/i,
    delete: /DELETE\s+FROM/i,
    create: /CREATE\s+(?:TABLE|VIEW|INDEX|PROCEDURE|FUNCTION)/i,
    alter: /ALTER\s+(?:TABLE|VIEW|INDEX|PROCEDURE|FUNCTION)/i
  },
  
  dialect: {
    postgresql: [
      /WITH\s+\w+\s+AS\s*\(/i,                    // CTEs
      /OVER\s*\([^)]*\)/i,                        // Window functions
      /DATE_TRUNC\(['"][^)]+['"]/i,               // Date functions
      /EXTRACT\s*\([^)]+\)/i,                     // Extract
      /ROW_NUMBER\s*\(\s*\)/i,                    // Row numbering
      /LATERAL/i,                                 // Lateral joins
      /JSONB?_/i,                                 // JSON operations
      /@>/i,                                      // Contains operator
      /CREATE\s+EXTENSION/i,                      // Extensions
      /CREATE\s+TYPE/i                            // Custom types
    ],
    // ...other dialect patterns as defined...
  }
};

const DIALECT_FEATURES = {
  postgresql: {
    windowFunctions: true,
    ctes: true,
    jsonSupport: true,
    arraySupport: true,
    customTypes: true,
    extensions: true,
    parallelQueries: true,
    fullTextSearch: true,
    foreignDataWrappers: true,
    materializedViews: true
  },
  // ...other dialect features as defined...
} as const;

// Add SQL query templates
const QUERY_TEMPLATES = {
  postgresql: {
    analyze: 'EXPLAIN (FORMAT JSON, ANALYZE, BUFFERS) ',
    optimize: 'SET enable_seqscan = off; SET random_page_cost = 1.1;',
    indexCheck: `
      SELECT schemaname, tablename, indexname, idx_scan, idx_tup_read, idx_tup_fetch
      FROM pg_stat_user_indexes
      WHERE idx_scan = 0 AND schemaname = $1
    `
  },
  // ...other dialect templates...
};

// Enhanced SQL Pattern Detection
const ADVANCED_SQL_PATTERNS = {
  performanceRisks: {
    cartesianJoin: /FROM\s+([^\s]+\s*,\s*[^\s]+\s*)(WHERE|GROUP|ORDER|LIMIT|$)/i,
    unboundedWildcard: /LIKE\s+['"]%[^%]*['"]/i,
    implicitConversion: /([^\s]+)\s*([=<>])\s*['"][^'"]*['"]/i
  },
  optimization: {
    missingIndex: /WHERE\s+([^\s]+)\s*([=<>])/i,
    suboptimalJoin: /LEFT\s+JOIN.*ON\s+[^=]+=\s*NULL/i,
    inefficientGrouping: /GROUP\s+BY\s+[^)]+(ORDER|LIMIT|$)/i
  }
};

function buildSQLPrompt(
  description: string,
  dialect: SQLDialect,
  schema?: string,
  features?: OptimizationFeatures
): string {
  const dialectConfig = DIALECT_CONFIGS[dialect];
  const dialectFeatures = getSQLDialectFeatures(dialect);
  
  if (!dialectConfig) {
    throw new Error(`Unsupported dialect: ${dialect}`);
  }

  const featuresList = Object.entries(dialectFeatures)
    .filter(([, enabled]) => enabled)
    .map(([feature]) => `- ${feature}`)
    .join('\n');

  // Add template suggestions for dashboard queries
  if (description.toLowerCase().includes('dashboard') || 
      description.toLowerCase().includes('performance') ||
      description.toLowerCase().includes('analytics')) {
    const template = getDashboardTemplate(dialect);
    return `You are an expert ${dialect.toUpperCase()} developer.
Please generate a comprehensive sales dashboard query based on:

SCHEMA:
${schema || 'No schema provided'}

TASK:
${description}

Here's a template to help structure the query:
${template}

REQUIREMENTS:
1. Use proper ${dialect} syntax and features
2. Include rolling averages for trend analysis
3. Calculate year-over-year comparisons
4. Add performance metrics by category and region
5. Ensure proper date handling and aggregations

Return the response in this exact JSON format:
{
  "query": "-- Your ${dialect} query here\n...",
  "explanation": "Detailed explanation of the dashboard metrics",
  "optimizations": {
    "indexRecommendations": ["Recommended indexes for performance"],
    "queryPlan": "Execution plan details",
    "partitioningStrategy": "Partitioning recommendations for large datasets",
    "replicationSetup": "Replication suggestions for read performance"
  }
}`;
  }

  // Add dialect-specific examples and hints
  const dialectHints = DIALECT_OPTIMIZERS[dialect]?.hints || [];
  const hintsList = dialectHints.map(hint => `- ${hint}`).join('\n');

  if (dialect === 'mssql') {
    // Check if it's a partitioning-related query
    if (description.toLowerCase().includes('partition') || 
        description.toLowerCase().includes('archiv')) {
      const template = getMSSQLTemplate('partitioning');
      return `You are an expert SQL Server developer. Generate a T-SQL partitioning solution that:

SCHEMA:
${schema || 'No schema provided'}

TASK:
${description}

Use this template as a reference:
${template}

REQUIREMENTS:
1. Create appropriate partition functions and schemes
2. Set up partitioned tables with correct clustering keys
3. Implement archival strategy with sliding window
4. Include maintenance procedures
5. Add monitoring capabilities
6. Use proper file groups for different partitions
7. Implement error handling and transaction management
8. Consider data retention policies

Return a complete solution in this JSON format:
{
  "query": "-- SQL Server Partitioning Solution\n<complete implementation>",
  "explanation": "Detailed explanation of the partitioning strategy",
  "optimizations": {
    "indexRecommendations": [
      "Aligned indexes needed for partitioned tables",
      "Additional indexes for query performance"
    ],
    "partitioningStrategy": "Detailed partitioning approach and maintenance plan",
    "maintenancePlan": "Schedule and procedures for partition maintenance",
    "monitoringStrategy": "How to monitor partition usage and performance"
  }
}`;
    }

    return `You are an expert SQL Server developer. Generate a T-SQL query based on:

SCHEMA:
${schema || 'No schema provided'}

TASK:
${description}

REQUIREMENTS:
1. Use proper T-SQL syntax and SQL Server specific features
2. Format query for readability
3. Include performance optimizations
4. Use appropriate SQL Server functions
5. Consider query execution plan

Return the response in this exact JSON format:
{
  "query": "-- Your T-SQL query here\nSELECT ...",
  "explanation": "Detailed explanation of how the query works",
  "optimizations": {
    "indexRecommendations": ["Index recommendation 1", "Index recommendation 2"],
    "queryPlan": "Execution plan details",
    "partitioningStrategy": "Partitioning recommendations if applicable",
    "replicationSetup": "Replication suggestions if needed"
  }
}

Focus on generating a valid T-SQL query that follows SQL Server best practices.`;
  }

  if (dialect === 'postgresql') {
    return `You are an expert PostgreSQL developer. Generate a PostgreSQL query that solves:

TASK:
${description}

${schema ? `SCHEMA:\n${schema}\n` : ''}

IMPORTANT POSTGRESQL SYNTAX REQUIREMENTS:
1. Use double quotes (") for identifiers, not square brackets or backticks
2. Use proper PostgreSQL type casting with ::
3. Use $1, $2, etc. for parameters
4. Follow PostgreSQL date/time syntax: INTERVAL '1 day'
5. Use proper PostgreSQL functions and operators

FEATURES TO USE:
- Common Table Expressions (WITH queries)
- Window functions with PARTITION BY and ORDER BY
- Proper aggregation functions
- PostgreSQL-specific functions
- Appropriate indexes and constraints

Return the response in this exact JSON format:
{
  "query": "-- PostgreSQL query\nWITH ....",
  "explanation": "Step by step explanation",
  "optimizations": {
    "indexRecommendations": ["index details"],
    "queryPlan": "execution plan",
    "partitioningStrategy": "partitioning approach"
  }
}`;
  }

  return `You are an expert ${dialect.toUpperCase()} database developer.
Available features:
${featuresList}

TASK:
${description}

${schema ? `SCHEMA:\n${schema}\n` : ''}

REQUIREMENTS:
- Use proper ${dialect} syntax and features
- Follow ${dialect} naming conventions
- Use ${dialectConfig.identifierQuotes} for identifiers when needed
- Include appropriate indexes and optimizations
${features?.indexDesign ? '- Include detailed index recommendations' : ''}
${features?.queryTuning ? '- Add performance optimization suggestions' : ''}
${features?.partitioning ? '- Provide partitioning strategy if applicable' : ''}
${features?.replication ? '- Include replication configuration if needed' : ''}

Return results in this JSON format:
{
  "query": "Your SQL query here",
  "explanation": "Detailed explanation of the query",
  "optimizations": {
    "indexRecommendations": ["index suggestions"],
    "queryPlan": "execution plan details",
    "partitioningStrategy": "partitioning details",
    "replicationSetup": "replication configuration"
  }
}`;
}

function parseOllamaResponse(response: string, dialect: SQLDialect): SQLGenerationResult {
  // Try JSON parsing first
  try {
    const jsonMatches = response.match(/\{[\s\S]*\}/g) || [];
    for (const match of jsonMatches) {
      try {
        const parsed = JSON.parse(match);
        if (parsed.query && typeof parsed.query === 'string') {
          return {
            query: parsed.query.trim(),
            explanation: parsed.explanation,
            optimizations: parsed.optimizations
          };
        }
      } catch (e) {
        continue;
      }
    }
  } catch (error) {
    console.log('JSON parsing failed, trying code block extraction...');
  }

  // Extract SQL code blocks with flexible matching
  const codeBlockPatterns = [
    /```(?:sql|tsql|mssql)\n([\s\S]+?)\n```/,
    /```\n([\s\S]+?)\n```/,
    /Query:\s*([\s\S]+?)(?=Explanation:|Optimizations:|$)/i
  ];

  for (const pattern of codeBlockPatterns) {
    const match = response.match(pattern);
    if (match && match[1]) {
      const query = match[1].trim();
      if (isValidDialectQuery(query, dialect)) {
        return {
          query,
          explanation: extractExplanation(response),
          optimizations: extractOptimizations(response)
        };
      }
    }
  }

  // More lenient SQL extraction as fallback
  const sqlStatements = response.match(/(?:SELECT|INSERT|UPDATE|DELETE|MERGE|WITH|CREATE|ALTER)[\s\S]+?(?=(?:SELECT|INSERT|UPDATE|DELETE|MERGE|WITH|CREATE|ALTER)|$)/gi);
  
  if (sqlStatements) {
    for (const stmt of sqlStatements) {
      if (isValidDialectQuery(stmt.trim(), dialect)) {
        return {
          query: stmt.trim(),
          explanation: extractExplanation(response),
          optimizations: extractOptimizations(response)
        };
      }
    }
  }

  throw new Error(`Could not find valid ${dialect} query in response`);
}

function isValidDialectQuery(query: string, dialect: SQLDialect): boolean {
  if (!query || typeof query !== 'string') return false;

  // Use specific validators for each dialect
  switch (dialect) {
    case 'postgresql':
      return isValidPostgreSQLQuery(query);
    case 'oracle':
      return isValidOracleQuery(query);
    case 'mysql':
      return isValidMySQLQuery(query);
    case 'sqlite':
      return isValidSQLiteQuery(query);
    case 'mssql':
      // ... existing SQL Server validation ...
      break;
  }

  // Fallback to generic validation
  const normalizedQuery = query.trim().toUpperCase();
  
  // Check common patterns first
  if (!SQL_PATTERNS.common.basic.test(normalizedQuery)) return false;

  const commonValidation = Object.values(SQL_PATTERNS.common).some(pattern => 
    pattern.test(normalizedQuery)
  );

  const dialectPatterns = SQL_PATTERNS.dialect[dialect] || [];
  const dialectValidation = dialectPatterns.some(pattern => 
    pattern.test(query)
  );

  // Additional dialect-specific validations
  const extraValidations: Record<SQLDialect, (q: string) => boolean> = {
    postgresql: (q) => /\$\d+/.test(q) || /::\w+/.test(q),
    mysql: (q) => /COLLATE\s+\w+/.test(q),
    sqlite: (q) => /SELECT\s+changes\(\)/.test(q),
    mssql: (q) => /@\w+\s*=/.test(q) || /\;\s*GO\b/.test(q),
    oracle: (q) => /:\w+/.test(q) || /SELECT\s+\*\s+FROM\s+USER_/.test(q)
  };

  return commonValidation || dialectValidation || extraValidations[dialect]?.(query) || false;
}

function extractExplanation(response: string): string | undefined {
  const explanationMatch = response.match(/Explanation:\s*([\s\S]*?)(?=Optimizations:|$)/i);
  return explanationMatch ? explanationMatch[1].trim() : undefined;
}

function extractOptimizations(response: string): SQLGenerationResult['optimizations'] | undefined {
  const optimizationsMatch = response.match(/Optimizations:\s*([\s\S]*?)$/i);
  if (!optimizationsMatch) return undefined;

  const optimizationsText = optimizationsMatch[1];
  return {
    indexRecommendations: extractListItems(optimizationsText, 'Index Recommendations:'),
    queryPlan: extractSection(optimizationsText, 'Query Plan:'),
    partitioningStrategy: extractSection(optimizationsText, 'Partitioning Strategy:'),
    replicationSetup: extractSection(optimizationsText, 'Replication Setup:')
  };
}

function extractListItems(text: string, section: string): string[] | undefined {
  const sectionMatch = text.match(new RegExp(`${section}\\s*([\\s\\S]*?)(?=\\n\\s*\\w+:|$)`));
  if (!sectionMatch) return undefined;
  
  return sectionMatch[1]
    .split('\n')
    .map(line => line.replace(/^[-*]\s*/, '').trim())
    .filter(line => line.length > 0);
}

function extractSection(text: string, section: string): string | undefined {
  const sectionMatch = text.match(new RegExp(`${section}\\s*([\\s\\S]*?)(?=\\n\\s*\\w+:|$)`));
  return sectionMatch ? sectionMatch[1].trim() : undefined;
}

async function generateWithOllama(
  prompt: string,
  modelId: string,
  dialect: SQLDialect,
  onProgress?: ProgressCallback
): Promise<SQLGenerationResult> {
  let responseData: any;
  
  try {
    onProgress?.({
      [modelId]: { modelId, status: 'processing', progress: 0 }
    });

    const response = await fetch(`${ENV_CONFIG.OLLAMA_API_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: modelId,
        prompt,
        stream: false,
        options: {
          temperature: 0.2,
          top_p: 0.95
        }
      })
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    responseData = await response.json();
    if (!responseData.response) {
      throw new Error('Empty response from API');
    }

    const result = parseOllamaResponse(responseData.response, dialect);
    
    // Add debug logging
    console.log('Generated Query:', result.query);
    console.log('Dialect:', dialect);
    console.log('Validation result:', isValidDialectQuery(result.query, dialect));

    if (!isValidDialectQuery(result.query, dialect)) {
      throw new Error(`Generated query does not match ${dialect.toUpperCase()} syntax`);
    }

    // Apply dialect-specific optimizations
    if (DIALECT_OPTIMIZERS[dialect]) {
      result.query = DIALECT_OPTIMIZERS[dialect].rewriteQuery(result.query);
    }
    
    onProgress?.({
      [modelId]: { 
        modelId, 
        status: 'completed', 
        progress: 100,
        result 
      }
    });
    
    return result;
  } catch (error) {
    console.error('Generation error:', error);
    console.log('Raw response:', responseData?.response || 'No response data');
    
    onProgress?.({
      [modelId]: {
        modelId,
        status: 'error',
        progress: 0,
        error: error instanceof Error ? error.message : 'Unknown error'
      }
    });
    
    throw new Error(
      error instanceof Error 
        ? `Failed to generate SQL: ${error.message}`
        : 'Failed to generate SQL query'
    );
  }
}

async function generateWithGemini(
  prompt: string,
  modelId: string,
  dialect: SQLDialect,
  onProgress?: ProgressCallback
): Promise<SQLGenerationResult> {
  try {
    if (!ENV_CONFIG.GOOGLE_API_KEY) {
      throw new Error('Google API key not configured');
    }

    onProgress?.({
      [modelId]: { modelId, status: 'processing', progress: 0 }
    });

    const genAI = new GoogleGenerativeAI(ENV_CONFIG.GOOGLE_API_KEY);
    const model = genAI.getGenerativeModel({ model: modelId });

    const result = await model.generateContent(prompt);
    const responseText = result.response.text();

    const parsedResult = parseOllamaResponse(responseText, dialect);

    onProgress?.({
      [modelId]: { modelId, status: 'completed', progress: 100, result: parsedResult }
    });

    return parsedResult;
  } catch (error) {
    console.error('Gemini SQL generation failed:', error);
    onProgress?.({
      [modelId]: {
        modelId,
        status: 'error',
        progress: 0,
        error: error instanceof Error ? error.message : 'Unknown error'
      }
    });
    throw error;
  }
}

export async function generateSQL({
  description,
  tableSchema,
  dialect,
  optimizationFeatures,
  modelId,
  onProgress
}: {
  description: string;
  tableSchema?: string;
  dialect: SQLDialect;
  optimizationFeatures: OptimizationFeatures;
  modelId: string;
  onProgress?: (progress: Record<string, EnhancedSQLProgress>) => void;
}): Promise<Record<string, SQLGenerationResult>> {
  const prompt = buildSQLPrompt(
    description,
    dialect,
    tableSchema,
    optimizationFeatures
  );

  try {
    let result: SQLGenerationResult;
    if (modelId.startsWith('gemini')) {
      result = await generateWithGemini(prompt, modelId, dialect, onProgress);
    } else {
      result = await generateWithOllama(prompt, modelId, dialect, onProgress);
    }

    return { [modelId]: result };

  } catch (error) {
    console.error('SQL generation failed:', error);
    throw error;
  }
}

function getSQLDialectFeatures(dialect: SQLDialect) {
  return DIALECT_FEATURES[dialect] || {};
}
