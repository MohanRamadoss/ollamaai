export interface AIApiOptions {
  temperature?: number;
  topP?: number;
  topK?: number;
  maxTokens?: number;
  stream?: boolean;
}

export interface AIApiResponse {
  text: string;
  usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  model: string;
  created: number;
}

export interface AIApiError extends Error {
  code?: string;
  status?: number;
  retryable?: boolean;
}
