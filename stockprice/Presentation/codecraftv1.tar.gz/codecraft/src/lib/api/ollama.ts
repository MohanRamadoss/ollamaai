import { ENV_CONFIG } from '../../config/env';
import { AIApiOptions, AIApiResponse, AIApiError } from './types';

export class OllamaAPI {
  private baseUrl: string;
  private defaultOptions: AIApiOptions = {
    temperature: 0.7,
    topP: 0.9,
    topK: 40,
    maxTokens: 2048,
    stream: false
  };

  constructor(baseUrl = ENV_CONFIG.OLLAMA_API_URL) {
    this.baseUrl = baseUrl;
  }

  async generate(
    modelId: string, 
    prompt: string, 
    options: AIApiOptions = {}
  ): Promise<AIApiResponse> {
    try {
      const cleanModelId = modelId.replace('ollama/', '');
      const response = await fetch(`${this.baseUrl}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: cleanModelId,
          prompt,
          options: { ...this.defaultOptions, ...options }
        })
      });

      if (!response.ok) {
        const error: AIApiError = new Error(`HTTP error! status: ${response.status}`);
        error.status = response.status;
        error.retryable = response.status >= 500;
        throw error;
      }

      const data = await response.json();
      
      if (!data.response) {
        throw new Error('Empty response from model');
      }

      return {
        text: data.response,
        model: cleanModelId,
        created: Date.now(),
        usage: {
          promptTokens: data.prompt_eval_count || 0,
          completionTokens: data.eval_count || 0,
          totalTokens: (data.prompt_eval_count || 0) + (data.eval_count || 0)
        }
      };
    } catch (error) {
      console.error('[OllamaAPI] Error:', error);
      throw error;
    }
  }

  async getModels(): Promise<string[]> {
    try {
      const response = await fetch(`${this.baseUrl}/api/tags`);
      if (!response.ok) {
        throw new Error(`Failed to get models: ${response.status}`);
      }
      const data = await response.json();
      return data.models?.map((model: any) => model.name) || [];
    } catch (error) {
      console.error('[OllamaAPI] Error getting models:', error);
      throw error;
    }
  }
}

export const ollama = new OllamaAPI();

const OLLAMA_API_URL = ENV_CONFIG.OLLAMA_API_URL || 'http://localhost:11434';

interface OllamaResponse {
  model: string;
  created_at: string;
  response: string;
  done: boolean;
}

export async function generateWithOllama(
  prompt: string,
  modelId: string,
  options: AIApiOptions = {}
): Promise<string> {
  try {
    // Extract the model name from modelId (e.g., 'ollama/codellama:13b' -> 'codellama:13b')
    const modelName = modelId.replace('ollama/', '');

    const response = await fetch(`${OLLAMA_API_URL}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: modelName,
        prompt: prompt,
        stream: false,
        options: {
          temperature: options.temperature ?? 0.7,
          top_p: options.topP ?? 0.9,
          top_k: options.topK ?? 40,
          num_predict: options.maxTokens ?? 2048,
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.statusText}`);
    }

    const result: OllamaResponse = await response.json();
    
    if (!result.response) {
      throw new Error('Empty response from Ollama');
    }

    return result.response;
  } catch (error) {
    console.error('[Ollama] Generation failed:', error);
    throw new Error(`Failed to generate with Ollama: ${error.message}`);
  }
}

// Add streaming version if needed
export async function generateWithOllamaStream(
  prompt: string,
  modelId: string,
  options: AIApiOptions = {},
  onProgress?: (text: string) => void
): Promise<string> {
  try {
    const modelName = modelId.replace('ollama/', '');
    const response = await fetch(`${OLLAMA_API_URL}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: modelName,
        prompt: prompt,
        stream: true,
        options: {
          temperature: options.temperature ?? 0.7,
          top_p: options.topP ?? 0.9,
          top_k: options.topK ?? 40,
          num_predict: options.maxTokens ?? 2048,
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.statusText}`);
    }

    if (!response.body) {
      throw new Error('Response body is null');
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      try {
        const lines = chunk.split('\n').filter(line => line.trim());
        for (const line of lines) {
          const data: OllamaResponse = JSON.parse(line);
          fullText += data.response;
          onProgress?.(fullText);
        }
      } catch (e) {
        console.warn('Failed to parse chunk:', e);
      }
    }

    return fullText;
  } catch (error) {
    console.error('[Ollama Stream] Generation failed:', error);
    throw new Error(`Failed to generate with Ollama stream: ${error.message}`);
  }
}
