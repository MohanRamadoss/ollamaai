import { MODEL_CONFIGS } from '../../config/models';

export function getFallbackModels(modelId: string): string[] {
  const config = MODEL_CONFIGS[modelId];
  if (!config) return [];
  
  // Get fallbacks that are actually configured
  return config.fallbacks.filter(id => MODEL_CONFIGS[id]);
}

export function getNextModel(currentModel: string, attemptedModels: string[] = []): string | null {
  const fallbacks = getFallbackModels(currentModel)
    .filter(id => !attemptedModels.includes(id));
    
  return fallbacks[0] || null;
}
