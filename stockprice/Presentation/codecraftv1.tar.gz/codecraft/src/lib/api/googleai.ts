import { GoogleGenerativeAI } from '@google/generative-ai';
import { ENV_CONFIG } from '../../config/env';
import { AIApiOptions, AIApiResponse, AIApiError } from './types';

export class GoogleAI {
  private client: GoogleGenerativeAI;
  private defaultOptions: AIApiOptions = {
    temperature: 0.7,
    topP: 0.9,
    topK: 40,
    maxTokens: 8192
  };

  constructor(apiKey = ENV_CONFIG.GOOGLE_API_KEY) {
    if (!apiKey) {
      throw new Error('Google API key not configured');
    }
    this.client = new GoogleGenerativeAI(apiKey);
  }

  async generate(
    modelId: string,
    prompt: string,
    options: AIApiOptions = {}
  ): Promise<AIApiResponse> {
    try {
      const geminiModelId = modelId === 'gemini-pro-code' ? 'gemini-pro' : modelId;
      
      const model = this.client.getGenerativeModel({
        model: geminiModelId,
        ...options
      });

      const result = await model.generateContent({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: options.temperature ?? this.defaultOptions.temperature,
          topK: options.topK ?? this.defaultOptions.topK,
          topP: options.topP ?? this.defaultOptions.topP,
          maxOutputTokens: options.maxTokens ?? this.defaultOptions.maxTokens,
        }
      });

      const response = await result.response;
      const text = response.text();

      if (!text) {
        throw new Error('Empty response from Gemini');
      }

      return {
        text,
        model: geminiModelId,
        created: Date.now(),
        usage: {
          promptTokens: 0,
          completionTokens: 0,
          totalTokens: 0
        }
      };
    } catch (error: any) {
      console.error('[GoogleAI] Error:', error);
      const apiError: AIApiError = new Error(error.message);
      apiError.code = error.code;
      apiError.retryable = error.code === 'RESOURCE_EXHAUSTED';
      throw apiError;
    }
  }
}

export const googleai = new GoogleAI();
