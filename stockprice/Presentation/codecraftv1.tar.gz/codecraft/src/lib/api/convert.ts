import { generateWithOpenAI } from '../ai/openai';
import { ENV_CONFIG } from '../../config/env';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { MODEL_CONFIGS, AI_MODELS } from '../../config/models';
import { LANGUAGES, PROGRAMMING_LANGUAGES } from '../../config/languages';
import type { GenerationRequest, ComplexityLevel } from '../../types/models';

interface ProgrammingLanguage {
  id: string;
  name: string;
  features: string[];
  extension: string;
  category?: string;
}

export type ConversionProgress = {
  modelId: string;
  status: 'pending' | 'converting' | 'completed' | 'failed';
  progress: number;
  result?: string;
  error?: string;
  provider?: string;
};

export interface ConversionParams {
  temperature?: number;
  topP?: number;
  topK?: number;
  maxTokens?: number;
  safetySettings?: Array<{
    category: string;
    threshold: string;
  }>;
}

export interface ExtendedGenerationRequest extends GenerationRequest {
  modelParams?: ConversionParams;
}

export type ProgressCallback = (progress: Record<string, ConversionProgress>) => void;

function createConversionPrompt(
  sourceCode: string,
  sourceLanguage: string,
  targetLanguage: string,
  complexity: ComplexityLevel
): string {
  // Try to get language info from both configurations
  const sourceLangProg = PROGRAMMING_LANGUAGES[sourceLanguage];
  const targetLangProg = PROGRAMMING_LANGUAGES[targetLanguage];
  const sourceLangBasic = LANGUAGES[sourceLanguage as keyof typeof LANGUAGES];
  const targetLangBasic = LANGUAGES[targetLanguage as keyof typeof LANGUAGES];

  // Use PROGRAMMING_LANGUAGES if available, fall back to LANGUAGES
  const sourceLang = sourceLangProg || { 
    id: sourceLanguage,
    name: sourceLangBasic?.name || sourceLanguage,
    features: [],
    extension: sourceLangBasic?.fileExtension || sourceLanguage
  };
  
  const targetLang = targetLangProg || {
    id: targetLanguage,
    name: targetLangBasic?.name || targetLanguage,
    features: [],
    extension: targetLangBasic?.fileExtension || targetLanguage
  };

  if (!sourceLangBasic && !sourceLangProg || !targetLangBasic && !targetLangProg) {
    throw new Error(`Unsupported language combination: ${sourceLanguage} -> ${targetLanguage}`);
  }

  // Handle special cases for configuration management languages
  if (targetLang.category === 'config') {
    switch (targetLanguage) {
      case 'ansible':
        if (sourceLanguage === 'shell' || sourceLanguage === 'bash') {
          return createShellToAnsiblePrompt(sourceCode);
        }
        return createConfigManagementPrompt(sourceCode, sourceLang, targetLang, 'ansible');
      case 'terraform':
        return createConfigManagementPrompt(sourceCode, sourceLang, targetLang, 'terraform');
      case 'powershell':
        if (sourceLanguage === 'shell' || sourceLanguage === 'bash') {
          return createShellToPowerShellPrompt(sourceCode);
        }
        return createConfigManagementPrompt(sourceCode, sourceLang, targetLang, 'powershell');
    }
  }

  return `You are an expert code converter. Convert the following ${sourceLang?.name} code to ${targetLang?.name}.

SOURCE CODE:
\`\`\`${sourceLanguage}
${sourceCode}
\`\`\`

REQUIREMENTS:
1. Convert to ${targetLang?.name} using best practices
2. Maintain exact functionality
3. Add proper error handling
4. Include comprehensive comments
5. Follow ${targetLang?.name} conventions
6. Complexity level: ${complexity}

Return ONLY the converted code wrapped in a code block:
\`\`\`${targetLanguage}
[Your converted code here]
\`\`\``;
}

function createConfigManagementPrompt(
  sourceCode: string,
  sourceLang: ProgrammingLanguage,
  targetLang: ProgrammingLanguage,
  platform: 'ansible' | 'terraform' | 'powershell'
): string {
  const platformSpecifics = {
    ansible: {
      format: 'YAML',
      extension: 'yml',
      concepts: ['playbooks', 'roles', 'modules', 'tasks', 'handlers'],
      bestPractices: [
        'Use appropriate modules over shell/command',
        'Implement proper error handling',
        'Use variables and facts',
        'Follow idempotency principles',
        'Include proper documentation'
      ]
    },
    terraform: {
      format: 'HCL',
      extension: 'tf',
      concepts: ['providers', 'resources', 'data sources', 'modules', 'state'],
      bestPractices: [
        'Use proper resource naming',
        'Implement state management',
        'Use variables and outputs',
        'Follow resource dependency patterns',
        'Include proper documentation'
      ]
    },
    powershell: {
      format: 'PowerShell',
      extension: 'ps1',
      concepts: ['cmdlets', 'functions', 'modules', 'scripts', 'workflows'],
      bestPractices: [
        'Use proper error handling',
        'Follow PowerShell naming conventions',
        'Implement parameter validation',
        'Use proper scoping',
        'Include proper documentation'
      ]
    }
  };

  const spec = platformSpecifics[platform];
  
  return `Convert the following ${sourceLang.name} code to ${targetLang.name}:

SOURCE CODE:
\`\`\`${sourceLang.id}
${sourceCode}
\`\`\`

PLATFORM SPECIFICS:
- Target Format: ${spec.format}
- Key Concepts: ${spec.concepts.join(', ')}

REQUIREMENTS:
1. Create proper ${platform} structure
2. Use appropriate ${platform} constructs
3. Maintain the same functionality
4. Follow these best practices:
${spec.bestPractices.map(bp => `   - ${bp}`).join('\n')}
5. Handle errors and edge cases
6. Add comprehensive comments

Return ONLY the converted code in a code block:
\`\`\`${spec.extension}
[Your converted code here]
\`\`\``;
}

function createShellToAnsiblePrompt(shellScript: string): string {
  return `Convert this shell script to Ansible playbook:

SOURCE SHELL SCRIPT:
\`\`\`bash
${shellScript}
\`\`\`

REQUIREMENTS:
1. Create a proper Ansible playbook structure
2. Use appropriate Ansible modules instead of direct shell commands:
   - Use 'apt' or 'yum' for package management
   - Use 'service' for service management
   - Use 'file' for file operations
   - Use 'template' for file templating
   - Use 'command' or 'shell' only when necessary
3. Maintain the same functionality
4. Include proper error handling and checks
5. Add helpful comments and descriptions
6. Follow Ansible best practices:
   - Make tasks idempotent
   - Use meaningful names for tasks
   - Group related tasks
   - Use variables when appropriate
   - Handle errors gracefully

Return ONLY the Ansible playbook code in YAML format:
\`\`\`yaml
[Your ansible playbook here]
\`\`\``;
}

function createShellToPowerShellPrompt(shellScript: string): string {
  return `Convert this shell script to PowerShell:

SOURCE SHELL SCRIPT:
\`\`\`bash
${shellScript}
\`\`\`

REQUIREMENTS:
1. Use PowerShell best practices and idioms
2. Convert shell commands to appropriate PowerShell cmdlets:
   - Use 'Get-Process', 'Start-Process' for process management
   - Use 'Get-Service', 'Start-Service' for services
   - Use 'Get-Item', 'Set-Item' for file operations
   - Use proper error handling with try/catch
3. Maintain the same functionality
4. Include error handling and input validation
5. Add comprehensive comments
6. Follow PowerShell conventions:
   - Use approved verbs
   - Use proper parameter names
   - Implement proper pipeline support
   - Use proper variable scope

Return ONLY the PowerShell code in a code block:
\`\`\`powershell
[Your converted code here]
\`\`\``;
}

function extractCodeFromResponse(response: string, targetLanguage: string): string {
  // First try to find a code block with language identifier
  const codeBlockRegex = new RegExp(`\`\`\`(?:${targetLanguage})?\n([\\s\\S]*?)\`\`\``, 'i');
  const match = response.match(codeBlockRegex);
  
  if (match) {
    return match[1].trim();
  }

  // If no code block found, try to clean the response
  const lines = response.split('\n').filter(line => 
    !line.startsWith('Here') && 
    !line.startsWith('This') &&
    !line.includes('example:') &&
    line.trim().length > 0
  );

  return lines.join('\n').trim();
}

async function convertWithOllama(
  request: GenerationRequest,
  onProgress?: ProgressCallback
): Promise<string> {
  const { modelIds, prompt: sourceCode, sourceLanguage, targetLanguage, complexity } = request;
  const modelId = modelIds[0];

  try {
    onProgress?.({
      [modelId]: {
        modelId,
        status: 'converting',
        progress: 0,
        result: ''
      }
    });

    const prompt = createConversionPrompt(
      sourceCode,
      sourceLanguage,
      targetLanguage!,
      complexity
    );

    // Add error handling for Ollama connection
    try {
      const modelCheckResponse = await fetch(`${ENV_CONFIG.OLLAMA_API_URL}/api/tags`);
      if (!modelCheckResponse.ok) {
        throw new Error(`Ollama API not available: ${modelCheckResponse.status}`);
      }
    } catch (error) {
      throw new Error(`Failed to connect to Ollama: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    const response = await fetch(`${ENV_CONFIG.OLLAMA_API_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: modelId.replace('ollama/', ''),
        prompt,
        options: {
          temperature: request.temperature || 0.7,
          top_p: request.topP || 0.9,
          top_k: request.topK || 40,
        },
        stream: false
      })
    });

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.status}`);
    }

    const data = await response.json();
    if (!data || !data.response) {
      throw new Error('Empty response from Ollama');
    }

    const result = extractCodeFromResponse(data.response, targetLanguage!);

    onProgress?.({
      [modelId]: {
        modelId,
        status: 'completed',
        progress: 100,
        result
      }
    });

    return result;
  } catch (error) {
    console.error(`Ollama conversion error for ${modelId}:`, error);
    
    onProgress?.({
      [modelId]: {
        modelId,
        status: 'failed',
        progress: 0,
        error: error instanceof Error ? error.message : 'Unknown error'
      }
    });
    
    throw error;
  }
}

// Local implementation of generateWithGemini
async function generateWithGemini(
  prompt: string,
  modelId: string,
  params: ConversionParams = {}
): Promise<string> {
  console.log(`[Gemini] Starting conversion with ${modelId}`);

  if (!ENV_CONFIG.GOOGLE_API_KEY) {
    throw new Error('Google API key not configured');
  }

  try {
    const genAI = new GoogleGenerativeAI(ENV_CONFIG.GOOGLE_API_KEY);
    const model = genAI.getGenerativeModel({ 
      model: MODEL_CONFIGS[modelId]?.modelName || modelId
    });

    const result = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: params.temperature ?? 0.7,
        topK: params.topK ?? 40,
        topP: params.topP ?? 0.8,
        maxOutputTokens: params.maxTokens ?? 8192,
      }
    });

    if (!result.response) {
      throw new Error('Empty response from Gemini');
    }

    const text = result.response.text();
    if (!text) {
      throw new Error('Empty text in Gemini response');
    }

    console.log(`[Gemini] Conversion completed successfully`);
    return text;

  } catch (error: any) {
    console.error(`[Gemini] Conversion error:`, error);
    throw new Error(`Gemini API error: ${error.message}`);
  }
}

export async function convertCode(
  request: ExtendedGenerationRequest,
  onProgress?: ProgressCallback
): Promise<string> {
  const { modelIds, sourceLanguage, targetLanguage } = request;

  if (!modelIds?.length) {
    throw new Error('At least one model must be selected');
  }

  // Initialize progress for all models
  modelIds.forEach(modelId => {
    onProgress?.({
      [modelId]: {
        modelId,
        status: 'pending',
        progress: 0,
        result: ''
      }
    });
  });

  const apiKey = import.meta.env.VITE_GOOGLE_API_KEY;
  if (!apiKey) {
    throw new Error('Google API key is not configured');
  }

  // Initialize Gemini
  const genAI = new GoogleGenerativeAI(apiKey);

  try {
    // Process all models concurrently
    const results = await Promise.allSettled(
      modelIds.map(async (modelId) => {
        try {
          onProgress?.({
            [modelId]: {
              modelId,
              status: 'converting',
              progress: 10
            }
          });

          const config = MODEL_CONFIGS[modelId];
          if (!config) {
            throw new Error(`Invalid model: ${modelId}`);
          }

          let result: string;
          if (config.provider === 'google') {
            result = await generateWithGemini(
              createConversionPrompt(request.prompt, sourceLanguage, targetLanguage!, request.complexity),
              modelId,
              request.modelParams || {}
            );
          } else if (config.provider === 'ollama') {
            result = await convertWithOllama({
              ...request,
              modelIds: [modelId]
            });
          } else {
            result = await generateWithOpenAI(
              createConversionPrompt(request.prompt, sourceLanguage, targetLanguage!, request.complexity),
              modelId,
              request.modelParams || {}
            );
          }

          const extractedCode = extractCodeFromResponse(result, targetLanguage!);

          onProgress?.({
            [modelId]: {
              modelId,
              status: 'completed',
              progress: 100,
              result: extractedCode
            }
          });

          return { modelId, result: extractedCode };

        } catch (error) {
          onProgress?.({
            [modelId]: {
              modelId,
              status: 'failed',
              progress: 0,
              error: error instanceof Error ? error.message : 'Unknown error'
            }
          });
          throw error;
        }
      })
    );

    // Process results
    const successfulResults = results
      .filter((r): r is PromiseFulfilledResult<{modelId: string; result: string}> => 
        r.status === 'fulfilled' && Boolean(r.value?.result)
      )
      .map(r => r.value);

    if (successfulResults.length === 0) {
      const errors = results
        .filter((r): r is PromiseRejectedResult => r.status === 'rejected')
        .map(r => r.reason.message || 'Unknown error')
        .join('; ');
      throw new Error(`All models failed: ${errors}`);
    }

    // Return the most comprehensive result
    const bestResult = successfulResults.reduce((best, current) => 
      current.result.length > best.result.length ? current : best
    );

    return bestResult.result;
  } catch (error) {
    console.error('Conversion failed:', error);
    throw error;
  }
}