import { ENV_CONFIG } from '../../config/env';
import { logger } from '../utils/logger';

export interface HealthStatus {
  ollama: boolean;
  google: boolean;
  error?: string;
  models: {
    [key: string]: boolean;
  };
}

export async function checkOllamaHealth(): Promise<boolean> {
  logger.debug('Health', 'Checking Ollama API health');
  try {
    const response = await fetch(`${ENV_CONFIG.OLLAMA_API_URL}/api/version`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });
    const isHealthy = response.ok;
    logger.info('Health', `Ollama API health check: ${isHealthy ? 'OK' : 'Failed'}`);
    return isHealthy;
  } catch (error) {
    logger.error('Health', 'Ollama connection error', error);
    return false;
  }
}

export async function checkModelAvailability(modelId: string): Promise<boolean> {
  logger.debug('Health', `Checking availability for model: ${modelId}`);
  
  if (modelId.startsWith('gemini-')) {
    const hasKey = Boolean(ENV_CONFIG.GOOGLE_API_KEY);
    logger.info('Health', `Gemini API key ${hasKey ? 'present' : 'missing'}`);
    return hasKey;
  }

  try {
    const response = await fetch(`${ENV_CONFIG.OLLAMA_API_URL}/api/tags`);
    if (!response.ok) {
      logger.warn('Health', `Failed to get model list: ${response.status}`);
      return false;
    }
    const data = await response.json();
    const isAvailable = data.models?.some((model: any) => model.name === modelId) || false;
    logger.info('Health', `Model ${modelId} availability: ${isAvailable}`);
    return isAvailable;
  } catch (error) {
    logger.error(`[Health] Model check failed for ${modelId}:`, error);
    return false;
  }
}

async function checkGoogleApiHealth(): Promise<boolean> {
  logger.debug('Health', 'Checking Google API health');
  
  if (!ENV_CONFIG.GOOGLE_API_KEY) {
    logger.warn('Health', 'Google API key not configured');
    return false;
  }

  try {
    // Use the models.list endpoint to verify API access
    const response = await fetch(
      `${ENV_CONFIG.GOOGLE_API_URL}/models?key=${ENV_CONFIG.GOOGLE_API_KEY}`,
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        }
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      logger.error('Health', 'Google API error response', {
        status: response.status,
        statusText: response.statusText,
        error: errorText
      });
      return false;
    }

    const data = await response.json();
    const hasGeminiModel = data.models?.some((model: any) => 
      model.name.includes('gemini-pro')
    );

    logger.info('Health', `Google API check: ${hasGeminiModel ? 'OK' : 'Models not found'}`);
    return hasGeminiModel;

  } catch (error) {
    logger.error('Health', 'Google API connection error', error);
    return false;
  }
}

export async function checkApiHealth(): Promise<HealthStatus> {
  const [ollamaStatus, googleStatus] = await Promise.all([
    checkOllamaHealth(),
    checkGoogleApiHealth()
  ]);

  logger.info('Health', 'API Status', { 
    ollama: ollamaStatus, 
    google: googleStatus,
    googleApiUrl: ENV_CONFIG.GOOGLE_API_URL,
    hasGoogleKey: Boolean(ENV_CONFIG.GOOGLE_API_KEY)
  });

  return {
    ollama: ollamaStatus,
    google: googleStatus,
    models: {},
  };
}
