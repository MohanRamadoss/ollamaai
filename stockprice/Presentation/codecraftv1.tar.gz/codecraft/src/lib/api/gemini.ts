import { GoogleGenerativeAI } from '@google/generative-ai';
import { ENV_CONFIG } from '../../config/env';

interface GeminiParams {
  temperature?: number;
  topP?: number;
  maxTokens?: number;
  topK?: number;
}

export async function generateWithGemini(prompt: string, modelName: string, params: GeminiParams): Promise<string> {
  try {
    if (!ENV_CONFIG.GOOGLE_API_KEY) {
      throw new Error('Google API key not configured');
    }

    const genAI = new GoogleGenerativeAI(ENV_CONFIG.GOOGLE_API_KEY);
    const model = genAI.getGenerativeModel({ model: modelName });

    const result = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: params.temperature,
        topP: params.topP,
        maxOutputTokens: params.maxTokens,
        topK: params.topK
      }
    });

    return result.response.text();
  } catch (error) {
    console.error(`Gemini generation failed for model ${modelName}:`, error);
    throw error;
  }
}
