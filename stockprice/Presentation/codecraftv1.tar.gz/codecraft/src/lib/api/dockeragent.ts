import { generateWithGemini } from '../ai/gemini';
import { generateWithOllama } from '../ai/ollama';
import { logger } from '../../utils/logger/dockeragent';
import { DOCKER_CONFIG } from '../../config/dockeragent';
import type { DockerPromptParams, DockerAgentOptions, DockerAgentResponse } from '../../types/dockeragent';

// Docker operation prompts
const DOCKER_PROMPTS = {
  'LIST_CONTAINERS': (params: DockerPromptParams) => `
You are a Docker expert analyzing container data.
Based on this container data: ${JSON.stringify(params.data, null, 2)}

Return a JSON object with this exact structure:
{
  "summary": {
    "totalContainers": number,
    "runningContainers": number,
    "images": string[],
    "status": "healthy"|"warning"|"critical"
  },
  "containerAnalysis": {
    "securityIssues": string[],
    "performanceMetrics": {
      "cpuUsage": string,
      "memoryUsage": string,
      "networkUsage": string
    },
    "exposedPorts": number[],
    "publicAccess": boolean
  },
  "recommendations": string[]
}`,

  'CONTAINER_STATUS': (params: DockerPromptParams) => `
You are a Docker expert analyzing container ${params.containerName}.
Based on this container data: ${JSON.stringify(params.data, null, 2)}

Provide a detailed analysis in this exact JSON format:
{
  "status": {
    "state": string,
    "health": "healthy"|"warning"|"critical",
    "uptime": string,
    "issues": string[]
  },
  "performance": {
    "cpu": {
      "current": string,
      "trend": "stable"|"increasing"|"spiking",
      "concerns": string[]
    },
    "memory": {
      "usage": string,
      "limit": string,
      "pressure": "low"|"medium"|"high"
    },
    "network": {
      "throughput": string,
      "connections": number,
      "issues": string[]
    }
  },
  "security": {
    "exposedPorts": string[],
    "privileged": boolean,
    "risks": string[],
    "recommendations": string[]
  },
  "recommendations": {
    "immediate": string[],
    "longTerm": string[]
  }
}`,

  'VIEW_LOGS': (params: DockerPromptParams) => `
Analyze these container logs and provide insights:
${JSON.stringify(params.data, null, 2)}

Return a JSON object with this exact structure:
{
  "summary": {
    "totalEntries": number,
    "timeRange": {
      "start": string,
      "end": string
    },
    "severity": {
      "error": number,
      "warning": number,
      "info": number
    }
  },
  "analysis": {
    "errorPatterns": [
      {
        "pattern": string,
        "count": number,
        "severity": "high"|"medium"|"low",
        "recommendation": string
      }
    ],
    "performanceIssues": [
      {
        "type": string,
        "description": string,
        "impact": string,
        "solution": string
      }
    ]
  },
  "recommendations": string[]
}`,

  'DEPLOY_CONTAINER': (params: DockerPromptParams) => `
You are a Docker expert. Generate a complete docker-compose.yml for:
Container Name: ${params.containerName}
Image: ${params.data.imageName}

Return ONLY the YAML configuration in this format:
version: '3.8'
services:
  ${params.containerName}:
    image: ${params.data.imageName}
    container_name: ${params.containerName}
    restart: unless-stopped
    ports:
      - "80:80"  # Default HTTP port
    environment:
      # Common environment variables
      TZ: UTC
      LANG: en_US.UTF-8
    volumes:
      # Persistent data volume
      - ${params.containerName}_data:/var/www/html
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:80/"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
    networks:
      - ${params.containerName}_net

networks:
  ${params.containerName}_net:
    driver: bridge

volumes:
  ${params.containerName}_data:
    driver: local`,

  'ANALYZE_COMPOSE': (params: DockerPromptParams) => `
Analyze this docker-compose configuration:
${params.yaml}

Provide analysis in this JSON format:
{
  "validation": {
    "isValid": boolean,
    "issues": string[]
  },
  "security": {
    "concerns": string[],
    "recommendations": string[]
  },
  "performance": {
    "resourceAllocations": {
      "cpu": string,
      "memory": string
    },
    "recommendations": string[]
  },
  "bestPractices": {
    "followed": string[],
    "missing": string[]
  }
}`,

  'CONTAINER_STATS': (params: DockerPromptParams) => `
    You are a Docker expert analyzing container ${params.containerName} performance metrics.
    Based on this container stats data: ${JSON.stringify(params.data, null, 2)}

    Return a JSON object with this exact structure:
    {
      "summary": {
        "containerId": string,
        "name": string,
        "timestamp": string,
        "status": "healthy"|"warning"|"critical"
      },
      "resources": {
        "cpu": {
          "usage": string,
          "limit": string,
          "usagePercent": number,
          "throttling": {
            "periods": number,
            "throttledPeriods": number
          }
        },
        "memory": {
          "usage": string,
          "limit": string,
          "usagePercent": number,
          "stats": {
            "cache": string,
            "rss": string,
            "swap": string
          }
        },
        "network": {
          "rxBytes": string,
          "txBytes": string,
          "rxPackets": number,
          "txPackets": number,
          "dropped": number
        },
        "io": {
          "read": string,
          "write": string,
          "readOps": number,
          "writeOps": number
        }
      },
      "alerts": {
        "cpu": string[],
        "memory": string[],
        "network": string[],
        "io": string[]
      },
      "recommendations": string[]
    }`,
};

// Helper function to analyze with AI
async function analyzeWithAI(operation: string, data: any, modelId: string): Promise<string> {
  try {
    const promptFn = DOCKER_PROMPTS[operation];
    if (!promptFn) {
      throw new Error(`Invalid operation: ${operation}`);
    }

    const prompt = promptFn({ 
      host: data.host,
      port: data.port,
      containerName: data.containerName,
      data: data.data
    });

    let response: string;
    if (modelId.startsWith('gemini-')) {
      response = await generateWithGemini(prompt, modelId);
    } else {
      // Enhanced Ollama handling
      response = await generateWithOllama(prompt, modelId);
      
      // Clean and validate Ollama response
      try {
        // Remove any markdown code block syntax
        response = response.replace(/```json\s*|\s*```/g, '');
        
        // Ensure response starts with {
        response = response.trim();
        if (!response.startsWith('{')) {
          const jsonStart = response.indexOf('{');
          if (jsonStart !== -1) {
            response = response.slice(jsonStart);
          }
        }
        
        // Ensure response ends with }
        const lastBrace = response.lastIndexOf('}');
        if (lastBrace !== -1) {
          response = response.slice(0, lastBrace + 1);
        }

        // Validate JSON structure
        JSON.parse(response); // This will throw if invalid
      } catch (jsonError) {
        // If JSON parsing fails, generate a valid JSON response
        logger.warn('Failed to parse Ollama response, generating fallback response', {
          originalResponse: response,
          error: jsonError
        });

        // Create a properly structured response based on the operation
        const fallbackResponse = generateFallbackResponse(operation, data.data);
        return JSON.stringify(fallbackResponse);
      }
    }

    // Extract JSON from response if needed
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('No valid JSON found in response');
    }

    const parsedResponse = JSON.parse(jsonMatch[0]);

    // Validate response structure based on operation
    validateResponseStructure(operation, parsedResponse);

    return jsonMatch[0];
  } catch (error) {
    logger.error('AI analysis failed', error);
    return JSON.stringify({
      error: error instanceof Error ? error.message : 'Analysis failed',
      timestamp: new Date().toISOString(),
      modelId,
      operation,
      data: {
        containerInfo: data.data,
        rawError: error
      }
    });
  }
}

function validateResponseStructure(operation: string, response: any) {
  const validationRules = {
    'LIST_CONTAINERS': () => {
      if (!response.summary?.totalContainers || !response.containerAnalysis) {
        throw new Error('Invalid LIST_CONTAINERS response structure');
      }
    },
    'CONTAINER_STATUS': () => {
      if (!response.status?.state || !response.performance || !response.security) {
        throw new Error('Invalid CONTAINER_STATUS response structure');
      }
    },
    'VIEW_LOGS': () => {
      if (!response.summary?.totalEntries || !response.analysis) {
        throw new Error('Invalid VIEW_LOGS response structure');
      }
    }
  };

  const validate = validationRules[operation];
  if (validate) {
    validate();
  }
}

function generateFallbackResponse(operation: string, data: any) {
  const baseResponse = {
    timestamp: new Date().toISOString(),
    status: 'generated_fallback',
    originalData: data
  };

  switch (operation) {
    case 'LIST_CONTAINERS':
      return {
        ...baseResponse,
        summary: {
          totalContainers: Array.isArray(data) ? data.length : 0,
          runningContainers: Array.isArray(data) ? 
            data.filter(container => container.state === 'running').length : 0,
          images: Array.isArray(data) ? 
            [...new Set(data.map(container => container.image))] : [],
          status: 'warning'
        },
        containerAnalysis: {
          securityIssues: [],
          performanceMetrics: {
            cpuUsage: 'N/A',
            memoryUsage: 'N/A',
            networkUsage: 'N/A'
          },
          exposedPorts: Array.isArray(data) ? 
            data.flatMap(container => container.ports || [])
              .map(port => parseInt(port.split(':')[0]))
              .filter(port => !isNaN(port)) : [],
          publicAccess: false
        },
        recommendations: [
          'Unable to perform detailed analysis. Please check container logs for more information.'
        ]
      };

    case 'CONTAINER_STATUS':
      return {
        ...baseResponse,
        status: {
          state: data.state || 'unknown',
          health: 'warning',
          uptime: data.status || 'N/A',
          issues: ['Unable to perform detailed analysis']
        },
        performance: {
          cpu: {
            current: 'N/A',
            trend: 'stable',
            concerns: []
          },
          memory: {
            usage: 'N/A',
            limit: 'N/A',
            pressure: 'unknown'
          },
          network: {
            throughput: 'N/A',
            connections: 0,
            issues: []
          }
        },
        security: {
          exposedPorts: data.ports || [],
          privileged: false,
          risks: [],
          recommendations: ['Perform manual security audit']
        },
        recommendations: {
          immediate: ['Review container logs for detailed status'],
          longTerm: ['Set up monitoring for better visibility']
        }
      };

    case 'VIEW_LOGS':
      return {
        ...baseResponse,
        summary: {
          totalEntries: Array.isArray(data.logs) ? data.logs.length : 0,
          timeRange: {
            start: data.logs?.[0]?.timestamp || 'N/A',
            end: data.logs?.[data.logs?.length - 1]?.timestamp || 'N/A'
          },
          severity: {
            error: 0,
            warning: 0,
            info: 0
          }
        },
        analysis: {
          errorPatterns: [],
          performanceIssues: []
        },
        recommendations: ['Review logs manually for detailed analysis']
      };

    default:
      return {
        ...baseResponse,
        message: 'Operation not supported for fallback response'
      };
  }
}


// Helper function to get Docker API path
function getDockerApiPath(operation: string, containerName?: string): string {
  switch (operation) {
    case 'LIST_CONTAINERS':
      return '/containers/json';
    case 'CONTAINER_STATUS':
      return `/containers/${containerName}/json?size=1`;
    case 'VIEW_LOGS':
      return `/containers/${containerName}/logs?stdout=1&stderr=1&timestamps=1&since=3600&tail=1000`;
    case 'CONTAINER_STATS':
      return `/containers/${containerName}/stats?stream=false`;
    case 'DEPLOY_CONTAINER':
      return `/containers/create`;
    default:
      throw new Error(`Unknown operation: ${operation}`);
  }
}

// Helper function to format Docker API responses
function formatDockerResponse(operation: string, data: any): any {
  switch (operation) {
    case 'LIST_CONTAINERS':
      return data.map((container: any) => ({
        id: container.Id?.substring(0, 12),
        name: container.Names?.[0]?.replace(/^\//, ''),
        image: container.Image,
        state: container.State,
        status: container.Status,
        ports: container.Ports?.map((p: any) => `${p.PublicPort}:${p.PrivatePort}`),
        created: new Date(container.Created * 1000).toISOString()
      }));
    
    case 'CONTAINER_STATUS':
      return {
        id: data.Id?.substring(0, 12),
        name: data.Name?.replace(/^\//, ''),
        image: data.Config?.Image,
        state: data.State,
        platform: data.Platform,
        network: data.NetworkSettings,
        mounts: data.Mounts,
        config: {
          env: data.Config?.Env?.length || 0,
          cmd: data.Config?.Cmd,
          ports: Object.keys(data.Config?.ExposedPorts || {})
        }
      };
    
    case 'VIEW_LOGS':
      return {
        logs: data,
        summary: {
          totalEntries: data.length,
          errorCount: data.filter((log: any) => log.type === 'error').length,
          warningCount: data.filter((log: any) => log.type === 'warning').length,
          timeRange: {
            start: data[0]?.timestamp,
            end: data[data.length - 1]?.timestamp
          }
        }
      };

    case 'CONTAINER_STATS':
      return formatContainerStats(data);
    
    default:
      return data;
  }
}

// Helper function to generate container configuration
async function generateContainerConfig(
  containerName: string,
  imageName: string,
  modelId: string
): Promise<string> {
  try {
    const prompt = DOCKER_PROMPTS['DEPLOY_CONTAINER']({
      containerName,
      data: { imageName },
      host: '',
      port: 0
    });

    let response: string;
    if (modelId.startsWith('gemini-')) {
      response = await generateWithGemini(prompt, modelId);
    } else {
      response = await generateWithOllama(prompt, modelId);
    }

    // Extract YAML from response
    const yamlMatch = response.match(/```ya?ml\n([\s\S]+?)```/) || 
                     response.match(/version: ['"]3\.8['"][\s\S]+/);
    
    if (!yamlMatch) {
      throw new Error('No valid docker-compose configuration generated');
    }

    return yamlMatch[1] || yamlMatch[0];
  } catch (error) {
    logger.error('Failed to generate container config:', error);
    throw new Error('Failed to generate Docker configuration');
  }
}

// Main Docker operation function
export async function executeDockerOperation(
  options: DockerAgentOptions,
  onProgress?: (progress: number) => void
): Promise<DockerAgentResponse> {
  try {
    logger.info('Starting Docker operation', { operation: options.operation });
    onProgress?.(10);

    if (options.operation === 'DEPLOY_CONTAINER') {
      if (options.dockerCompose) {
        onProgress?.(20);
        
        // Parse docker-compose YAML to extract container config
        const config = {
          Image: options.imageName,
          Hostname: options.containerName,
          ExposedPorts: {
            "80/tcp": {}
          },
          HostConfig: {
            PortBindings: {
              "80/tcp": [{ HostPort: "80" }]
            },
            RestartPolicy: {
              Name: "unless-stopped"
            },
            Resources: {
              Memory: 536870912,
              NanoCPUs: 500000000
            },
            Binds: [`${options.containerName}_data:/var/www/html`]
          },
          Env: [
            "TZ=UTC",
            "LANG=en_US.UTF-8"
          ],
          NetworkingConfig: {
            EndpointsConfig: {
              [`${options.containerName}_net`]: {
                Aliases: [options.containerName]
              }
            }
          }
        };

        // First create the network if it doesn't exist
        await fetch(`${DOCKER_CONFIG.API_URL}/networks/create`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            Name: `${options.containerName}_net`,
            Driver: 'bridge'
          })
        }).catch(err => console.warn('Network may already exist:', err));

        onProgress?.(40);

        // Pull the image before creating container
        logger.info('Pulling image:', options.imageName);
        const pullResponse = await fetch(`${DOCKER_CONFIG.API_URL}/images/create?fromImage=${encodeURIComponent(options.imageName)}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' }
        });

        if (!pullResponse.ok) {
          const error = await pullResponse.text();
          throw new Error(`Failed to pull image: ${error}`);
        }

        // Wait for the pull to complete by reading the stream
        const reader = pullResponse.body?.getReader();
        if (reader) {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            // Log pull progress if needed
            if (value) {
              const text = new TextDecoder().decode(value);
              logger.debug('Pull progress:', text);
            }
          }
        }

        onProgress?.(40);

        // Create container
        const createResponse = await fetch(`${DOCKER_CONFIG.API_URL}/containers/create?name=${options.containerName}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(config)
        });

        if (!createResponse.ok) {
          const error = await createResponse.text();
          throw new Error(`Failed to create container: ${error}`);
        }

        const container = await createResponse.json();
        onProgress?.(60);

        // Start container
        const startResponse = await fetch(`${DOCKER_CONFIG.API_URL}/containers/${container.Id}/start`, {
          method: 'POST'
        });

        if (!startResponse.ok) {
          const error = await startResponse.text();
          throw new Error(`Failed to start container: ${error}`);
        }

        onProgress?.(80);

        // Get container info
        const inspectResponse = await fetch(`${DOCKER_CONFIG.API_URL}/containers/${container.Id}/json`);
        const containerInfo = await inspectResponse.json();

        onProgress?.(100);

        return {
          output: JSON.stringify({
            status: 'success',
            operation: 'DEPLOY_CONTAINER',
            containerId: container.Id,
            containerName: options.containerName,
            containerInfo: {
              state: containerInfo.State,
              networkSettings: containerInfo.NetworkSettings,
              ports: containerInfo.NetworkSettings?.Ports,
              status: containerInfo.State?.Status
            }
          }, null, 2),
          status: 'success'
        };
      } else {
        // Handle AI-assisted deployment
        onProgress?.(10);

        // Generate docker-compose configuration using AI
        const configResponse = await generateContainerConfig(
          options.containerName,
          options.imageName,
          options.modelIds[0]
        );

        // Extract YAML from response
        const yamlMatch = configResponse.match(/```ya?ml\n([\s\S]+?)```/) || 
                         configResponse.match(/version: ['"]3\.8['"][\s\S]+/);
                         
        if (!yamlMatch) {
          throw new Error('Failed to generate valid docker-compose configuration');
        }

        const composerConfig = yamlMatch[1] || yamlMatch[0];
        
        onProgress?.(50);

        // Analyze the generated configuration
        let analysis = null;
        try {
          analysis = await analyzeWithAI(
            'ANALYZE_COMPOSE',
            { yaml: composerConfig },
            options.modelIds[0]
          );
        } catch (error) {
          console.error('Config analysis failed:', error);
        }

        onProgress?.(80);

        const result = {
          operation: 'DEPLOY_CONTAINER',
          timestamp: new Date().toISOString(),
          deployment: {
            containerName: options.containerName,
            image: options.imageName,
            status: 'configuration_generated',
            config: composerConfig,
            analysis: analysis ? JSON.parse(analysis) : null
          },
          steps: [
            "1. Review the generated docker-compose.yml configuration below",
            "2. Modify settings if needed",
            "3. Click 'Deploy Container' to create and start the container",
            "4. Check container status after deployment"
          ]
        };

        onProgress?.(100);
        return {
          output: JSON.stringify(result, null, 2),
          status: 'success'
        };
      }
    }

    // Handle other operations
    const apiPath = getDockerApiPath(options.operation, options.containerName);
    let rawData;
    
    if (options.operation === 'VIEW_LOGS') {
      const response = await fetch(`${DOCKER_CONFIG.API_URL}${apiPath}`, {
        headers: {
          'Accept': 'text/plain',
        },
      });

      if (!response.ok) {
        throw new Error(`Docker API error: ${response.statusText}`);
      }

      const textData = await response.text();
      
      rawData = textData
        .split('\n')
        .filter(Boolean)
        .map(line => {
          const cleanLine = line
            .replace(/\x1b\[[0-9;]*[mGK]/g, '')
            .replace(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z\s/, '');

          return {
            timestamp: line.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z/)?.[0],
            message: cleanLine,
            type: line.includes('ERROR') ? 'error' : 
                  line.includes('WARN') ? 'warning' : 'info'
          };
        });
    } else {
      const response = await fetch(`${DOCKER_CONFIG.API_URL}${apiPath}`, {
        headers: { 'Accept': 'application/json' }
      });
      
      if (!response.ok) {
        throw new Error(`Docker API error: ${response.statusText}`);
      }

      rawData = await response.json();
    }

    onProgress?.(50);

    // AI Analysis for supported operations
    if (['LIST_CONTAINERS', 'CONTAINER_STATUS', 'VIEW_LOGS'].includes(options.operation) && options.modelIds?.length > 0) {
      const formattedData = formatDockerResponse(options.operation, rawData);
      
      const aiAnalysis = await Promise.all(
        options.modelIds.map(async (modelId) => {
          try {
            const analysis = await analyzeWithAI(
              options.operation,
              {
                host: options.host,
                port: options.port,
                containerName: options.containerName,
                data: formattedData
              },
              modelId
            );

            return { 
              modelId, 
              analysis: JSON.parse(analysis)
            };
          } catch (error) {
            return { 
              modelId, 
              analysis: {
                error: 'AI analysis failed',
                details: error instanceof Error ? error.message : 'Unknown error',
                containerData: formattedData
              }
            };
          }
        })
      );

      const result = {
        operation: options.operation,
        timestamp: new Date().toISOString(),
        containerInfo: formattedData,
        aiAnalysis: aiAnalysis.reduce((acc, curr) => ({
          ...acc,
          [curr.modelId]: curr.analysis
        }), {})
      };

      return {
        output: JSON.stringify(result, null, 2),
        status: 'success'
      };
    }

    // Regular response for other operations
    const result = {
      operation: options.operation,
      timestamp: new Date().toISOString(),
      data: formatDockerResponse(options.operation, rawData)
    };

    onProgress?.(100);
    return {
      output: JSON.stringify(result, null, 2),
      status: 'success'
    };

  } catch (error) {
    logger.error('Docker operation failed', error);
    throw error;
  }
}

// Types
export interface DockerPromptParams {
  host: string;
  port: number;
  containerName?: string;
  data: any;
  yaml?: string;
}

export interface DockerAgentOptions {
  operation: string;
  host: string;
  port: number;
  containerName?: string;
  imageName?: string;
  modelIds: string[];
  dockerCompose?: boolean;
}

export interface DockerAgentResponse {
  output: string;
  status: 'success' | 'error';
  error?: string;
}

// Export other necessary functions
export {
  analyzeWithAI,
  generateContainerConfig,
  formatDockerResponse,
  getDockerApiPath
};

// Add formatContainerStats helper function
function formatContainerStats(stats: any) {
  const formatBytes = (bytes: number) => {
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let size = bytes;
    let unitIndex = 0;
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    return `${size.toFixed(2)} ${units[unitIndex]}`;
  };

  const calculateCPUPercent = (stats: any) => {
    const cpuDelta = stats.cpu_stats.cpu_usage.total_usage - stats.precpu_stats.cpu_usage.total_usage;
    const systemDelta = stats.cpu_stats.system_cpu_usage - stats.precpu_stats.system_cpu_usage;
    const cpuPercent = (cpuDelta / systemDelta) * 100 * stats.cpu_stats.online_cpus;
    return cpuPercent.toFixed(2);
  };

  return {
    id: stats.id,
    name: stats.name,
    cpu: {
      usage: calculateCPUPercent(stats),
      totalUsage: stats.cpu_stats.cpu_usage.total_usage,
      systemUsage: stats.cpu_stats.system_cpu_usage,
      onlineCpus: stats.cpu_stats.online_cpus,
      throttling: stats.cpu_stats.throttling_data
    },
    memory: {
      usage: formatBytes(stats.memory_stats.usage),
      limit: formatBytes(stats.memory_stats.limit),
      stats: stats.memory_stats.stats
    },
    network: Object.entries(stats.networks || {}).reduce((acc, [key, value]: [string, any]) => ({
      ...acc,
      [key]: {
        rxBytes: formatBytes(value.rx_bytes),
        txBytes: formatBytes(value.tx_bytes),
        rxPackets: value.rx_packets,
        txPackets: value.tx_packets,
        dropped: value.rx_dropped + value.tx_dropped
      }
    }), {}),
    blockIO: stats.blkio_stats
  };
}