import { ENV_CONFIG } from '../../config/env';
import { AIApiOptions } from './types';

export async function generateWithOpenAI(
  prompt: string,
  modelId: string,
  options: AIApiOptions = {}
): Promise<string> {
  try {
    const response = await fetch(`${ENV_CONFIG.OPENAI_API_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${ENV_CONFIG.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: modelId,
        messages: [
          {
            role: 'system',
            content: 'You are a CI/CD pipeline expert. Generate only the pipeline configuration code.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: options.temperature ?? 0.7,
        top_p: options.topP ?? 0.9,
        max_tokens: options.maxTokens ?? 2048,
        stream: options.stream ?? false
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error('[OpenAI] Generation failed:', error);
    throw error;
  }
}
