import { Model } from '../../types';
import { ollama } from '../ollama';
import { googleai } from '../googleai';
import { MODEL_CONFIGS, SECURITY_MODEL_CONFIGS } from '../../config/securityModels';
import { PROGRAMMING_SECURITY_PROMPTS, CONFIG_SECURITY_PROMPTS } from '../security/prompts';
import type { SecurityScanType, SecurityCategory, SecurityIssue, SecurityMetrics } from '../../types/security';
import { ENV_CONFIG } from '../../config/env'; // Add this import
import { SECURITY_CATEGORIES, CWE_MAPPINGS, calculateCVSSScore } from '../../config/securityCategories';
import { GoogleGenerativeAI } from '@google/generative-ai';

// Update model mapping to use exact model names from ollama list
const SECURITY_MODEL_MAPPING = {
  'mistral-security:latest': 'mistral:latest',
  'granite-code:8b': 'granite-code:8b',     // Fixed mapping
  'mistral-small:latest': 'mistral-small:latest', // Use exact name
  'granite-code:20b': 'granite-code:20b',
  'mistral:latest': 'mistral:latest',
  'mistral-nemo:latest': 'mistral-nemo:latest',
  'gemini-pro': 'gemini-pro',
  'gemini-1.5-pro-001': 'gemini-1.5-pro-001',
  'gemini-2.0-flash': 'gemini-2.0-flash'
} as const;

// Update model installation commands with exact model names
const MODEL_INSTALL_COMMANDS = {
  'mistral:latest': 'ollama pull mistral:latest',
  'mistral-small:latest': 'ollama pull mistral-small:latest',
  'mistral-nemo:latest': 'ollama pull mistral-nemo:latest',
  'granite-code:8b': 'ollama pull granite-code:8b',
  'granite-code:20b': 'ollama pull granite-code:20b',
  'gemini-pro': 'googleai pull gemini-pro',
  'gemini-1.5-pro-001': 'googleai pull gemini-1.5-pro-001',
  'gemini-2.0-flash': 'googleai pull gemini-2.0-flash'
} as const;

// Add model name mapping for display
const MODEL_DISPLAY_NAMES = {
  'mistral:latest': 'Mistral',
  'mistral-small:latest': 'Mistral Small',
  'mistral-nemo:latest': 'Mistral Nemo',
  'granite-code:8b': 'Granite Code 8B',
  'granite-code:20b': 'Granite Code 20B',
  'gemini-pro': 'Gemini Pro',
  'gemini-1.5-pro-001': 'Gemini 1.5 Pro',
  'gemini-2.0-flash': 'Gemini 2.0 Flash'
} as const;

export interface SecurityScanRequest {
  modelIds: string[];
  language: string;
  sourceCode: string;
  scanType: SecurityScanType;
  features: Record<SecurityCategory, boolean>;
  customRules?: Array<{
    name: string;
    pattern: string;
    severity: string;
    category: string;
  }>;
}

export interface SecurityScanProgress {
  modelId: string;
  status: 'pending' | 'analyzing' | 'completed' | 'failed';
  progress: number;
  result?: {
    issues: SecurityIssue[];
    metrics: SecurityMetrics;
  };
  error?: string;
}

export interface SecurityScanParams {
  sourceCode: string;
  language: string;
  modelIds: string[];
  scanType: 'quick' | 'full' | 'deep';
  features: Record<string, boolean>;
  onProgress?: (progress: Record<string, SecurityScanProgress>) => void;
}

function getSecurityPrompt(
  language: string,
  scanType: SecurityScanType,
  category: SecurityCategory,
  sourceCode: string
): string {
  // Get default prompt template
  const defaultTemplate = `
Analyze this ${language} code for ${category} security issues.
Focus on identifying vulnerabilities, risks, and providing actionable recommendations.

Parameters:
- Language: ${language}
- Scan Type: ${scanType}
- Security Category: ${category}

SOURCE CODE:
\`\`\`${language}
${sourceCode}
\`\`\`

Return results in JSON format:
{
  "issues": [
    {
      "type": "critical|high|medium|low",
      "title": "Issue title",
      "description": "Detailed description",
      "line": 123,
      "recommendation": "How to fix",
      "cwe": "CWE-XXX",
      "cvss": 9.8
    }
  ],
  "metrics": {
    "score": 85,
    "criticalIssues": 1,
    "highIssues": 2,
    "mediumIssues": 3,
    "lowIssues": 4
  }
}`;

  // Get language-specific prompts
  const prompts = language.toLowerCase().includes('ansible') ? 
    CONFIG_SECURITY_PROMPTS :
    PROGRAMMING_SECURITY_PROMPTS;

  // Find matching prompt or use default
  const prompt = prompts.find(p => 
    p.language === language && 
    p.scanType === scanType && 
    p.category === category
  );

  return prompt ? prompt.prompt : defaultTemplate;
}

// Add this type
type ProgressCallback = (progress: Record<string, SecurityScanProgress>) => void;

const MODEL_SPECIFIC_PROMPTS = {
  'granite-code:20b': (language: string, scanType: string, features: string) => `
You are a security-focused code analyzer. Analyze the following ${language} code for security vulnerabilities.
Focus on providing accurate, actionable results in JSON format.

Analysis Parameters:
- Scan Type: ${scanType}
- Features: ${features}

Return ONLY a JSON response in this exact format:
{
  "issues": [
    {
      "type": "critical|high|medium|low",
      "title": "Brief issue title",
      "description": "Detailed description",
      "category": "vulnerability type",
      "line": "line number",
      "cwe": "CWE identifier",
      "cvss": "CVSS score",
      "recommendation": "How to fix"
    }
  ],
  "metrics": {
    "score": 0-100,
    "criticalIssues": number,
    "highIssues": number,
    "mediumIssues": number,
    "lowIssues": number
  }
}`,

  'mistral-small:latest': (language: string, scanType: string, features: string) => `
Perform a focused security scan of this ${language} code. 
Scan type: ${scanType}
Features: ${features}

Return a clean JSON response with this structure:
{
  "issues": [
    {
      "type": "severity level",
      "title": "issue name",
      "description": "what's wrong",
      "line": "location",
      "recommendation": "fix suggestion"
    }
  ],
  "metrics": {
    "score": "overall score",
    "criticalIssues": "count",
    "highIssues": "count",
    "mediumIssues": "count",
    "lowIssues": "count"
  }
}`,

  'granite-security:8b': (language: string, scanType: string, features: string) => `
Execute a comprehensive security analysis of the following ${language} code.
Mode: ${scanType}
Checking: ${features}

Provide results in this JSON structure only:
{
  "issues": [
    {
      "type": "critical|high|medium|low",
      "title": "Clear title",
      "description": "Detailed explanation",
      "category": "Issue category",
      "line": "Line number",
      "evidence": "Problematic code",
      "recommendation": "How to fix",
      "references": ["Reference URLs"]
    }
  ],
  "metrics": {
    "score": 0-100,
    "criticalIssues": "count",
    "highIssues": "count",
    "mediumIssues": "count",
    "lowIssues": "count"
  }
}`,

  'mistral-nemo:latest': (language: string, scanType: string, features: string) => `
You are a security expert analyzing code for vulnerabilities. 
Review this ${language} code and identify security issues.

Analysis scope: ${features}
Scan type: ${scanType}

Provide a security assessment in this exact JSON format:
{
  "issues": [
    {
      "type": "critical|high|medium|low",
      "title": "Clear, specific issue name",
      "description": "Detailed explanation of the vulnerability",
      "category": "category of vulnerability",
      "line": "affected line number",
      "cwe": "CWE identifier if applicable",
      "cvss": "CVSS score if applicable",
      "recommendation": "Specific fix recommendation",
      "evidence": "Relevant code snippet"
    }
  ],
  "metrics": {
    "score": number between 0-100,
    "criticalIssues": number,
    "highIssues": number,
    "mediumIssues": number,
    "lowIssues": number,
    "passedChecks": number,
    "failedChecks": number
  }
}

IMPORTANT:
- Return ONLY valid JSON
- Do not include any explanatory text
- Ensure all numbers are actual numbers, not strings
- Always include metrics object
- Every issue must have type, title, and description

Analyze the following code:
`,

  'granite-code:8b': (language: string, scanType: string, features: string) => `
You are a code security expert. Perform a comprehensive security analysis of the provided ${language} code.
Focus on identifying vulnerabilities, security risks, and potential threats.

Scan Parameters:
- Language: ${language}
- Scan Type: ${scanType}
- Features: ${features}

Provide your analysis in this exact JSON format only:
{
  "issues": [
    {
      "type": "critical|high|medium|low",
      "title": "Brief, specific title",
      "description": "Detailed explanation of the issue",
      "category": "security category",
      "line": line_number,
      "cwe": "CWE-XXX",
      "cvss": numeric_score,
      "evidence": "Relevant code snippet",
      "recommendation": "Specific fix suggestion",
      "references": ["Reference URLs"]
    }
  ],
  "metrics": {
    "score": numeric_score_0_to_100,
    "criticalIssues": count,
    "highIssues": count,
    "mediumIssues": count,
    "lowIssues": count,
    "passedChecks": total_passed,
    "failedChecks": total_failed
  }
}

REQUIREMENTS:
- Return valid JSON only
- Use numeric values (not strings) for numbers
- Include specific line numbers where possible
- Provide actionable recommendations
- Include CWE IDs where applicable
- Calculate CVSS scores for vulnerabilities

Analyze this code:
`
};

// Add Gemini-specific prompts
const GEMINI_SPECIFIC_PROMPTS = {
  'gemini-pro': {
    modelName: 'gemini-pro',
    maxTokens: 8192
  },
  'gemini-1.5-pro-001': {
    modelName: 'gemini-1.5-pro-001',
    maxTokens: 8192
  },
  'gemini-2.0-flash': {
    modelName: 'gemini-2.0-flash',
    maxTokens: 16384
  }
};

// Update generateSecurityPrompt function
function generateSecurityPrompt(
  code: string,
  language: string,
  scanType: string,
  features: Record<string, boolean>,
  modelId: string
): string {
  const enabledFeatures = Object.entries(features)
    .filter(([_, enabled]) => enabled)
    .map(([feature]) => feature)
    .join(', ');

  // Use model-specific prompt if available
  const modelPrompt = MODEL_SPECIFIC_PROMPTS[modelId as keyof typeof MODEL_SPECIFIC_PROMPTS];
  if (modelPrompt) {
    return `${modelPrompt(language, scanType, enabledFeatures)}

CODE TO ANALYZE:
\`\`\`${language}
${code}
\`\`\``;
  }

  // Fall back to default prompt
  return `
    Analyze the following ${language} code for security issues.
    Scan type: ${scanType}
    Features to check: ${enabledFeatures}
    
    Code to analyze:
    ${code}
    
    Provide a detailed security analysis including:
    1. Vulnerabilities
    2. Security risks
    3. Best practices
    4. Recommendations

    Return the results in strict JSON format:
    {
      "issues": [
        {
          "type": "critical|high|medium|low",
          "title": "Issue title",
          "description": "Issue description",
          "category": "vulnerability type",
          "line": "affected line number (optional)"
        }
      ],
      "metrics": {
        "score": "0-100",
        "criticalIssues": "count",
        "highIssues": "count",
        "mediumIssues": "count",
        "lowIssues": "count"
      }
    }

    Return ONLY the JSON response, no other text.
  `;
}

// Update getAvailableModels to be more robust
async function getAvailableModels(): Promise<string[]> {
  try {
    // Get Ollama models
    const ollamaResponse = await fetch(`${ENV_CONFIG.OLLAMA_API_URL}/api/tags`);
    const ollamaModels = ollamaResponse.ok ? 
      (await ollamaResponse.json()).models?.map((m: any) => m.name) || [] : 
      [];

    // Add Gemini models if API key is configured, excluding gemini-1.5-pro-001
    const geminiModels = [];
    if (import.meta.env.VITE_GOOGLE_API_KEY) {
      geminiModels.push('gemini-pro', 'gemini-2.0-flash');  // Exclude problematic model
    }

    return [...ollamaModels, ...geminiModels];
  } catch (error) {
    console.error('Error fetching available models:', error);
    // Return just working Gemini models if Ollama is not available
    return import.meta.env.VITE_GOOGLE_API_KEY ? 
      ['gemini-pro', 'gemini-2.0-flash'] : 
      [];
  }
}

// Add helper to suggest model installation
function getModelInstallHint(modelId: string): string {
  const baseModel = modelId.split(':')[0];
  const command = MODEL_INSTALL_COMMANDS[modelId] || MODEL_INSTALL_COMMANDS[baseModel];
  return command ? `Run '${command}' to install the model` : 'Model not available';
}

// Update scanWithOllama to handle missing models better
async function scanWithOllama(
  request: SecurityScanRequest,
  modelId: string,
  onProgress?: ProgressCallback
): Promise<{ issues: SecurityIssue[]; metrics: SecurityMetrics }> {
  const updateProgress = (status: 'pending' | 'analyzing' | 'completed' | 'failed', progress: number, error?: string) => {
    onProgress?.({
      [modelId]: {
        modelId,
        status,
        progress,
        error
      }
    });
  };

  try {
    const mappedModel = modelId.includes('granite-code:8b') ? 'granite-code:8b' : SECURITY_MODEL_MAPPING[modelId];
    if (!mappedModel) {
      throw new Error(`Unknown model: ${modelId}`);
    }

    const availableModels = await getAvailableModels();
    console.log('Available models:', availableModels);
    console.log('Trying to use model:', mappedModel);
    
    if (!availableModels.includes(mappedModel)) {
      const installHint = getModelInstallHint(mappedModel);
      const displayName = MODEL_DISPLAY_NAMES[mappedModel] || mappedModel;
      const error = `Model ${displayName} (${mappedModel}) is not available. ${installHint}`;
      console.error(error);
      updateProgress('failed', 0, error);
      throw new Error(error);
    }

    // Log request details
    console.log('Scanning with Ollama:', {
      originalModel: modelId,
      mappedModel: SECURITY_MODEL_MAPPING[modelId] || modelId,
      language: request.language
    });

    updateProgress('analyzing', 25);

    // Use the same API endpoint structure as generate
    const endpoint = `${ENV_CONFIG.OLLAMA_API_URL}/api/generate`;
    console.log('Using endpoint:', endpoint);

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: SECURITY_MODEL_MAPPING[modelId] || 'mistral', // Fallback to mistral
        prompt: request.language === 'ansible' ? 
          generateAnsiblePrompt(request.sourceCode) : 
          generateSecurityPrompt(
            request.sourceCode,
            request.language,
            request.scanType,
            request.features,
            modelId // Pass modelId to generateSecurityPrompt
          ),
        stream: false,
        options: {
          temperature: modelId.includes('granite') ? 0.1 : 0.3, // Lower temperature for Granite models
          top_p: 0.9,
          num_predict: modelId.includes('granite') ? 4096 : 2048 // Larger context for Granite models
        }
      })
    });

    // Enhanced error handling
    if (!response.ok) {
      const errorText = await response.text();
      console.error('Ollama API Error:', {
        status: response.status,
        statusText: response.statusText,
        error: errorText
      });
      updateProgress('failed', 0, `API error: ${response.status} - ${errorText}`);
      throw new Error(`API error: ${response.status} - ${errorText}`);
    }

    updateProgress('analyzing', 75);

    const data = await response.json();

    // Better response validation
    if (!data?.response) {
      console.error('Invalid response:', data);
      updateProgress('failed', 0, 'Invalid response from API');
      throw new Error('Invalid response from API');
    }

    try {
      // Parse response with error handling
      const parsedResponse = parseOllamaResponse(data.response, modelId);
      updateProgress('completed', 100);
      return parsedResponse;
    } catch (error) {
      console.error('Failed to parse response:', error);
      updateProgress('failed', 0, 'Failed to parse security analysis results');
      throw new Error('Failed to parse security analysis results');
    }

  } catch (error) {
    console.error(`Scan failed for ${modelId}:`, error);
    updateProgress('failed', 0, error instanceof Error ? error.message : 'Unknown error');
    throw error;
  }
}

// Helper function to generate Ansible-specific prompt
function generateAnsiblePrompt(sourceCode: string): string {
  return `Analyze this Ansible playbook for security issues:
    
SOURCE CODE:
\`\`\`yaml
${sourceCode}
\`\`\`

Focus on:
1. Privilege escalation risks
2. Secret management
3. Role permissions
4. Module security
5. Task security

Return analysis in JSON format:
{
  "issues": [
    {
      "type": "critical|high|medium|low",
      "title": "Issue title",
      "description": "Description",
      "line": "line number",
      "recommendation": "How to fix"
    }
  ],
  "metrics": {
    "criticalIssues": 0,
    "highIssues": 0,
    "mediumIssues": 0,
    "lowIssues": 0
  }
}`;
}

// Helper function to parse Ollama response
function parseOllamaResponse(response: string, modelId: string): { issues: SecurityIssue[]; metrics: SecurityMetrics } {
  // Add specific handling for mistral-nemo
  if (modelId === 'mistral-nemo:latest') {
    try {
      // First try to extract JSON block
      const jsonMatch = response.match(/```json\n([\s\S]+?)\n```/) || 
                       response.match(/\{[\s\S]*\}/);
      
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0].replace(/```json\n|```/g, '').trim());
        if (isValidSecurityResponse(parsed)) {
          return parsed;
        }
      }
    } catch (error) {
      console.log('Mistral Nemo JSON parsing failed, falling back to structured parsing');
    }
  }

  if (modelId === 'granite-code:8b') {
    try {
      // First try to find a JSON block
      const jsonMatch = response.match(/```json\n([\s\S]+?)\n```/) || 
                       response.match(/\{[\s\S]*\}/);
      
      if (jsonMatch) {
        const cleaned = jsonMatch[0].replace(/```json\n|```/g, '').trim();
        const parsed = JSON.parse(cleaned);
        
        // Ensure numeric values
        if (parsed.metrics) {
          Object.keys(parsed.metrics).forEach(key => {
            parsed.metrics[key] = Number(parsed.metrics[key]);
          });
        }
        
        if (parsed.issues) {
          parsed.issues.forEach((issue: any) => {
            if (issue.cvss) issue.cvss = Number(issue.cvss);
            if (issue.line) issue.line = Number(issue.line);
          });
        }

        if (isValidSecurityResponse(parsed)) {
          return parsed;
        }
      }
    } catch (error) {
      console.log('Granite-code:8b JSON parsing failed, trying alternative parsing');
    }
  }

  try {
    // First try direct JSON parse
    const parsed = JSON.parse(response);
    if (isValidSecurityResponse(parsed)) {
      return parsed;
    }
  } catch (error) {
    console.log('Initial JSON parse failed, trying alternative parsing...');
  }

  try {
    // Try to extract JSON from markdown code blocks
    const jsonMatch = response.match(/```json?\n([\s\S]+?)\n```/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[1].trim());
      if (isValidSecurityResponse(parsed)) {
        return parsed;
      }
    }

    // Try to extract any JSON object
    const anyJsonMatch = response.match(/\{[\s\S]*\}/);
    if (anyJsonMatch) {
      const parsed = JSON.parse(anyJsonMatch[0]);
      if (isValidSecurityResponse(parsed)) {
        return parsed;
      }
    }

    // If no JSON found, try to format unstructured response
    return formatMistralResponse(response);
  } catch (error) {
    console.error('Failed to parse security response:', error);
    console.log('Raw response:', response);
    throw new Error('Failed to parse security analysis results');
  }
}

function isValidSecurityResponse(obj: any): boolean {
  return (
    obj &&
    Array.isArray(obj.issues) &&
    typeof obj.metrics === 'object' &&
    typeof obj.metrics.score === 'number'
  );
}

function formatMistralResponse(response: string): { issues: SecurityIssue[]; metrics: SecurityMetrics } {
  const issues: SecurityIssue[] = [];
  let criticalCount = 0;
  let highCount = 0;
  let mediumCount = 0;
  let lowCount = 0;

  // Split response into lines and process each section
  const lines = response.split('\n');
  let currentIssue: Partial<SecurityIssue> = {};

  for (const line of lines) {
    const trimmed = line.trim();
    
    // Skip empty lines and markdown
    if (!trimmed || trimmed.startsWith('#') || trimmed.startsWith('```')) continue;

    // Try to identify issue patterns
    if (trimmed.match(/critical|high|medium|low/i)) {
      // Save previous issue if exists
      if (Object.keys(currentIssue).length > 0) {
        issues.push(currentIssue as SecurityIssue);
      }

      // Start new issue
      currentIssue = {
        type: getIssueSeverity(trimmed),
        title: trimmed.replace(/\[(critical|high|medium|low)\]/i, '').trim(),
        description: '',
        category: 'vulnerabilities'
      };

      // Update counts
      switch (currentIssue.type) {
        case 'critical': criticalCount++; break;
        case 'high': highCount++; break;
        case 'medium': mediumCount++; break;
        case 'low': lowCount++; break;
      }
    } else if (currentIssue.title) {
      // Append to current issue description
      currentIssue.description = currentIssue.description 
        ? `${currentIssue.description}\n${trimmed}`
        : trimmed;
    }
  }

  // Add last issue if exists
  if (Object.keys(currentIssue).length > 0) {
    issues.push(currentIssue as SecurityIssue);
  }

  // Calculate security score
  const totalIssues = criticalCount * 10 + highCount * 5 + mediumCount * 2 + lowCount;
  const score = Math.max(0, Math.round(100 - (totalIssues * 2)));

  return {
    issues,
    metrics: {
      score,
      criticalIssues: criticalCount,
      highIssues: highCount,
      mediumIssues: mediumCount,
      lowIssues: lowCount,
      passedChecks: issues.length,
      failedChecks: totalIssues
    }
  };
}

function getIssueSeverity(text: string): SecurityIssue['type'] {
  text = text.toLowerCase();
  if (text.includes('critical')) return 'critical';
  if (text.includes('high')) return 'high';
  if (text.includes('medium')) return 'medium';
  return 'low';
}

// Add Gemini response parsing function
function parseGeminiResponse(text: string): { issues: SecurityIssue[]; metrics: SecurityMetrics } {
  try {
    // Clean the response - remove any markdown formatting
    const cleanedText = text.replace(/```json\n?|\n?```/g, '').trim();
    
    // Try to parse the cleaned JSON
    const parsed = JSON.parse(cleanedText);
    
    // Validate and normalize the response
    if (!parsed.issues || !parsed.metrics) {
      throw new Error('Invalid response format');
    }

    // Ensure numeric values in metrics
    const metrics = {
      score: Number(parsed.metrics.score) || 0,
      criticalIssues: Number(parsed.metrics.criticalIssues) || 0,
      highIssues: Number(parsed.metrics.highIssues) || 0,
      mediumIssues: Number(parsed.metrics.mediumIssues) || 0,
      lowIssues: Number(parsed.metrics.lowIssues) || 0,
      passedChecks: Number(parsed.metrics.passedChecks) || 0,
      failedChecks: Number(parsed.metrics.failedChecks) || 0
    };

    // Normalize issues
    const issues = parsed.issues.map((issue: any) => ({
      type: issue.type || 'low',
      title: issue.title || 'Unknown Issue',
      description: issue.description || '',
      category: issue.category || 'general',
      line: Number(issue.line) || undefined,
      cwe: issue.cwe,
      cvss: Number(issue.cvss) || undefined,
      recommendation: issue.recommendation,
      evidence: issue.evidence
    }));

    return { issues, metrics };
  } catch (error) {
    console.error('Failed to parse Gemini response:', error);
    console.log('Raw response:', text);
    return {
      issues: [{
        type: 'high',
        title: 'Response Parsing Error',
        description: 'Failed to parse security analysis results',
        category: 'system'
      }],
      metrics: {
        score: 0,
        criticalIssues: 0,
        highIssues: 1,
        mediumIssues: 0,
        lowIssues: 0,
        passedChecks: 0,
        failedChecks: 1
      }
    };
  }
}

// Update scanWithGemini function with improved prompt and parsing
const GEMINI_PROMPT_TEMPLATE = `
You are a security code analyzer. Your task is to analyze the provided code for security vulnerabilities and respond ONLY with a valid JSON object that strictly adheres to the following schema.

## Input
\`\`\`
[CODE]
\`\`\`

## Instructions
1.  Carefully analyze the provided code for potential security vulnerabilities, focusing EXCLUSIVELY on common weaknesses such as:
    - SQL injection
    - Cross-site scripting (XSS)
    - Authentication failures
    - Insecure direct object references
2.  For each vulnerability found:
    - Identify the specific type of vulnerability.
    - Provide a brief, descriptive title.
    - Offer a detailed explanation of the vulnerability.
    - Specify the category of the vulnerability (e.g., "Injection", "Authentication").
    - Indicate the line number where the vulnerability occurs (if applicable).
    - Provide a clear and concise recommendation for fixing the vulnerability.
3.  Calculate a security score (0-100) based on the severity and number of vulnerabilities found. Higher scores indicate fewer and less severe vulnerabilities.
4.  Return a single JSON object that strictly conforms to the JSON Schema below.
5.  Do NOT include any explanatory text, markdown formatting, or code blocks outside of the JSON object. The response MUST be a valid JSON object.

## JSON Schema
\`\`\`json
{
  "issues": [
    {
      "type": "critical|high|medium|low",
      "title": "Brief issue title",
      "description": "Detailed explanation of the vulnerability",
      "category": "Category name",
      "line": number,
      "recommendation": "How to fix this issue"
    }
  ],
  "metrics": {
    "score": number,
    "criticalIssues": number,
    "highIssues": number,
    "mediumIssues": number,
    "lowIssues": number,
    "passedChecks": number,
    "failedChecks": number
  }
}
\`\`\`

Ensure that all numbers are actual numbers (not strings).
`;

const GEMINI_1_5_PRO_PROMPT = `
You are a security code analyzer. Analyze the following code for security vulnerabilities. Respond ONLY with a valid JSON object that strictly adheres to the following schema.

## Input
\`\`\`
[CODE]
\`\`\`

## Instructions
1.  Identify potential security vulnerabilities in the provided code, such as SQL injection, XSS, authentication failures, and insecure direct object references.
2.  Return a JSON object with a list of issues and overall metrics.

## JSON Schema
\`\`\`json
{
  "issues": [
    {
      "type": "critical|high|medium|low",
      "title": "Brief issue title",
      "description": "Brief description of the vulnerability",
      "category": "Category name",
      "line": number
    }
  ],
  "metrics": {
    "score": number,
    "criticalIssues": number,
    "highIssues": number,
    "mediumIssues": number,
    "lowIssues": number
  }
}
\`\`\`

Ensure that all numbers are actual numbers (not strings).
`;

// Retry mechanism with exponential backoff
async function retryWithBackoff<T>(fn: () => Promise<T>, maxRetries = 3, delay = 1000): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    if (maxRetries > 0 && error.message.includes('429')) {
      console.warn(`Rate limit exceeded. Retrying in ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return retryWithBackoff(fn, maxRetries - 1, delay * 2);
    }
    throw error;
  }
}

async function scanWithGemini(
  request: SecurityScanRequest,
  modelId: string,
  onProgress?: ProgressCallback
): Promise<{ issues: SecurityIssue[]; metrics: SecurityMetrics }> {
  try {
    onProgress?.({
      [modelId]: {
        modelId,
        status: 'scanning',
        progress: 0
      }
    });

    const apiKey = import.meta.env.VITE_GOOGLE_API_KEY;
    if (!apiKey) {
      throw new Error('Google API key is not configured');
    }

    const genAI = new GoogleGenerativeAI(apiKey);
    const modelConfig = GEMINI_SPECIFIC_PROMPTS[modelId as keyof typeof GEMINI_SPECIFIC_PROMPTS];
    if (!modelConfig) {
      throw new Error(`Unknown Gemini model: ${modelId}`);
    }

    const model = genAI.getGenerativeModel({ 
      model: modelConfig.modelName,
      generationConfig: {
        temperature: 0.0, // Set temperature to 0 for deterministic output
        topP: 0.0, // Set topP to 0 for deterministic output
        topK: 1,
        maxOutputTokens: modelConfig.maxTokens
      }
    });

    // Use a simplified prompt for gemini-1.5-pro-001
    const prompt = modelId === 'gemini-1.5-pro-001'
      ? GEMINI_1_5_PRO_PROMPT.replace('[CODE]', request.sourceCode)
      : GEMINI_PROMPT_TEMPLATE.replace('[CODE]', request.sourceCode);

    // Wrap the generateContent call with retryWithBackoff
    const result = await retryWithBackoff(() => model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }]
    }));

    let text = result.response.text().trim();
    console.log('Raw Gemini response:', text);

    let parsed: any = null;
    try {
      // Attempt 1: Direct JSON parsing
      parsed = JSON.parse(text);
    } catch (e1) {
      console.warn('Direct JSON parsing failed:', e1.message);
      console.warn('Raw Gemini response:', text); // Log the raw response

      try {
        // Attempt 2: Extract JSON-like substring
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          parsed = JSON.parse(jsonMatch[0]);
        } else {
          throw new Error('No JSON-like content found');
        }
      } catch (e2) {
        console.warn('JSON extraction failed:', e2.message);
        console.warn('Raw Gemini response:', text); // Log the raw response

        try {
          // Attempt 3: Replace newlines and try again
          const textWithoutNewlines = text.replace(/[\r\n]+/g, '');
          parsed = JSON.parse(textWithoutNewlines);
        } catch (e3) {
          console.error('Newline removal failed:', e3.message);
          console.warn('Raw Gemini response:', text); // Log the raw response
          throw new Error('Failed to parse JSON after multiple attempts');
        }
      }
    }

    // Normalize the response
    try {
      if (!parsed || !parsed.issues || !Array.isArray(parsed.issues) || !parsed.metrics) {
        throw new Error('Invalid response structure');
      }

      const issues = parsed.issues.map((issue: any) => ({
        type: String(issue.type || 'low').toLowerCase(),
        title: String(issue.title || 'Unnamed Issue'),
        description: String(issue.description || ''),
        category: String(issue.category || 'general'),
        line: typeof issue.line === 'number' ? issue.line : undefined,
        recommendation: String(issue.recommendation || '')
      }));

      const metrics = {
        score: Number(parsed.metrics.score) || 0,
        criticalIssues: Number(parsed.metrics.criticalIssues) || 0,
        highIssues: Number(parsed.metrics.highIssues) || 0,
        mediumIssues: Number(parsed.metrics.mediumIssues) || 0,
        lowIssues: Number(parsed.metrics.lowIssues) || 0,
        passedChecks: Number(parsed.metrics.passedChecks) || 0,
        failedChecks: Number(parsed.metrics.failedChecks) || 0
      };

      onProgress?.({
        [modelId]: {
          modelId,
          status: 'completed',
          progress: 100,
          result: { issues, metrics }
        }
      });

      return { issues, metrics };
    } catch (normalizationError) {
      console.error('Failed to normalize Gemini response:', normalizationError);
      console.log('Raw response:', text);

      onProgress?.({
        [modelId]: {
          modelId,
          status: 'failed',
          progress: 0,
          error: 'Failed to normalize security analysis results. The model may be unstable. Please try again or use a different model.'
        }
      });

      return {
        issues: [{
          type: 'high',
          title: 'Analysis Error',
          description: `Gemini model returned an unparseable response. Please try again or use a different model. Raw response: ${text}`,
          category: 'system',
          line: undefined,
          recommendation: 'Try running the scan again or select a different model'
        }],
        metrics: {
          score: 0,
          criticalIssues: 0,
          highIssues: 1,
          mediumIssues: 0,
          lowIssues: 0,
          passedChecks: 0,
          failedChecks: 1
        }
      };
    }
  } catch (error) {
    console.error(`Gemini scan error:`, error);
    let errorMessage = `Gemini scan error: ${error.message}`;
    if (error.message.includes('SAFETY')) {
      errorMessage = `Gemini scan error: Candidate was blocked due to SAFETY. The model may be unstable or the code may trigger safety filters. Please try again or use a different model.`;
    }

    onProgress?.({
      [modelId]: {
        modelId,
        status: 'failed',
        progress: 0,
        error: errorMessage
      }
    });
    return {
      issues: [{
        type: 'high',
        title: 'Analysis Error',
        description: 'Failed to analyze code. Please try again or use a different model.',
        category: 'system',
        line: undefined,
        recommendation: 'Try running the scan again or select a different model'
      }],
      metrics: {
        score: 0,
        criticalIssues: 0,
        highIssues: 1,
        mediumIssues: 0,
        lowIssues: 0,
        passedChecks: 0,
        failedChecks: 1
      }
    };
  }
}

function normalizeGeminiResponse(parsed: any): { issues: SecurityIssue[]; metrics: SecurityMetrics } {
  if (!parsed.issues || !Array.isArray(parsed.issues) || !parsed.metrics) {
    throw new Error('Invalid response structure');
  }

  const issues = parsed.issues.map((issue: any) => ({
    type: String(issue.type || 'low').toLowerCase(),
    title: String(issue.title || 'Unnamed Issue'),
    description: String(issue.description || ''),
    category: String(issue.category || 'general'),
    line: typeof issue.line === 'number' ? issue.line : 
          typeof issue.line === 'string' ? parseInt(issue.line, 10) : undefined,
    recommendation: String(issue.recommendation || '')
  }));

  const metrics = {
    score: Number(parsed.metrics.score) || 0,
    criticalIssues: Number(parsed.metrics.criticalIssues) || 0,
    highIssues: Number(parsed.metrics.highIssues) || 0,
    mediumIssues: Number(parsed.metrics.mediumIssues) || 0,
    lowIssues: Number(parsed.metrics.lowIssues) || 0,
    passedChecks: Number(parsed.metrics.passedChecks) || 0,
    failedChecks: Number(parsed.metrics.failedChecks) || 0
  };

  return { issues, metrics };
}

export async function scanSecurity({
  sourceCode,
  language,
  modelIds,
  scanType,
  features,
  onProgress
}: SecurityScanParams): Promise<Record<string, any>> {
  if (!sourceCode.trim()) {
    throw new Error('Source code is required');
  }

  // Initialize progress for all models
  onProgress?.(modelIds.reduce((acc, modelId) => ({
    ...acc,
    [modelId]: {
      modelId,
      status: 'pending',
      progress: 0
    }
  }), {}));

  // Check model availability before starting
  const availableModels = await getAvailableModels();
  if (availableModels.length === 0) {
    throw new Error('No Ollama models available. Please ensure Ollama is running and models are installed.');
  }

  console.log('Starting security scan with parameters:', {
    language,
    modelIds,
    availableModels,
    scanType,
    enabledFeatures: Object.entries(features)
      .filter(([_, enabled]) => enabled)
      .map(([feature]) => feature)
  });

  // Check model availability
  const unavailableModels = modelIds.filter(id => !availableModels.includes(id));
  
  if (unavailableModels.length > 0) {
    console.warn('Some models are not available:', unavailableModels);
    // Don't throw error, continue with available models
  }

  // Filter to use only available models
  let usableModels = modelIds.filter(id => availableModels.includes(id));
    
  // Exclude gemini-1.5-pro-001 if it consistently fails
  if (modelIds.includes('gemini-1.5-pro-001')) {
      console.warn('Excluding gemini-1.5-pro-001 due to consistent safety filter blocks.');
      usableModels = usableModels.filter(id => id !== 'gemini-1.5-pro-001');
  }
  
  if (usableModels.length === 0) {
    throw new Error('None of the selected models are available. Please ensure Ollama is running or Google API key is configured.');
  }

  try {
    const results = await Promise.all(usableModels.map(async (modelId) => {
      const request: SecurityScanRequest = {
        modelIds: [modelId],
        language,
        sourceCode,
        scanType: scanType as SecurityScanType,
        features: Object.values(SECURITY_CATEGORIES).reduce((acc, category) => ({
          ...acc,
          [category]: features[category] || false
        }), {})
      };

      if (modelId.includes('gemini')) {
        return await scanWithGemini(request, modelId, onProgress);
      } else {
        return await scanWithOllama(request, modelId, onProgress);
      }
    }));

    return results.reduce((acc, result, index) => {
      acc[usableModels[index]] = result;
      return acc;
    }, {} as Record<string, any>);

  } catch (error) {
    console.error('Security scan failed:', error);
    throw error;
  }
}