import { streamOllama } from './ollama';
import { generateWithOpenAI } from '../ai/openai';
import { generateWithGemini } from '../ai/gemini';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { ENV_CONFIG } from '../../config/env';
import { logger } from '../utils/logger';
import type { AIMLGenerateParams } from '../../types/aiml';

export interface AIMLProgress {
  status: string;
  progress: number;
}

const LANGUAGE_TEMPLATES: Record<string, {
  codeStyle: string;
  imports: string[];
  patterns: string[];
}> = {
  python: {
    codeStyle: 'PEP 8',
    imports: [
      'numpy as np',
      'pandas as pd',
      'sklearn',
      'tensorflow as tf',
      'torch',
      'matplotlib.pyplot as plt',
      'seaborn as sns',
      'scipy',
      'xgboost as xgb',
      'lightgbm as lgb'
    ],
    patterns: [
      'Use type hints for function parameters and returns',
      'Implement comprehensive error handling with try-except',
      'Add detailed docstrings following NumPy style',
      'Follow OOP principles for complex implementations',
      'Use dataclasses for data containers',
      'Implement logging for debugging',
      'Use context managers when appropriate'
    ]
  },
  r: {
    codeStyle: 'tidyverse',
    imports: [
      'tidyverse',
      'caret',
      'mlr3',
      'keras',
      'data.table',
      'randomForest',
      'xgboost',
      'ggplot2',
      'dplyr',
      'tidyr'
    ],
    patterns: [
      'Use pipe operators for data manipulation',
      'Implement error handling with tryCatch',
      'Follow functional programming principles',
      'Use tibbles for data structures',
      'Implement parallel processing when possible',
      'Use vectorization over loops'
    ]
  },
  sql: {
    codeStyle: 'ANSI SQL',
    imports: [
      'WITH clause',
      'Window functions',
      'Common table expressions',
      'Stored procedures',
      'User-defined functions'
    ],
    patterns: [
      'Use CTEs for complex queries',
      'Implement proper indexing',
      'Follow set-based operations',
      'Use appropriate join types',
      'Implement error handling with TRY-CATCH',
      'Use transactions when necessary'
    ]
  },
  java: {
    codeStyle: 'Google Java Style',
    imports: [
      'org.deeplearning4j',
      'org.nd4j',
      'org.apache.spark.ml',
      'weka',
      'smile',
      'org.apache.commons.math3',
      'javax.persistence'
    ],
    patterns: [
      'Use proper exception handling',
      'Implement builder pattern for complex objects',
      'Follow SOLID principles',
      'Use dependency injection',
      'Implement proper threading',
      'Use Java Stream API'
    ]
  },
  julia: {
    codeStyle: 'Blue Style',
    imports: [
      'Flux',
      'DataFrames',
      'Statistics',
      'Distributions',
      'MLJ',
      'Plots',
      'CUDA'
    ],
    patterns: [
      'Use multiple dispatch',
      'Implement type stability',
      'Use broadcasting',
      'Implement proper error handling',
      'Use meta-programming when appropriate',
      'Leverage Julia\'s parallel computing'
    ]
  },
  scala: {
    codeStyle: 'Scala Style Guide',
    imports: [
      'org.apache.spark.ml',
      'breeze',
      'vegas',
      'scala.collection.parallel',
      'akka',
      'cats'
    ],
    patterns: [
      'Use functional programming patterns',
      'Implement proper error handling with Try',
      'Use immutable collections',
      'Implement type classes',
      'Use pattern matching',
      'Follow category theory principles'
    ]
  },
  cpp: {
    codeStyle: 'Google C++ Style',
    imports: [
      'tensorflow/core',
      'torch',
      'mlpack',
      'opencv',
      'eigen',
      'boost',
      'dlib'
    ],
    patterns: [
      'Use RAII principles',
      'Implement proper memory management',
      'Use smart pointers',
      'Follow modern C++ practices',
      'Implement exception handling',
      'Use templates appropriately'
    ]
  },
  javascript: {
    codeStyle: 'Airbnb Style',
    imports: [
      'tensorflow.js',
      'brain.js',
      'ml5.js',
      'scikit-learn.js',
      'd3.js',
      'plotly.js'
    ],
    patterns: [
      'Use async/await for asynchronous operations',
      'Implement proper error handling',
      'Use TypeScript for type safety',
      'Follow functional programming principles',
      'Implement proper memory management',
      'Use modern ES6+ features'
    ]
  },
  swift: {
    codeStyle: 'Swift API Design Guidelines',
    imports: [
      'CoreML',
      'CreateML',
      'TensorFlowLite',
      'Accelerate',
      'Vision',
      'NaturalLanguage'
    ],
    patterns: [
      'Use proper error handling with do-catch',
      'Implement protocol-oriented programming',
      'Use value types when appropriate',
      'Follow Swift concurrency patterns',
      'Use proper memory management',
      'Implement proper type safety'
    ]
  },
  matlab: {
    codeStyle: 'MATLAB Style Guide',
    imports: [
      'Statistics and Machine Learning Toolbox',
      'Deep Learning Toolbox',
      'Optimization Toolbox',
      'Parallel Computing Toolbox',
      'Computer Vision Toolbox'
    ],
    patterns: [
      'Use vectorization over loops',
      'Implement proper error handling',
      'Use object-oriented features',
      'Implement parallel processing',
      'Use proper data types',
      'Follow functional programming when possible'
    ]
  },
  go: {
    codeStyle: 'Go Standard',
    imports: [
      'gonum',
      'gorgonia',
      'golearn',
      'gomind',
      'gobrain',
      'plot'
    ],
    patterns: [
      'Use proper error handling',
      'Implement goroutines for concurrency',
      'Follow Go idioms',
      'Use interfaces appropriately',
      'Implement proper testing',
      'Use channels for communication'
    ]
  },
  sas: {
    codeStyle: 'SAS Standards',
    imports: [
      'PROC SQL',
      'PROC IML',
      'PROC ARIMA',
      'PROC NEURAL',
      'Enterprise Miner',
      'SAS/STAT'
    ],
    patterns: [
      'Use proper macro programming',
      'Implement error handling',
      'Follow data step principles',
      'Use proper procedures',
      'Implement proper logging',
      'Use hash tables when appropriate'
    ]
  }
};

const TASK_TEMPLATES = {
  modelTraining: (language: string) => `Create a production-ready ML training pipeline in ${language} that includes:
- Data loading and preprocessing
- Model architecture definition
- Training loop with validation
- Checkpointing and early stopping
- Metrics logging and visualization
- Error handling and recovery
Implementation must follow ML best practices and be well-documented.`,

  dataPreprocessing: (language: string) => `Create a robust data preprocessing pipeline in ${language} that includes:
- Data loading and validation
- Missing value handling
- Feature scaling and normalization
- Outlier detection and handling
- Feature engineering
- Data splitting (train/val/test)
Implementation must be efficient and handle edge cases.`,

  evaluation: (language: string) => `Create a comprehensive model evaluation suite in ${language} that includes:
- Multiple performance metrics
- Cross-validation
- Error analysis
- Performance visualization
- Statistical significance tests
Must handle different data types and model outputs.`,

  deployment: (language: string) => `Create a production deployment pipeline in ${language} that includes:
- Model serialization
- API endpoint creation
- Input validation
- Error handling
- Logging and monitoring
- Performance optimization
Must follow deployment best practices.`,

  optimization: (language: string) => `Create an optimization pipeline in ${language} that includes:
- Hyperparameter tuning
- Model compression
- Inference optimization
- Resource usage monitoring
- Performance profiling
Must improve model efficiency without sacrificing accuracy.`
};

const MODEL_SPECIFIC_PROMPTS = {
  'falcon3:10b': {
    system: (language: string) => `Generate ${language} AI/ML code with:
- ${LANGUAGE_TEMPLATES[language]?.codeStyle || 'standard'} conventions
- Proper documentation
- Error handling
- Testing considerations`,
    format: 'plain'
  },
  'phi4:latest': {
    system: (language: string) => `Expert ${language} AI/ML implementation using:
- ${LANGUAGE_TEMPLATES[language]?.codeStyle || 'standard'} conventions
- Common libraries: ${LANGUAGE_TEMPLATES[language]?.imports.join(', ')}
- Best practices: ${LANGUAGE_TEMPLATES[language]?.patterns.join(', ')}`,
    format: 'markdown'
  },
  'mistral-small:latest': {
    system: (language: string) => `Generate optimized ${language} code following:
- ${LANGUAGE_TEMPLATES[language]?.codeStyle || 'standard'} guidelines
- Performance best practices
- Clear documentation`,
    format: 'markdown'
  },
  'llama3.3:latest': {
    system: (language: string) => `Create efficient ${language} code following:
- ${LANGUAGE_TEMPLATES[language]?.codeStyle || 'standard'} guidelines
- Error handling patterns
- Performance optimization`,
    format: 'markdown'
  }
};

export async function generateAIML(
  params: AIMLGenerateParams,
  onProgress?: (progress: AIMLProgress) => void
): Promise<string> {
  try {
    // Validate input parameters
    if (!params.model || !params.language || !params.task) {
      throw new Error('Missing required parameters');
    }

    // Ensure default parameters for all models
    const defaultParams = {
      temperature: 0.7,
      topP: 0.9,
      maxTokens: 2048
    };

    // Create parameters object with defaults
    params.parameters = {
      ...defaultParams,
      ...(params.parameters || {})
    };

    // Build language-aware prompt
    const taskPrompt = TASK_TEMPLATES[params.task as keyof typeof TASK_TEMPLATES];
    const modelPrompt = MODEL_SPECIFIC_PROMPTS[params.model as keyof typeof MODEL_SPECIFIC_PROMPTS];
    
    const fullPrompt = `
${modelPrompt?.system(params.language) || ''}

Task Requirements:
${taskPrompt?.(params.language) || params.prompt}

Additional Requirements:
${params.prompt}

Complexity Level: ${params.complexity}
`.trim();

    // Initialize progress
    onProgress?.({ status: 'Starting generation...', progress: 0 });

    let result: string;
    
    // Update model handling to include all supported models
    if (['llama3.3:latest', 'phi4:latest', 'mistral-small:latest', 'falcon3:10b'].includes(params.model)) {
      result = await generateWithOllamaAIML(fullPrompt, params, onProgress);
    } else if (['gemini-pro', 'gemini-1.5-pro-001', 'gemini-2.0-flash'].includes(params.model)) {
      result = await generateWithGeminiAIML(fullPrompt, params, onProgress);
    } else {
      throw new Error(`Unsupported model: ${params.model}`);
    }

    // Clean and format the response
    const cleanedResult = cleanResponse(result);
    
    onProgress?.({ status: 'Completed', progress: 100 });
    return cleanedResult;

  } catch (error) {
    logger.error('AIML Generation Failed:', error);
    throw error;
  }
}

async function generateWithGeminiAIML(
  prompt: string,
  params: AIMLGenerateParams,
  onProgress?: (progress: AIMLProgress) => void
): Promise<string> {
  try {
    if (!ENV_CONFIG.GOOGLE_API_KEY) {
      throw new Error('Google API key not configured');
    }

    const genAI = new GoogleGenerativeAI(ENV_CONFIG.GOOGLE_API_KEY);
    const model = genAI.getGenerativeModel({ model: params.model });

    const result = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: params.parameters.temperature,
        topP: params.parameters.topP,
        maxOutputTokens: params.parameters.maxTokens,
      }
    });

    return result.response?.text() || '';
  } catch (error) {
    logger.error('Gemini AIML Generation Failed:', error);
    throw error;
  }
}

async function generateWithDeepSeek(prompt: string, params: AIMLGenerateParams): Promise<string> {
  try {
    const parameters = {
      temperature: params.parameters?.temperature || 0.3,
      topP: params.parameters?.topP || 0.9,
      maxTokens: params.parameters?.maxTokens || 2048
    };

    logger.info('DeepSeek Generation', {
      parameters,
      promptLength: prompt.length
    });

    const response = await fetch(`${ENV_CONFIG.OLLAMA_API_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'deepseek-coder:33b',
        prompt,
        stream: false,
        options: {
          temperature: parameters.temperature,
          top_p: parameters.topP,
          num_predict: parameters.maxTokens
        }
      })
    });

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.status}`);
    }

    const data = await response.json();
    if (!data.response) {
      throw new Error('Empty response from model');
    }

    logger.info('DeepSeek Generation', 'Completed successfully');
    return data.response;
  } catch (error) {
    logger.error('DeepSeek Generation Failed:', error);
    throw new Error(`DeepSeek generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

async function generateWithOllamaAIML(
  prompt: string,
  params: AIMLGenerateParams,
  onProgress?: (progress: AIMLProgress) => void
): Promise<string> {
  let retryCount = 0;
  const maxRetries = 2;

  while (retryCount <= maxRetries) {
    try {
      onProgress?.({ 
        status: retryCount > 0 ? `Retrying... (${retryCount}/${maxRetries})` : 'Starting generation...',
        progress: 10 
      });

      // Simplified model ID handling - use model name directly
      const modelId = params.model;
      
      logger.info('Ollama', `Using model: ${modelId}`);

      const response = await fetch(`${ENV_CONFIG.OLLAMA_API_URL}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: modelId,
          prompt: prompt,
          stream: false, // Changed to false for more reliable responses
          options: {
            temperature: params.parameters?.temperature || 0.7,
            top_p: params.parameters?.topP || 0.9,
            num_predict: params.parameters?.maxTokens || 2048,
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Ollama API error: ${response.status}`);
      }

      onProgress?.({ status: 'Processing response...', progress: 50 });

      const data = await response.json();
      
      if (!data.response) {
        throw new Error('Empty response from model');
      }

      // Add code block markers if missing
      let processedResponse = data.response;
      if (!processedResponse.includes('```')) {
        processedResponse = `\`\`\`${params.language}\n${processedResponse}\n\`\`\``;
      }

      onProgress?.({ status: 'Completed', progress: 100 });
      logger.info('Ollama', 'Generation completed successfully');
      
      return cleanResponse(processedResponse);

    } catch (error) {
      logger.error('Ollama Generation', `Attempt ${retryCount + 1} failed:`, error);
      
      if (retryCount < maxRetries) {
        retryCount++;
        await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
        continue;
      }
      
      // If all retries failed and in development, return test data
      if (process.env.NODE_ENV === 'development') {
        logger.warn('Ollama', 'Using test data in development');
        return generateTestResponse(params.task);
      }
      
      throw error;
    }
  }

  throw new Error('Failed to generate after all retries');
}

// Update cleanResponse to better handle code blocks
function cleanResponse(response: string): string {
  try {
    // First try to extract code block
    const codeBlockMatch = response.match(/```(?:\w+)?\n([\s\S]*?)```/);
    if (codeBlockMatch) {
      return codeBlockMatch[1].trim();
    }

    // If no code block, clean up any markdown artifacts
    return response
      .trim()
      // Remove potential language tags
      .replace(/^(?:python|javascript|java|cpp|r)\n/i, '')
      // Remove any remaining markdown code markers
      .replace(/```/g, '')
      // Ensure proper line endings
      .replace(/\r\n/g, '\n')
      // Remove any leading/trailing blank lines
      .replace(/^\n+|\n+$/g, '');
  } catch (error) {
    logger.error('Response cleaning failed:', error);
    return response.trim();
  }
}

// Update test response to match the task
function generateTestResponse(task: string): string {
  switch (task) {
    case 'dataPreprocessing':
      return `
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

def preprocess_timeseries(df: pd.DataFrame) -> pd.DataFrame:
    """
    Preprocess time series data with missing values handling and feature engineering.
    
    Args:
        df: Input DataFrame with datetime index
    Returns:
        Preprocessed DataFrame
    """
    # Handle missing values
    imputer = SimpleImputer(strategy='mean')
    df_imputed = pd.DataFrame(
        imputer.fit_transform(df),
        columns=df.columns,
        index=df.index
    )
    
    # Add time-based features
    df_imputed['hour'] = df_imputed.index.hour
    df_imputed['day_of_week'] = df_imputed.index.dayofweek
    
    # Scale features
    scaler = StandardScaler()
    df_scaled = pd.DataFrame(
        scaler.fit_transform(df_imputed),
        columns=df_imputed.columns,
        index=df_imputed.index
    )
    
    return df_scaled`;

    case 'modelTraining':
      return `
import tensorflow as tf
from tensorflow.keras import layers, models
import numpy as np
from typing import Tuple

def create_training_pipeline(
    input_shape: Tuple[int, ...],
    num_classes: int,
    learning_rate: float = 0.001
) -> Tuple[tf.keras.Model, dict]:
    """
    Create and compile a model with training configuration.
    
    Args:
        input_shape: Shape of input data
        num_classes: Number of output classes
        learning_rate: Initial learning rate
    Returns:
        model: Compiled model
        callbacks: Dictionary of training callbacks
    """
    # Define model architecture
    model = models.Sequential([
        layers.Input(shape=input_shape),
        layers.Conv2D(32, 3, activation='relu'),
        layers.MaxPooling2D(),
        layers.Conv2D(64, 3, activation='relu'),
        layers.MaxPooling2D(),
        layers.Flatten(),
        layers.Dense(64, activation='relu'),
        layers.Dropout(0.5),
        layers.Dense(num_classes, activation='softmax')
    ])
    
    # Compile model
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    # Setup callbacks
    callbacks = {
        'early_stopping': tf.keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=5,
            restore_best_weights=True
        ),
        'checkpoint': tf.keras.callbacks.ModelCheckpoint(
            'model_checkpoint.h5',
            monitor='val_accuracy',
            save_best_only=True
        ),
        'tensorboard': tf.keras.callbacks.TensorBoard(log_dir='./logs')
    }
    
    return model, callbacks`;

    case 'evaluation':
      return `
import numpy as np
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, Any

def evaluate_model(model, X_test: np.ndarray, y_test: np.ndarray) -> Dict[str, Any]:
    """
    Comprehensive model evaluation with multiple metrics.
    
    Args:
        model: Trained model
        X_test: Test features
        y_test: True labels
    Returns:
        Dictionary containing evaluation metrics and plots
    """
    # Get predictions
    y_pred = model.predict(X_test)
    y_pred_classes = np.argmax(y_pred, axis=1)
    
    # Calculate metrics
    conf_matrix = confusion_matrix(y_test, y_pred_classes)
    class_report = classification_report(y_test, y_pred_classes, output_dict=True)
    
    # ROC curve for each class
    fpr, tpr, _ = roc_curve(y_test, y_pred[:, 1])
    roc_auc = auc(fpr, tpr)
    
    # Create visualizations
    plt.figure(figsize=(12, 8))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues')
    plt.title('Confusion Matrix')
    plt.savefig('confusion_matrix.png')
    
    return {
        'confusion_matrix': conf_matrix,
        'classification_report': class_report,
        'roc_auc': roc_auc,
        'predictions': y_pred
    }`;

    case 'deployment':
      return `
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import tensorflow as tf
import numpy as np
import logging
from typing import List, Dict, Any

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()

class PredictionRequest(BaseModel):
    features: List[float]
    model_version: str = "latest"

class PredictionResponse(BaseModel):
    prediction: float
    confidence: float
    model_version: str

@app.post("/predict", response_model=PredictionResponse)
async def predict(request: PredictionRequest) -> Dict[str, Any]:
    try:
        # Load model (in practice, keep loaded)
        model = tf.keras.models.load_model("model/latest")
        
        # Preprocess input
        features = np.array(request.features).reshape(1, -1)
        
        # Make prediction
        prediction = model.predict(features)
        
        # Log request and response
        logger.info(f"Prediction made for input shape: {features.shape}")
        
        return {
            "prediction": float(prediction[0]),
            "confidence": float(np.max(prediction)),
            "model_version": request.model_version
        }
    except Exception as e:
        logger.error(f"Prediction failed: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))`;

    case 'optimization':
      return `
from sklearn.model_selection import RandomizedSearchCV
import optuna
import numpy as np
from typing import Dict, Any

def optimize_hyperparameters(
    model_class,
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_trials: int = 100
) -> Dict[str, Any]:
    """
    Optimize model hyperparameters using Optuna.
    
    Args:
        model_class: Model class to optimize
        X_train: Training features
        y_train: Training labels
        n_trials: Number of optimization trials
    Returns:
        Best parameters and study results
    """
    def objective(trial):
        # Define hyperparameter space
        params = {
            'learning_rate': trial.suggest_float('learning_rate', 1e-5, 1e-1, log=True),
            'num_layers': trial.suggest_int('num_layers', 1, 5),
            'hidden_units': trial.suggest_int('hidden_units', 32, 512),
            'dropout': trial.suggest_float('dropout', 0.1, 0.5)
        }
        
        # Create and train model
        model = model_class(**params)
        model.fit(X_train, y_train, validation_split=0.2)
        
        return model.evaluate(X_train, y_train)[1]
    
    # Create study
    study = optuna.create_study(direction='maximize')
    study.optimize(objective, n_trials=n_trials)
    
    return {
        'best_params': study.best_params,
        'best_value': study.best_value,
        'study': study
    }`;

    default:
      return `
# Example code for ${task}
def main():
    print(f"Implementing ${task}...")
    # Add implementation here
    pass

if __name__ == "__main__":
    main()`;
  }
}

// ...rest of the file remains unchanged...
