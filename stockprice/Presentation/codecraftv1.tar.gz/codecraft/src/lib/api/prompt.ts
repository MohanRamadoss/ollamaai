import type { PromptTemplate, PromptGenerationParams, PromptProgress } from '../../types/prompt';
import { getPromptTemplate } from '../prompts/promptgenerator';
import { generateWithGemini } from './gemini';
import { generateWithOllama } from './ollama';
import { getPromptModel } from '../../config/promptModels';
import type { Language, ComplexityLevel, Model } from '../../types';

export async function generateBasicPrompt({
  task,
  language,
  complexity,
  requirements,
  model
}: PromptGenerationParams): Promise<string> {
  const promptTemplate = `You are a prompt engineering assistant. Your task is to create a well-structured prompt (NOT CODE) that describes how to implement the following task.

Task Description: ${task}
Programming Language: ${language}
Complexity Level: ${complexity}

Create a detailed prompt that includes:
1. Problem context and background
2. Specific functionality requirements
3. Technical constraints and considerations
4. Expected behavior and outcomes
5. Quality requirements and standards
${requirements.length > 0 ? '\nAdditional Requirements:\n' + requirements.map(req => `- ${req}`).join('\n') : ''}

IMPORTANT: DO NOT GENERATE ANY CODE. Instead, create a clear, detailed prompt that someone could use to implement this functionality.

Format your response as a detailed prompt that focuses on WHAT needs to be implemented rather than HOW to implement it.`;

  const promptModel = getPromptModel(model.id);
  if (!promptModel) throw new Error(`Model ${model.id} not found`);

  try {
    let result: string;
    if (promptModel.provider === 'google') {
      result = await generateWithGemini(promptTemplate, 'gemini-pro', {
        temperature: 0.7,
        topP: 0.95,
        maxTokens: 1024
      });
    } else if (promptModel.provider === 'ollama') {
      const modelName = model.id.replace('ollama/', '');
      result = await generateWithOllama(promptTemplate, modelName, {
        temperature: 0.7,
        topP: 0.95,
        topK: 40,
        maxTokens: 1024
      });
    } else {
      throw new Error(`Unsupported provider: ${promptModel.provider}`);
    }

    return result;
  } catch (error) {
    console.error('Failed to generate prompt:', error);
    throw error;
  }
}

async function generateWithProvider(
  modelId: string,
  prompt: string,
  options: PromptGenerationParams
): Promise<{ code: string; explanation?: string }> {
  const model = getPromptModel(modelId);
  if (!model) throw new Error(`Model ${modelId} not found`);

  try {
    const systemPrompt = `You are a prompt engineering assistant. Your task is to create detailed, structured prompts for code generation. 

DO NOT generate actual code. Instead, create a comprehensive prompt that will help generate high-quality code.

Focus on:
1. Clear requirements specification
2. Technical constraints and considerations
3. Expected behaviors and outcomes
4. Quality and performance expectations
5. Testing and validation requirements

Format your response as:
PROMPT:
[Your detailed prompt here]

EXPLANATION:
[Brief explanation of the prompt structure and key considerations]`;

    const fullPrompt = `${systemPrompt}\n\nBased on these requirements:\n${prompt}`;

    let result: string;
    if (model.provider === 'google') {
      const geminiModel = model.modelIdentifier;
      result = await generateWithGemini(fullPrompt, geminiModel, {
        temperature: options.temperature ?? model.defaultParams.temperature,
        topP: options.topP ?? model.defaultParams.topP,
        maxTokens: options.maxTokens ?? model.defaultParams.maxTokens,
        topK: model.defaultParams.topK,
      });
    } else if (model.provider === 'ollama') {
      const modelName = modelId.replace('ollama/', '');
      result = await generateWithOllama(fullPrompt, modelName, {
        temperature: options.temperature ?? 0.7,
        topP: options.topP ?? 0.9,
        topK: options.topK ?? 40,
        maxTokens: options.maxTokens ?? 2048
      });
    } else {
      throw new Error(`Unsupported provider: ${model.provider}`);
    }

    const [promptPart, explanationPart] = parseResult(result);
    return {
      code: promptPart,
      explanation: explanationPart
    };
  } catch (error) {
    console.error(`Generation failed for ${modelId}:`, error);
    throw error;
  }
}

function parseResult(result: string): [string, string] {
  const parts = result.split('EXPLANATION:');
  return [
    parts[0].replace('PROMPT:', '').trim(),
    parts[1]?.trim() ?? ''
  ];
}

export const generatePrompt = async (
  options: GeneratePromptOptions,
  onProgress?: (progress: Record<string, PromptProgress>) => void
): Promise<Record<string, { code: string; explanation?: string }>> => {
  const results: Record<string, { code: string; explanation?: string }> = {};
  const progress = initializeProgress(options.modelIds);
  onProgress?.(progress);

  const processedTemplate = processTemplate(options);
  const fullPrompt = buildFullPrompt(options, processedTemplate);

  await Promise.all(
    options.modelIds.map(modelId => 
      generateForModel(modelId, fullPrompt, options, progress, results, onProgress)
    )
  );

  if (Object.keys(results).length === 0) {
    throw new Error('All models failed to generate code');
  }

  return results;
};

function initializeProgress(modelIds: string[]): Record<string, PromptProgress> {
  return Object.fromEntries(
    modelIds.map(modelId => [
      modelId,
      { modelId, status: 'idle', progress: 0 }
    ])
  );
}

function processTemplate(options: GeneratePromptOptions): string {
  let template = options.template.template;
  if (options.variables) {
    Object.entries(options.variables).forEach(([key, value]) => {
      template = template.replace(new RegExp(`{${key}}`, 'g'), value || '');
    });
  }
  return template;
}

function buildFullPrompt(options: GeneratePromptOptions, processedTemplate: string): string {
  const languageSpecific = options.template.language ? 
    generateLanguageSpecificGuidelines(options.template.language) : '';

  return `
Category: ${options.template.category}
${options.template.language ? `Language: ${options.template.language}` : ''}
${options.template.complexity ? `Complexity: ${options.template.complexity}` : ''}

${languageSpecific}

${processedTemplate}

Please provide a ${options.template.language}-specific response:
<code>
[Your generated code here]
</code>

### Explanation:
[Explanation highlighting language-specific considerations]
`;
}

function generateLanguageSpecificGuidelines(language: string): string {
  const guidelines: Record<string, string> = {
    // Standard Programming Languages
    'javascript': 'Consider: ES6+ features, async/await, functional programming, package management, testing frameworks',
    'python': 'Consider: PEP 8, type hints, virtual environments, package management, testing frameworks',
    'java': 'Consider: OOP principles, Spring ecosystem, build tools, JVM optimization, testing frameworks',
    'typescript': 'Consider: Type safety, interfaces, generics, decorators, module system',
    'julia': 'Consider: Multiple dispatch, meta-programming, package ecosystem, scientific computing',
    'go': 'Consider: Goroutines, channels, error handling, tooling, standard library',
    'rust': 'Consider: Memory safety, ownership, lifetimes, cargo ecosystem, testing practices',
    'csharp': 'Consider: .NET ecosystem, LINQ, async/await, dependency injection, testing',
    'swift': 'Consider: Optionals, protocols, ARC memory management, SwiftUI, testing',
    'cpp': 'Consider: Memory management, STL usage, modern C++ features, build systems',
    'r': 'Consider: Vectorization, data frames, package ecosystem, statistical methods',
    'php': 'Consider: Modern PHP features, Composer, frameworks, testing practices',
    'ruby': 'Consider: Ruby idioms, gems, metaprogramming, testing frameworks',
    'perl': 'Consider: CPAN modules, text processing, regular expressions, testing',

    // Infrastructure & Automation
    'ansible': 'Consider: Playbook structure, roles, inventory management, best practices',
    'terraform': 'Consider: HCL syntax, state management, modules, providers',
    'cloudformation': 'Consider: Template structure, resource dependencies, intrinsic functions',
    'arm': 'Consider: Template syntax, resource providers, linked templates, deployment',
    'pulumi': 'Consider: Infrastructure as code, state management, providers, testing',
    'powershell': 'Consider: Cmdlets, modules, error handling, Windows integration',
    'bash': 'Consider: Shell features, error handling, platform compatibility, testing',
    'shell': 'Consider: POSIX compliance, portability, error handling, best practices',
    'docker': 'Consider: Dockerfile best practices, multi-stage builds, security, networking',
    'kubernetes': 'Consider: Resource types, YAML structure, controllers, operators',
    'helm': 'Consider: Chart structure, templates, values, release management',
    'puppet': 'Consider: Manifest structure, modules, Hiera integration, testing',
    'chef': 'Consider: Cookbook structure, resources, attributes, testing',
    'bicep': 'Consider: Resource declarations, modules, parameter handling, deployment',
    'serverless': 'Consider: Framework features, event handling, deployment, testing',
    'gitlab-ci': 'Consider: Pipeline structure, job definitions, artifacts, caching',
    'github-actions': 'Consider: Workflow syntax, actions, events, secrets management'
  };

  return guidelines[language.toLowerCase()] ?? '';
}

async function generateForModel(
  modelId: string,
  fullPrompt: string,
  options: GeneratePromptOptions,
  progress: Record<string, PromptProgress>,
  results: Record<string, { code: string; explanation?: string }>,
  onProgress?: (progress: Record<string, PromptProgress>) => void
): Promise<void> {
  try {
    progress[modelId].status = 'generating';
    progress[modelId].progress = 10;
    onProgress?.(progress);

    const model = getPromptModel(modelId);
    const result = await generateWithProvider(
      modelId, 
      fullPrompt, 
      {
        temperature: options.temperature ?? model?.defaultParams.temperature ?? 0.7,
        topP: options.topP ?? model?.defaultParams.topP ?? 0.9,
        topK: options.topK ?? model?.defaultParams.topK ?? 40,
        maxTokens: options.maxTokens ?? model?.defaultParams.maxTokens ?? 2048,
      }
    );

    results[modelId] = result;
    progress[modelId].status = 'completed';
    progress[modelId].progress = 100;
  } catch (error) {
    console.error(`Failed to generate with ${modelId}:`, error);
    progress[modelId].status = 'failed';
    progress[modelId].error = error instanceof Error ? error.message : 'Unknown error';
  }
  onProgress?.(progress);
}