import { generateWithOpenAI } from '../ai/openai';
import { generateWithGemini } from '../ai/gemini';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { ENV_CONFIG } from '../../config/env';
import { MODEL_CONFIGS } from '../../config/models';
import { LANGUAGES } from '../../config/languages';
import type { GenerationRequest, ComplexityLevel } from '../../types/models';
import { logger } from '../utils/logger';

const COMPLEXITY_PROMPTS: Record<ComplexityLevel, (language: string) => string> = {
  basic: (language) => `You are an expert ${language} developer. Create a basic solution that:
- Uses clear, simple implementations
- Has good error handling
- Follows standard coding patterns
- Includes helpful comments
- Uses clear variable naming
- Prioritizes readability
- Focuses on core functionality
- Uses simple, straightforward implementations
- Includes basic error handling
- Has minimal dependencies
- Uses standard library features


Focus on producing clean, maintainable code.`,

  intermediate: (language) => `You are a senior ${language} developer. Create a professional solution that:
- Implements robust error handling
- Uses design patterns appropriately
- Includes input validation
- Has comprehensive logging
- Uses efficient algorithms
- Follows all best practices for ${language}
- Includes detailed documentation
- Follows SOLID principles
- Has unit test examples

The code should be production-ready and well-documented.`,

  advanced: (language) => `You are a principal ${language} architect. Create an enterprise-grade solution that:
- Uses advanced ${language} features
- Implements complete error handling and recovery
- Includes performance optimizations
- Has security best practices
- Uses dependency injection
- Implements caching where appropriate
- Includes metrics and monitoring
- Has extensive documentation
- Is highly scalable and maintainable
- Includes comprehensive testing approach
- Implements comprehensive error handling and recovery
- Includes performance optimizations
- Has thread safety considerations
- Implements caching where appropriate
- Uses advanced design patterns

The solution should be highly scalable and maintainable.`
};

// Add Ansible-specific configuration
const ANSIBLE_PATTERNS = {
  codeIdentifiers: ['hosts:', 'tasks:', 'vars:', 'handlers:', 'roles:', 'become:', 'gather_facts:'],
  structureElements: ['---', 'name:', 'with_items:', 'register:', 'when:'],
  commonTasks: ['yum:', 'apt:', 'service:', 'template:', 'file:', 'copy:']
};

// Add shell-specific patterns
const SHELL_PATTERNS = {
  bash: {
    codeIdentifiers: ['#!/bin/bash', 'function', 'if', 'while', 'for', 'case', 'source'],
    commonCommands: ['echo', 'read', 'export', 'set', 'trap', 'eval', 'exec'],
    bestPractices: ['set -e', 'set -u', 'set -o pipefail']
  },
  powershell: {
    codeIdentifiers: ['param(', 'function', 'if', 'foreach', 'try', 'catch', 'begin'],
    commonCommands: ['Write-Host', 'Get-Item', 'Set-Item', '$PSScriptRoot', '$ErrorActionPreference'],
    bestPractices: ['[CmdletBinding()]', 'Write-Verbose', 'Write-Debug']
  }
};

// Add Terraform patterns
const TERRAFORM_PATTERNS = {
  codeIdentifiers: ['provider', 'resource', 'variable', 'output', 'module', 'data'],
  blockTypes: ['terraform', 'locals', 'backend', 'workspace'],
  bestPractices: ['version', 'required_providers', 'count', 'for_each', 'depends_on']
};

// Update the buildPrompt function to be language-aware
function buildPrompt(language: string, complexity: ComplexityLevel, prompt: string): string {
  const lowerLang = language.toLowerCase();
  
  if (lowerLang === 'bash' || lowerLang === 'shell' || lowerLang === 'sh') {
    return buildShellPrompt('bash', complexity, prompt);
  }
  if (lowerLang === 'powershell' || lowerLang === 'ps1') {
    return buildShellPrompt('powershell', complexity, prompt);
  }
  if (lowerLang === 'terraform' || lowerLang === 'hcl') {
    return buildTerraformPrompt(prompt, complexity);
  }

  const langConfig = LANGUAGES[language as keyof typeof LANGUAGES];
  const langName = langConfig?.name || language;

  // Special handling for configuration languages
  if (language === 'ansible' || language === 'yaml') {
    return buildAnsiblePrompt(prompt, complexity);
  }

  return `You are an expert ${langName} developer. Generate production-ready code that solves the following problem.

TASK:
${prompt}

REQUIREMENTS:
1. Use ${langName} best practices and conventions
2. Include proper error handling
3. Add clear comments explaining the logic
4. Follow standard coding patterns
5. Use clear variable/function naming
6. Make code modular and maintainable
7. Complexity level: ${complexity}

FORMAT:
\`\`\`${language}
[Your code here]
\`\`\`

Ensure the code:
- Is complete and runnable
- Has proper indentation
- Includes necessary imports/dependencies
- Follows ${langName} style guidelines`;
}

// Update buildAnsiblePrompt for better ansible output
function buildAnsiblePrompt(prompt: string, complexity: ComplexityLevel): string {
  return `You are an expert Ansible developer. Create a ${complexity} level playbook that:

TASK DESCRIPTION:
${prompt}

TECHNICAL REQUIREMENTS:
1. Structure:
   - Use proper YAML syntax and indentation
   - Include meaningful play and task names
   - Organize tasks logically
   - Use role-based structure when appropriate

2. Best Practices:
   - Ensure idempotent operations
   - Use handlers for service management
   - Include proper variable naming
   - Add pre and post tasks as needed
   - Use tags for task organization

3. Error Handling:
   - Add proper error checking
   - Include failure conditions
   - Use register and when clauses
   - Handle service dependencies

4. Documentation:
   - Add comments for complex tasks
   - Document variables and defaults
   - Include usage examples
   - Specify requirements

EXAMPLE FORMAT:
\`\`\`yaml
---
- name: Example playbook
  hosts: target_servers
  become: yes
  gather_facts: yes

  vars:
    # Define variables here
    
  pre_tasks:
    # Pre-requisite checks

  tasks:
    - name: First task
      # Task implementation

  handlers:
    # Define handlers
\`\`\`

Generate only the playbook code, no explanations.`;
}

function buildShellPrompt(language: string, complexity: ComplexityLevel, prompt: string): string {
  const isWindows = language.toLowerCase() === 'powershell';
  const shellType = isWindows ? 'PowerShell' : 'Bash';
  
  return `Generate a ${complexity} level ${shellType} script that:

TASK DESCRIPTION:
${prompt}

TECHNICAL REQUIREMENTS:
1. Script Structure:
   - Include proper shebang line ${isWindows ? '' : '(#!/bin/bash)'}
   - Add script description and usage
   - Include parameter validation
   - Implement proper error handling
   - Add logging functionality
   - Use functions for modularity

2. Best Practices:
   ${isWindows ? `
   - Use proper PowerShell conventions
   - Implement error handling with try/catch
   - Use proper parameter declarations
   - Include comment-based help
   - Use approved verbs for functions
   ` : `
   - Use set -e for error handling
   - Implement proper variable quoting
   - Use shellcheck compatible code
   - Include cleanup traps
   - Use safe path handling
   `}

3. Features:
   - Input validation and sanitization
   - Proper exit codes
   - Progress indicators
   - Logging mechanisms
   - Configuration handling
   - Resource cleanup

FORMAT:
\`\`\`${language}
[Script implementation]
\`\`\`

Focus on security, reliability, and maintainability.`;
}

function buildTerraformPrompt(prompt: string, complexity: ComplexityLevel): string {
  return `Generate a ${complexity} level Terraform configuration that:

TASK DESCRIPTION:
${prompt}

TECHNICAL REQUIREMENTS:
1. Structure:
   - Use proper HCL syntax
   - Implement resource organization
   - Include variable definitions
   - Add output configurations
   - Use proper state management
   - Implement proper provider configuration

2. Best Practices:
   - Use proper resource naming
   - Implement proper tagging
   - Include data sources where appropriate
   - Use variables for reusability
   - Implement proper state locking
   - Use workspaces if needed

3. Features:
   - Resource dependencies
   - Conditional creation
   - Count/for_each usage
   - Local values
   - Data transformation
   - Module organization

4. Security:
   - IAM best practices
   - Security group configurations
   - Encryption settings
   - Access controls
   - Secure variable handling

FORMAT:
\`\`\`hcl
# Resource configuration
[Terraform code here]
\`\`\`

Ensure the configuration is production-ready and follows infrastructure-as-code best practices.`;
}

async function checkOllamaModel(modelId: string): Promise<boolean> {
  try {
    console.log(`[Ollama] Checking if model ${modelId} is available`);
    const response = await fetch(`${ENV_CONFIG.OLLAMA_API_URL}/api/tags`);
    if (!response.ok) {
      console.error(`[Ollama] Failed to get model list: ${response.status}`);
      return false;
    }
    const data = await response.json();
    const modelExists = data.models?.some((model: any) => model.name === modelId);
    console.log(`[Ollama] Model ${modelId} available: ${modelExists}`);
    return modelExists;
  } catch (error) {
    console.error(`[Ollama] Error checking model:`, error);
    return false;
  }
}

// Update generateWithOllama function with minimal options
async function generateWithOllama(prompt: string, modelId: string, retryCount = 0): Promise<string> {
  logger.info('Ollama', `Starting generation with ${modelId}`);
  
  try {
    const cleanModelId = modelId.replace('ollama/', '');
    logger.debug('Ollama', 'Sending request', { modelId: cleanModelId, retryCount });
    
    const response = await fetch(`${ENV_CONFIG.OLLAMA_API_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: cleanModelId,
        prompt: prompt,
        stream: false,
        options: {
          temperature: 0.3,
          top_p: 0.9,
        }
      })
    });

    if (!response.ok) {
      logger.error('Ollama', `HTTP error ${response.status}`);
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    logger.debug('Ollama', 'Response received', { 
      modelId, 
      responseLength: data.response?.length 
    });
    
    if (!data.response) {
      logger.error('Ollama', 'Empty response from model');
      throw new Error('Empty response from model');
    }

    return data.response;
  } catch (error) {
    logger.error('Ollama', `Error with ${modelId}`, error);
    
    if (retryCount < 2) {
      logger.info('Ollama', `Retrying generation (${retryCount + 1}/2)`);
      await new Promise(resolve => setTimeout(resolve, 1000));
      return generateWithOllama(prompt, modelId, retryCount + 1);
    }
    throw error;
  }
}

async function generateWithGemini(prompt: string, modelId: string): Promise<string> {
  console.log(`[Gemini] Generating with model ${modelId}`);
  
  if (!ENV_CONFIG.GOOGLE_API_KEY) {
    throw new Error('Google API key not configured');
  }

  try {
    const genAI = new GoogleGenerativeAI(ENV_CONFIG.GOOGLE_API_KEY);
    
    // Map Gemini model IDs
    const geminiModelId = modelId === 'gemini-pro-code' ? 'gemini-pro' : modelId;
    console.log(`[Gemini] Using model ID: ${geminiModelId}`);
    
    const model = genAI.getGenerativeModel({ model: geminiModelId });

    const result = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.8,
        maxOutputTokens: 8192,
      }
    });

    if (!result.response) {
      throw new Error('Empty response from Gemini');
    }

    const text = result.response.text();
    if (!text) {
      throw new Error('Empty text in Gemini response');
    }

    console.log(`[Gemini] Raw response:`, text.substring(0, 100));
    return text;
  } catch (error: any) {
    console.error(`[Gemini] Error:`, error);
    throw new Error(`Gemini API error: ${error.message}`);
  }
}

// Update extractCodeFromResponse to use language config
function extractCodeFromResponse(text: string, language: string): string {
  console.log('[Extract] Processing response:', text.substring(0, 100));
  
  const langConfig = LANGUAGES[language as keyof typeof LANGUAGES];
  
  // First try to find a code block
  const blockMatch = text.match(/```[\w]*\n?([\s\S]+?)```/);
  if (blockMatch) {
    return blockMatch[1].trim();
  }

  // Clean the text and check for language-specific patterns
  const cleanedText = text
    .split('\n')
    .filter(line => 
      !line.startsWith('Here') &&
      !line.startsWith('This') &&
      !line.includes('example:') &&
      line.trim().length > 0
    )
    .join('\n')
    .trim();

  // Special handling for Ansible/YAML
  if (language.toLowerCase() === 'ansible' || language.toLowerCase() === 'yaml') {
    const hasAnsibleStructure = ANSIBLE_PATTERNS.structureElements
      .some(pattern => text.includes(pattern));
    
    const hasAnsibleTasks = ANSIBLE_PATTERNS.commonTasks
      .some(pattern => text.includes(pattern));
    
    if (hasAnsibleStructure || hasAnsibleTasks) {
      // Clean and validate YAML structure
      const cleanedYaml = text
        .split('\n')
        .filter(line => 
          !line.startsWith('Here') &&
          !line.startsWith('This') &&
          line.trim() !== ''
        )
        .join('\n')
        .trim();

      if (cleanedYaml.startsWith('---')) {
        return cleanedYaml;
      }

      // Add YAML document start if missing
      return `---\n${cleanedYaml}`;
    }
  }

  // Special handling for shell scripts
  const lowerLang = language.toLowerCase();
  if (lowerLang === 'bash' || lowerLang === 'shell' || lowerLang === 'sh') {
    if (text.includes('#!/bin/bash') || text.includes('#!/bin/sh')) {
      return text;
    }
    const hasShellPatterns = SHELL_PATTERNS.bash.codeIdentifiers
      .some(pattern => text.includes(pattern));
    if (hasShellPatterns) {
      return `#!/bin/bash\n\n${text}`;
    }
  }

  // Special handling for PowerShell
  if (lowerLang === 'powershell' || lowerLang === 'ps1') {
    if (SHELL_PATTERNS.powershell.codeIdentifiers
      .some(pattern => text.includes(pattern))) {
      return text;
    }
  }

  // Special handling for Terraform
  if (lowerLang === 'terraform' || lowerLang === 'hcl') {
    if (TERRAFORM_PATTERNS.codeIdentifiers
      .some(pattern => text.includes(pattern))) {
      return text;
    }
  }

  // Use language-specific identifiers to validate code
  if (langConfig?.codeIdentifiers.some(identifier => 
    cleanedText.includes(identifier))) {
    return cleanedText;
  }

  throw new Error(`No valid ${langConfig?.name || language} code found in response`);
}

export type GenerationProgress = {
  modelId: string;
  status: 'pending' | 'generating' | 'completed' | 'failed';
  result?: string;
  error?: string;
};

export type ProgressCallback = (progress: Record<string, GenerationProgress>) => void;

function buildCodeLlamaPrompt(language: string, complexity: ComplexityLevel, prompt: string): string {
  return `You are an expert ${language} developer. Your task is to generate production-quality code based on the following requirements:

TASK: ${prompt}

REQUIREMENTS:
1. Language: ${language}
2. Complexity Level: ${complexity}
3. Include proper error handling
4. Add clear comments
5. Follow best practices
6. Use efficient algorithms
7. Make code modular and reusable

FORMAT:
- Return ONLY the code
- Wrap code in triple backticks
- Include language identifier
- Do not include explanations outside the code block

Example format:
\`\`\`${language}
[Your code here]
\`\`\`

Focus on writing clean, efficient, and well-structured code.`;
}

// Update buildOllamaPrompt for better language support
function buildOllamaPrompt(language: string, complexity: ComplexityLevel, prompt: string): string {
  const langConfig = LANGUAGES[language as keyof typeof LANGUAGES];
  const langName = langConfig?.name || language;

  return `Generate ${langName} code for the following task:

${prompt}

Instructions:
1. Write production-ready ${langName} code
2. Include error handling
3. Add helpful comments
4. Follow ${langName} conventions
5. Complexity: ${complexity}

Start the implementation:`;
}

export async function generateCode(
  request: GenerationRequest,
  onProgress?: ProgressCallback
): Promise<string> {
  const { modelIds, prompt, language, complexity } = request;
  logger.info('Generate', 'Starting code generation', { 
    modelIds, 
    language, 
    complexity 
  });
  
  // Remove health check section and use modelIds directly
  const availableModels = modelIds;

  // Update progress callback
  onProgress?.(
    availableModels.reduce((acc, modelId) => ({
      ...acc,
      [modelId]: { modelId, status: 'pending' }
    }), {})
  );

  // Continue with the generation process
  const results = await Promise.allSettled(
    availableModels.map(async (modelId) => {
      try {
        onProgress?.({
          [modelId]: { modelId, status: 'generating' }
        });

        // Choose prompt based on model type
        const modelPrompt = modelId.includes('codellama') || modelId.includes('granite')
          ? buildOllamaPrompt(language, complexity, prompt)
          : buildPrompt(language, complexity, prompt);

        console.log(`[Generate] Using model ${modelId} with custom prompt`);
        
        let result: string;
        if (modelId.startsWith('gemini-')) {
          result = await generateWithGemini(modelPrompt, modelId);
        } else {
          // Add retry logic for Ollama models
          let retryCount = 0;
          while (retryCount < 3) {
            try {
              result = await generateWithOllama(modelPrompt, modelId);
              break;
            } catch (error) {
              if (retryCount === 2) throw error;
              retryCount++;
              await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
            }
          }
        }

        const code = extractCodeFromResponse(result, language);
        
        // Validate extracted code
        if (!code || code.length < 10 || !code.trim()) {
          throw new Error('Invalid or empty code generated');
        }

        onProgress?.({
          [modelId]: { 
            modelId, 
            status: 'completed', 
            result: code 
          }
        });

        return { modelId, result: code };
      } catch (error) {
        console.error(`[Generate] Error with ${modelId}:`, error);
        onProgress?.({
          [modelId]: { 
            modelId, 
            status: 'failed',
            error: error instanceof Error ? error.message : 'Unknown error'
          }
        });
        
        // Handle fallbacks without recursion
        if (MODEL_CONFIGS[modelId]?.fallbacks?.length) {
          const fallbackId = MODEL_CONFIGS[modelId].fallbacks[0];
          console.log(`[Generate] Trying fallback model: ${fallbackId}`);
          
          try {
            const fallbackResult = await generateWithOllama(modelPrompt, fallbackId);
            const fallbackCode = extractCodeFromResponse(fallbackResult, language);
            
            if (fallbackCode) {
              onProgress?.({
                [fallbackId]: { 
                  modelId: fallbackId, 
                  status: 'completed', 
                  result: fallbackCode 
                }
              });
              return { modelId: fallbackId, result: fallbackCode };
            }
          } catch (fallbackError) {
            console.error(`[Generate] Fallback failed:`, fallbackError);
          }
        }
        
        throw error;
      }
    })
  );

  // Process results
  const successfulResults = results
    .filter((r): r is PromiseFulfilledResult<{modelId: string; result: string}> => 
      r.status === 'fulfilled' && Boolean(r.value?.result)
    )
    .map(r => r.value);

  if (successfulResults.length === 0) {
    const errors = results
      .filter((r): r is PromiseRejectedResult => r.status === 'rejected')
      .map(r => r.reason.message || 'Unknown error')
      .join('; ');
    throw new Error(`Generation failed: ${errors}`);
  }

  // Add logging to results processing
  logger.info('Generate', `Generation completed. Results:`, {
    totalResults: results.length,
    successful: successfulResults.length,
    failed: results.length - successfulResults.length
  });

  // Return the most comprehensive result
  return successfulResults.reduce((best, current) => 
    (current.result.length > best.result.length) ? current : best
  ).result;
}

// New type definitions for model capabilities
interface ModelCapabilities {
  languages: string[];
  strengths: string[];
  contextLength: number;
  bestFor: string[];
}

const MODEL_CAPABILITIES: Record<string, ModelCapabilities> = {
  'gemini-pro-code': {
    languages: Object.keys(LANGUAGES),
    strengths: ['Code Generation', 'Documentation', 'Testing'],
    contextLength: 8192,
    bestFor: ['Modern Programming Languages', 'Web Development', 'Testing']
  },
  'codellama-13b': {
    languages: Object.keys(LANGUAGES),
    strengths: ['Low Level Programming', 'System Programming', 'Algorithms'],
    contextLength: 4096,
    bestFor: ['C++', 'Rust', 'Systems Programming']
  },
  'codellama-34b': {
    languages: Object.keys(LANGUAGES),
    strengths: ['Complex Architectures', 'Infrastructure Code', 'Enterprise Solutions'],
    contextLength: 8192,
    bestFor: ['Enterprise Applications', 'Infrastructure as Code', 'DevOps']
  }
};

function buildLanguageSpecificPrompt(language: string, complexity: ComplexityLevel, prompt: string): string {
  const langConfig = LANGUAGES[language as keyof typeof LANGUAGES];
  if (!langConfig) {
    throw new Error(`Unsupported language: ${language}`);
  }

  const features = langConfig.features.join(', ');
  const category = langConfig.category || 'programming';
  const extension = langConfig.extension;

  // Base prompt structure
  let basePrompt = `As an expert ${langConfig.name} developer, generate production-ready code that:

TASK:
${prompt}

TECHNICAL REQUIREMENTS:
1. Language: ${langConfig.name} (${extension})
2. Complexity Level: ${complexity}
3. Key Features: ${features}
4. Must Include:
   - Proper error handling
   - Input validation
   - Clear documentation
   - Best practices
   - Efficient algorithms
   - Security considerations

`;

  // Add category-specific requirements
  switch (category) {
    case 'config':
      basePrompt += `
INFRASTRUCTURE REQUIREMENTS:
- Ensure idempotency
- Include state validation
- Add security controls
- Implement logging
- Handle dependencies
- Include cleanup procedures
`;
      break;

    case 'shell':
      basePrompt += `
SHELL SCRIPT REQUIREMENTS:
- Proper error handling with set -e
- Input validation
- Secure variable handling
- Logging mechanisms
- Cleanup procedures
- Signal handling
`;
      break;

    default:
      basePrompt += `
CODE REQUIREMENTS:
- Modern language features
- Clean code principles
- Unit test examples
- Type safety
- Performance considerations
- Maintainable structure
`;
  }

  basePrompt += `
FORMAT:
\`\`\`${language}
[Your code here]
\`\`\`

Return ONLY the implementation without explanations.`;

  return basePrompt;
}

// Enhanced validation for specific language categories
function validateGeneratedCode(code: string, language: string): boolean {
  const langConfig = LANGUAGES[language as keyof typeof LANGUAGES];
  if (!langConfig || !code) return false;

  const category = langConfig.category || 'programming';
  const patterns = {
    config: [
      'version:', 'name:', 'description:',
      'dependencies:', 'variables:', 'resources:'
    ],
    shell: [
      '#!/bin', 'function', 'if [', 'while', 'for',
      'case', 'exit', 'return'
    ],
    programming: [
      'class', 'function', 'import', 'const',
      'let', 'var', 'def', 'public'
    ]
  };

  // Check category-specific patterns
  const categoryPatterns = patterns[category as keyof typeof patterns] || patterns.programming;
  const hasValidPattern = categoryPatterns.some(pattern => code.includes(pattern));

  // Check language-specific identifiers
  const langPatterns = LANGUAGES[language as keyof typeof LANGUAGES]?.codeIdentifiers || [];
  const hasLanguagePattern = langPatterns.some(pattern => code.includes(pattern));

  return hasValidPattern || hasLanguagePattern;
}