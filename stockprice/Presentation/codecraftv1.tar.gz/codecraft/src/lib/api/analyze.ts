import { generateWithOpenAI } from '../ai/openai';
import { ENV_CONFIG } from '../../config/env';
import { GoogleGenerativeAI } from '@google/generative-ai';
import type { AnalysisRequest, AnalysisType } from '../../types/models';

// Add new types for enhanced analysis
export interface AnalysisMetrics {
  tokenCount: number;
  responseTime: number;
  confidenceScore?: number;
}

export type AnalysisProgress = {
  modelId: string;
  status: 'pending' | 'analyzing' | 'completed' | 'failed';
  result?: string;
  error?: string;
  metrics?: AnalysisMetrics;
  provider?: string;
  timestamp?: string; // Make timestamp optional
};

export type ProgressCallback = (progress: Record<string, AnalysisProgress>) => void;

// Add new analysis types
export type EnhancedAnalysisType = AnalysisType | 'security-check' | 'performance-profile' | 'dependency-check' | 'code-metrics';

// Enhanced OLLAMA_MODEL_MAPPING
const OLLAMA_MODEL_MAPPING: Record<string, any> = {
  'codellama:13b': 'codellama:13b',
  'codellama:7b': 'codellama:latest',
  'codestral:7b': 'codestral:latest',
  'codegemma:7b': 'codegemma:latest',
  'granite-code:8b': 'granite-code:8b',
  'granite-code:20b': 'granite-code:20b',
  'llama3.2': 'llama3.2:latest',
  'llama3.3:70b': 'llama3.3:latest',
  'phi4': 'phi4:latest',
  'mistral-small:latest': 'mistral-small:latest',
  'mistral-nemo:latest': 'mistral-nemo:latest',
  
  // Add performance optimized settings for each model
  settings: {
    'codellama:13b': { contextSize: 8192, temperature: 0.7 },
    'codellama:7b': { contextSize: 4096, temperature: 0.8 },
    'codestral:7b': { contextSize: 4096, temperature: 0.7 },
    'codegemma:7b': { contextSize: 8192, temperature: 0.8 },
    'granite-code:8b': { contextSize: 8192, temperature: 0.75 },
    'granite-code:20b': { contextSize: 16384, temperature: 0.7 },
    'llama3.2': { contextSize: 4096, temperature: 0.7 },
    'llama3.3:70b': { contextSize: 32768, temperature: 0.8 },
    'phi4': { contextSize: 4096, temperature: 0.7 },
    'mistral-small:latest': { contextSize: 8192, temperature: 0.7 },
    'mistral-nemo:latest': { contextSize: 4096, temperature: 0.7 }
  }
};

// Add new analysis prompts
const ENHANCED_ANALYSIS_PROMPTS: Partial<Record<EnhancedAnalysisType, (language: string) => string>> = {
  analyze: (language) => `Perform a comprehensive analysis of the following ${language} code:
1. Code Quality:
   - Clean code principles
   - Code organization
   - Variable/function naming
   - Comments and documentation
   - Code quality and structure
   - Design patterns and architecture
   - Best practices and standards
   - Potential improvements

2. Potential Issues:
   - Logic errors
   - Edge cases
   - Error handling
   - Resource management

3. Security:
   - Security vulnerabilities
   - Input validation
   - Data sanitization
   - Access control

4. Performance:
   - Time complexity
   - Space complexity
   - Resource usage
   - Optimization opportunities

5. Maintainability:
   - Code duplication
   - Modularity
   - Testing
   - Documentation

Provide specific examples and recommendations for improvements.`,

  test: (language) => `Generate comprehensive unit tests for the following ${language} code:
1. Test Cases:
   - Core functionality
   - Edge cases
   - Error conditions
   - Input validation

2. Include:
   - Test setup
   - Test assertions
   - Error handling tests
   - Mock examples if needed`,
  
  debug: (language) => `Analyze the following ${language} code for potential bugs and issues:
- Identify logical errors
- Find edge cases
- Spot potential runtime errors
- Potential bugs and edge cases
- Error handling gaps
- Memory leaks and resource issues
- Race conditions and concurrency problems
- Security vulnerabilities
- Suggest fixes
`,
  optimize: (language) => `Analyze the following ${language} code for performance optimization:
- Identify performance bottlenecks
- Time complexity optimization
- Memory usage optimization
- Resource utilization
- Algorithm efficiency
- Caching and memoization
- Async/parallel processing opportunities
- Suggest optimizations
- Consider time and space complexity
- Recommend better algorithms or data structures
`,
  refactor: (language) => `Suggest refactoring improvements for the following ${language} code:
- Improve code structure
- Enhance readability
- Code maintainability
- Design patterns implementation
- SOLID principles
- Code reusability
- Modularity and coupling
- Clean code principles
- Apply design patterns
- Remove code smells
`,
  document: (language) => `Generate comprehensive documentation for the following ${language} code:
- Function/method documentation
- Parameter descriptions
- Return value explanations
- Usage examples
`,
  'best-practices': (language) => `Check the following ${language} code against best practices:
- Code organization
- Error handling
- Resource management
- Design principles
`,
  'style-check': (language) => `Review the following ${language} code for style issues:
- Formatting
- Naming conventions
- Code organization
- Consistency
`,
  'security-check': (_language) => `Perform a comprehensive security analysis:
- OWASP top 10 vulnerabilities
- Common security anti-patterns
- Input validation issues
- Authentication/Authorization concerns
- Data exposure risks
- Secure coding practices`,

  'performance-profile': (_language) => `Analyze performance characteristics:
- Time complexity analysis
- Memory usage patterns
- Resource utilization
- Bottleneck identification
- Optimization opportunities
- Benchmark considerations`,

  'dependency-check': (_language) => `Review dependencies and imports:
- Circular dependencies
- Unused imports
- Version conflicts
- Security vulnerabilities
- Licensing issues
- Update recommendations`,

  'code-metrics': (_language) => `Analyze code metrics:
- Complexity metrics
- Code coverage
- Maintainability index
- Technical debt estimation
- Code duplication
  `
};

// Enhanced generation functions
async function generateWithRetry(
  generationFn: () => Promise<string>,
  retryOptions = { maxRetries: 3, delay: 1000 }
): Promise<string> {
  for (let attempt = 0; attempt < retryOptions.maxRetries; attempt++) {
    try {
      return await generationFn();
    } catch (error) {
      if (attempt === retryOptions.maxRetries - 1) throw error;
      await new Promise(resolve => setTimeout(resolve, retryOptions.delay * (attempt + 1)));
    }
  }
  throw new Error('All retry attempts failed');
}

// Enhanced Ollama generation
async function generateWithOllama(
  prompt: string, 
  modelId: string, 
  options: {
    temperature?: number;
    topP?: number;
    maxTokens?: number;
    stream?: boolean;
  } = {}
): Promise<string> {
  const modelSettings = OLLAMA_MODEL_MAPPING.settings[modelId] || {};
  
  return generateWithRetry(async () => {
    const cleanModelId = OLLAMA_MODEL_MAPPING[modelId] || modelId.replace('ollama/', '');
    console.log(`[Ollama] Using model: ${cleanModelId}`);

    const response = await fetch(`${ENV_CONFIG.OLLAMA_API_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: cleanModelId,
        prompt: prompt,
        stream: false,
        options: {
          temperature: options.temperature ?? modelSettings.temperature ?? 0.7,
          top_p: options.topP ?? 0.9,
          max_tokens: options.maxTokens ?? modelSettings.contextSize ?? 2048,
        }
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    
    if (!data.response) {
      throw new Error('Empty response from model');
    }

    return data.response;
  });
}

// Add improved Gemini generation
async function generateWithGemini(
  prompt: string, 
  modelId: string,
  params: any = {}
): Promise<string> {
  console.log(`[Gemini] Starting analysis with ${modelId}`);

  if (!ENV_CONFIG.GOOGLE_API_KEY) {
    throw new Error('Google API key not configured');
  }

  try {
    const genAI = new GoogleGenerativeAI(ENV_CONFIG.GOOGLE_API_KEY);
    
    // Map Gemini model IDs
    const geminiModelId = modelId === 'gemini-pro-code' ? 'gemini-pro' : modelId;
    console.log(`[Gemini] Using model ID: ${geminiModelId}`);
    
    const model = genAI.getGenerativeModel({ model: geminiModelId });

    const result = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: params.temperature ?? 0.7,
        topK: params.topK ?? 40,
        topP: params.topP ?? 0.8,
        maxOutputTokens: params.maxTokens ?? 8192,
      }
    });

    if (!result.response) {
      throw new Error('Empty response from Gemini');
    }

    const text = result.response.text();
    if (!text) {
      throw new Error('Empty text in Gemini response');
    }

    console.log(`[Gemini] Analysis completed successfully`);
    return text;

  } catch (error: any) {
    console.error(`[Gemini] Analysis error:`, error);
    throw new Error(`Gemini API error: ${error.message}`);
  }
}

export interface AnalysisParams {
  temperature?: number;
  topP?: number;
  topK?: number;
  maxTokens?: number;
  safetySettings?: Array<{
    category: string;
    threshold: string;
  }>;
}

export interface ExtendedAnalysisRequest extends AnalysisRequest {
  modelParams?: AnalysisParams;
  sourceLanguage: string; // Add this to fix the language property error
}

export async function analyzeCode(
  request: ExtendedAnalysisRequest,
  onProgress?: ProgressCallback
): Promise<string> {
  const {
    modelIds,
    prompt: sourceCode,
    sourceLanguage, // Update to use sourceLanguage instead of language
    action,
    complexity = 'intermediate',
    modelParams = {}
  } = request;

  // Add input validation
  if (!modelIds?.length || !sourceCode?.trim()) {
    throw new Error('Invalid request parameters');
  }

  const analysisPrompt = generateAnalysisPrompt(sourceLanguage, sourceCode, action, complexity);

  const modelResults = await Promise.allSettled(
    modelIds.map(async (modelId) => {
      const modelStartTime = Date.now();
      try {
        onProgress?.({
          [modelId]: { modelId, status: 'analyzing' }
        });

        let result: string;
        
        // Updated model handling logic to support all Ollama models
        if (OLLAMA_MODEL_MAPPING[modelId] || 
            Object.keys(OLLAMA_MODEL_MAPPING).some(prefix => modelId.startsWith(prefix.split(':')[0]))) {
          result = await generateWithOllama(analysisPrompt, modelId, modelParams);
        } else if (modelId.startsWith('gpt')) {
          result = await generateWithOpenAI(analysisPrompt, modelId, modelParams);
        } else if (modelId.startsWith('gemini')) {
          result = await generateWithGemini(analysisPrompt, modelId, modelParams);
        } else {
          throw new Error(`Unsupported model: ${modelId}`);
        }

        const formattedResult = formatAnalysisResult(result);

        const modelMetrics: AnalysisMetrics = {
          tokenCount: result.length,
          responseTime: Date.now() - modelStartTime,
          confidenceScore: calculateConfidenceScore(result)
        };

        onProgress?.({
          [modelId]: {
            modelId,
            status: 'completed',
            result: formattedResult,
            metrics: modelMetrics,
            timestamp: new Date().toISOString()
          }
        });

        return { result: formattedResult, metrics: modelMetrics };

      } catch (error) {
        console.error(`Error with model ${modelId}:`, error);
        onProgress?.({
          [modelId]: {
            modelId,
            status: 'failed',
            error: error instanceof Error ? error.message : 'Analysis failed'
          }
        });
        return null;
      }
    })
  );

  const successfulResults = modelResults
    .filter((result): result is PromiseFulfilledResult<{ result: string, metrics: AnalysisMetrics }> => 
      result.status === 'fulfilled' && Boolean(result.value)
    )
    .map(result => result.value.result);

  if (successfulResults.length === 0) {
    throw new Error('Analysis failed with all selected models');
  }

  return successfulResults.join('\n\n');
}

function generateAnalysisPrompt(
  language: string,
  sourceCode: string,
  action: AnalysisType,
  complexity: string
): string {
  const defaultPrompt = (lang: string) => `Analyze this ${lang} code for quality and improvements.`;
  const prompt = ENHANCED_ANALYSIS_PROMPTS[action] || defaultPrompt;
  
  return `You are an expert code analyzer. Review and analyze the following ${language} code based on these requirements:

${prompt(language)}

CODE TO ANALYZE:
\`\`\`${language}
${sourceCode}
\`\`\`

ANALYSIS LEVEL: ${complexity.toUpperCase()}

REQUIREMENTS FOR RESPONSE:
1. Be specific and detailed
2. Include line numbers where relevant
3. Format each issue as:
   ERROR: for critical problems
   WARNING: for potential issues
   SUGGESTION: for improvements
4. Focus on ${complexity} level analysis
5. Provide actionable feedback

Please begin your analysis:`;
}

// Helper function to format analysis results
function formatAnalysisResult(result: string): string {
  // Remove code blocks and clean up
  result = result.replace(/```[\s\S]*?```/g, '');

  // Split into lines and process each
  const lines = result.split('\n')
    .map(line => {
      line = line.trim();
      if (!line) return '';

      // Skip meta text
      if (line.toLowerCase().includes('here is') ||
          line.toLowerCase().includes('analysis of') ||
          line.toLowerCase().includes('reviewing the')) {
        return '';
      }

      // Keep existing prefixes
      if (line.startsWith('ERROR:') || 
          line.startsWith('WARNING:') || 
          line.startsWith('SUGGESTION:') ||
          line.startsWith('* ') ||
          line.startsWith('## ')) {
        return line;
      }

      // Add prefix for unprefixed lines
      return `* ${line}`;
    })
    .filter(Boolean);

  return lines.join('\n');
}

// Add helper functions
function calculateConfidenceScore(_result: string): number {
  // Placeholder implementation
  return 0.9;
}