import { AIApiError } from './types';

export async function withRetry<T>(
  operation: () => Promise<T>,
  options = { maxRetries: 3, delay: 1000 }
): Promise<T> {
  let lastError: Error | null = null;

  for (let attempt = 0; attempt < options.maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error as Error;
      
      if ((error as AIApiError).retryable === false) {
        throw error;
      }

      if (attempt === options.maxRetries - 1) {
        break;
      }

      await new Promise(resolve => 
        setTimeout(resolve, options.delay * Math.pow(2, attempt))
      );
    }
  }

  throw lastError || new Error('Operation failed after retries');
}

export function extractCodeFromResponse(text: string, language?: string): string {
  const codeBlockRegex = language
    ? new RegExp(`\`\`\`(?:${language})?\n([\\s\\S]*?)\`\`\``, 'i')
    : /```\w*\n([\s\S]*?)```/;
    
  const match = text.match(codeBlockRegex);
  if (match) {
    return match[1].trim();
  }

  return text
    .split('\n')
    .filter(line => 
      !line.startsWith('Here') && 
      !line.startsWith('This') &&
      !line.includes('example:') &&
      line.trim().length > 0
    )
    .join('\n')
    .trim();
}
