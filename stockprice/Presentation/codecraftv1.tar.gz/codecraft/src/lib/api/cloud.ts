import { GoogleGenerativeAI } from '@google/generative-ai';
import { ENV_CONFIG } from '../../config/env';
import type { CloudRequest, CloudProgress, CloudGenerationResult } from '../../types/cloud';
import { getCloudPrompt, getSpecializedPrompt } from '../prompts/cloud';
import { fetchWithTimeout } from '../utils/fetchWithTimeout';

type ProgressCallback = (progress: Record<string, CloudProgress>) => void;

// Helper function to generate with Ollama
async function generateWithOllama(
  modelId: string, 
  prompt: string, 
  options?: { temperature?: number; topP?: number; topK?: number; maxTokens?: number }
): Promise<string> {
  try {
    const cleanPrompt = prompt.replace(/\n/g, ' ').trim();
    
    const payload = {
      model: modelId,
      prompt: cleanPrompt,
      stream: false,
      options: {
        temperature: options?.temperature ?? 0.7,
        num_predict: options?.maxTokens ?? 2048
      }
    };

    const response = await fetchWithTimeout(`${ENV_CONFIG.OLLAMA_API_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      timeout: 120000
    });

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data.response;
  } catch (error) {
    console.error('Ollama generation error:', error);
    throw error;
  }
}

// Helper function to generate with Gemini
async function generateWithGemini(
  modelId: string,
  prompt: string,
  options?: { temperature?: number; topP?: number; topK?: number; maxTokens?: number }
): Promise<string> {
  try {
    const genAI = new GoogleGenerativeAI(ENV_CONFIG.GOOGLE_API_KEY);
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

    const response = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: options?.temperature ?? 0.7,
        topK: options?.topK ?? 40,
        topP: options?.topP ?? 0.8,
        maxOutputTokens: options?.maxTokens ?? 8192,
      }
    });

    return response.response.text();
  } catch (error) {
    console.error('Gemini generation error:', error);
    throw error;
  }
}

export async function generateCloudInfrastructure(
  request: CloudRequest,
  onProgress?: ProgressCallback
): Promise<Record<string, CloudGenerationResult>> {
  const { modelIds, provider, resourceType, requirements, complexity, options } = request;
  
  const progress: Record<string, CloudProgress> = {};
  modelIds.forEach(modelId => {
    progress[modelId] = {
      modelId,
      status: 'pending',
      progress: 0
    };
  });
  onProgress?.(progress);

  // Get either specialized or standard prompt
  const prompt = ['kubernetes', 'serverless'].includes(resourceType)
    ? getSpecializedPrompt(provider, resourceType, requirements)
    : getCloudPrompt(provider, resourceType, requirements, complexity);

  const results: Record<string, CloudGenerationResult> = {};

  for (const modelId of modelIds) {
    try {
      progress[modelId] = { ...progress[modelId], status: 'generating', progress: 10 };
      onProgress?.(progress);

      let result: string;
      if (modelId.startsWith('gemini')) {
        result = await generateWithGemini(modelId, prompt, options);
      } else {
        const ollamaModelId = modelId.replace('ollama/', '');
        result = await generateWithOllama(ollamaModelId, prompt, options);
      }

      progress[modelId] = { ...progress[modelId], status: 'completed', progress: 100 };
      onProgress?.(progress);

      results[modelId] = {
        code: result,
        explanation: 'Infrastructure generated successfully',
        bestPractices: [],
        securityChecks: [],
        automationSteps: []
      };
    } catch (error) {
      console.error(`Generation failed for ${modelId}:`, error);
      progress[modelId] = {
        ...progress[modelId],
        status: 'failed',
        progress: 0,
        error: error instanceof Error ? error.message : 'Generation failed'
      };
      onProgress?.(progress);
    }
  }

  if (Object.keys(results).length === 0) {
    throw new Error('All models failed to generate infrastructure');
  }

  return results;
}
