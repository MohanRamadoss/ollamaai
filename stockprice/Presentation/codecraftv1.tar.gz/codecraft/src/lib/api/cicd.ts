import { GoogleGenerativeAI } from '@google/generative-ai';
import { ENV_CONFIG } from '../../config/env';
import type { CICDRequest, CICDProgress, CICDGenerationResult } from '../../types/cicd';
import { getPipelinePrompt } from '../prompts/pipeline';
import { fetchWithTimeout } from '../utils/fetchWithTimeout';

type ProgressCallback = (progress: Record<string, CICDProgress>) => void;

// Helper function to generate with Ollama
async function generateWithOllama(
  modelId: string, 
  prompt: string, 
  options?: { temperature?: number; topP?: number; topK?: number; maxTokens?: number }
): Promise<string> {
  try {
    console.log('Generating with Ollama model:', modelId);
    
    // Clean up the prompt to prevent JSON parsing issues
    const cleanPrompt = prompt.replace(/\n/g, ' ').trim();
    
    const payload = {
      model: modelId,
      prompt: cleanPrompt,
      stream: false,
      options: {
        temperature: options?.temperature ?? 0.7,
        num_predict: 2048
      }
    };

    console.log('Sending request to Ollama:', payload);

    const response = await fetchWithTimeout(`${ENV_CONFIG.OLLAMA_API_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      timeout: 120000
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Ollama API error details:', {
        status: response.status,
        statusText: response.statusText,
        error: errorText
      });
      throw new Error(`Ollama API error: ${response.status} ${response.statusText}`);
    }

    let data;
    try {
      const text = await response.text();
      console.log('Raw response:', text);
      data = JSON.parse(text);
    } catch (parseError) {
      console.error('JSON parse error:', parseError);
      throw new Error('Failed to parse Ollama response');
    }

    if (!data.response) {
      console.error('Invalid Ollama response:', data);
      throw new Error('Invalid response format from Ollama');
    }

    return data.response;
  } catch (error) {
    console.error('Ollama generation error:', error);
    throw error;
  }
}

// Helper function to generate with Gemini
async function generateWithGemini(
  modelId: string,
  prompt: string,
  options?: { temperature?: number; topP?: number; topK?: number; maxTokens?: number }
): Promise<string> {
  try {
    if (!ENV_CONFIG.GOOGLE_API_KEY) {
      throw new Error('Google API key not configured');
    }

    const genAI = new GoogleGenerativeAI(ENV_CONFIG.GOOGLE_API_KEY);
    const modelIdentifier = modelId === 'gemini-1.5-flash' ? 'gemini-1.5-pro' : 'gemini-pro';
    const model = genAI.getGenerativeModel({ model: modelIdentifier });

    const response = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: options?.temperature ?? 0.7,
        topK: options?.topK ?? 40,
        topP: options?.topP ?? 0.8,
        maxOutputTokens: options?.maxTokens ?? 8192,
      }
    });

    return response.response.text();
  } catch (error) {
    console.error('Gemini generation error:', error);
    throw new Error(`Gemini generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

// Extract segments function
function extractSegments(response: string) {
  const segments = {
    code: '',
    explanation: '',
    bestPractices: [] as string[],
    securityChecks: [] as string[],
    automationSteps: [] as string[]
  };

  try {
    // Extract code block (looking for both yaml and groovy)
    const codeMatch = response.match(/```(?:yaml|groovy)?\n([\s\S]*?)```/);
    segments.code = codeMatch ? codeMatch[1].trim() : '';

    // Extract explanation
    const explanationMatch = response.match(/(?:#{1,3}\s*Explanation:?\n*|\nExplanation:?\n*)([\s\S]*?)(?=(?:#{1,3}|\n{2,}))/i);
    segments.explanation = explanationMatch 
      ? explanationMatch[1].trim()
      : response.match(/Explanation:([\s\S]*?)(?=\n{2,}|$)/i)?.[1]?.trim() || '';

    // Extract best practices
    const bestPracticesSection = response.match(/#{1,3}\s*Best Practices[\s\S]*?(?=#{1,3}|$)/i)?.[0] || '';
    segments.bestPractices = bestPracticesSection
      .split('\n')
      .filter(line => line.match(/^[-*•]\s+/))
      .map(line => line.replace(/^[-*•]\s+/, '').trim());

    // Extract security checks
    const securitySection = response.match(/#{1,3}\s*Security Checks[\s\S]*?(?=#{1,3}|$)/i)?.[0] || '';
    segments.securityChecks = securitySection
      .split('\n')
      .filter(line => line.match(/^[-*•]\s+/))
      .map(line => line.replace(/^[-*•]\s+/, '').trim());

    // Extract automation steps
    const stepsSection = response.match(/#{1,3}\s*(?:Automation|Pipeline) Steps[\s\S]*?(?=#{1,3}|$)/i)?.[0] || '';
    segments.automationSteps = stepsSection
      .split('\n')
      .filter(line => line.match(/^[-*•]\s+|\d+\.\s+/))
      .map(line => line.replace(/^[-*•]\s+|\d+\.\s+/, '').trim());

  } catch (error) {
    console.error('Error extracting segments:', error);
  }

  return segments;
}

export async function generateCICDPipeline(
  request: CICDRequest,
  onProgress?: ProgressCallback
): Promise<Record<string, CICDGenerationResult>> {  // Changed return type
  const { modelIds, platform, pipelineType, requirements, complexity, options } = request;
  
  // Initialize progress for all models
  const progress: Record<string, CICDProgress> = {};
  modelIds.forEach(modelId => {
    progress[modelId] = {
      modelId,
      status: 'pending',
      progress: 0
    };
  });
  onProgress?.(progress);

  const prompt = getPipelinePrompt(platform, pipelineType, requirements, complexity);
  const results: Record<string, CICDGenerationResult> = {};  // Changed to store all results

  // Process each model with retries
  for (const modelId of modelIds) {
    let retryCount = 0;
    const maxRetries = 3;

    while (retryCount < maxRetries) {
      try {
        progress[modelId] = { ...progress[modelId], status: 'generating', progress: 10 + (retryCount * 5) };
        onProgress?.(progress);

        let result: string;
        if (modelId.startsWith('gemini')) {
          result = await generateWithGemini(modelId, prompt, options);
        } else {
          // Simplify Ollama model handling
          const ollamaModelId = modelId.replace('ollama/', '');
          result = await generateWithOllama(ollamaModelId, prompt, options);
        }

        if (!result) {
          throw new Error('Empty response from model');
        }

        console.log(`Generation successful for model ${modelId}`);
        console.log('Result preview:', result.substring(0, 200));

        progress[modelId] = { ...progress[modelId], status: 'completed', progress: 100 };
        onProgress?.(progress);

        const segments = extractSegments(result);
        results[modelId] = {  // Store result by modelId
          code: segments.code,
          explanation: segments.explanation,
          bestPractices: segments.bestPractices,
          securityChecks: segments.securityChecks,
          automationSteps: segments.automationSteps
        };
        break; // Success, exit retry loop

      } catch (error) {
        retryCount++;
        console.error(`Attempt ${retryCount} failed for ${modelId}:`, error);
        
        if (retryCount === maxRetries) {
          progress[modelId] = {
            ...progress[modelId],
            status: 'failed',
            progress: 0,
            error: error instanceof Error ? error.message : 'Generation failed'
          };
          onProgress?.(progress);
          results.push({ 
            modelId, 
            error: error instanceof Error ? error : new Error('Generation failed')
          });
        } else {
          await new Promise(resolve => setTimeout(resolve, 2000 * retryCount)); // Longer delay between retries
        }
      }
    }
  }

  // Check if any models succeeded
  if (Object.keys(results).length === 0) {
    throw new Error('All models failed to generate pipeline');
  }

  return results;  // Return all results
}
