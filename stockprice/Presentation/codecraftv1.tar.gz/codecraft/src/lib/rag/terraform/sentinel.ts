import { generateWithOpenAI } from '../../ai/openai';
import { generateWithGemini } from '../../ai/gemini';

export class SentinelPolicyGenerator {
  async generatePolicy(requirements: string, provider: string, resourceType: string): Promise<string> {
    const prompt = `Generate a Sentinel policy for Terraform that enforces the following requirements:

${requirements}

The policy should:
1. Focus on ${provider} ${resourceType}
2. Include proper policy rules and functions
3. Implement security best practices
4. Add helpful comments
5. Include test cases
6. Enforce container orchestration best practices
7. Implement cost controls
8. Ensure compliance with security standards

For container orchestration (EKS/AKS/GKE), ensure the policy covers:
- Node pool configuration
- Network policies
- RBAC settings
- Security context
- Resource quotas
- Pod security policies
- Image scanning requirements
- Admission controllers

Use the official Sentinel policy syntax.`;

    try {
      // Try with GPT-4 first
      const gptResult = await generateWithOpenAI(prompt, 'gpt-4', {
        temperature: 0.7,
        maxTokens: 2048,
      });

      if (gptResult) {
        return gptResult;
      }

      // Fallback to Gemini
      const geminiResult = await generateWithGemini(prompt, 'gemini-pro-code', {
        temperature: 0.7,
        maxTokens: 2048,
      });

      return geminiResult;
    } catch (error) {
      console.error('Error generating Sentinel policy:', error);
      throw error;
    }
  }

  validatePolicy(policy: string): { valid: boolean; errors: string[]; warnings: string[] } {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Basic syntax validation
    if (!policy.includes('import "tfplan"')) {
      errors.push('Missing required tfplan import');
    }
    if (!policy.includes('main =')) {
      errors.push('Missing main rule');
    }

    // Container orchestration specific checks
    if (policy.includes('kubernetes') || policy.includes('eks') || policy.includes('aks') || policy.includes('gke')) {
      if (!policy.includes('rbac')) {
        warnings.push('Consider adding RBAC validation rules');
      }
      if (!policy.includes('network_policy')) {
        warnings.push('Consider adding network policy validation');
      }
      if (!policy.includes('security_context')) {
        warnings.push('Consider adding security context validation');
      }
      if (!policy.includes('resource_quotas')) {
        warnings.push('Consider adding resource quota validation');
      }
    }

    // Security best practices
    if (!policy.includes('deny {')) {
      warnings.push('Consider adding explicit deny rules');
    }
    if (!policy.includes('print(')) {
      warnings.push('Consider adding print statements for debugging');
    }

    // Cost control checks
    if (!policy.includes('cost')) {
      warnings.push('Consider adding cost control rules');
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  }

  generateTestCases(policy: string): string {
    // Generate test cases based on policy content
    const testCases = `
test "verify_policy" {
  rules = {
    main = true
  }
}

mock "tfplan/v2" {
  module {
    source = "./mock-tfplan.sentinel"
  }
}

test "verify_kubernetes_config" {
  rules = {
    main = false
  }

  module "mock-tfplan" {
    source = "./mock-tfplan-invalid.sentinel"
  }
}
`;

    return testCases;
  }
}