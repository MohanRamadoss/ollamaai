import { generateSQL } from '../lib/api/sql';
import type { SQLDialect } from '../types/sql';

async function generateDashboardQueries() {
  const dialects: SQLDialect[] = ['postgresql', 'mysql', 'sqlite', 'mssql', 'oracle'];
  const schema = `
    CREATE TABLE sales (
      id SERIAL PRIMARY KEY,
      product_id INTEGER,
      sale_date DATE,
      amount DECIMAL(12,2),
      region VARCHAR(50)
    );

    CREATE TABLE products (
      id INTEGER PRIMARY KEY,
      name VARCHAR(100),
      category VARCHAR(50),
      unit_price DECIMAL(10,2)
    );`;

  const description = 'Create a dashboard showing sales performance with rolling averages and year-over-year comparison';

  for (const dialect of dialects) {
    console.log(`\n=== Generating ${dialect.toUpperCase()} Query ===\n`);
    
    try {
      const result = await generateSQL({
        description,
        tableSchema: schema,
        dialect,
        optimizationFeatures: {
          indexDesign: true,
          queryTuning: true,
          partitioning: true,
          replication: true
        },
        onProgress: (progress) => {
          Object.values(progress).forEach(p => {
            console.log(`${dialect} Progress: ${p.progress}%`);
          });
        }
      });

      // Get the first model's result
      const modelResult = result['mistral-small:latest'];
      
      console.log('\nGenerated Query:');
      console.log(modelResult.query);
      
      console.log('\nExplanation:');
      console.log(modelResult.explanation);
      
      if (modelResult.optimizations) {
        console.log('\nOptimizations:');
        
        if (modelResult.optimizations.indexRecommendations) {
          console.log('\nIndex Recommendations:');
          modelResult.optimizations.indexRecommendations.forEach(rec => 
            console.log(`- ${rec}`)
          );
        }
        
        if (modelResult.optimizations.queryPlan) {
          console.log('\nQuery Plan:');
          console.log(modelResult.optimizations.queryPlan);
        }
        
        if (modelResult.optimizations.partitioningStrategy) {
          console.log('\nPartitioning Strategy:');
          console.log(modelResult.optimizations.partitioningStrategy);
        }
      }
      
    } catch (error) {
      console.error(`Error generating ${dialect} query:`, error);
    }
  }
}

// Example usage:
generateDashboardQueries().catch(console.error);
