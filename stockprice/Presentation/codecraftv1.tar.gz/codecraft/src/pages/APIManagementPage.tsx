import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Network,
  Settings2,
  Loader2,
  AlertTriangle,
  Shield,
  GitBranch,
  CheckCircle2,
  Lock,
  Globe,
  Zap,
  FileJson,
  Activity
} from 'lucide-react';
import { ModelSelector } from '../components/ModelSelector';
import { CodeEditor } from '../components/CodeEditor';
import { TokenCounter } from '../components/TokenCounter';

const apiSchema = z.object({
  projectName: z.string().min(3, 'Project name must be at least 3 characters'),
  api: z.object({
    version: z.string().min(1, 'API version is required'),
    baseUrl: z.string().url('Must be a valid URL'),
    documentation: z.enum(['swagger', 'openapi', 'raml', 'graphql']),
  }),
  security: z.object({
    authentication: z.enum(['jwt', 'oauth2', 'apikey', 'basic']),
    rateLimit: z.boolean(),
    cors: z.boolean(),
  }),
  features: z.object({
    versioning: z.boolean(),
    caching: z.boolean(),
    monitoring: z.boolean(),
    analytics: z.boolean(),
  }),
  gateway: z.object({
    enabled: z.boolean(),
    provider: z.enum(['kong', 'ambassador', 'nginx', 'traefik']),
  }),
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
});

type APIForm = z.infer<typeof apiSchema>;

const API_DOCS = {
  swagger: { name: 'Swagger/OpenAPI 2.0', format: 'yaml' },
  openapi: { name: 'OpenAPI 3.0', format: 'yaml' },
  raml: { name: 'RAML', format: 'yaml' },
  graphql: { name: 'GraphQL Schema', format: 'graphql' },
};

const GATEWAYS = {
  kong: { name: 'Kong Gateway', features: ['Enterprise-grade', 'Plugin ecosystem', 'Developer portal'] },
  ambassador: { name: 'Ambassador Edge Stack', features: ['Kubernetes-native', 'Rate limiting', 'OAuth/OIDC'] },
  nginx: { name: 'NGINX Gateway', features: ['High performance', 'Load balancing', 'SSL/TLS'] },
  traefik: { name: 'Traefik Proxy', features: ['Auto-discovery', 'Let\'s Encrypt', 'Middleware'] },
};

export function APIManagementPage() {
  const [apiSpec, setApiSpec] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<APIForm>({
    resolver: zodResolver(apiSchema),
    defaultValues: {
      api: {
        version: '1.0',
        documentation: 'openapi',
      },
      security: {
        authentication: 'jwt',
        rateLimit: true,
        cors: true,
      },
      features: {
        versioning: true,
        caching: true,
        monitoring: true,
        analytics: true,
      },
      gateway: {
        enabled: true,
        provider: 'kong',
      },
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedModels = watch('modelIds');
  const selectedDocType = watch('api.documentation');
  const selectedGateway = watch('gateway.provider');
  const gatewayEnabled = watch('gateway.enabled');

  const onSubmit = async (data: APIForm) => {
    setIsProcessing(true);
    setProgress(0);
    setError(null);
    setResult(null);
    
    try {
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      // TODO: Implement actual API management integration
      await new Promise(resolve => setTimeout(resolve, 3000));

      setResult({
        portalUrl: 'https://api.example.com/portal',
        docsUrl: 'https://api.example.com/docs',
        metrics: {
          uptime: '99.99%',
          latency: '45ms',
          requests: '1.2M/day',
        },
      });
      
      setProgress(100);
    } catch (error) {
      console.error('Processing failed:', error);
      setError('Failed to process request. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Network className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">API Management</h1>
              <p className="mt-1 text-sm text-gray-500">
                Design, secure, and monitor your APIs with comprehensive management tools
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <FileJson className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Documentation</div>
                <div className="text-xs text-gray-500">OpenAPI/Swagger</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Shield className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Security</div>
                <div className="text-xs text-gray-500">Auth & Protection</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Activity className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Monitoring</div>
                <div className="text-xs text-gray-500">Real-time metrics</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Globe className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Gateway</div>
                <div className="text-xs text-gray-500">Traffic management</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">API Configuration</h2>
            </div>

            <div className="space-y-6">
              <ModelSelector 
                selectedModels={selectedModels} 
                onChange={(models) => setValue('modelIds', models)} 
              />

              <div>
                <label className="block text-sm font-medium text-gray-700">Project Name</label>
                <input
                  type="text"
                  {...register('projectName')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
                {errors.projectName && (
                  <p className="mt-1 text-sm text-red-600">{errors.projectName.message}</p>
                )}
              </div>

              {/* API Configuration */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">API Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Version</label>
                    <input
                      type="text"
                      {...register('api.version')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Base URL</label>
                    <input
                      type="text"
                      {...register('api.baseUrl')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      placeholder="https://api.example.com/v1"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Documentation</label>
                    <select
                      {...register('api.documentation')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      {Object.entries(API_DOCS).map(([key, doc]) => (
                        <option key={key} value={key}>
                          {doc.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Security Configuration */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Security</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Authentication</label>
                    <select
                      {...register('security.authentication')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      <option value="jwt">JWT</option>
                      <option value="oauth2">OAuth 2.0</option>
                      <option value="apikey">API Key</option>
                      <option value="basic">Basic Auth</option>
                    </select>
                  </div>
                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        {...register('security.rateLimit')}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className="text-sm text-gray-700">Rate Limiting</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        {...register('security.cors')}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className="text-sm text-gray-700">CORS Protection</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Features */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Features</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('features.versioning')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">API Versioning</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('features.caching')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">Response Caching</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('features.monitoring')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">Monitoring</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('features.analytics')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">Analytics</span>
                  </label>
                </div>
              </div>

              {/* API Gateway */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium text-gray-900">API Gateway</h3>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('gateway.enabled')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">Enable Gateway</span>
                  </label>
                </div>
                
                {gatewayEnabled && (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {Object.entries(GATEWAYS).map(([key, gateway]) => (
                      <label
                        key={key}
                        className={`relative flex flex-col p-4 cursor-pointer rounded-lg border transition-colors ${
                          selectedGateway === key
                            ? 'border-indigo-500 bg-indigo-50'
                            : 'border-gray-200 hover:border-indigo-300'
                        }`}
                      >
                        <input
                          type="radio"
                          {...register('gateway.provider')}
                          value={key}
                          className="sr-only"
                        />
                        <div className="font-medium text-gray-900">{gateway.name}</div>
                        <ul className="mt-2 space-y-1">
                          {gateway.features.map((feature, index) => (
                            <li key={index} className="text-xs text-gray-500 flex items-center gap-1">
                              <div className="w-1 h-1 bg-gray-400 rounded-full" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </label>
                    ))}
                  </div>
                )}
              </div>

              {/* API Specification */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium text-gray-900">API Specification</h3>
                  <TokenCounter code={apiSpec} maxTokens={2048} />
                </div>
                <CodeEditor
                  value={apiSpec}
                  onChange={setApiSpec}
                  language={API_DOCS[selectedDocType as keyof typeof API_DOCS].format}
                />
              </div>
            </div>
          </div>

          {/* Process Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isProcessing}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5 mr-2" />
                  Deploy API
                </>
              )}
            </button>
          </div>
        </form>

        {/* Results Section */}
        {result && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="space-y-6">
              {/* API Portal */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">API Portal</h3>
                <div className="flex items-center gap-3 p-4 bg-green-50 rounded-lg">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">API Portal is live</p>
                    <a
                      href={result.portalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-indigo-600 hover:text-indigo-500"
                    >
                      Access Developer Portal
                    </a>
                  </div>
                </div>
              </div>

              {/* API Metrics */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">API Metrics</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="text-sm font-medium text-gray-500">Uptime</div>
                    <div className="mt-1 text-2xl font-semibold text-blue-600">
                      {result.metrics.uptime}
                    </div>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg">
                    <div className="text-sm font-medium text-gray-500">Avg. Latency</div>
                    <div className="mt-1 text-2xl font-semibold text-green-600">
                      {result.metrics.latency}
                    </div>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-lg">
                    <div className="text-sm font-medium text-gray-500">Daily Requests</div>
                    <div className="mt-1 text-2xl font-semibold text-purple-600">
                      {result.metrics.requests}
                    </div>
                  </div>
                </div>
              </div>

              {/* Documentation */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">API Documentation</h3>
                <div className="flex items-center gap-3 p-4 bg-green-50 rounded-lg">
                  <FileJson className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">Documentation is published</p>
                    <a
                      href={result.docsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-indigo-600 hover:text-indigo-500"
                    >
                      View API Documentation
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}