import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Box,
  Settings2,
  Loader2,
  AlertTriangle,
  GitBranch,
  CheckCircle2,
  TestTube2,
  Server,
  Cloud,
  Lock,
  Play,
  Upload
} from 'lucide-react';
import { ModelSelector } from '../components/ModelSelector';
import { CodeEditor } from '../components/CodeEditor';
import { TokenCounter } from '../components/TokenCounter';

const dockerSchema = z.object({
  projectName: z.string().min(3, 'Project name must be at least 3 characters'),
  runtime: z.object({
    base: z.string().min(1, 'Base image is required'),
    version: z.string().min(1, 'Version is required'),
  }),
  testing: z.object({
    framework: z.string().min(1, 'Testing framework is required'),
    coverage: z.boolean(),
    e2e: z.boolean(),
  }),
  github: z.object({
    repository: z.string().min(1, 'Repository URL is required'),
    branch: z.string().min(1, 'Branch name is required'),
    autoPromote: z.boolean(),
  }),
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
});

type DockerForm = z.infer<typeof dockerSchema>;

const RUNTIMES = {
  node: { name: 'Node.js', versions: ['16', '18', '20'] },
  python: { name: 'Python', versions: ['3.8', '3.9', '3.10', '3.11'] },
  java: { name: 'Java', versions: ['11', '17', '21'] },
  go: { name: 'Go', versions: ['1.19', '1.20', '1.21'] },
};

const TEST_FRAMEWORKS = {
  node: ['Jest', 'Mocha', 'Vitest'],
  python: ['Pytest', 'Unittest', 'Robot'],
  java: ['JUnit', 'TestNG', 'Mockito'],
  go: ['Go Test', 'Testify', 'Ginkgo'],
};

export function DockerCategoryPage() {
  const [dockerFile, setDockerFile] = useState('');
  const [testConfig, setTestConfig] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<DockerForm>({
    resolver: zodResolver(dockerSchema),
    defaultValues: {
      runtime: {
        base: 'node',
        version: '20',
      },
      testing: {
        framework: 'Jest',
        coverage: true,
        e2e: false,
      },
      github: {
        branch: 'main',
        autoPromote: true,
      },
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedRuntime = watch('runtime.base');
  const selectedModels = watch('modelIds');

  const onSubmit = async (data: DockerForm) => {
    setIsProcessing(true);
    setProgress(0);
    setError(null);
    setResult(null);
    
    try {
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      // TODO: Implement actual Docker and GitHub integration
      await new Promise(resolve => setTimeout(resolve, 3000));

      setResult({
        dockerUrl: 'https://hub.docker.com/r/example/app',
        testResults: {
          passed: 42,
          failed: 0,
          coverage: '94%',
        },
        githubPr: 'https://github.com/example/app/pull/1',
      });
      
      setProgress(100);
    } catch (error) {
      console.error('Processing failed:', error);
      setError('Failed to process request. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Box className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Docker Integration</h1>
              <p className="mt-1 text-sm text-gray-500">
                Test and deploy your code with Docker and GitHub integration
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <TestTube2 className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Testing</div>
                <div className="text-xs text-gray-500">Automated tests</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Server className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Docker</div>
                <div className="text-xs text-gray-500">Containerization</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <GitBranch className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">GitHub</div>
                <div className="text-xs text-gray-500">Version control</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Cloud className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Deploy</div>
                <div className="text-xs text-gray-500">Auto promotion</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Docker Configuration</h2>
            </div>

            <div className="space-y-6">
              <ModelSelector 
                selectedModels={selectedModels} 
                onChange={(models) => setValue('modelIds', models)} 
              />

              <div>
                <label className="block text-sm font-medium text-gray-700">Project Name</label>
                <input
                  type="text"
                  {...register('projectName')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
                {errors.projectName && (
                  <p className="mt-1 text-sm text-red-600">{errors.projectName.message}</p>
                )}
              </div>

              {/* Runtime Configuration */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Runtime</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Base Image</label>
                    <select
                      {...register('runtime.base')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      {Object.entries(RUNTIMES).map(([key, runtime]) => (
                        <option key={key} value={key}>
                          {runtime.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Version</label>
                    <select
                      {...register('runtime.version')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      {RUNTIMES[selectedRuntime as keyof typeof RUNTIMES].versions.map(version => (
                        <option key={version} value={version}>
                          {version}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Testing Configuration */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Testing</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Framework</label>
                    <select
                      {...register('testing.framework')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      {TEST_FRAMEWORKS[selectedRuntime as keyof typeof TEST_FRAMEWORKS].map(framework => (
                        <option key={framework} value={framework}>
                          {framework}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        {...register('testing.coverage')}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className="text-sm text-gray-700">Code Coverage</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        {...register('testing.e2e')}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className="text-sm text-gray-700">E2E Testing</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* GitHub Configuration */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">GitHub Integration</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Repository URL</label>
                    <input
                      type="text"
                      {...register('github.repository')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      placeholder="https://github.com/username/repo"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Branch</label>
                    <input
                      type="text"
                      {...register('github.branch')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    />
                  </div>
                </div>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    {...register('github.autoPromote')}
                    className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-sm text-gray-700">Auto-promote after successful tests</span>
                </label>
              </div>

              {/* Generated Configurations */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium text-gray-900">Dockerfile</h3>
                  <TokenCounter code={dockerFile} maxTokens={2048} />
                </div>
                <CodeEditor
                  value={dockerFile}
                  onChange={setDockerFile}
                  language="dockerfile"
                />

                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium text-gray-900">Test Configuration</h3>
                  <TokenCounter code={testConfig} maxTokens={2048} />
                </div>
                <CodeEditor
                  value={testConfig}
                  onChange={setTestConfig}
                  language="yaml"
                />
              </div>
            </div>
          </div>

          {/* Process Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isProcessing}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 mr-2" />
                  Start Integration
                </>
              )}
            </button>
          </div>
        </form>

        {/* Results Section */}
        {result && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="space-y-6">
              {/* Docker Results */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Docker Build</h3>
                <div className="flex items-center gap-3 p-4 bg-green-50 rounded-lg">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">Image built successfully</p>
                    <a
                      href={result.dockerUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-indigo-600 hover:text-indigo-500"
                    >
                      View on Docker Hub
                    </a>
                  </div>
                </div>
              </div>

              {/* Test Results */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Test Results</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-green-50 rounded-lg">
                    <div className="text-sm font-medium text-gray-500">Tests Passed</div>
                    <div className="mt-1 text-2xl font-semibold text-green-600">
                      {result.testResults.passed}
                    </div>
                  </div>
                  <div className="p-4 bg-red-50 rounded-lg">
                    <div className="text-sm font-medium text-gray-500">Tests Failed</div>
                    <div className="mt-1 text-2xl font-semibold text-red-600">
                      {result.testResults.failed}
                    </div>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="text-sm font-medium text-gray-500">Code Coverage</div>
                    <div className="mt-1 text-2xl font-semibold text-blue-600">
                      {result.testResults.coverage}
                    </div>
                  </div>
                </div>
              </div>

              {/* GitHub Results */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">GitHub Integration</h3>
                <div className="flex items-center gap-3 p-4 bg-green-50 rounded-lg">
                  <GitBranch className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">Pull Request Created</p>
                    <a
                      href={result.githubPr}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-indigo-600 hover:text-indigo-500"
                    >
                      View Pull Request
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}