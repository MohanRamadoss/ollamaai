import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Sparkles, 
  Wand2, 
  Code2, 
  FileCode, 
  Loader2, 
  Settings2, 
  CheckCircle2,
  Brain,
  AlertTriangle,
  Save,
  Plus,
  Trash2,
  Edit2,
  FileText,
  RefreshCw,
  TestTube2,
  Zap
} from 'lucide-react'; // Add missing icons

// Fix imports paths to match your project structure
import { TokenCounter } from '../components/Prompt/TokenCounter';
import { ModelMultiSelect } from '../components/Prompt/ModelMultiSelect';
import { LanguageSelector } from '../components/Prompt/LanguageSelector';
import { ComplexitySelector } from '../components/Prompt/ComplexitySelector';
import { generatePrompt } from '../lib/api/prompt';
import type { PromptTemplate, PromptProgress, PromptCategory, ComplexityLevel, ProgrammingLanguage } from '../types/prompt';
import { PROMPT_MODELS, getDefaultPromptModel } from '../config/promptModels';

// Add missing PROMPT_CATEGORIES type
interface PromptCategoryOption {
  id: PromptCategory;
  name: string;
  icon: React.ReactNode;
  description: string;
}

// Define category options with icons
const PROMPT_CATEGORIES: PromptCategoryOption[] = [
  { id: 'code', name: 'Code Generation', icon: <Code2 className="w-5 h-5" />, description: 'Generate code snippets and functions' },
  { id: 'conversion', name: 'Code Conversion', icon: <RefreshCw className="w-5 h-5" />, description: 'Convert between languages' },
  { id: 'documentation', name: 'Documentation', icon: <FileText className="w-5 h-5" />, description: 'Generate documentation' },
  { id: 'testing', name: 'Testing', icon: <TestTube2 className="w-5 h-5" />, description: 'Create test cases' },
  { id: 'optimization', name: 'Optimization', icon: <Zap className="w-5 h-5" />, description: 'Optimize code' },
  { id: 'custom', name: 'Custom', icon: <Wand2 className="w-5 h-5" />, description: 'Custom prompts' }
];

// Add this schema definition before the component
const promptSchema = z.object({
  title: z.string().min(3, 'Title must be at least 3 characters'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  template: z.string().min(20, 'Template must be at least 20 characters'),
  category: z.enum(['code', 'conversion', 'documentation', 'testing', 'optimization', 'custom']),
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  language: z.string().optional(),
  complexity: z.enum(['basic', 'intermediate', 'advanced']).optional(),
  variables: z.array(z.object({
    name: z.string().min(1),
    description: z.string(),
    required: z.boolean(),
    defaultValue: z.string().optional(),
  })),
  temperature: z.number().min(0).max(1).default(0.7),
  topP: z.number().min(0).max(1).default(0.9),
  topK: z.number().min(1).max(100).default(40),
  maxTokens: z.number().min(1).max(8192).default(2048),
});

type PromptForm = z.infer<typeof promptSchema>;

export function PromptsPage() {
  const [generatedCode, setGeneratedCode] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState<Record<string, PromptProgress>>({});
  const [previewPrompt, setPreviewPrompt] = useState('');
  const [variables, setVariables] = useState<Record<string, string>>({});
  const [prompts, setPrompts] = useState<PromptTemplate[]>([]);
  const [editingPrompt, setEditingPrompt] = useState<PromptTemplate | null>(null);
  const [error, setError] = useState<Error | null>(null);

  const { register, handleSubmit, watch, setValue, reset, formState: { errors } } = useForm<PromptForm>({
    resolver: zodResolver(promptSchema),
    defaultValues: {
      category: 'code',
      variables: [],
      modelIds: [getDefaultPromptModel().id],
      language: 'typescript',
      complexity: 'intermediate',
    },
  });

  const template = watch('template');
  const selectedModels = watch('modelIds');
  const selectedCategory = watch('category');
  const selectedLanguage = watch('language');
  const selectedComplexity = watch('complexity');

  const handleAddVariable = () => {
    setValue('variables', [
      ...(watch('variables') || []),
      { name: '', description: '', required: false },
    ]);
  };

  const handleRemoveVariable = (index: number) => {
    const variables = watch('variables');
    setValue('variables', variables.filter((_, i) => i !== index));
  };

  const handlePreview = async () => {
    try {
      setIsGenerating(true);
      setError(null);

      // Validate required variables
      const missingVariables = watch('variables')
        ?.filter(v => v.required && !variables[v.name])
        .map(v => v.name);

      if (missingVariables?.length > 0) {
        throw new Error(`Missing required variables: ${missingVariables.join(', ')}`);
      }

      // Validate required fields
      if (!watch('title') || !watch('description') || !watch('template')) {
        throw new Error('Please fill in all required fields');
      }

      console.log('Starting generation with:', {
        models: selectedModels,
        category: selectedCategory,
        language: selectedLanguage,
        complexity: selectedComplexity,
        variables: variables
      });

      const result = await generatePrompt({
        modelIds: selectedModels,
        template: {
          id: Date.now().toString(),
          title: watch('title'),
          description: watch('description'),
          category: selectedCategory as PromptCategory,
          template: watch('template'),
          language: selectedLanguage as ProgrammingLanguage,
          complexity: selectedComplexity as ComplexityLevel,
          variables: watch('variables'),
        },
        variables: variables,
        temperature: watch('temperature'),
        topP: watch('topP'),
        topK: watch('topK'),
        maxTokens: watch('maxTokens'),
      }, (progress) => {
        setProgress(progress);
        console.log('Generation progress:', progress);
      });

      // Log the result for debugging
      console.log('Generation result:', result);

      // Set preview content from the first successful result
      const firstResult = Object.values(result)[0];
      if (firstResult) {
        setPreviewPrompt(firstResult.code);
        setGeneratedCode(firstResult.explanation || '');
      } else {
        throw new Error('No valid response received');
      }

    } catch (error) {
      console.error('Preview generation failed:', error);
      setError(error instanceof Error ? error : new Error('Failed to generate preview'));
    } finally {
      setIsGenerating(false);
    }
  };

  const renderPreviewButton = () => (
    <button
      type="button"
      onClick={handlePreview}
      disabled={isGenerating}
      className="w-full flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {isGenerating ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          Generating...
        </>
      ) : (
        <>
          <Wand2 className="w-4 h-4 mr-2" />
          Generate Preview
        </>
      )}
    </button>
  );

  const onSubmit = async (data: PromptForm) => {
    try {
      if (editingPrompt) {
        setPrompts(prompts.map(p => 
          p.id === editingPrompt.id ? { ...data, id: editingPrompt.id } as PromptTemplate : p
        ));
      } else {
        const newPrompt: PromptTemplate = {
          ...data,
          id: Date.now().toString(),
        };
        setPrompts([...prompts, newPrompt]);
      }
      reset();
      setEditingPrompt(null);
    } catch (error) {
      console.error('Save failed:', error);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Sparkles className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">AI Prompt Templates</h1>
              <p className="mt-1 text-sm text-gray-500">
                Create and manage your AI prompt templates for consistent code generation
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {PROMPT_CATEGORIES.map((category) => (
              <div key={category.id} className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                <div className="text-indigo-600">{category.icon}</div>
                <div>
                  <div className="text-sm font-medium text-gray-900">{category.name}</div>
                  <div className="text-xs text-gray-500">{category.description}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Prompt Editor */}
          <div className="space-y-6">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Model Selection */}
              <ModelMultiSelect 
                selectedModels={selectedModels} 
                onChange={(models) => setValue('modelIds', models)} 
              />

              {/* Basic Info */}
              <div>
                <label className="block text-sm font-medium text-gray-700">Title</label>
                <input
                  type="text"
                  {...register('title')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                />
                {errors.title && (
                  <p className="mt-1 text-sm text-red-600 flex items-center gap-1">
                    <AlertTriangle className="w-4 h-4" />
                    {errors.title.message}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Description</label>
                <textarea
                  {...register('description')}
                  rows={2}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                />
                {errors.description && (
                  <p className="mt-1 text-sm text-red-600 flex items-center gap-1">
                    <AlertTriangle className="w-4 h-4" />
                    {errors.description.message}
                  </p>
                )}
              </div>

              {/* Category and Language Selection */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Category</label>
                  <select
                    {...register('category')}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                  >
                    {PROMPT_CATEGORIES.map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>

                {selectedCategory === 'code' && (
                  <LanguageSelector 
                    value={selectedLanguage || ''}
                    onChange={(lang) => setValue('language', lang)}
                  />
                )}
              </div>

              {/* Complexity Selection */}
              {selectedCategory === 'code' && (
                <ComplexitySelector
                  value={selectedComplexity || 'intermediate'}
                  onChange={(complexity) => setValue('complexity', complexity as ComplexityLevel)}
                />
              )}

              {/* Template Editor */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-sm font-medium text-gray-700">Template</label>
                  <TokenCounter code={template || ''} maxTokens={2048} />
                </div>
                <textarea
                  {...register('template')}
                  rows={6}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm font-mono"
                  placeholder="Write your prompt template here. Use {variable} syntax for dynamic values."
                />
                {errors.template && (
                  <p className="mt-1 text-sm text-red-600 flex items-center gap-1">
                    <AlertTriangle className="w-4 h-4" />
                    {errors.template.message}
                  </p>
                )}
              </div>

              {/* Variables Section */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-sm font-medium text-gray-700">Variables</label>
                  <button
                    type="button"
                    onClick={handleAddVariable}
                    className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200"
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    Add Variable
                  </button>
                </div>
                
                <div className="space-y-4">
                  {watch('variables')?.map((_, index) => (
                    <div key={index} className="flex gap-4 items-start">
                      <div className="flex-1">
                        <input
                          {...register(`variables.${index}.name`)}
                          placeholder="Variable name"
                          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                        />
                      </div>
                      <div className="flex-1">
                        <input
                          {...register(`variables.${index}.description`)}
                          placeholder="Description"
                          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <label className="inline-flex items-center">
                          <input
                            type="checkbox"
                            {...register(`variables.${index}.required`)}
                            className="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                          />
                          <span className="ml-2 text-sm text-gray-600">Required</span>
                        </label>
                        <button
                          type="button"
                          onClick={() => handleRemoveVariable(index)}
                          className="p-1 text-gray-400 hover:text-red-500"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end space-x-4">
                <button
                  type="button"
                  onClick={handlePreview}
                  disabled={isGenerating}
                  className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  Preview
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {editingPrompt ? 'Update Template' : 'Save Template'}
                </button>
              </div>
            </form>
          </div>

          {/* Preview and Saved Prompts */}
          <div className="space-y-6">
            {/* Preview Section */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="flex items-center gap-3 mb-6">
                <Brain className="w-5 h-5 text-indigo-600" />
                <h2 className="text-lg font-medium text-gray-900">Preview</h2>
              </div>
              
              <div className="space-y-4">
                {watch('variables')?.map((variable, index) => (
                  <div key={index}>
                    <label className="block text-sm font-medium text-gray-700">
                      {variable.name} {variable.required && <span className="text-red-500">*</span>}
                    </label>
                    <input
                      type="text"
                      value={variables[variable.name] || ''}
                      onChange={(e) => setVariables({ ...variables, [variable.name]: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                      placeholder={variable.description}
                    />
                  </div>
                ))}

                {renderPreviewButton()}

                {previewPrompt && (
                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Generated Preview
                    </label>
                    <div className="bg-gray-50 rounded-md p-4 font-mono text-sm whitespace-pre-wrap">
                      {previewPrompt}
                    </div>
                  </div>
                )}

                {error && (
                  <div className="mt-4 p-4 bg-red-50 rounded-md">
                    <p className="text-sm text-red-600 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4" />
                      {error.message}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Generated Preview */}
            {previewPrompt && (
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center gap-3 mb-6">
                  <Brain className="w-5 h-5 text-indigo-600" />
                  <h2 className="text-lg font-medium text-gray-900">Generated Preview</h2>
                </div>
                <pre className="bg-gray-50 rounded-md p-4 font-mono text-sm whitespace-pre-wrap">
                  {previewPrompt}
                </pre>
              </div>
            )}

            {/* Saved Prompts */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="flex items-center gap-3 mb-6">
                <CheckCircle2 className="w-5 h-5 text-indigo-600" />
                <h2 className="text-lg font-medium text-gray-900">Saved Templates</h2>
              </div>
              
              <div className="space-y-4">
                {prompts.map((prompt) => {
                  const category = PROMPT_CATEGORIES.find(c => c.id === prompt.category);
                  return (
                    <div key={prompt.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-3">
                          {category?.icon}
                          <div>
                            <h3 className="font-medium text-gray-900">{prompt.title}</h3>
                            <p className="text-sm text-gray-500">{prompt.description}</p>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => setEditingPrompt(prompt)}
                            className="p-1 text-gray-400 hover:text-indigo-500"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setPrompts(prompts.filter(p => p.id !== prompt.id))}
                            className="p-1 text-gray-400 hover:text-red-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      <div className="mt-2">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                          {category?.name || prompt.category}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}