import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Bot,
  Code2, 
  Search, 
  Play, 
  Bug, 
  Loader2, 
  Brain,
  Settings2,
  FileCode,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Zap,
  RefreshCw
} from 'lucide-react';
import { ModelSelector } from '../components/ModelSelector';
import { LanguageSelector } from '../components/LanguageSelector';
import { FileAttachment } from '../components/CodeConversion/FileAttachment';
import { CodeEditor } from '../components/CodeEditor';
import { TokenCounter } from '../components/TokenCounter';

const agentSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  language: z.string().min(1, 'Select a programming language'),
  mode: z.enum(['analyze', 'generate', 'execute', 'debug']),
  features: z.object({
    codeAnalysis: z.boolean(),
    errorDetection: z.boolean(),
    optimization: z.boolean(),
    documentation: z.boolean(),
  }),
});

type AgentForm = z.infer<typeof agentSchema>;

const AGENT_MODES = [
  { id: 'analyze', name: 'Code Analysis', icon: <Search className="w-5 h-5" />, description: 'Analyze code structure and quality' },
  { id: 'generate', name: 'Code Generation', icon: <Code2 className="w-5 h-5" />, description: 'Generate optimized code' },
  { id: 'execute', name: 'Code Execution', icon: <Play className="w-5 h-5" />, description: 'Execute and test code' },
  { id: 'debug', name: 'Code Debugging', icon: <Bug className="w-5 h-5" />, description: 'Find and fix issues' }
];

const AGENT_FEATURES = [
  { id: 'codeAnalysis', name: 'Code Analysis', icon: <Search className="w-5 h-5" />, description: 'Deep code analysis' },
  { id: 'errorDetection', name: 'Error Detection', icon: <AlertTriangle className="w-5 h-5" />, description: 'Find potential errors' },
  { id: 'optimization', name: 'Optimization', icon: <Zap className="w-5 h-5" />, description: 'Performance optimization' },
  { id: 'documentation', name: 'Documentation', icon: <FileCode className="w-5 h-5" />, description: 'Generate documentation' }
];

export function ProgrammingAgentPage() {
  const [sourceCode, setSourceCode] = useState('');
  const [result, setResult] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<AgentForm>({
    resolver: zodResolver(agentSchema),
    defaultValues: {
      mode: 'analyze',
      features: {
        codeAnalysis: true,
        errorDetection: true,
        optimization: true,
        documentation: true,
      },
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedModels = watch('modelIds');
  const selectedLanguage = watch('language');
  const selectedMode = watch('mode');

  const handleFileSelect = (content: string) => {
    setSourceCode(content);
    setResult('');
  };

  const onSubmit = async (data: AgentForm) => {
    if (!sourceCode.trim()) {
      setError('Please provide source code to process');
      return;
    }

    setIsProcessing(true);
    setProgress(0);
    setError(null);
    
    try {
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      // TODO: Implement actual code processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setResult(`// Generated result for ${data.mode} mode
function processedCode() {
  // AI-generated code will appear here
  console.log("Processing complete");
}`);
      
      setProgress(100);
    } catch (error) {
      console.error('Processing failed:', error);
      setError('Failed to process code. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Bot className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Programming Agent</h1>
              <p className="mt-1 text-sm text-gray-500">
                AI-powered code analysis, generation, execution, and debugging
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Brain className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Smart Analysis</div>
                <div className="text-xs text-gray-500">AI-powered insights</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Code Generation</div>
                <div className="text-xs text-gray-500">Optimized code</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Zap className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Fast Execution</div>
                <div className="text-xs text-gray-500">Quick processing</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <RefreshCw className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Auto Debug</div>
                <div className="text-xs text-gray-500">Issue resolution</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Agent Configuration</h2>
            </div>

            <div className="space-y-8">
              <ModelSelector 
                selectedModels={selectedModels} 
                onChange={(models) => setValue('modelIds', models)} 
              />

              <LanguageSelector 
                value={selectedLanguage}
                onChange={(language) => setValue('language', language)}
              />

              {/* Mode Selection */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium text-gray-700">Operation Mode</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {AGENT_MODES.map(mode => (
                    <label
                      key={mode.id}
                      className={`relative flex flex-col p-4 cursor-pointer rounded-lg border transition-colors ${
                        selectedMode === mode.id
                          ? 'border-indigo-500 bg-indigo-50'
                          : 'border-gray-200 hover:border-indigo-300'
                      }`}
                    >
                      <input
                        type="radio"
                        {...register('mode')}
                        value={mode.id}
                        className="sr-only"
                      />
                      <div className="flex items-center gap-2">
                        <div className={selectedMode === mode.id ? 'text-indigo-600' : 'text-gray-400'}>
                          {mode.icon}
                        </div>
                        <div className="font-medium text-gray-900">{mode.name}</div>
                      </div>
                      <p className="mt-1 text-sm text-gray-500">{mode.description}</p>
                    </label>
                  ))}
                </div>
              </div>

              {/* Features */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium text-gray-700">Features</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {AGENT_FEATURES.map(feature => (
                    <label key={feature.id} className="flex items-start gap-3 p-4 border rounded-lg hover:bg-gray-50">
                      <input
                        type="checkbox"
                        {...register(`features.${feature.id}`)}
                        className="mt-1 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <div className="text-indigo-600">{feature.icon}</div>
                          <div className="font-medium text-gray-900">{feature.name}</div>
                        </div>
                        <div className="text-sm text-gray-500">{feature.description}</div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Code Input */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <FileCode className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Source Code</h2>
            </div>

            <div className="space-y-6">
              <FileAttachment onFileSelect={handleFileSelect} />

              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium text-gray-700">Code Editor</h3>
                <TokenCounter code={sourceCode} maxTokens={8192} />
              </div>

              <CodeEditor
                value={sourceCode}
                onChange={setSourceCode}
                language={selectedLanguage}
              />

              {error && (
                <div className="flex items-center gap-2 text-sm text-red-600">
                  <AlertTriangle className="w-4 h-4" />
                  <span>{error}</span>
                </div>
              )}
            </div>
          </div>

          {/* Process Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isProcessing || !sourceCode.trim()}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Bot className="w-5 h-5 mr-2" />
                  Process Code
                </>
              )}
            </button>
          </div>
        </form>

        {/* Results Section */}
        {result && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <CheckCircle2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Results</h2>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium text-gray-700">Generated Output</h3>
                <TokenCounter code={result} maxTokens={8192} />
              </div>

              <CodeEditor
                value={result}
                onChange={() => {}}
                language={selectedLanguage}
                readOnly
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}