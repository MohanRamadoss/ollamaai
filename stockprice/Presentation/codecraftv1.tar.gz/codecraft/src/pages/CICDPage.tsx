import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  GitBranch, 
  Code2, 
  FileCode, 
  Loader2, 
  Settings2, 
  CheckCircle2, 
  Upload,
  Sparkles,
  Brain,
  Zap,
  AlertTriangle,
  Workflow,
  TestTube2,
  Rocket,
  Activity
} from 'lucide-react';
import { CICDControl } from '../components/CICD/CICDControl';
import { CICDProgress } from '../components/CICD/CICDProgress';
import { CICDOutput } from '../components/CICD/CICDOutput';
import { ModelMultiSelect } from '../components/CICD/ModelMultiSelect';
import { ComplexitySelector } from '../components/CICD/ComplexitySelector';
import { TokenCounter } from '../components/TokenCounter';
import type { Platform, PipelineType } from '../types/cicd';
import type { ComplexityLevel } from '../types/models';
import { generateCICDPipeline } from '../lib/api/cicd';
import type { CICDProgress as CICDProgressType } from '../types/cicd';
import { CICD_MODELS, getDefaultCICDModel, getCICDModel } from '../config/cicdModels';
import { MultiModelOutput } from '../components/CICD/MultiModelOutput';
import { CICD_EXAMPLES } from '../config/cicd.config';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogFooter } from '../components/ui/AlertDialog';

const cicdSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  platform: z.enum(['github', 'gitlab', 'azure-devops', 'jenkins']),
  pipelineType: z.enum(['build', 'test', 'deploy', 'monitor']),
  complexity: z.enum(['basic', 'intermediate', 'advanced']),
  requirements: z.string().min(10, 'Requirements must be at least 10 characters'),
  temperature: z.number().min(0).max(1),
  topP: z.number().min(0).max(1),
  topK: z.number().min(1).max(100),
  maxTokens: z.number().min(1).max(8192),
});

type CICDForm = z.infer<typeof cicdSchema>;

export function CICDPage() {
  const [generatedCode, setGeneratedCode] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<Error | null>(null);
  const [modelProgress, setModelProgress] = useState<Record<string, CICDProgressType>>({});
  const [selectedModelName, setSelectedModelName] = useState('');
  const [modelOutputs, setModelOutputs] = useState<Record<string, any>>({});
  const [lastGeneratedConfig, setLastGeneratedConfig] = useState<{
    modelIds: string[];
    platform: Platform;
    pipelineType: PipelineType;
    requirements: string;
    complexity: ComplexityLevel;
  } | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [pendingFormData, setPendingFormData] = useState<CICDForm | null>(null);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<CICDForm>({
    resolver: zodResolver(cicdSchema),
    defaultValues: {
      temperature: getDefaultCICDModel().defaultParams.temperature,
      topP: getDefaultCICDModel().defaultParams.topP,
      topK: getDefaultCICDModel().defaultParams.topK,
      maxTokens: getDefaultCICDModel().defaultParams.maxTokens,
      complexity: 'intermediate' as ComplexityLevel,
      platform: 'github',
      pipelineType: 'build',
      modelIds: [getDefaultCICDModel().id],
    },
  });

  const selectedModels = watch('modelIds');
  const selectedPlatform = watch('platform') as Platform;
  const selectedPipelineType = watch('pipelineType') as PipelineType;
  const selectedComplexity = watch('complexity');
  const maxTokens = watch('maxTokens');

  const isConfigUnchanged = (data: CICDForm) => {
    if (!lastGeneratedConfig) return false;
    
    return (
      JSON.stringify(data.modelIds) === JSON.stringify(lastGeneratedConfig.modelIds) &&
      data.platform === lastGeneratedConfig.platform &&
      data.pipelineType === lastGeneratedConfig.pipelineType &&
      data.requirements === lastGeneratedConfig.requirements &&
      data.complexity === lastGeneratedConfig.complexity
    );
  };

  const onSubmit = async (data: CICDForm) => {
    if (isGenerating) return;

    // Store form data and show confirmation
    setPendingFormData(data);
    setShowConfirmation(true);
  };

  const handleConfirmedGeneration = async () => {
    if (!pendingFormData || isGenerating) return;

    setShowConfirmation(false);
    setIsGenerating(true);
    setError(null);
    setModelOutputs({});
    setProgress(0);
    setModelProgress({});
    
    try {
      const results = await generateCICDPipeline({
        ...pendingFormData,
        options: {
          temperature: pendingFormData.temperature,
          topP: pendingFormData.topP,
          topK: pendingFormData.topK,
          maxTokens: pendingFormData.maxTokens,
        }
      }, (progress) => {
        setModelProgress(progress);
        const totalProgress = Object.values(progress).reduce(
          (acc, curr) => acc + curr.progress, 
          0
        );
        setProgress(totalProgress / Object.keys(progress).length);
      });

      setModelOutputs(results);
      const firstResult = Object.values(results)[0];
      if (firstResult) {
        setGeneratedCode(firstResult.code);
      }
    } catch (error) {
      console.error('Generation failed:', error);
      setError(error instanceof Error ? error : new Error('Failed to generate pipeline'));
    } finally {
      setIsGenerating(false);
      setPendingFormData(null);
    }
  };

  const handleExampleSelect = (example: string) => {
    setValue('requirements', example);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <GitBranch className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">CI/CD Pipeline</h1>
              <p className="mt-1 text-sm text-gray-500">
                Generate production-ready CI/CD pipelines using advanced AI models
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Workflow className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Automation</div>
                <div className="text-xs text-gray-500">Build & Deploy</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <TestTube2 className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Testing</div>
                <div className="text-xs text-gray-500">Quality Assurance</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Rocket className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Deployment</div>
                <div className="text-xs text-gray-500">Multi-environment</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Activity className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Monitoring</div>
                <div className="text-xs text-gray-500">Real-time metrics</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Form Content - 3 columns */}
          <div className="lg:col-span-3">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
              {/* Configuration Section */}
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center gap-3 mb-6">
                  <Settings2 className="w-5 h-5 text-indigo-600" />
                  <h2 className="text-lg font-medium text-gray-900">Pipeline Settings</h2>
                </div>

                <div className="space-y-8">
                  <ModelMultiSelect 
                    selectedModels={selectedModels} 
                    onChange={(models) => setValue('modelIds', models)} 
                  />

                  <CICDControl
                    platform={selectedPlatform}
                    pipelineType={selectedPipelineType}
                    onPlatformChange={(platform) => setValue('platform', platform)}
                    onPipelineTypeChange={(type) => setValue('pipelineType', type)}
                  />

                  <ComplexitySelector
                    value={selectedComplexity}
                    onChange={(complexity) => setValue('complexity', complexity as ComplexityLevel)}
                  />

                  <div className="space-y-6">
                    <div className="flex items-center gap-3 mb-4">
                      <FileCode className="w-5 h-5 text-indigo-600" />
                      <h3 className="text-sm font-medium text-gray-900">Generation Parameters</h3>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          Temperature ({watch('temperature')})
                        </label>
                        <input
                          type="range"
                          {...register('temperature', { valueAsNumber: true })}
                          min="0"
                          max="1"
                          step="0.1"
                          className="w-full mt-2"
                        />
                        <p className="mt-1 text-sm text-gray-500">
                          Controls creativity in the generation process
                        </p>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          Top P ({watch('topP')})
                        </label>
                        <input
                          type="range"
                          {...register('topP', { valueAsNumber: true })}
                          min="0"
                          max="1"
                          step="0.1"
                          className="w-full mt-2"
                        />
                        <p className="mt-1 text-sm text-gray-500">
                          Controls diversity in the output
                        </p>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          Top K ({watch('topK')})
                        </label>
                        <input
                          type="range"
                          {...register('topK', { valueAsNumber: true })}
                          min="1"
                          max="100"
                          className="w-full mt-2"
                        />
                        <p className="mt-1 text-sm text-gray-500">
                          Limits token consideration during generation
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Requirements Section */}
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center gap-3 mb-6">
                  <Brain className="w-5 h-5 text-indigo-600" />
                  <h2 className="text-lg font-medium text-gray-900">Pipeline Requirements</h2>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <label className="block text-sm font-medium text-gray-700">Requirements</label>
                    <TokenCounter code={watch('requirements') || ''} maxTokens={maxTokens} />
                  </div>
                  <textarea
                    {...register('requirements')}
                    rows={6}
                    className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    placeholder="Describe your CI/CD pipeline requirements..."
                  />
                  {errors.requirements && (
                    <p className="flex items-center gap-2 text-sm text-red-600">
                      <AlertTriangle className="w-4 h-4" />
                      {errors.requirements.message}
                    </p>
                  )}
                </div>
              </div>

              {/* Output Section */}
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center gap-3 mb-6">
                  <CheckCircle2 className="w-5 h-5 text-indigo-600" />
                  <h2 className="text-lg font-medium text-gray-900">Generated Pipeline</h2>
                </div>

                {/* Model progress display */}
                {Object.values(modelProgress).map(model => (
                  <div key={model.modelId} className="mb-4">
                    <CICDProgress 
                      isGenerating={model.status === 'generating'}
                      progress={model.progress}
                    />
                    {model.error && (
                      <p className="text-red-500 text-sm mt-2">{model.error}</p>
                    )}
                  </div>
                ))}
                
                <MultiModelOutput
                  modelOutputs={modelOutputs}
                  modelProgress={modelProgress}
                  platform={selectedPlatform}
                  pipelineType={selectedPipelineType}
                />

                {error && (
                  <div className="mt-4 p-4 bg-red-50 text-red-600 rounded-lg">
                    {error.message}
                  </div>
                )}
              </div>

              {/* Generate Button */}
              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isGenerating || Object.keys(modelProgress).some(id => modelProgress[id].status === 'generating')}
                  className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <GitBranch className="w-5 h-5 mr-2" />
                      Generate Pipeline
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Examples Panel - 1 column */}
          <div className="lg:col-span-1">
            <div className="sticky top-8">
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center gap-3 mb-4">
                  <GitBranch className="w-5 h-5 text-indigo-600" />
                  <h3 className="text-lg font-medium">Examples</h3>
                </div>
                <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
                  {CICD_EXAMPLES[selectedPlatform]?.[selectedPipelineType]?.map((example, index) => (
                    <button
                      key={index}
                      onClick={() => handleExampleSelect(example)}
                      className="w-full text-left group hover:bg-gray-50 p-3 rounded-lg border border-gray-200"
                    >
                      <p className="text-sm text-gray-600">{example}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add confirmation dialog */}
      <AlertDialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <h3 className="text-lg font-medium">Confirm Pipeline Generation</h3>
            <p className="text-sm text-gray-500 mt-2">
              You are about to generate a CI/CD pipeline with the following configuration:
            </p>
            {pendingFormData && (
              <div className="mt-4 space-y-2 text-sm">
                <p>Platform: <span className="font-medium">{pendingFormData.platform}</span></p>
                <p>Type: <span className="font-medium">{pendingFormData.pipelineType}</span></p>
                <p>Complexity: <span className="font-medium">{pendingFormData.complexity}</span></p>
                <p>Models: <span className="font-medium">{pendingFormData.modelIds.length} selected</span></p>
              </div>
            )}
          </AlertDialogHeader>
          <AlertDialogFooter>
            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowConfirmation(false)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmedGeneration}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Confirm & Generate
              </button>
            </div>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}