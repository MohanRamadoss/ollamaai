import React from 'react';
import { Wand2, Code2, Brain, Sparkles, Zap, CheckCircle2, AlertCircle, GitBranch, Shield, Cpu } from 'lucide-react';

export function CodeGenerationDoc() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Wand2 className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">CodeCraft: Multi-Model Code Generation</h1>
              <p className="mt-1 text-sm text-gray-500">
                Advanced code generation platform using multiple AI models for optimal results
              </p>
            </div>
          </div>
        </div>

        {/* System Architecture */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">System Architecture</h2>
          <div className="text-gray-600">
            <p>The platform integrates multiple AI models through a unified generation manager:</p>
          </div>
          
          {/* Flow Diagram using SVG */}
          <div className="mt-6 mb-6">
            <svg className="w-full" viewBox="0 0 800 400">
              {/* Input Layer */}
              <rect x="50" y="50" width="120" height="60" rx="8" fill="#4F46E5" />
              <text x="110" y="85" textAnchor="middle" fill="white" fontSize="14">User Interface</text>
              
              {/* Core Layer */}
              <rect x="250" y="50" width="300" height="60" rx="8" fill="#6366F1" />
              <text x="400" y="85" textAnchor="middle" fill="white" fontSize="14">Generation Manager</text>
              
              {/* Model Layer */}
              <g transform="translate(250, 160)">
                <rect x="0" y="0" width="60" height="40" rx="4" fill="#818CF8" />
                <text x="30" y="25" textAnchor="middle" fill="white" fontSize="12">OpenAI</text>
                
                <rect x="80" y="0" width="60" height="40" rx="4" fill="#818CF8" />
                <text x="110" y="25" textAnchor="middle" fill="white" fontSize="12">Gemini</text>
                
                <rect x="160" y="0" width="60" height="40" rx="4" fill="#818CF8" />
                <text x="190" y="25" textAnchor="middle" fill="white" fontSize="12">Ollama</text>
                
                <rect x="240" y="0" width="60" height="40" rx="4" fill="#818CF8" />
                <text x="270" y="25" textAnchor="middle" fill="white" fontSize="12">Local</text>
              </g>
              
              {/* Output Layer */}
              <rect x="250" y="250" width="300" height="60" rx="8" fill="#4F46E5" />
              <text x="400" y="285" textAnchor="middle" fill="white" fontSize="14">Code Output</text>
              
              {/* Arrows */}
              <path d="M170 80 L250 80" stroke="#6366F1" strokeWidth="2" markerEnd="url(#arrowhead)" />
              <path d="M400 110 L400 160" stroke="#6366F1" strokeWidth="2" markerEnd="url(#arrowhead)" />
              <path d="M400 200 L400 250" stroke="#6366F1" strokeWidth="2" markerEnd="url(#arrowhead)" />
              
              {/* Arrow Marker */}
              <defs>
                <marker
                  id="arrowhead"
                  markerWidth="10"
                  markerHeight="7"
                  refX="9"
                  refY="3.5"
                  orient="auto"
                >
                  <polygon points="0 0, 10 3.5, 0 7" fill="#6366F1" />
                </marker>
              </defs>
            </svg>
          </div>
          
          {/* Process Flow using SVG */}
          <div className="mt-6 mb-6">
            <svg className="w-full" viewBox="0 0 800 200">
              <g transform="translate(50, 50)">
                {/* Process Steps */}
                <g className="step" transform="translate(0, 0)">
                  <circle cx="35" cy="35" r="35" fill="#4F46E5" />
                  <text x="35" y="35" textAnchor="middle" fill="white" fontSize="12">Input</text>
                </g>
                
                <g className="step" transform="translate(150, 0)">
                  <circle cx="35" cy="35" r="35" fill="#6366F1" />
                  <text x="35" y="35" textAnchor="middle" fill="white" fontSize="12">Process</text>
                </g>
                
                <g className="step" transform="translate(300, 0)">
                  <circle cx="35" cy="35" r="35" fill="#818CF8" />
                  <text x="35" y="35" textAnchor="middle" fill="white" fontSize="12">Generate</text>
                </g>
                
                <g className="step" transform="translate(450, 0)">
                  <circle cx="35" cy="35" r="35" fill="#6366F1" />
                  <text x="35" y="35" textAnchor="middle" fill="white" fontSize="12">Validate</text>
                </g>
                
                <g className="step" transform="translate(600, 0)">
                  <circle cx="35" cy="35" r="35" fill="#4F46E5" />
                  <text x="35" y="35" textAnchor="middle" fill="white" fontSize="12">Output</text>
                </g>
                
                {/* Connecting Lines */}
                <line x1="70" y1="35" x2="150" y2="35" stroke="#6366F1" strokeWidth="2" />
                <line x1="220" y1="35" x2="300" y2="35" stroke="#6366F1" strokeWidth="2" />
                <line x1="370" y1="35" x2="450" y2="35" stroke="#6366F1" strokeWidth="2" />
                <line x1="520" y1="35" x2="600" y2="35" stroke="#6366F1" strokeWidth="2" />
              </g>
            </svg>
          </div>
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* ... rest of the architecture section ... */}
          </div>
        </div>

        {/* Model Capabilities */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Model Capabilities</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">Gemini Pro Code</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• High accuracy code generation</li>
                <li>• Modern framework expertise</li>
                <li>• Web development focus</li>
                <li>• Full-stack capabilities</li>
              </ul>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">CodeLlama</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• System programming optimization</li>
                <li>• Algorithm generation</li>
                <li>• Backend development</li>
                <li>• Performance-focused code</li>
              </ul>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">DeepSeek</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Enterprise code generation</li>
                <li>• Architecture patterns</li>
                <li>• Large project expertise</li>
                <li>• Scalability focus</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Generation Process */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Generation Process</h2>
          
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">1. Input Processing</h3>
              <ul className="space-y-1 text-sm text-gray-600">
                <li>• Requirement analysis</li>
                <li>• Language/framework detection</li>
                <li>• Complexity assessment</li>
                <li>• Constraint validation</li>
              </ul>
            </div>

            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">2. Parallel Generation</h3>
              <ul className="space-y-1 text-sm text-gray-600">
                <li>• Multi-model execution</li>
                <li>• Progress tracking</li>
                <li>• Error handling</li>
                <li>• Result aggregation</li>
              </ul>
            </div>

            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">3. Result Selection</h3>
              <ul className="space-y-1 text-sm text-gray-600">
                <li>• Quality assessment</li>
                <li>• Performance analysis</li>
                <li>• Best result selection</li>
                <li>• Output formatting</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Advanced Features */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Advanced Features</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-5 h-5 text-indigo-600" />
                <h3 className="font-medium text-gray-900">Performance</h3>
              </div>
              <ul className="space-y-1 text-sm text-gray-600">
                <li>• Caching implementation</li>
                <li>• Response optimization</li>
                <li>• Resource management</li>
                <li>• Parallel processing</li>
              </ul>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-5 h-5 text-indigo-600" />
                <h3 className="font-medium text-gray-900">Security</h3>
              </div>
              <ul className="space-y-1 text-sm text-gray-600">
                <li>• Input validation</li>
                <li>• Code sanitization</li>
                <li>• Rate limiting</li>
                <li>• Access control</li>
              </ul>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Code2 className="w-5 h-5 text-indigo-600" />
                <h3 className="font-medium text-gray-900">Quality</h3>
              </div>
              <ul className="space-y-1 text-sm text-gray-600">
                <li>• Best practices</li>
                <li>• Documentation</li>
                <li>• Error handling</li>
                <li>• Testing support</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Best Practices */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Best Practices</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Do's</h3>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Provide detailed requirements and constraints
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Specify target language and framework versions
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Review and test generated code thoroughly
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Consider multiple model outputs for best results
                  </span>
                </li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Don'ts</h3>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Generate security-critical code without review
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Skip testing and validation of generated code
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Use vague or incomplete requirements
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Ignore error handling and edge cases
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}