import React from 'react';
import { ArrowLeftRight, Code2, Brain, Sparkles, Zap, CheckCircle2, AlertCircle, GitBranch, RefreshCw } from 'lucide-react';

export function CodeConversionDoc() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <ArrowLeftRight className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Code Conversion</h1>
              <p className="mt-1 text-sm text-gray-500">
                Learn how to convert code between different programming languages while maintaining functionality
              </p>
            </div>
          </div>
        </div>

        {/* Overview */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Overview</h2>
          <p className="text-gray-600">
            The Code Conversion feature allows you to translate code between different programming languages while preserving functionality, 
            maintaining best practices, and optimizing for the target language's idioms and patterns.
          </p>
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Brain className="w-5 h-5 text-indigo-600" />
                <h3 className="font-medium text-gray-900">Smart Translation</h3>
              </div>
              <p className="text-sm text-gray-600">
                Intelligent code translation with context awareness
              </p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Code2 className="w-5 h-5 text-indigo-600" />
                <h3 className="font-medium text-gray-900">Language Support</h3>
              </div>
              <p className="text-sm text-gray-600">
                Wide range of programming languages and frameworks
              </p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-5 h-5 text-indigo-600" />
                <h3 className="font-medium text-gray-900">Optimization</h3>
              </div>
              <p className="text-sm text-gray-600">
                Target language optimizations and best practices
              </p>
            </div>
          </div>
        </div>

        {/* Getting Started */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Getting Started</h2>
          
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">1. Select Languages</h3>
              <p className="text-sm text-gray-600">
                Choose your source and target languages:
              </p>
              <ul className="mt-2 space-y-1 text-sm text-gray-600">
                <li>• Source Language - The original code's language</li>
                <li>• Target Language - The desired output language</li>
                <li>• Framework Selection (optional)</li>
                <li>• Version Specification</li>
              </ul>
            </div>

            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">2. Configure Conversion</h3>
              <p className="text-sm text-gray-600">
                Set conversion parameters:
              </p>
              <ul className="mt-2 space-y-1 text-sm text-gray-600">
                <li>• Optimization Level</li>
                <li>• Style Preferences</li>
                <li>• Documentation Options</li>
                <li>• Type Conversion Rules</li>
              </ul>
            </div>

            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">3. Provide Source Code</h3>
              <p className="text-sm text-gray-600">
                Input your source code:
              </p>
              <ul className="mt-2 space-y-1 text-sm text-gray-600">
                <li>• Direct code input</li>
                <li>• File upload</li>
                <li>• Project structure</li>
                <li>• Dependencies</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Features in Detail */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Features in Detail</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Conversion Capabilities</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Language Features</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Type System Translation</li>
                    <li>• Language-specific Idioms</li>
                    <li>• Standard Library Mapping</li>
                    <li>• Error Handling Patterns</li>
                    <li>• Async/Await Conversion</li>
                    <li>• Module System Adaptation</li>
                  </ul>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Framework Support</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Web Frameworks</li>
                    <li>• Testing Frameworks</li>
                    <li>• ORM Libraries</li>
                    <li>• UI Components</li>
                    <li>• State Management</li>
                    <li>• API Integration</li>
                  </ul>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Optimization Features</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Code Quality</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Style Guidelines</li>
                    <li>• Code Organization</li>
                    <li>• Documentation</li>
                    <li>• Best Practices</li>
                  </ul>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Performance</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Language Optimizations</li>
                    <li>• Memory Management</li>
                    <li>• Resource Usage</li>
                    <li>• Execution Speed</li>
                  </ul>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Compatibility</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Version Support</li>
                    <li>• Platform Specifics</li>
                    <li>• Dependencies</li>
                    <li>• API Compatibility</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Examples */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Examples</h2>
          
          <div className="space-y-6">
            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">Python to JavaScript Conversion</h3>
              <pre className="p-4 bg-gray-100 rounded-lg overflow-x-auto text-sm">
{`# Python Source Code
def calculate_total(items):
    return sum(item["price"] * item["quantity"] for item in items)

def apply_discount(total, discount_percent):
    return total * (1 - discount_percent / 100)

# JavaScript Converted Code
function calculateTotal(items) {
  return items.reduce((sum, item) => 
    sum + item.price * item.quantity, 0);
}

function applyDiscount(total, discountPercent) {
  return total * (1 - discountPercent / 100);
}`}
              </pre>
            </div>

            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">Java to TypeScript Conversion</h3>
              <pre className="p-4 bg-gray-100 rounded-lg overflow-x-auto text-sm">
{`// Java Source Code
public class User {
    private String name;
    private int age;
    
    public User(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    public boolean isAdult() {
        return age >= 18;
    }
}

// TypeScript Converted Code
interface User {
  name: string;
  age: number;
}

class UserImpl implements User {
  constructor(
    public name: string,
    public age: number
  ) {}

  isAdult(): boolean {
    return this.age >= 18;
  }
}`}
              </pre>
            </div>
          </div>
        </div>

        {/* Best Practices */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Best Practices</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Do's</h3>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Review converted code thoroughly before use
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Test converted code with comprehensive test cases
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Verify type conversions and data structures
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Check for language-specific optimizations
                  </span>
                </li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Don'ts</h3>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Skip testing converted code in production
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Ignore language-specific best practices
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Assume direct one-to-one feature mapping
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-600">
                    Forget to update dependencies and imports
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}