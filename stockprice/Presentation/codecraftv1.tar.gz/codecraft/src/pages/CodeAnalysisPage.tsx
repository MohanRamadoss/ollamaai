import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { AI_MODELS } from '../config/models';
import type { AnalysisProgress } from '../lib/api/analyze';
import {
  Search,
  AlertTriangle,
  Loader2,
  Settings2,
  Upload,
  CheckCircle2,
  FileCode,
  TestTube2,
  Bug,
  RefreshCw,
  FileText
} from 'lucide-react';
import { ModelMultiSelect } from '../components/CodeGeneration/ModelMultiSelect';
import { LanguageSelector } from '../components/LanguageSelector';
import { ActionSelect } from '../components/CodeAnalysis/ActionSelect';
import { AnalysisOutput } from '../components/CodeAnalysis/AnalysisOutput';
import { CodeEditor } from '../components/CodeEditor';
import { TokenCounter } from '../components/TokenCounter';
import { FileAttachment } from '../components/CodeConversion/FileAttachment';
import { analyzeCode } from '../lib/api/analyze';
import { ComplexitySelector } from '../components/CodeAnalysis/ComplexitySelector';
import { CodeAnalysisProgress } from '../components/CodeAnalysis/CodeAnalysisProgress';
import { MultiModelOutput } from '../components/CodeAnalysis/MultiModelOutput';

interface AnalysisResult {
  type: 'error' | 'warning' | 'info' | 'success';
  message: string;
  line?: number;
  timestamp?: string;
}

const analysisSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  language: z.string().min(1, 'Select a programming language'),
  action: z.string().min(1, 'Select an analysis type'),
  complexity: z.enum(['basic', 'intermediate', 'advanced']),
  temperature: z.number().min(0).max(1),
  topP: z.number().min(0).max(1),
  topK: z.number().min(1).max(100),
  maxTokens: z.number().min(1).max(8192),
});

type AnalysisForm = z.infer<typeof analysisSchema>;

const ANALYSIS_FEATURES = [
  { icon: <TestTube2 className="w-5 h-5" />, title: 'Test Generation', description: 'Automated tests' },
  { icon: <Bug className="w-5 h-5" />, title: 'Bug Detection', description: 'Find issues' },
  { icon: <RefreshCw className="w-5 h-5" />, title: 'Refactoring', description: 'Code improvements' },
  { icon: <FileText className="w-5 h-5" />, title: 'Documentation', description: 'Auto-document code' }
];

export function CodeAnalysisPage() {
  const [sourceCode, setSourceCode] = useState('');
  const [analysisResults, setAnalysisResults] = useState<any[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [analysisProgress, setAnalysisProgress] = useState<Record<string, AnalysisProgress>>({});
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isAnalysisStarted, setIsAnalysisStarted] = useState(false);

  const { register, handleSubmit, watch, setValue, formState } = useForm<AnalysisForm>({
    resolver: zodResolver(analysisSchema),
    defaultValues: {
      temperature: 0.7,
      topP: 0.9,
      topK: 50,
      maxTokens: 2048,
      language: 'javascript',
      action: 'analyze',
      modelIds: [], // Initialize with empty array instead of REQUIRED_MODELS
      complexity: 'intermediate',
    },
  });

  const selectedModels = watch('modelIds');
  const selectedLanguage = watch('language');
  const selectedAction = watch('action');
  const maxTokens = watch('maxTokens');

  // Add form validation effect
  useEffect(() => {
    const subscription = watch((value, { name }) => {
      console.debug('Form value changed:', { name, value });
      setValidationError(null);
    });
    return () => subscription.unsubscribe();
  }, [watch]);

  // Reset analysis state when language changes
  useEffect(() => {
    setIsAnalysisStarted(false);
  }, [selectedLanguage, selectedAction]);

  const handleFileSelect = (content: string) => {
    setSourceCode(content);
  };

  const parseAnalysisResults = (rawResults: string): AnalysisResult[] => {
    const lines = rawResults.split('\n');
    return lines
      .filter(line => line.trim())
      .map(line => {
        const trimmed = line.trim();
        if (trimmed.toLowerCase().startsWith('error:')) {
          return {
            type: 'error',
            message: trimmed.substring(6).trim(),
            line: extractLineNumber(trimmed)
          };
        }
        if (trimmed.toLowerCase().startsWith('warning:')) {
          return {
            type: 'warning',
            message: trimmed.substring(8).trim(),
            line: extractLineNumber(trimmed)
          };
        }
        if (trimmed.toLowerCase().startsWith('suggestion:')) {
          return {
            type: 'info',
            message: trimmed.substring(11).trim(),
            line: extractLineNumber(trimmed)
          };
        }
        return {
          type: 'success',
          message: trimmed,
          line: extractLineNumber(trimmed)
        };
      });
  };

  const extractLineNumber = (text: string): number | undefined => {
    const match = text.match(/line\s*(\d+)/i);
    return match ? parseInt(match[1], 10) : undefined;
  };

  // Add this validation function
  const validateModels = (modelIds: string[]) => {
    if (!modelIds || modelIds.length === 0) {
      setValue('modelIds', [AI_MODELS[0].id]); // Set default model if none selected
      setValidationError(null);
      return true;
    }
    setValidationError(null);
    return true;
  };

  // Add model type check helper
  const isGeminiModel = (modelId: string) => modelId.startsWith('gemini-');

  // Modify handleSubmit to include validation
  const handleAnalysisClick = handleSubmit((data) => {
    if (!isAnalysisStarted) {
      setIsAnalysisStarted(true);
      return;
    }
    return onSubmit(data);
  });

  const onSubmit = async (data: AnalysisForm) => {
    if (!sourceCode.trim()) {
      setValidationError('Please enter or upload source code');
      return;
    }

    setValidationError(null);
    setIsAnalyzing(true);
    setAnalysisProgress({});
    setAnalysisResults([]);
    
    try {
      // Initialize progress tracking for each model
      const initialProgress = data.modelIds.reduce((acc, modelId) => ({
        ...acc,
        [modelId]: { 
          modelId, 
          status: 'pending',
          result: '',
          error: undefined,
          // Add provider info for UI feedback
          provider: isGeminiModel(modelId) ? 'Google AI' : 'Ollama'
        }
      }), {});
      
      setAnalysisProgress(initialProgress);

      const result = await analyzeCode({
        ...data,
        sourceLanguage: data.language,
        prompt: sourceCode,
        targetLanguage: data.language,
        modelParams: {
          temperature: data.temperature,
          topP: data.topP,
          topK: data.topK,
          maxTokens: data.maxTokens,
          // Add Gemini-specific params when using Gemini models
          ...(data.modelIds.some(isGeminiModel) && {
            safetySettings: [
              { category: 'HARM_CATEGORY_DANGEROUS', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
              { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
              { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
              { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_MEDIUM_AND_ABOVE' }
            ]
          })
        }
      }, (progress) => {
        setAnalysisProgress(prev => ({
          ...prev,
          ...progress
        }));
        // Update overall progress
        const completed = Object.values(progress).filter(p => p.status === 'completed').length;
        const total = data.modelIds.length;
        setProgress((completed / total) * 100);
      });

      const parsedResults = parseAnalysisResults(result);
      setAnalysisResults(parsedResults.length > 0 ? parsedResults : [{
        type: 'success',
        message: 'No issues found in the code.',
        timestamp: new Date().toISOString()
      }]);

    } catch (error) {
      console.error('Analysis failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Analysis failed';
      setValidationError(
        error instanceof Error && error.message.includes('Google API') 
          ? 'Google AI service error. Please check your API key configuration.'
          : errorMessage
      );
      setAnalysisResults([{
        type: 'error',
        message: errorMessage,
        timestamp: new Date().toISOString()
      }]);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Add validation error display */}
        {validationError && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-4 h-4" />
              <span>{validationError}</span>
            </div>
          </div>
        )}

        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Search className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Code Analysis</h1>
              <p className="mt-1 text-sm text-gray-500">
                Analyze, test, and improve your code using advanced AI models
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            {ANALYSIS_FEATURES.map((feature) => (
              <div key={feature.title} className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                <div className="text-indigo-600">{feature.icon}</div>
                <div>
                  <div className="text-sm font-medium text-gray-900">{feature.title}</div>
                  <div className="text-xs text-gray-500">{feature.description}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <form onSubmit={handleAnalysisClick} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Analysis Settings</h2>
            </div>

            <div className="space-y-8">
              <ModelMultiSelect 
                selectedModels={selectedModels} 
                onChange={(models) => {
                  if (models.length === 0) {
                    // If attempting to deselect all models, keep at least one
                    setValue('modelIds', [selectedModels[0] || AI_MODELS[0].id]);
                  } else {
                    setValue('modelIds', models);
                  }
                  validateModels(models);
                }}
              />

              <LanguageSelector 
                value={selectedLanguage}
                onChange={(language) => setValue('language', language)}
              />

              <ActionSelect
                selectedAction={selectedAction}
                onChange={(action) => setValue('action', action)}
              />

              <ComplexitySelector
                value={watch('complexity')}
                onChange={(value) => setValue('complexity', value)}
              />

              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-4">
                  <FileCode className="w-5 h-5 text-indigo-600" />
                  <h3 className="text-sm font-medium text-gray-900">Analysis Parameters</h3>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Temperature ({watch('temperature')})
                    </label>
                    <input
                      type="range"
                      {...register('temperature', { valueAsNumber: true })}
                      min="0"
                      max="1"
                      step="0.1"
                      className="w-full mt-2"
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      Controls creativity in the analysis
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Top P ({watch('topP')})
                    </label>
                    <input
                      type="range"
                      {...register('topP', { valueAsNumber: true })}
                      min="0"
                      max="1"
                      step="0.1"
                      className="w-full mt-2"
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      Controls diversity in the analysis
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Top K ({watch('topK')})
                    </label>
                    <input
                      type="range"
                      {...register('topK', { valueAsNumber: true })}
                      min="1"
                      max="100"
                      className="w-full mt-2"
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      Limits token consideration during analysis
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* File Upload Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Upload className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Source Code</h2>
            </div>

            <div className="space-y-6">
              <FileAttachment onFileSelect={handleFileSelect} />

              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium text-gray-700">Code Editor</h3>
                <TokenCounter code={sourceCode} maxTokens={maxTokens} />
              </div>

              <CodeEditor
                value={sourceCode}
                onChange={setSourceCode}
                language={selectedLanguage}
              />

              {!sourceCode.trim() && (
                <div className="flex items-center gap-2 text-sm text-amber-600">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Please enter or upload source code to analyze</span>
                </div>
              )}
            </div>
          </div>

          {/* Analysis Results Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <CheckCircle2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Analysis Results</h2>
            </div>

            {isAnalyzing && (
              <CodeAnalysisProgress progress={analysisProgress} />
            )}

            <AnalysisOutput
              results={analysisResults}
              isAnalyzing={isAnalyzing}
              progress={progress}
            />

            <MultiModelOutput 
              results={analysisProgress} 
              maxTokens={maxTokens}
              language={selectedLanguage}
              analysisType={selectedAction} // Add this prop
            />
          </div>

          {/* Analyze Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isAnalyzing || !sourceCode.trim() || Boolean(validationError)}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : isAnalysisStarted ? (
                <>
                  <Search className="w-5 h-5 mr-2" />
                  Start Analysis
                </>
              ) : (
                <>
                  <Search className="w-5 h-5 mr-2" />
                  Validate Settings
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}