import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Layers,
  Server,
  Database,
  Globe,
  Settings2,
  Loader2,
  AlertTriangle,
  Cloud,
  GitBranch,
  Lock
} from 'lucide-react';
import { ModelSelector } from '../components/ModelSelector';
import { TokenCounter } from '../components/TokenCounter';

const deploymentSchema = z.object({
  projectName: z.string().min(3, 'Project name must be at least 3 characters'),
  frontend: z.object({
    framework: z.enum(['react', 'vue', 'angular', 'next', 'nuxt']),
    buildCommand: z.string().min(1, 'Build command is required'),
    outputDir: z.string().min(1, 'Output directory is required'),
  }),
  backend: z.object({
    runtime: z.enum(['node', 'python', 'go', 'java']),
    framework: z.string().min(1, 'Backend framework is required'),
    port: z.number().min(1).max(65535),
  }),
  database: z.object({
    type: z.enum(['postgresql', 'mysql', 'mongodb']),
    version: z.string().min(1, 'Database version is required'),
  }),
  environment: z.array(z.object({
    key: z.string().min(1, 'Key is required'),
    value: z.string(),
    isSecret: z.boolean(),
  })),
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
});

type DeploymentForm = z.infer<typeof deploymentSchema>;

const FRAMEWORKS = {
  frontend: [
    { id: 'react', name: 'React', buildCommand: 'npm run build', outputDir: 'dist' },
    { id: 'vue', name: 'Vue.js', buildCommand: 'npm run build', outputDir: 'dist' },
    { id: 'angular', name: 'Angular', buildCommand: 'ng build', outputDir: 'dist' },
    { id: 'next', name: 'Next.js', buildCommand: 'next build', outputDir: '.next' },
    { id: 'nuxt', name: 'Nuxt.js', buildCommand: 'nuxt build', outputDir: '.nuxt' },
  ],
  backend: [
    { runtime: 'node', frameworks: ['Express', 'NestJS', 'Fastify'] },
    { runtime: 'python', frameworks: ['FastAPI', 'Django', 'Flask'] },
    { runtime: 'go', frameworks: ['Gin', 'Echo', 'Fiber'] },
    { runtime: 'java', frameworks: ['Spring Boot', 'Quarkus', 'Micronaut'] },
  ],
};

export function FullStackCategoryPage() {
  const [isDeploying, setIsDeploying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [deploymentUrl, setDeploymentUrl] = useState<string | null>(null);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<DeploymentForm>({
    resolver: zodResolver(deploymentSchema),
    defaultValues: {
      frontend: {
        framework: 'react',
        buildCommand: 'npm run build',
        outputDir: 'dist',
      },
      backend: {
        runtime: 'node',
        framework: 'Express',
        port: 3000,
      },
      database: {
        type: 'postgresql',
        version: '14',
      },
      environment: [],
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedModels = watch('modelIds');
  const selectedRuntime = watch('backend.runtime');

  const handleAddEnvironmentVariable = () => {
    const environment = watch('environment');
    setValue('environment', [
      ...environment,
      { key: '', value: '', isSecret: false },
    ]);
  };

  const handleRemoveEnvironmentVariable = (index: number) => {
    const environment = watch('environment');
    setValue('environment', environment.filter((_, i) => i !== index));
  };

  const onSubmit = async (data: DeploymentForm) => {
    setIsDeploying(true);
    setProgress(0);
    
    try {
      // Simulate deployment progress
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(interval);
            return 90;
          }
          return prev + 10;
        });
      }, 1000);

      // TODO: Implement actual deployment
      await new Promise(resolve => setTimeout(resolve, 5000));
      
      setDeploymentUrl('https://example.com');
      setProgress(100);
    } catch (error) {
      console.error('Deployment failed:', error);
    } finally {
      setIsDeploying(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Layers className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Fullstack Deployment</h1>
              <p className="mt-1 text-sm text-gray-500">
                Deploy your complete application stack with automated configuration
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Cloud className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Frontend</div>
                <div className="text-xs text-gray-500">Static hosting</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Server className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Backend</div>
                <div className="text-xs text-gray-500">API services</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Database className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Database</div>
                <div className="text-xs text-gray-500">Managed DB</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Lock className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Security</div>
                <div className="text-xs text-gray-500">SSL & Auth</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Project Configuration */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Project Configuration</h2>
            </div>

            <div className="space-y-6">
              <ModelSelector 
                selectedModels={selectedModels} 
                onChange={(models) => setValue('modelIds', models)} 
              />

              <div>
                <label className="block text-sm font-medium text-gray-700">Project Name</label>
                <input
                  type="text"
                  {...register('projectName')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
                {errors.projectName && (
                  <p className="mt-1 text-sm text-red-600">{errors.projectName.message}</p>
                )}
              </div>

              {/* Frontend Configuration */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Frontend</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Framework</label>
                    <select
                      {...register('frontend.framework')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      {FRAMEWORKS.frontend.map(framework => (
                        <option key={framework.id} value={framework.id}>
                          {framework.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Build Command</label>
                    <input
                      type="text"
                      {...register('frontend.buildCommand')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Output Directory</label>
                    <input
                      type="text"
                      {...register('frontend.outputDir')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              </div>

              {/* Backend Configuration */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Backend</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Runtime</label>
                    <select
                      {...register('backend.runtime')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      {FRAMEWORKS.backend.map(runtime => (
                        <option key={runtime.runtime} value={runtime.runtime}>
                          {runtime.runtime.toUpperCase()}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Framework</label>
                    <select
                      {...register('backend.framework')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      {FRAMEWORKS.backend
                        .find(r => r.runtime === selectedRuntime)
                        ?.frameworks.map(framework => (
                          <option key={framework} value={framework}>
                            {framework}
                          </option>
                        ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Port</label>
                    <input
                      type="number"
                      {...register('backend.port', { valueAsNumber: true })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              </div>

              {/* Database Configuration */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Database</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Type</label>
                    <select
                      {...register('database.type')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      <option value="postgresql">PostgreSQL</option>
                      <option value="mysql">MySQL</option>
                      <option value="mongodb">MongoDB</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Version</label>
                    <input
                      type="text"
                      {...register('database.version')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              </div>

              {/* Environment Variables */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium text-gray-900">Environment Variables</h3>
                  <button
                    type="button"
                    onClick={handleAddEnvironmentVariable}
                    className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-indigo-600 bg-indigo-100 hover:bg-indigo-200"
                  >
                    Add Variable
                  </button>
                </div>
                <div className="space-y-2">
                  {watch('environment').map((_, index) => (
                    <div key={index} className="flex gap-4">
                      <input
                        {...register(`environment.${index}.key`)}
                        placeholder="KEY"
                        className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      />
                      <input
                        {...register(`environment.${index}.value`)}
                        placeholder="Value"
                        className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      />
                      <label className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          {...register(`environment.${index}.isSecret`)}
                          className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <span className="text-sm text-gray-600">Secret</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => handleRemoveEnvironmentVariable(index)}
                        className="p-2 text-gray-400 hover:text-red-500"
                      >
                        <AlertTriangle className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Deploy Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isDeploying}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isDeploying ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Deploying...
                </>
              ) : (
                <>
                  <Cloud className="w-5 h-5 mr-2" />
                  Deploy Stack
                </>
              )}
            </button>
          </div>
        </form>

        {/* Deployment Progress */}
        {isDeploying && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="space-y-4">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Deployment Progress</span>
                <span>{progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>
        )}

        {/* Deployment Result */}
        {deploymentUrl && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              <div>
                <h3 className="text-lg font-medium text-gray-900">Deployment Successful</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Your application is now live at{' '}
                  <a
                    href={deploymentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-indigo-600 hover:text-indigo-500"
                  >
                    {deploymentUrl}
                  </a>
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}