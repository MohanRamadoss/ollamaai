import React from 'react';
import { Link } from 'react-router-dom';
import { 
  FileText,
  Wand2,
  ArrowLeftRight,
  Search,
  Shield,
  Cloud,
  GitBranch,
  Database,
  Bot,
  Sparkles,
  FileCode,
  Layers,
  Blocks,
  Box,
  Network,
  BarChart2,
  CheckCircle2,
  Code2
} from 'lucide-react';

const documentationSections = [
  {
    id: 'code-generation',
    name: 'Code Generation',
    description: 'Learn how to generate production-ready code using AI',
    icon: <Wand2 className="w-6 h-6" />,
    path: '/docs/code-generation',
    topics: [
      'Understanding AI code generation',
      'Language and framework support',
      'Generation parameters',
      'Best practices and optimization',
      'Error handling and validation'
    ]
  },
  {
    id: 'code-conversion',
    name: 'Code Conversion',
    description: 'Convert code between different programming languages',
    icon: <ArrowLeftRight className="w-6 h-6" />,
    path: '/docs/code-conversion',
    topics: [
      'Language conversion process',
      'Syntax mapping',
      'Type conversion',
      'Framework equivalents',
      'Handling language-specific features'
    ]
  },
  {
    id: 'code-analysis',
    name: 'Code Analysis',
    description: 'Analyze and improve code quality',
    icon: <Search className="w-6 h-6" />,
    path: '/docs/code-analysis',
    topics: [
      'Static code analysis',
      'Performance optimization',
      'Security scanning',
      'Best practices validation',
      'Code metrics and insights'
    ]
  },
  {
    id: 'cloud-infrastructure',
    name: 'Cloud Infrastructure',
    description: 'Generate and manage cloud infrastructure code',
    icon: <Cloud className="w-6 h-6" />,
    path: '/docs/cloud-infrastructure',
    topics: [
      'Multi-cloud support',
      'Infrastructure as Code',
      'Resource management',
      'Security best practices',
      'Cost optimization'
    ]
  },
  {
    id: 'cicd',
    name: 'CI/CD Pipelines',
    description: 'Set up continuous integration and deployment',
    icon: <GitBranch className="w-6 h-6" />,
    path: '/docs/cicd',
    topics: [
      'Pipeline configuration',
      'Build automation',
      'Testing strategies',
      'Deployment workflows',
      'Monitoring and alerts'
    ]
  },
  {
    id: 'sql',
    name: 'SQL Generation',
    description: 'Generate optimized SQL queries',
    icon: <Database className="w-6 h-6" />,
    path: '/docs/sql',
    topics: [
      'Query optimization',
      'Database design',
      'Performance tuning',
      'Security considerations',
      'Best practices'
    ]
  },
  {
    id: 'agent',
    name: 'AI Agent',
    description: 'Work with the AI programming agent',
    icon: <Bot className="w-6 h-6" />,
    path: '/docs/agent',
    topics: [
      'Agent capabilities',
      'Code generation modes',
      'Model selection',
      'Interaction patterns',
      'Advanced features'
    ]
  },
  {
    id: 'addons',
    name: 'Addons',
    description: 'Extended features and integrations',
    icon: <Layers className="w-6 h-6" />,
    path: '/docs/addons',
    topics: [
      'Fullstack deployment',
      'Blockchain integration',
      'Docker workflows',
      'API management',
      'Security features'
    ]
  }
];

export function DocumentationPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <FileText className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Documentation</h1>
              <p className="mt-1 text-sm text-gray-500">
                Comprehensive guides and documentation for all features and services
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <FileCode className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Detailed Guides</div>
                <div className="text-xs text-gray-500">Step-by-step tutorials</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Best Practices</div>
                <div className="text-xs text-gray-500">Recommended patterns</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Code2 className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Code Examples</div>
                <div className="text-xs text-gray-500">Real-world usage</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Bot className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">AI Features</div>
                <div className="text-xs text-gray-500">AI capabilities</div>
              </div>
            </div>
          </div>
        </div>

        {/* Documentation Sections */}
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {documentationSections.map((section) => (
            <Link
              key={section.id}
              to={section.path}
              className="relative group bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0 text-indigo-600">
                  {section.icon}
                </div>
                <h3 className="text-lg font-medium text-gray-900">{section.name}</h3>
              </div>
              <p className="mt-2 text-gray-500">{section.description}</p>
              <ul className="mt-4 space-y-2">
                {section.topics.map((topic, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-sm text-gray-600">{topic}</span>
                  </li>
                ))}
              </ul>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}