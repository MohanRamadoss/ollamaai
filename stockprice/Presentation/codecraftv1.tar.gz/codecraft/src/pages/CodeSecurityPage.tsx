import React, { useState, useEffect, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ModelSelector } from '../components/Security/ModelSelector';
import { LanguageSelector } from '../components/LanguageSelector';
import { FileAttachment } from '../components/Security/FileAttachment';
import { SecurityOutput } from '../components/Security/SecurityOutput';
import { MultiModelOutput } from '../components/Security/MultiModelOutput';
import { SecurityProgress } from '../components/Security/SecurityProgress';
import { CodeEditor } from '../components/CodeEditor';
import { TokenCounter } from '../components/TokenCounter';
import { 
  Shield,
  AlertTriangle,
  Loader2,
  CheckCircle2,
  Lock,
  FileCode,
  Bug,
  Search,
  Key,
  ShieldAlert,
  FileWarning,
  Network
} from 'lucide-react';
import { scanSecurity, SecurityScanProgress } from '../lib/api/security';
import { ErrorBoundary } from '../components/ErrorBoundary';
import { SECURITY_MODEL_CONFIGS } from '../config/securityModels';
import { SecurityIssue, AnalysisProgress } from '../types/security';
import { CodeExamples } from '../components/Security/CodeExamples';
import { getExamplesForLanguage } from '../lib/security/examples';
import type { CodeExample } from '../types/security';
import { SECURITY_CATEGORIES } from '../config/securityCategories';
import { SECURITY_TEST_EXAMPLES, SECURITY_TEST_CASES } from '../lib/security/examples';

const SCAN_TYPES = [
  { id: 'quick', name: 'Quick Scan', description: 'Basic security checks', duration: '~1 min' },
  { id: 'full', name: 'Full Scan', description: 'Comprehensive analysis', duration: '~5 mins' },
  { id: 'deep', name: 'Deep Scan', description: 'In-depth security audit', duration: '~15 mins' },
];

const securitySchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  language: z.string().min(1, 'Select a programming language'),
  scanType: z.enum(['full', 'quick', 'deep']),
  features: z.record(z.boolean()),
});

type SecurityForm = z.infer<typeof securitySchema>;

const SECURITY_CATEGORY_ITEMS = [
  { id: SECURITY_CATEGORIES.INJECTION, name: 'Injection', icon: <Bug className="w-5 h-5" />, description: 'SQL, XSS, Command injection' },
  { id: SECURITY_CATEGORIES.BROKEN_ACCESS_CONTROL, name: 'Access Control', icon: <Shield className="w-5 h-5" />, description: 'Authorization issues' },
  { id: SECURITY_CATEGORIES.CRYPTOGRAPHIC_FAILURES, name: 'Crypto Failures', icon: <Key className="w-5 h-5" />, description: 'Encryption issues' },
  // ... add more categories as needed
];

export function CodeSecurityPageWrapper() {
  return (
    <ErrorBoundary>
      <CodeSecurityPage />
    </ErrorBoundary>
  );
}

const defaultModel = Object.keys(SECURITY_MODEL_CONFIGS)[0];

export function CodeSecurityPage() {
  const [sourceCode, setSourceCode] = useState('');
  const [securityIssues, setSecurityIssues] = useState<SecurityIssue[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [analysisProgress, setAnalysisProgress] = useState<Record<string, AnalysisProgress>>({});
  const [isAnalysisStarted, setIsAnalysisStarted] = useState(false);
  const [examples, setExamples] = useState<CodeExample[]>([]);
  const [availableModels, setAvailableModels] = useState<string[]>([]);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<SecurityForm>({
    resolver: zodResolver(securitySchema),
    defaultValues: {
      scanType: 'full',
      features: Object.values(SECURITY_CATEGORIES).reduce((acc, category) => ({
        ...acc,
        [category]: true
      }), {}),
      modelIds: ['gemini-pro', 'gemini-1.5-pro-001', 'gemini-2.0-flash'],
    },
  });

  const selectedModels = watch('modelIds');
  const selectedLanguage = watch('language');
  const selectedFeatures = watch('features');
  const scanType = watch('scanType');

  useEffect(() => {
    console.log('Selected Models:', selectedModels);
    console.log('Selected Language:', selectedLanguage);
  }, [selectedLanguage, selectedModels]);

  useEffect(() => {
    async function loadExamples() {
      if (selectedLanguage) {
        try {
          const loadedExamples = await getExamplesForLanguage(selectedLanguage);
          setExamples(loadedExamples);
        } catch (error) {
          console.error('Failed to load examples:', error);
          setExamples([]);
        }
      }
    }
    loadExamples();
  }, [selectedLanguage]);

  useEffect(() => {
    async function checkAvailableModels() {
      try {
        const models = await getAvailableModels();
        setAvailableModels(models);
        
        // Update selected models to only include available ones
        const validModels = watch('modelIds').filter(id => models.includes(id));
        if (validModels.length !== watch('modelIds').length) {
          setValue('modelIds', validModels);
        }
      } catch (error) {
        console.error('Failed to fetch available models:', error);
      }
    }
    
    checkAvailableModels();
  }, []);

  const handleFileSelect = useCallback((content: string) => {
    setSourceCode(content);
    setSecurityIssues([]);
    setError(null);
  }, []);

  const handleCodeChange = useCallback((newCode: string) => {
    setSourceCode(newCode);
  }, []);

  const handleSecurityScanClick = handleSubmit(async (data) => {
    if (!sourceCode.trim()) {
      setError('Please provide source code to analyze');
      return;
    }

    if (data.modelIds.length === 0) {
      setError('Please select at least one available model');
      return;
    }

    if (!isAnalysisStarted) {
      setIsAnalysisStarted(true);
      return;
    }

    setIsScanning(true);
    setError(null);

    const initialProgress = data.modelIds.reduce((acc, modelId) => ({
      ...acc,
      [modelId]: { 
        modelId, 
        status: 'pending',
        progress: 0
      }
    }), {});

    setAnalysisProgress(prev => ({
      ...prev,
      ...initialProgress
    }));

    scanSecurity({
      sourceCode,
      language: data.language,
      modelIds: data.modelIds,
      scanType: data.scanType,
      features: data.features,
      onProgress: (progress) => {
        setAnalysisProgress(prev => ({
          ...prev,
          ...progress
        }));
      }
    })
    .then((results) => {
      const allIssues = Object.values(results).flatMap(result => 
        result.issues || []
      );
      setSecurityIssues(allIssues);
    })
    .catch((error) => {
      console.error('Security analysis failed:', error);
      setError(error instanceof Error ? error.message : 'Security analysis failed');
    })
    .finally(() => {
      setIsScanning(false);
    });
  });

  const onSubmit = async (data: SecurityForm) => {
    setIsScanning(true);
    setError(null);
    setSecurityIssues([]);

    try {
      const initialProgress = data.modelIds.reduce((acc, modelId) => ({
        ...acc,
        [modelId]: { 
          modelId, 
          status: 'pending',
          progress: 0
        }
      }), {});
      setAnalysisProgress(initialProgress);

      const results = await scanSecurity({
        sourceCode,
        language: data.language,
        modelIds: data.modelIds,
        scanType: data.scanType,
        features: data.features,
        onProgress: (progress) => {
          setAnalysisProgress(prev => ({
            ...prev,
            ...progress
          }));
        }
      });

      const allIssues = Object.values(results).flatMap(result => 
        result.issues || []
      );
      setSecurityIssues(allIssues);
    } catch (error) {
      console.error('Security analysis failed:', error);
      setError(error instanceof Error ? error.message : 'Security analysis failed');
    } finally {
      setIsScanning(false);
    }
  };

  const handleReset = () => {
    setIsAnalysisStarted(false);
    setIsScanning(false);
    setError(null);
    setSecurityIssues([]);
    setAnalysisProgress({});
  };

  const getSeverityColor = (type: SecurityIssue['type']) => {
    switch (type) {
      case 'critical': return 'text-red-600 bg-red-50 border-red-200';
      case 'high': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const handleExampleSelect = useCallback((code: string) => {
    setSourceCode(''); // Clear first to force refresh
    requestAnimationFrame(() => {
      setSourceCode(code);
      setSecurityIssues([]);
      setError(null);
      setIsAnalysisStarted(false);
    });
  }, []);

  function TestExampleSelector({ onSelect, language }: { onSelect: (code: string) => void, language: string }) {
    return (
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-700">Security Test Examples</h3>
        <div className="grid grid-cols-1 gap-4">
          {Object.entries(SECURITY_TEST_EXAMPLES).map(([category, examples]) => (
            <div key={category} className="border rounded-lg p-4">
              <h4 className="font-medium mb-2">{category.replace(/_/g, ' ')}</h4>
              {examples[language] ? (
                <button
                  onClick={() => onSelect(examples[language])}
                  className="text-indigo-600 hover:text-indigo-800 text-sm"
                >
                  Load Example
                </button>
              ) : (
                <p className="text-sm text-gray-500">No example for {language}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }

  const renderModelOption = (modelId: string) => {
    const isAvailable = availableModels.includes(modelId);
    const config = SECURITY_MODEL_CONFIGS[modelId];
    const isExcluded = modelId === 'gemini-1.5-pro-001';
    
    return (
      <label key={modelId} className={`relative flex items-start p-4 cursor-pointer rounded-lg border 
        ${isAvailable && !isExcluded ? 'hover:border-indigo-300' : 'opacity-50 cursor-not-allowed'}
        ${isExcluded ? 'opacity-50 cursor-not-allowed border-red-500' : ''}`}>
        <input
          type="checkbox"
          checked={selectedModels.includes(modelId)}
          onChange={(e) => {
            if (isAvailable && !isExcluded) {
              const newModels = e.target.checked
                ? [...selectedModels, modelId]
                : selectedModels.filter(id => id !== modelId);
              setValue('modelIds', newModels);
            }
          }}
          disabled={!isAvailable || isExcluded}
          className="mt-1 h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
        />
        <div className="ml-3">
          <span className="block text-sm font-medium text-gray-900">
            {config.name}
            {!isAvailable && ' (Not Available)'}
            {isExcluded && ' (Excluded)'}
          </span>
          <span className="block text-sm text-gray-500">{config.description}</span>
          {isExcluded && (
            <span className="block text-sm text-red-500">
              Excluded due to safety filter issues.
            </span>
          )}
        </div>
      </label>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Shield className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Code Security Analysis</h1>
              <p className="mt-1 text-sm text-gray-500">
                Scan your code for security vulnerabilities, compliance issues, and best practices
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-5 gap-4">
            {SECURITY_CATEGORY_ITEMS.map(category => (
              <div key={category.id} className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                <div className="text-indigo-600">{category.icon}</div>
                <div>
                  <div className="text-sm font-medium text-gray-900">{category.name}</div>
                  <div className="text-xs text-gray-500">{category.description}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Form Section */}
          <div className="lg:col-span-3">
            <form className="space-y-8">
              {/* Configuration Section */}
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center gap-3 mb-6">
                  <Lock className="w-5 h-5 text-indigo-600" />
                  <h2 className="text-lg font-medium text-gray-900">Security Settings</h2>
                </div>

                <div className="space-y-8">
                  <ModelSelector 
                    selectedModels={selectedModels} 
                    onChange={(models) => setValue('modelIds', models)} 
                  />

                  <LanguageSelector 
                    value={selectedLanguage}
                    onChange={(language) => setValue('language', language)}
                  />

                  {/* Scan Type Selection */}
                  <div className="space-y-4">
                    <h3 className="text-sm font-medium text-gray-700">Scan Type</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {SCAN_TYPES.map((type) => (
                        <label
                          key={type.id}
                          className={`relative flex flex-col p-4 cursor-pointer rounded-lg border transition-colors ${
                            scanType === type.id
                              ? 'border-indigo-500 bg-indigo-50'
                              : 'border-gray-200 hover:border-indigo-300'
                          }`}
                        >
                          <input
                            type="radio"
                            {...register('scanType')}
                            value={type.id}
                            className="sr-only"
                          />
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-gray-900">{type.name}</span>
                            <span className="text-xs text-gray-500">{type.duration}</span>
                          </div>
                          <p className="mt-1 text-sm text-gray-500">{type.description}</p>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Security Features */}
                  <div className="space-y-4">
                    <h3 className="text-sm font-medium text-gray-700">Security Features</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {SECURITY_CATEGORY_ITEMS.map(category => (
                        <label
                          key={category.id}
                          className="flex items-start gap-3 p-4 border rounded-lg hover:bg-gray-50"
                        >
                          <input
                            type="checkbox"
                            {...register(`features.${category.id}`)}
                            className="mt-1 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                          />
                          <div>
                            <div className="font-medium text-gray-900">{category.name}</div>
                            <div className="text-sm text-gray-500">{category.description}</div>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Code Input Section */}
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center gap-3 mb-6">
                  <FileCode className="w-5 h-5 text-indigo-600" />
                  <h2 className="text-lg font-medium text-gray-900">Source Code</h2>
                </div>

                <div className="space-y-6">
                  <FileAttachment onFileSelect={handleFileSelect} />

                  <div className="flex justify-between items-center">
                    <h3 className="text-sm font-medium text-gray-700">Code Editor</h3>
                    <TokenCounter code={sourceCode} maxTokens={8192} />
                  </div>

                  <CodeEditor
                    value={sourceCode}
                    onChange={handleCodeChange}
                    language={selectedLanguage}
                    height="500px"
                    showLineNumbers={true}
                    theme="vscode"
                    fontSize={14}
                    lineHeight={1.6}
                    key={sourceCode} // Add key to force re-render when code changes
                  />

                  {error && (
                    <div className="flex items-center gap-2 text-sm text-red-600">
                      <AlertTriangle className="w-4 h-4" />
                      <span>{error}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Scan Button */}
              <div className="flex justify-end gap-4">
                {isAnalysisStarted && (
                  <button
                    type="button"
                    onClick={handleReset}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    Reset
                  </button>
                )}
                <button
                  type="button"
                  disabled={isScanning || !sourceCode.trim()}
                  onClick={handleSecurityScanClick}
                  className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isScanning ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Scanning...
                    </>
                  ) : isAnalysisStarted ? (
                    <>
                      <Search className="w-5 h-5 mr-2" />
                      Start Security Scan
                    </>
                  ) : (
                    <>
                      <Shield className="w-5 h-5 mr-2" />
                      Validate Settings
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Examples Panel - Fixed position */}
          <div className="lg:col-span-1 sticky top-8">
            <div className="space-y-4">
              {selectedLanguage && (
                <TestExampleSelector
                  language={selectedLanguage}
                  onSelect={handleExampleSelect}
                />
              )}
              {selectedLanguage && (
                <CodeExamples
                  examples={examples}
                  onSelect={handleExampleSelect}
                />
              )}
            </div>
          </div>
        </div>

        {/* Results Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-3 mb-6">
            <FileWarning className="w-5 h-5 text-indigo-600" />
            <h2 className="text-lg font-medium text-gray-900">Security Analysis Results</h2>
          </div>

          {isScanning && (
            <SecurityProgress progress={analysisProgress} />
          )}

          {/* Original Security Issues Display */}
          <div className="space-y-4 mb-6">
            {securityIssues.map((issue, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg border ${getSeverityColor(issue.type)}`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium">{issue.title}</h3>
                      {issue.cvss && (
                        <span className="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">
                          CVSS: {issue.cvss}
                        </span>
                      )}
                      {issue.cwe && (
                        <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                          {issue.cwe}
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-sm">{issue.description}</p>
                    {issue.line && (
                      <p className="mt-1 text-sm">
                        <span className="font-medium">Location:</span> Line {issue.line}
                      </p>
                    )}
                    {issue.recommendation && (
                      <div className="mt-2 p-2 bg-white rounded border border-gray-200">
                        <span className="font-medium">Recommendation:</span>{' '}
                        {issue.recommendation}
                      </div>
                    )}
                  </div>
                  <span className="px-2 py-1 text-xs font-medium rounded-full capitalize">
                    {issue.type}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* New Multi-model Output */}
          <MultiModelOutput 
            results={analysisProgress}
            maxTokens={8192}
            language={selectedLanguage}
            scanType={scanType}
          />
        </div>
      </div>
    </div>
  );
}
