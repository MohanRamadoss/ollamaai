import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  ArrowLeftRight, 
  Code2, 
  FileCode, 
  Loader2, 
  Settings2, 
  CheckCircle2, 
  Upload,
  AlertTriangle,
  Download,
  Sparkles,
  Brain,
  Zap
} from 'lucide-react';

import { ModelSelect } from '../components/CodeConversion/ModelSelect';
import { ConversionProgress as ConversionProgressComponent } from '../components/CodeConversion/ConversionProgress';
import { LanguageConverter } from '../components/CodeConversion/LanguageConverter';
import { ConversionParameters } from '../components/CodeConversion/ConversionParameters';
import { FileAttachment } from '../components/CodeConversion/FileAttachment';
import { CodeDisplay } from '../components/CodeConversion/CodeDisplay';
import { TokenCounter } from '../components/CodeConversion/TokenCounter';
import { CodeEditor } from '../components/CodeConversion/CodeEditor';
import type { ComplexityLevel } from '../types/models';
import { convertCode, ConversionProgress as ConversionProgressType, ExtendedGenerationRequest } from '../lib/api/convert';
import { ErrorBoundary } from '../components/ErrorBoundary';
import { logger } from '../utils/logger';
import { MODEL_CONFIGS } from '../config/models';

const convertSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  sourceLanguage: z.string().min(1, 'Select a source language'),
  targetLanguage: z.string().min(1, 'Select a target language'),
  complexity: z.enum(['basic', 'intermediate', 'advanced']),
  temperature: z.number().min(0).max(1),
  topP: z.number().min(0).max(1),
  topK: z.number().min(1).max(100),
  maxTokens: z.number().min(1).max(8192),
  modelParams: z.object({
    temperature: z.number().min(0).max(1).optional(),
    topP: z.number().min(0).max(1).optional(),
    topK: z.number().min(1).max(100).optional(),
    maxTokens: z.number().min(1).max(32768).optional(), // Increased for Gemini models
    safetySettings: z.array(z.object({
      category: z.string(),
      threshold: z.string()
    })).optional()
  }).optional()
});

type ConvertForm = z.infer<typeof convertSchema>;

function ConvertPageContent() {
  const [sourceCode, setSourceCode] = useState('');
  const [convertedCode, setConvertedCode] = useState('');
  const [isConverting, setIsConverting] = useState(false);
  const [modelOutputs, setModelOutputs] = useState<Array<{
    modelId: string;
    code: string;
    status: 'pending' | 'converting' | 'completed' | 'failed';
    error?: string;
  }>>([]);

  const [modelProgress, setModelProgress] = useState<Record<string, ConversionProgressType>>({});
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isConversionStarted, setIsConversionStarted] = useState(false);

  const { register, handleSubmit, watch, setValue, formState } = useForm<ConvertForm>({
    resolver: zodResolver(convertSchema),
    defaultValues: {
      temperature: 0.7,
      topP: 0.9,
      topK: 50,
      maxTokens: 2048,
      complexity: 'intermediate' as ComplexityLevel,
      sourceLanguage: 'javascript',
      targetLanguage: 'python',
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedModels = watch('modelIds');
  const sourceLanguage = watch('sourceLanguage');
  const targetLanguage = watch('targetLanguage');
  const maxTokens = watch('maxTokens');

  useEffect(() => {
    logger.info('ConvertPage mounted', {
      selectedModels,
      sourceLanguage,
      targetLanguage,
      maxTokens
    });
  }, []);

  const handleFileSelect = (content: string) => {
    setSourceCode(content);
  };

  useEffect(() => {
    const subscription = watch((value, { name }) => {
      logger.debug('Form value changed:', { name, value });
      setValidationError(null);
    });
    return () => subscription.unsubscribe();
  }, [watch]);

  const isGeminiModel = (modelId: string) => modelId.startsWith('gemini-');

  const onSubmit = async (data: ConvertForm) => {
    if (!isConversionStarted) {
      setIsConversionStarted(true);
      return;
    }

    logger.info('Starting code conversion', data);
    setValidationError(null);
    setModelProgress({});
    setConvertedCode('');

    if (!sourceCode.trim()) {
      setValidationError('Please enter or upload source code');
      return;
    }

    setIsConverting(true);

    const initialOutputs = data.modelIds.map(modelId => ({
      modelId,
      code: '',
      status: 'pending' as const
    }));
    setModelOutputs(initialOutputs);

    try {
      const request: ExtendedGenerationRequest = {
        ...data,
        prompt: sourceCode,
        modelIds: data.modelIds.map(id => {
          const config = MODEL_CONFIGS[id];
          if (config?.provider === 'google') {
            return config.modelName || id;
          }
          return id;
        }),
        modelParams: {
          temperature: data.temperature,
          topP: data.topP,
          topK: data.topK,
          maxTokens: data.maxTokens,
          ...(data.modelIds.some(isGeminiModel) && {
            safetySettings: [
              { category: 'HARM_CATEGORY_DANGEROUS', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
              { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
              { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
              { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_MEDIUM_AND_ABOVE' }
            ]
          })
        }
      };

      const result = await convertCode(request, (progress) => {
        const displayProgress = Object.entries(progress).reduce((acc, [modelId, modelProgress]) => {
          const config = MODEL_CONFIGS[modelId];
          const displayId = config?.provider === 'google' ? 
            Object.keys(MODEL_CONFIGS).find(key => MODEL_CONFIGS[key].modelName === modelId) || modelId : 
            modelId;
          
          acc[displayId] = modelProgress;
          return acc;
        }, {} as Record<string, ConversionProgressType>);

        setModelProgress(prev => ({...prev, ...displayProgress}));
        
        Object.entries(displayProgress).forEach(([modelId, modelProgress]) => {
          setModelOutputs(prev => prev.map(output => 
            output.modelId === modelId
              ? {
                  ...output,
                  code: modelProgress.result || output.code,
                  status: modelProgress.status,
                  error: modelProgress.error
                }
              : output
          ));
        });
      });

      setConvertedCode(result);

    } catch (error) {
      const errorMessage = error instanceof Error 
        ? error.message 
        : 'Failed to convert code';
      
      logger.error('Conversion failed:', error instanceof Error ? error : new Error(errorMessage));
      setValidationError(
        error instanceof Error && error.message.includes('Google API') 
          ? 'Google AI service error. Please check your API key configuration.'
          : errorMessage
      );

      setModelOutputs(prev => prev.map(output => 
        output.status === 'pending'
          ? { ...output, status: 'failed', error: errorMessage }
          : output
      ));
    } finally {
      setIsConverting(false);
    }
  };

  const handleConvertClick = handleSubmit((data) => {
    if (!isConversionStarted) {
      setIsConversionStarted(true);
      return;
    }
    return onSubmit(data);
  });

  useEffect(() => {
    setIsConversionStarted(false);
  }, [sourceLanguage, targetLanguage]);

  const languageExtensions: Record<string, string> = {
    'python': 'py',
    'javascript': 'js',
    'typescript': 'ts',
    'java': 'java',
    'cpp': 'cpp',
    'c++': 'cpp',
    'go': 'go',
    'ruby': 'rb',
    'php': 'php',
    'csharp': 'cs',
    'c#': 'cs',
    'rust': 'rs',
    'swift': 'swift',
    'kotlin': 'kt',
    'shell': 'sh',
    'powershell': 'ps1',
    'sql': 'sql',
    'yaml': 'yml',
    'json': 'json',
    'markdown': 'md',
    'terraform': 'tf',
    'ansible': 'yml',
    'dockerfile': 'Dockerfile'
  };

  const handleDownload = (code: string, modelId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    const extension = languageExtensions[targetLanguage.toLowerCase()] || 'txt';
    const filename = modelId.toLowerCase() === 'dockerfile' ? 'Dockerfile' : `${modelId}_output.${extension}`;
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <ArrowLeftRight className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Convert Code</h1>
              <p className="mt-1 text-sm text-gray-500">
                Transform code between different programming languages while maintaining functionality
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Code2 className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Smart Conversion</div>
                <div className="text-xs text-gray-500">Language-aware</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Best Practices</div>
                <div className="text-xs text-gray-500">Idiomatic code</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Brain className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Context Aware</div>
                <div className="text-xs text-gray-500">Maintains logic</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Zap className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Fast & Accurate</div>
                <div className="text-xs text-gray-500">Quick conversion</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleConvertClick} className="space-y-8">
          {validationError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center gap-2 text-red-600">
                <AlertTriangle className="w-4 h-4" />
                <span>{validationError}</span>
              </div>
            </div>
          )}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Conversion Settings</h2>
            </div>

            <div className="space-y-8">
              <ModelSelect 
                selectedModels={selectedModels} 
                onChange={(models) => setValue('modelIds', models)} 
              />

              <LanguageConverter
                sourceLanguage={sourceLanguage}
                targetLanguage={targetLanguage}
                onSourceChange={(language) => setValue('sourceLanguage', language)}
                onTargetChange={(language) => setValue('targetLanguage', language)}
              />

              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-4">
                  <FileCode className="w-5 h-5 text-indigo-600" />
                  <h3 className="text-sm font-medium text-gray-900">Conversion Parameters</h3>
                </div>

                <ConversionParameters register={register} watch={watch} />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Upload className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Source Code</h2>
            </div>

            <div className="space-y-6">
              <FileAttachment onFileSelect={handleFileSelect} />

              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium text-gray-700">Code Editor</h3>
                <TokenCounter code={sourceCode} maxTokens={maxTokens} />
              </div>

              <CodeEditor
                value={sourceCode}
                onChange={setSourceCode}
                language={sourceLanguage}
              />

              {!sourceCode.trim() && (
                <div className="flex items-center gap-2 text-sm text-amber-600">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Please enter or upload source code to convert</span>
                </div>
              )}
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <CheckCircle2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Converted Code</h2>
            </div>

            <ConversionProgressComponent 
              isConverting={isConverting} 
              modelProgress={modelProgress}
            />

            <div className="space-y-6">
              {modelOutputs.map((output) => (
                <div key={output.modelId} className="border rounded-lg">
                  <div className="bg-gray-50 px-4 py-2 border-b flex justify-between items-center">
                    <span className="font-medium">{output.modelId}</span>
                    {output.status === 'converting' && (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    )}
                  </div>
                  <div className="p-4">
                    {output.error ? (
                      <div className="text-red-500">{output.error}</div>
                    ) : (
                      <>
                        <CodeDisplay
                          code={output.code}
                          language={targetLanguage}
                          isGenerating={output.status === 'converting'}
                          error={output.error ? new Error(output.error) : null}
                          maxTokens={maxTokens}
                        />
                        {output.code && (
                          <button
                            type="button"
                            onClick={(event) => handleDownload(output.code, output.modelId, event)}
                            className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Download Code
                          </button>
                        )}
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {convertedCode && (
              <div className="mt-6 border-t pt-6">
                <h3 className="text-lg font-medium mb-4">Best Result</h3>
                <CodeDisplay
                  code={convertedCode}
                  language={targetLanguage}
                  isGenerating={false}
                  maxTokens={maxTokens}
                />
              </div>
            )}
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isConverting || !sourceCode.trim() || Boolean(validationError)}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isConverting ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Converting...
                </>
              ) : isConversionStarted ? (
                <>
                  <ArrowLeftRight className="w-5 h-5 mr-2" />
                  Start Conversion
                </>
              ) : (
                <>
                  <ArrowLeftRight className="w-5 h-5 mr-2" />
                  Validate Settings
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export function ConvertPage() {
  return (
    <ErrorBoundary>
      <ConvertPageContent />
    </ErrorBoundary>
  );
}