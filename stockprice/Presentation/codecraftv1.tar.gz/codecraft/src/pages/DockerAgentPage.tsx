import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Box,
  Settings2,
  Loader2,
  AlertTriangle,
  Terminal,
  Container,
  BarChart,
  Activity,
  Database,
  Play,
  RefreshCw
} from 'lucide-react';
import { ModelSelect } from '../components/dockeragent/ModelSelect';
import { FileAttachment } from '../components/dockeragent/FileAttachment';
import { DockerDisplay } from '../components/dockeragent/DockerDisplay';
import { executeDockerOperation, generateContainerConfig } from '../lib/api/dockeragent';
import { logger } from '../utils/logger/dockeragent';
import { ModelSelector } from '../components/dockeragent/ModelSelector';
import { CodeEditor } from '../components/dockeragent/CodeEditor';
import { TokenCounter } from '../components/dockeragent/TokenCounter';
import type { ComplexityLevel, DockerVersionInfo } from '../types/dockeragent';
import { DOCKER_MODELS, DOCKER_OPERATIONS } from '../config/dockerModels';
import { DOCKER_CONFIG, checkDockerConnection } from '../config/dockeragent';

const dockerAgentSchema = z.object({
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
  operation: z.enum(['LIST_CONTAINERS', 'CONTAINER_STATUS', 'VIEW_LOGS', 'DEPLOY_CONTAINER', 'CONTAINER_STATS']),
  containerName: z.string().optional(),
  imageName: z.string().optional(),
  dockerCompose: z.string().optional(),
  complexity: z.enum(['basic', 'intermediate', 'advanced']).default('basic'),
});

type DockerAgentForm = z.infer<typeof dockerAgentSchema>;

const OPERATIONS = [
  { value: 'LIST_CONTAINERS', label: 'List Containers' },
  { value: 'CONTAINER_STATUS', label: 'Container Status' },
  { value: 'VIEW_LOGS', label: 'View Logs' },
  { value: 'DEPLOY_CONTAINER', label: 'Deploy Container' },
  { value: 'CONTAINER_STATS', label: 'Container Stats' }
] as const;

const DockerVersionDetails = ({ versionInfo }: { versionInfo: DockerVersionInfo }) => (
  <div className="mt-2 space-y-1 text-sm text-gray-500">
    <div>Engine: {versionInfo.Platform?.Name || 'Docker Engine'} {versionInfo.Version}</div>
    <div>API Version: {versionInfo.ApiVersion} (Min: {versionInfo.MinAPIVersion})</div>
    <div className="grid grid-cols-2 gap-x-4 gap-y-1">
      <div>OS: {versionInfo.Os}</div>
      <div>Arch: {versionInfo.Arch}</div>
      {versionInfo.Components?.map(component => (
        <div key={component.Name} className="col-span-2">
          {component.Name}: {component.Version}
        </div>
      ))}
    </div>
  </div>
);

export function DockerAgentPage() {
  const [output, setOutput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dockerStatus, setDockerStatus] = useState<{
    isConnected: boolean;
    version?: string;
    error?: string;
    versionInfo?: DockerVersionInfo;
  }>({ isConnected: false });

  const [stats, setStats] = useState({
    runningContainers: 0,
    totalImages: 0,
    cpuUsage: '0%'
  });

  const [deploymentStep, setDeploymentStep] = useState<'generate' | 'deploy' | null>(null);
  const [generatedConfig, setGeneratedConfig] = useState<string | null>(null);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<DockerAgentForm>({
    resolver: zodResolver(dockerAgentSchema),
    defaultValues: {
      modelIds: [DOCKER_MODELS[0].id], // Assuming first model is default
      complexity: 'basic'
    },
  });

  const selectedModels = watch('modelIds');

  useEffect(() => {
    const checkConnection = async () => {
      console.log('Checking Docker connection...');
      const status = await checkDockerConnection();
      console.log('Docker connection status:', status);
      setDockerStatus(status);
      if (status.isConnected) {
        await fetchDockerStats();
      }
    };

    checkConnection();
    
    // Reduced polling frequency to avoid overwhelming the server
    const interval = setInterval(checkConnection, 60000); // Check every minute
    return () => clearInterval(interval);
  }, []);

  const fetchDockerStats = async () => {
    try {
      const response = await fetch(`${DOCKER_CONFIG.API_URL}/containers/json?all=true`);
      const containers = await response.json();
      
      const runningContainers = containers.filter((c: any) => c.State === 'running').length;
      const totalContainers = containers.length;

      const imagesResponse = await fetch(`${DOCKER_CONFIG.API_URL}/images/json`);
      const images = await imagesResponse.json();

      setStats({
        runningContainers,
        totalImages: images.length,
        cpuUsage: dockerStatus.versionInfo?.Platform?.Name ? 'Active' : 'N/A'
      });
    } catch (error) {
      console.error('Failed to fetch Docker stats:', error);
    }
  };

  const generateConfiguration = async (data: DockerAgentForm) => {
    setIsProcessing(true);
    setError(null);
    
    try {
      if (!dockerStatus.isConnected) {
        throw new Error('Docker daemon is not connected');
      }

      // Generate configs using all selected AI models
      const configPromises = selectedModels.map(modelId => 
        generateContainerConfig(data.containerName!, data.imageName!, modelId)
      );

      const configs = await Promise.all(configPromises);
      
      // Combine configurations or use the most detailed one
      const bestConfig = configs.reduce((best, current) => 
        current.length > best.length ? current : best
      );

      // Update the form with the generated configuration
      setValue('dockerCompose', bestConfig);
      setGeneratedConfig(bestConfig);

      // Show the generation result
      setOutput(JSON.stringify({
        status: 'Configuration Generated',
        containerInfo: {
          name: data.containerName,
          image: data.imageName
        },
        config: bestConfig,
        nextSteps: [
          "1. Review the generated configuration above",
          "2. Make any necessary modifications",
          "3. Click 'Deploy Container' to create and start the container"
        ]
      }, null, 2));

      setDeploymentStep('deploy');
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to generate configuration');
    } finally {
      setIsProcessing(false);
    }
  };

  const deployContainer = async (data: DockerAgentForm) => {
    setIsProcessing(true);
    setError(null);

    try {
      if (!data.dockerCompose) {
        throw new Error('Docker Compose configuration is required');
      }

      const response = await executeDockerOperation({
        ...data,
        complexity: data.complexity || 'basic',
        host: '192.168.1.24',
        port: 2375,
        modelIds: selectedModels
      }, (progress) => console.log(`Deployment progress: ${progress}%`));

      if (response.status === 'success') {
        setOutput(JSON.stringify({
          status: 'Deployment Completed',
          containerInfo: {
            name: data.containerName,
            image: data.imageName
          },
          deploymentSteps: [
            "Configuration applied",
            "Container created",
            "Service started",
            `Container accessible at http://192.168.1.24:${data.containerName}`
          ]
        }, null, 2));
        
        await fetchDockerStats();
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Deployment failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const onSubmit = async (data: DockerAgentForm) => {
    if (data.operation === 'DEPLOY_CONTAINER') {
      // Container name and image validation only for DEPLOY_CONTAINER
      if (!data.containerName || !data.imageName) {
        setError('Container name and image are required for deployment');
        return;
      }

      if (deploymentStep === 'generate' || !generatedConfig) {
        await generateConfiguration(data);
      } else {
        await deployContainer(data);
      }
    } else {
      // For other operations, execute directly
      setIsProcessing(true);
      setError(null);
      
      try {
        if (!dockerStatus.isConnected) {
          throw new Error('Docker daemon is not connected');
        }

        const response = await executeDockerOperation({
          ...data,
          complexity: data.complexity || 'basic',
          host: '192.168.1.24',
          port: 2375,
          modelIds: selectedModels
        }, (progress) => console.log(`Operation progress: ${progress}%`));

        setOutput(response.output);
        await fetchDockerStats();
      } catch (error) {
        setError(error instanceof Error ? error.message : 'Operation failed');
      } finally {
        setIsProcessing(false);
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Container className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Docker Agent</h1>
              <p className="mt-1 text-sm text-gray-500">
                AI-powered Docker container management and operations
              </p>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Box className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Running Containers</div>
                <div className="text-xl font-semibold text-indigo-600">{stats.runningContainers}</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Database className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Total Images</div>
                <div className="text-xl font-semibold text-indigo-600">{stats.totalImages}</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Activity className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">CPU Usage</div>
                <div className="text-xl font-semibold text-indigo-600">{stats.cpuUsage}</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Configuration</h2>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">AI Models</label>
                <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                  {DOCKER_MODELS.map((model) => (
                    <label
                      key={model.id}
                      className={`relative flex items-start p-4 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                        selectedModels.includes(model.id) ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200'
                      }`}
                    >
                      <div className="flex items-center h-5">
                        <input
                          type="checkbox"
                          checked={selectedModels.includes(model.id)}
                          onChange={(e) => {
                            const newModels = e.target.checked
                              ? [...selectedModels, model.id]
                              : selectedModels.filter(id => id !== model.id);
                            setValue('modelIds', newModels);
                          }}
                          className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                      </div>
                      <div className="ml-3">
                        <span className="block text-sm font-medium text-gray-900">{model.name}</span>
                        <span className="block text-xs text-gray-500">{model.description}</span>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Operation</label>
                <select
                  {...register('operation')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                  <option value="">Select Operation</option>
                  {Object.entries(DOCKER_OPERATIONS).map(([value, label]) => (
                    <option key={value} value={value}>
                      {label}
                    </option>
                  ))}
                </select>
                {errors.operation && (
                  <p className="mt-1 text-sm text-red-600">{errors.operation.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Container Name</label>
                <input
                  type="text"
                  {...register('containerName')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
                {errors.containerName && (
                  <p className="mt-1 text-sm text-red-600">{errors.containerName.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Image Name</label>
                <input
                  type="text"
                  {...register('imageName')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
                {errors.imageName && (
                  <p className="mt-1 text-sm text-red-600">{errors.imageName.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Docker Compose Configuration</label>
                <CodeEditor
                  value={watch('dockerCompose') || ''}
                  onChange={(value) => setValue('dockerCompose', value)}
                  language="yaml"
                  placeholder="Paste your docker-compose.yml here..."
                />
              </div>
            </div>
          </div>

          {/* Docker Connection Status */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-start gap-3">
              <div className={`h-2.5 w-2.5 rounded-full mt-1 ${
                dockerStatus.isConnected ? 'bg-green-500' : 'bg-red-500'
              }`} />
              <div className="flex-1">
                <span className="text-sm text-gray-600">
                  {dockerStatus.isConnected
                    ? `Connected to ${DOCKER_CONFIG.API_URL}`
                    : `Failed to connect to Docker daemon: ${dockerStatus.error}`
                  }
                </span>
                {dockerStatus.isConnected && dockerStatus.versionInfo && (
                  <DockerVersionDetails versionInfo={dockerStatus.versionInfo} />
                )}
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-4">
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Reset
            </button>

            {watch('operation') === 'DEPLOY_CONTAINER' && (
              <>
                <button
                  type="button"
                  disabled={isProcessing || deploymentStep === 'deploy'}
                  onClick={() => {
                    setDeploymentStep('generate');
                    handleSubmit(generateConfiguration)();
                  }}
                  className="px-4 py-2 text-sm font-medium text-indigo-600 bg-white border border-indigo-300 rounded-md hover:bg-indigo-50"
                >
                  Generate Configuration
                </button>

                <button
                  type="submit"
                  disabled={isProcessing || !generatedConfig}
                  className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      {deploymentStep === 'generate' ? 'Generating...' : 'Deploying...'}
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 mr-2" />
                      {deploymentStep === 'deploy' ? 'Deploy Container' : 'Execute Operation'}
                    </>
                  )}
                </button>
              </>
            )}

            {watch('operation') !== 'DEPLOY_CONTAINER' && (
              <button
                type="submit"
                disabled={isProcessing}
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 mr-2" />
                    Execute Operation
                  </>
                )}
              </button>
            )}
          </div>
        </form>

        {/* Output Console */}
        {(output || error) && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-4">
              <Terminal className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Console Output</h2>
            </div>
            <div className="bg-gray-900 rounded-lg p-4">
              <pre className="text-gray-100 font-mono text-sm whitespace-pre-wrap">
                {error ? error : output}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
