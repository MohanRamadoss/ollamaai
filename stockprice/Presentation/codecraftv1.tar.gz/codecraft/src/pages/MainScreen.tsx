import React from 'react';
import { Link } from 'react-router-dom';
import {
  Code2,
  GitBranch,
  Database,
  Cloud,
  Bot,
  RefreshCw,
  Search,
  Zap,
  CheckCircle2,
  ArrowRight,
  Braces,
  FileCode,
  GitPullRequest,
  Server,
  Workflow,
  TestTube2,
  Layers,
  Blocks
} from 'lucide-react';

const features = [
  {
    title: 'Code Generation',
    path: '/generate',
    icon: <Code2 className="w-6 h-6" />,
    description: 'Generate production-ready code using AI',
    features: [
      'Multiple programming languages support',
      'Customizable complexity levels',
      'Best practices implementation',
      'Error handling and validation',
      'Documentation generation'
    ]
  },
  {
    title: 'Code Conversion',
    path: '/convert',
    icon: <RefreshCw className="w-6 h-6" />,
    description: 'Convert code between different languages',
    features: [
      'Accurate syntax conversion',
      'Language-specific optimizations',
      'Maintain code structure',
      'Preserve comments and documentation',
      'Handle dependencies'
    ]
  },
  {
    title: 'Code Analysis',
    path: '/analyze',
    icon: <Search className="w-6 h-6" />,
    description: 'Analyze and improve code quality',
    features: [
      'Performance optimization',
      'Security vulnerability detection',
      'Code smell identification',
      'Best practices validation',
      'Complexity analysis'
    ]
  },
  {
    title: 'Cloud Infrastructure',
    path: '/cloud',
    icon: <Cloud className="w-6 h-6" />,
    description: 'Generate cloud infrastructure code',
    features: [
      'Multi-cloud support (AWS, Azure, GCP)',
      'Infrastructure as Code (IaC)',
      'Security best practices',
      'Cost optimization',
      'Scalability patterns'
    ]
  },
  {
    title: 'CI/CD Pipelines',
    path: '/cicd',
    icon: <GitBranch className="w-6 h-6" />,
    description: 'Create automated CI/CD pipelines',
    features: [
      'Multiple platform support',
      'Build automation',
      'Test integration',
      'Deployment strategies',
      'Monitoring setup'
    ]
  },
  {
    title: 'SQL Generation',
    path: '/sql',
    icon: <Database className="w-6 h-6" />,
    description: 'Generate optimized SQL queries',
    features: [
      'Multiple SQL dialects',
      'Query optimization',
      'Index recommendations',
      'Performance tuning',
      'Schema validation'
    ]
  },
  {
    title: 'AI Agent',
    path: '/agent',
    icon: <Bot className="w-6 h-6" />,
    description: 'Multi-model AI code generation',
    features: [
      'Language auto-detection',
      'Multiple AI models',
      'Parallel generation',
      'Result comparison',
      'Fallback handling'
    ]
  },
  {
    title: 'Addons',
    path: '/addons',
    icon: <Layers className="w-6 h-6" />,
    description: 'Extended deployment features',
    features: [
      'Fullstack deployment',
      'Blockchain integration',
      'Advanced configurations',
      'Environment management',
      'Monitoring setup'
    ]
  }
];

const languages = [
  { name: 'JavaScript', icon: '📜', features: ['ES6+', 'Node.js', 'React'] },
  { name: 'TypeScript', icon: '💪', features: ['Type Safety', 'ES6+', 'Decorators'] },
  { name: 'Python', icon: '🐍', features: ['Type Hints', 'Async/Await', 'Django'] },
  { name: 'Java', icon: '☕', features: ['Spring', 'JVM', 'Enterprise'] },
  { name: 'Go', icon: '🐹', features: ['Concurrency', 'Performance', 'Simplicity'] },
  { name: 'Rust', icon: '🦀', features: ['Memory Safety', 'Performance', 'Zero Cost'] },
  { name: 'C#', icon: '🎯', features: ['.NET', 'LINQ', 'Cross-platform'] },
  { name: 'Ruby', icon: '💎', features: ['Rails', 'Gems', 'Metaprogramming'] }
];

export function MainScreen() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl md:text-6xl">
              AI-Powered LLM Orchestrator
            </h1>
            <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
            The tool has potential to orchestrate simple work flow  Generate, convert, analyze, and optimize code  across multiple languages using advanced AI models.
            </p>
            <div className="mt-5 max-w-md mx-auto sm:flex sm:justify-center md:mt-8">
              <Link
                to="/generate"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
              >
                Get Started
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Features</h2>
          <p className="mt-4 text-lg text-gray-500">
            Comprehensive suite of AI-powered development tools
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <Link
              key={feature.title}
              to={feature.path}
              className="relative group bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0 text-indigo-600">
                  {feature.icon}
                </div>
                <h3 className="text-lg font-medium text-gray-900">{feature.title}</h3>
              </div>
              <p className="mt-2 text-gray-500">{feature.description}</p>
              <ul className="mt-4 space-y-2">
                {feature.features.map((item, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-sm text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </Link>
          ))}
        </div>
      </div>

      {/* Languages Section */}
      <div className="bg-gray-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white">Supported Languages</h2>
            <p className="mt-4 text-lg text-gray-300">
              Generate and analyze code in multiple programming languages
            </p>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:grid-cols-4">
            {languages.map((language) => (
              <div key={language.name} className="bg-gray-800 p-6 rounded-lg">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{language.icon}</span>
                  <h3 className="text-lg font-medium text-white">{language.name}</h3>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  {language.features.map((feature, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Workflow Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Development Workflow</h2>
          <p className="mt-4 text-lg text-gray-500">
            Streamline your development process with our integrated tools
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="text-center">
            <div className="flex justify-center">
              <FileCode className="w-12 h-12 text-indigo-600" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">Generate Code</h3>
            <p className="mt-2 text-sm text-gray-500">
              Create production-ready code using AI models
            </p>
          </div>
          <div className="text-center">
            <div className="flex justify-center">
              <GitPullRequest className="w-12 h-12 text-indigo-600" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">Version Control</h3>
            <p className="mt-2 text-sm text-gray-500">
              Integrate with CI/CD pipelines
            </p>
          </div>
          <div className="text-center">
            <div className="flex justify-center">
              <Server className="w-12 h-12 text-indigo-600" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">Deploy</h3>
            <p className="mt-2 text-sm text-gray-500">
              Deploy to cloud platforms
            </p>
          </div>
          <div className="text-center">
            <div className="flex justify-center">
              <TestTube2 className="w-12 h-12 text-indigo-600" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">Test & Monitor</h3>
            <p className="mt-2 text-sm text-gray-500">
              Ensure quality and performance
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}