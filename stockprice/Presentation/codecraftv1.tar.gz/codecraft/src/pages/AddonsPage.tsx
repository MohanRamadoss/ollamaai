import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Layers, 
  Blocks, 
  Server, 
  Database, 
  Cloud,
  GitBranch,
  Lock,
  Globe,
  Bot,
  Box,
  Network,
  Code2,
  Brain,
  Container
} from 'lucide-react';

const categories = [
  {
    id: 'fullstack',
    name: 'Fullstack Deployment',
    description: 'Deploy complete applications with frontend, backend, and database',
    icon: <Layers className="w-6 h-6" />,
    path: '/addons/fullstack',
    features: [
      'Frontend deployment',
      'Backend services',
      'Database setup',
      'Environment configuration'
    ]
  },
  {
    id: 'blockchain',
    name: 'Blockchain Technology',
    description: 'Build and deploy blockchain applications',
    icon: <Blocks className="w-6 h-6" />,
    path: '/addons/blockchain',
    features: [
      'Smart contracts',
      'Web3 integration',
      'DApp deployment',
      'Chain configuration'
    ]
  },
  {
    id: 'assistant',
    name: 'AI Assistant',
    description: 'Intelligent code assistance with Aider and Cline',
    icon: <Bot className="w-6 h-6" />,
    path: '/addons/assistant',
    features: [
      'Git integration',
      'CLI assistance',
      'Code review',
      'Smart suggestions'
    ]
  },
  {
    id: 'docker',
    name: 'Docker Integration',
    description: 'Test and deploy with Docker and GitHub',
    icon: <Box className="w-6 h-6" />,
    path: '/addons/docker',
    features: [
      'Automated testing',
      'Docker containerization',
      'GitHub integration',
      'Auto promotion'
    ]
  },
  {
    id: 'api',
    name: 'API Management',
    description: 'Design and manage APIs with comprehensive tools',
    icon: <Network className="w-6 h-6" />,
    path: '/addons/api',
    features: [
      'API documentation',
      'Security & auth',
      'Gateway integration',
      'Monitoring & analytics'
    ]
  },
  {
    id: 'sql',
    name: 'SQL Query Generator',
    description: 'Generate optimized SQL queries with advanced features',
    icon: <Database className="w-6 h-6" />,
    path: '/addons/sql-generator',
    features: [
      'Query optimization',
      'Performance analysis',
      'Security features',
      'Data insights'
    ]
  },
  {
    id: 'models',
    name: 'AI Models',
    description: 'Explore available AI models for code generation',
    icon: <Brain className="w-6 h-6" />,
    path: '/addons/models',
    features: [
      'Gemini models',
      'Ollama integration',
      'Model comparison',
      'Performance metrics'
    ]
  },
  {
    id: 'version-control',
    name: 'Version Control',
    description: 'Integrated version control and collaboration',
    icon: <GitBranch className="w-6 h-6" />,
    path: '/addons/version-control',
    features: [
      'Git integration',
      'Branch management',
      'Code review',
      'Commit history'
    ]
  },
  {
    id: 'programming-agent',
    name: 'Programming Agent',
    description: 'AI-powered code analysis and generation agent',
    icon: <Bot className="w-6 h-6" />,
    path: '/addons/programming-agent',
    features: [
      'Code analysis',
      'Code generation',
      'Code execution',
      'Code debugging'
    ]
  },
  {
    id: 'docker-agent',
    name: 'Docker Agent',
    description: 'AI-powered Docker container management and operations',
    icon: <Container className="w-6 h-6" />,
    path: '/addons/docker-agent',
    features: [
      'Container management',
      'Status monitoring',
      'Log analysis',
      'Performance metrics'
    ]
  }
];

export function AddonsPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Layers className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Addons</h1>
              <p className="mt-1 text-sm text-gray-500">
                Extend your development workflow with powerful addons
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Box className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Containerization</div>
                <div className="text-xs text-gray-500">Docker & Kubernetes</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <GitBranch className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Version Control</div>
                <div className="text-xs text-gray-500">Git integration</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Lock className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Security</div>
                <div className="text-xs text-gray-500">Best practices</div>
              </div>
            </div>
          </div>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => (
            <Link
              key={category.id}
              to={category.path}
              className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:border-indigo-300 transition-colors"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="text-indigo-600">{category.icon}</div>
                <div>
                  <h2 className="text-lg font-medium text-gray-900">{category.name}</h2>
                  <p className="text-sm text-gray-500">{category.description}</p>
                </div>
              </div>
              <ul className="space-y-2">
                {category.features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-2 text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full" />
                    {feature}
                  </li>
                ))}
              </ul>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}