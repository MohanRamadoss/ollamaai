import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Bot,
  Settings2,
  Loader2,
  AlertTriangle,
  Code2,
  FileCode,
  Terminal,
  GitBranch,
  CheckCircle2,
  MessageSquare,
  Sparkles,
  Zap,
  Brain
} from 'lucide-react';
import { ModelSelector } from '../components/ModelSelector';
import { CodeEditor } from '../components/CodeEditor';
import { TokenCounter } from '../components/TokenCounter';
import { AIAssistant } from '../lib/ai/assistant';

const assistantSchema = z.object({
  mode: z.enum(['aider', 'cline', 'hybrid']),
  language: z.string().min(1, 'Language is required'),
  action: z.enum(['review', 'suggest', 'explain']),
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
});

type AssistantForm = z.infer<typeof assistantSchema>;

const MODES = [
  { 
    id: 'aider', 
    name: 'Aider Mode', 
    description: 'Git-integrated AI pair programming',
    features: ['Git integration', 'Code edits', 'Commit suggestions']
  },
  { 
    id: 'cline', 
    name: 'Cline Mode', 
    description: 'Command-line AI assistance',
    features: ['Shell commands', 'Script generation', 'System tasks']
  },
  { 
    id: 'hybrid', 
    name: 'Hybrid Mode', 
    description: 'Combined Aider & Cline capabilities',
    features: ['Full integration', 'Cross-mode synergy', 'Enhanced assistance']
  }
];

const ACTIONS = [
  { 
    id: 'review', 
    name: 'Code Review', 
    icon: <Code2 className="w-5 h-5" />,
    description: 'Review code for quality and issues'
  },
  { 
    id: 'suggest', 
    name: 'Suggest Changes', 
    icon: <GitBranch className="w-5 h-5" />,
    description: 'Get improvement suggestions'
  },
  { 
    id: 'explain', 
    name: 'Explain Code', 
    icon: <MessageSquare className="w-5 h-5" />,
    description: 'Get detailed code explanations'
  }
];

export function AssistantCategoryPage() {
  const [sourceCode, setSourceCode] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const assistant = new AIAssistant();

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<AssistantForm>({
    resolver: zodResolver(assistantSchema),
    defaultValues: {
      mode: 'hybrid',
      language: 'javascript',
      action: 'review',
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedMode = watch('mode');
  const selectedAction = watch('action');
  const selectedModels = watch('modelIds');

  const onSubmit = async (data: AssistantForm) => {
    if (!sourceCode.trim()) {
      setError('Please enter some code to process');
      return;
    }

    setIsProcessing(true);
    setProgress(0);
    setError(null);
    setResult(null);
    
    try {
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      let response;
      switch (data.action) {
        case 'review':
          response = await assistant.reviewCode(sourceCode, data.language);
          break;
        case 'suggest':
          response = await assistant.suggestChanges(sourceCode, data.language);
          break;
        case 'explain':
          response = await assistant.explainCode(sourceCode, data.language);
          break;
      }

      setResult(response);
      setProgress(100);
    } catch (error) {
      console.error('Processing failed:', error);
      setError('Failed to process code. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Bot className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">AI Assistant</h1>
              <p className="mt-1 text-sm text-gray-500">
                Intelligent code assistance with Aider and Cline integration
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Terminal className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">CLI Integration</div>
                <div className="text-xs text-gray-500">Command-line AI</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <GitBranch className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Git Workflow</div>
                <div className="text-xs text-gray-500">Version control</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Smart Suggestions</div>
                <div className="text-xs text-gray-500">AI-powered help</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Brain className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Context Aware</div>
                <div className="text-xs text-gray-500">Intelligent assistance</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Configuration Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Assistant Configuration</h2>
            </div>

            <div className="space-y-6">
              <ModelSelector 
                selectedModels={selectedModels} 
                onChange={(models) => setValue('modelIds', models)} 
              />

              {/* Mode Selection */}
              <div className="space-y-4">
                <label className="block text-sm font-medium text-gray-700">Assistant Mode</label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {MODES.map((mode) => (
                    <label
                      key={mode.id}
                      className={`relative flex flex-col p-4 cursor-pointer rounded-lg border transition-colors ${
                        selectedMode === mode.id
                          ? 'border-indigo-500 bg-indigo-50'
                          : 'border-gray-200 hover:border-indigo-300'
                      }`}
                    >
                      <input
                        type="radio"
                        {...register('mode')}
                        value={mode.id}
                        className="sr-only"
                      />
                      <div className="flex items-center mb-2">
                        <span className="text-sm font-medium">{mode.name}</span>
                      </div>
                      <p className="text-sm text-gray-500">{mode.description}</p>
                      <div className="mt-2">
                        <ul className="text-xs text-gray-500 space-y-1">
                          {mode.features.map((feature, index) => (
                            <li key={index} className="flex items-center gap-1">
                              <div className="w-1 h-1 bg-gray-400 rounded-full" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Action Selection */}
              <div className="space-y-4">
                <label className="block text-sm font-medium text-gray-700">Action</label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {ACTIONS.map((action) => (
                    <label
                      key={action.id}
                      className={`relative flex items-center p-4 cursor-pointer rounded-lg border transition-colors ${
                        selectedAction === action.id
                          ? 'border-indigo-500 bg-indigo-50'
                          : 'border-gray-200 hover:border-indigo-300'
                      }`}
                    >
                      <input
                        type="radio"
                        {...register('action')}
                        value={action.id}
                        className="sr-only"
                      />
                      <div className="flex items-center gap-3">
                        <div className={selectedAction === action.id ? 'text-indigo-500' : 'text-gray-400'}>
                          {action.icon}
                        </div>
                        <div>
                          <div className="font-medium">{action.name}</div>
                          <div className="text-sm text-gray-500">{action.description}</div>
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Code Input */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-medium text-gray-700">Source Code</label>
                  <TokenCounter code={sourceCode} maxTokens={2048} />
                </div>
                <CodeEditor
                  value={sourceCode}
                  onChange={setSourceCode}
                  language={watch('language')}
                />
                {error && (
                  <p className="flex items-center gap-2 text-sm text-red-600">
                    <AlertTriangle className="w-4 h-4" />
                    {error}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Process Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isProcessing || !sourceCode.trim()}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5 mr-2" />
                  Process Code
                </>
              )}
            </button>
          </div>
        </form>

        {/* Results Section */}
        {result && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="space-y-6">
              {selectedAction === 'review' && (
                <>
                  {/* Code Quality */}
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium text-gray-900">Code Quality</h3>
                    <ul className="space-y-2">
                      {result.quality.map((item: string, index: number) => (
                        <li key={index} className="flex items-start gap-2 text-sm text-gray-600">
                          <div className="w-1.5 h-1.5 mt-1.5 bg-indigo-400 rounded-full flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Security Concerns */}
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium text-gray-900">Security Concerns</h3>
                    <ul className="space-y-2">
                      {result.security.map((item: string, index: number) => (
                        <li key={index} className="flex items-start gap-2 text-sm text-gray-600">
                          <div className="w-1.5 h-1.5 mt-1.5 bg-red-400 rounded-full flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Performance Optimizations */}
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium text-gray-900">Performance Optimizations</h3>
                    <ul className="space-y-2">
                      {result.performance.map((item: string, index: number) => (
                        <li key={index} className="flex items-start gap-2 text-sm text-gray-600">
                          <div className="w-1.5 h-1.5 mt-1.5 bg-green-400 rounded-full flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </>
              )}

              {selectedAction === 'suggest' && (
                <>
                  {/* Code Changes */}
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium text-gray-900">Suggested Changes</h3>
                    <ul className="space-y-2">
                      {result.changes.map((item: string, index: number) => (
                        <li key={index} className="flex items-start gap-2 text-sm text-gray-600">
                          <div className="w-1.5 h-1.5 mt-1.5 bg-indigo-400 rounded-full flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Modern Features */}
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium text-gray-900">Modern Language Features</h3>
                    <ul className="space-y-2">
                      {result.modernFeatures.map((item: string, index: number) => (
                        <li key={index} className="flex items-start gap-2 text-sm text-gray-600">
                          <div className="w-1.5 h-1.5 mt-1.5 bg-green-400 rounded-full flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </>
              )}

              {selectedAction === 'explain' && (
                <>
                  {/* Purpose */}
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium text-gray-900">Purpose</h3>
                    <div className="text-sm text-gray-600">
                      {result.purpose.join('\n')}
                    </div>
                  </div>

                  {/* Components */}
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium text-gray-900">Key Components</h3>
                    <ul className="space-y-2">
                      {result.components.map((item: string, index: number) => (
                        <li key={index} className="flex items-start gap-2 text-sm text-gray-600">
                          <div className="w-1.5 h-1.5 mt-1.5 bg-indigo-400 rounded-full flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Limitations */}
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium text-gray-900">Edge Cases & Limitations</h3>
                    <ul className="space-y-2">
                      {result.limitations.map((item: string, index: number) => (
                        <li key={index} className="flex items-start gap-2 text-sm text-gray-600">
                          <div className="w-1.5 h-1.5 mt-1.5 bg-yellow-400 rounded-full flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}