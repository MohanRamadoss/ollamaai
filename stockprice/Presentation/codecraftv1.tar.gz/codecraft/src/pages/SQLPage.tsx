import React, { useState, useEffect } from 'react';
import { AlertCircle, Loader2, Database, Code2, CheckCircle2 } from 'lucide-react';
import { SQLDialectSelector } from '../components/SQL/SQLDialectSelector';
import { SQLSchemaInput } from '../components/SQL/SQLSchemaInput';
import { SQLOutput } from '../components/SQL/SQLOutput';
import { SQLExamples } from '../components/SQL/SQLExamples';
import { SQLFileUpload } from '../components/SQL/SQLFileUpload';
import { Switch } from '../components/ui/switch';
import { ErrorBoundary } from '../components/ErrorBoundary';
import { generateSQL, SQLProgress } from '../lib/api/sql';
import { SQL_MODEL_CONFIGS } from '../config/sqlModels';
import { getExamplesForDialect } from '../lib/sql/examples';
import { TokenCounter } from '../components/SQL/TokenCounter';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';

export function SQLPageWrapper() {
  return (
    <ErrorBoundary>
      <SQLPage />
    </ErrorBoundary>
  );
}

export function SQLPage() {
  const [description, setDescription] = useState('');
  const [schema, setSchema] = useState('');
  const [sqlFile, setSqlFile] = useState('');
  const [dialect, setDialect] = useState<SQLDialect>('postgresql');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<SQLGenerationResult | null>(null);
  const [optimizations, setOptimizations] = useState<OptimizationFeatures>({
    indexDesign: false,
    queryTuning: false,
    partitioning: false,
    replication: false,
  });
  const [progress, setProgress] = useState<SQLProgress>({});
  const [examples, setExamples] = useState<SQLExample[]>([]);
  const [selectedModel, setSelectedModel] = useState<string>(Object.keys(SQL_MODEL_CONFIGS)[0]);

  useEffect(() => {
    async function loadExamples() {
      if (dialect) {
        try {
          console.log('Loading examples for dialect:', dialect);
          const loadedExamples = await getExamplesForDialect(dialect);
          console.log('Loaded examples:', loadedExamples);
          setExamples(loadedExamples || []);
        } catch (error) {
          console.error('Failed to load examples:', error);
          setExamples([]);
        }
      }
    }
    loadExamples();
  }, [dialect]);

  const handleGenerate = async () => {
    if (!description.trim() && !sqlFile.trim()) {
      setError('Please provide a description or upload a SQL file.');
      return;
    }
    
    setLoading(true);
    setError(null);
    setResult(null);
    
    try {
      const results = await generateSQL({
        description,
        tableSchema: schema,
        dialect,
        optimizationFeatures: optimizations,
        modelId: selectedModel, // Add selected model
        onProgress: (progress) => {
          setProgress(progress);
        }
      });

      setResult(results);
    } catch (err) {
      console.error('Generation error:', err);
      setError(err instanceof Error ? err.message : 'Failed to generate SQL query');
    } finally {
      setLoading(false);
    }
  };

  const handleExampleSelect = (example: SQLExample) => {
    console.log('Selected example:', example);
    setDescription(example.description);
    if (example.schema) {
      setSchema(example.schema);
    }
  };

  const handleFileSelect = (content: string) => {
    setSqlFile(content);
    // Try to extract schema from the SQL file
    const schemaMatch = content.match(/CREATE TABLE[^;]+;/gi);
    if (schemaMatch) {
      setSchema(schemaMatch.join('\n\n'));
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Database className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">SQL Generation</h1>
              <p className="mt-1 text-sm text-gray-500">
                Generate optimized SQL queries using AI models
              </p>
            </div>
          </div>
        </div>
        {/* Error Display */}
        {error && (
          <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Input Section */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-lg shadow-sm p-6 space-y-6">
              <SQLDialectSelector 
                selected={dialect} 
                onChange={setDialect} 
              />

              {/* Model Selection */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Select Model</label>
                <select
                  value={selectedModel}
                  onChange={(e) => setSelectedModel(e.target.value)}
                  className="w-full rounded-md border border-gray-300 bg-white py-2 pl-3 pr-10 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  {Object.entries(SQL_MODEL_CONFIGS).map(([modelId, config]) => (
                    <option key={modelId} value={modelId}>
                      {config.name} ({config.description.split('.')[0]})
                    </option>
                  ))}
                </select>
              </div>

              <SQLFileUpload onFileSelect={handleFileSelect} />
              
              <SQLSchemaInput 
                value={schema}
                onChange={setSchema}
              />

              {/* Description Input */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Describe the SQL query you need
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Example: Find all customers who made purchases over $1000 in the last month"
                  className="w-full h-32 px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                />
              </div>

              {/* Optimization Controls */}
              <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700">Optimization Features</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <label className="text-sm text-gray-600">Index Design</label>
                    <Switch
                      checked={optimizations.indexDesign}
                      onCheckedChange={(checked) =>
                        setOptimizations(prev => ({ ...prev, indexDesign: checked }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm text-gray-600">Query Tuning</label>
                    <Switch
                      checked={optimizations.queryTuning}
                      onCheckedChange={(checked) =>
                        setOptimizations(prev => ({ ...prev, queryTuning: checked }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm text-gray-600">Partitioning</label>
                    <Switch
                      checked={optimizations.partitioning}
                      onCheckedChange={(checked) =>
                        setOptimizations(prev => ({ ...prev, partitioning: checked }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm text-gray-600">Replication</label>
                    <Switch
                      checked={optimizations.replication}
                      onCheckedChange={(checked) =>
                        setOptimizations(prev => ({ ...prev, replication: checked }))
                      }
                    />
                  </div>
                </div>
              </div>

              {/* Generate Button */}
              <button
                onClick={handleGenerate}
                disabled={loading || (!description.trim() && !sqlFile.trim())}
                className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Code2 className="w-5 h-5" />
                    Generate SQL Query
                  </>
                )}
              </button>
            </div>

            {/* Results Section */}
            {Object.entries(progress).length > 0 && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-medium mb-4">Generation Progress</h3>
                {Object.entries(progress).map(([modelId, status]) => (
                  <div key={modelId} className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">
                        {SQL_MODEL_CONFIGS[modelId]?.name || modelId}
                      </span>
                      <span className="text-sm text-gray-500">
                        {status.progress}%
                      </span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full">
                      <div
                        className="h-full bg-indigo-600 rounded-full transition-all duration-500"
                        style={{ width: `${status.progress}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Results Display */}
            {result && Object.entries(result).map(([modelId, modelResult]) => (
              <div key={modelId} className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <h3 className="text-lg font-medium">
                      {SQL_MODEL_CONFIGS[modelId]?.name || modelId} Result
                    </h3>
                  </div>
                  <TokenCounter query={modelResult.query} />
                </div>
                <SQLOutput 
                  query={modelResult.query}
                  dialect={dialect}
                  explanation={modelResult.explanation}
                  optimizations={modelResult.optimizations}
                />
              </div>
            ))}
          </div>

          {/* Examples Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <SQLExamples 
                examples={examples}
                currentDialect={dialect}
                onSelectExample={handleExampleSelect}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}