import React, { useState, useEffect } from 'react';
import { Brain, Sparkles, Cpu, AlertCircle, Gauge, Zap, Cloud, Lock } from 'lucide-react';

interface GeminiModel {
  name: string;
  description: string;
  maxTokens: number;
  features: string[];
}

interface OllamaModel {
  name: string;
  size: number;
  details?: {
    family?: string;
    format?: string;
    parameter_size?: string;
    quantization_level?: string;
  };
}

const GEMINI_MODELS: GeminiModel[] = [
  {
    name: 'Gemini Pro',
    description: 'Advanced language model for general-purpose tasks',
    maxTokens: 32768,
    features: [
      'Text Generation',
      'Code Generation',
      'Analysis',
      'Reasoning'
    ]
  },
  {
    name: 'Gemini Pro Vision',
    description: 'Multimodal model for text and image understanding',
    maxTokens: 16384,
    features: [
      'Image Understanding',
      'Visual Analysis',
      'Multimodal Tasks',
      'OCR'
    ]
  },
  {
    name: 'Gemini Ultra',
    description: 'Most capable model for highly complex tasks',
    maxTokens: 65536,
    features: [
      'Complex Reasoning',
      'Advanced Code Generation',
      'Research Analysis',
      'Expert Systems'
    ]
  }
];

function ModelDisplayPage() {
  const [ollamaModels, setOllamaModels] = useState<OllamaModel[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchOllamaModels = async () => {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout

        const response = await fetch(`${import.meta.env.VITE_OLLAMA_API_URL}/api/tags`, {
          signal: controller.signal,
          headers: {
            'Accept': 'application/json'
          }
        });
        
        clearTimeout(timeoutId);

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        if (!data.models || data.models.length === 0) {
          setError(`Unable to connect to Ollama. This could be due to:

1. Ollama Service Status:
   - Ensure Ollama is installed and running
   - Check if the service is running with 'ollama serve'
   - Verify the service status with 'ps aux | grep ollama'

2. Network Configuration:
   - Confirm Ollama is listening on http://localhost:11434
   - Check firewall settings are not blocking the connection
   - Verify no other service is using port 11434

3. CORS Configuration:
   - Add the following headers to your Ollama service:
     Access-Control-Allow-Origin: *
     Access-Control-Allow-Methods: GET, OPTIONS
     Access-Control-Allow-Headers: Content-Type

4. Browser Security:
   - Check browser console for specific CORS errors
   - Try disabling browser security features temporarily for testing
   - Consider using browser extensions like CORS Unblock for development

To resolve:
1. Install Ollama: curl https://ollama.ai/install.sh | sh
2. Start the service: ollama serve
3. Pull a model: ollama pull llama2
4. Test the API: curl http://localhost:11434/api/tags`);
          return;
        }
        setOllamaModels(data.models);
      } catch (err) {
        console.error('Error fetching Ollama models:', err);
        setError(`Unable to connect to Ollama. This could be due to:

1. Ollama Service Status:
   - Ensure Ollama is installed and running
   - Check if the service is running with 'ollama serve'
   - Verify the service status with 'ps aux | grep ollama'

2. Network Configuration:
   - Confirm Ollama is listening on http://localhost:11434
   - Check firewall settings are not blocking the connection
   - Verify no other service is using port 11434

3. CORS Configuration:
   - Add the following headers to your Ollama service:
     Access-Control-Allow-Origin: *
     Access-Control-Allow-Methods: GET, OPTIONS
     Access-Control-Allow-Headers: Content-Type

4. Browser Security:
   - Check browser console for specific CORS errors
   - Try disabling browser security features temporarily for testing
   - Consider using browser extensions like CORS Unblock for development

To resolve:
1. Install Ollama: curl https://ollama.ai/install.sh | sh
2. Start the service: ollama serve
3. Pull a model: ollama pull llama2
4. Test the API: curl http://localhost:11434/api/tags`);
      } finally {
        setLoading(false);
      }
    };

    fetchOllamaModels();
  }, []);

  const formatModelSize = (bytes: number) => {
    const sizes = ['B', 'KB', 'MB', 'GB'];
    let i = 0;
    while (bytes >= 1024 && i < sizes.length - 1) {
      bytes /= 1024;
      i++;
    }
    return `${bytes.toFixed(2)} ${sizes[i]}`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Brain className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">AI Models</h1>
              <p className="mt-1 text-sm text-gray-500">
                Available AI models for code generation and analysis
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Gauge className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Performance</div>
                <div className="text-xs text-gray-500">High throughput</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Zap className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Fast</div>
                <div className="text-xs text-gray-500">Quick responses</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Cloud className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Cloud & Local</div>
                <div className="text-xs text-gray-500">Flexible deployment</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Lock className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Secure</div>
                <div className="text-xs text-gray-500">Privacy focused</div>
              </div>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-start gap-2 text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium">Error Loading Ollama Models</h3>
                <pre className="mt-2 text-sm whitespace-pre-wrap bg-red-50 p-4 rounded-lg border border-red-100">
                  {error}
                </pre>
                <div className="mt-4">
                  <h4 className="font-medium text-gray-900">Quick Setup Guide:</h4>
                  <ol className="list-decimal ml-4 mt-2 space-y-2 text-sm text-gray-600">
                    <li>Install Ollama from <a href="https://ollama.ai" target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:text-indigo-500">ollama.ai</a></li>
                    <li>Start the Ollama service with <code className="bg-gray-100 px-2 py-1 rounded">ollama serve</code></li>
                    <li>Pull your first model with <code className="bg-gray-100 px-2 py-1 rounded">ollama pull llama2</code></li>
                    <li>Verify the API is accessible at <code className="bg-gray-100 px-2 py-1 rounded">http://localhost:11434</code></li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Gemini Models */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Gemini Models</h2>
            </div>
            <div className="space-y-4">
              {GEMINI_MODELS.map((model) => (
                <div key={model.name} className="p-4 border rounded-lg hover:border-indigo-300 transition-colors">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium text-gray-900">{model.name}</h4>
                      <p className="text-sm text-gray-500 mt-1">{model.description}</p>
                    </div>
                    <span className="text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-1 rounded-full">
                      {model.maxTokens.toLocaleString()} tokens
                    </span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {model.features.map((feature, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Ollama Models */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Cpu className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Ollama Models</h2>
            </div>
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
              </div>
            ) : !error && ollamaModels.length === 0 ? (
              <div className="text-center py-8 text-gray-500">No Ollama models found</div>
            ) : !error && (
              <div className="space-y-4">
                {ollamaModels.map((model) => (
                  <div key={model.name} className="p-4 border rounded-lg hover:border-indigo-300 transition-colors">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium text-gray-900">{model.name}</h4>
                        <p className="text-sm text-gray-500 mt-1">
                          {model.details?.family || 'Local Model'}
                        </p>
                      </div>
                      <span className="text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-1 rounded-full">
                        {formatModelSize(model.size)}
                      </span>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {model.details?.format && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                          {model.details.format}
                        </span>
                      )}
                      {model.details?.parameter_size && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          {model.details.parameter_size}
                        </span>
                      )}
                      {model.details?.quantization_level && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                          {model.details.quantization_level}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export { ModelDisplayPage };