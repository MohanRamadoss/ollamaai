import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  GitBranch,
  Loader2,
  AlertTriangle,
  Settings2,
  GitCommit,
  GitMerge,
  GitPullRequest,
  History,
  CheckCircle2,
  FileCode,
  Code2,
  RefreshCw,
  Diff,
  GitFork,
  Search,
  Plus,
  Trash2,
  Shield
} from 'lucide-react';
import { CodeEditor } from '../components/CodeEditor';
import { TokenCounter } from '../components/TokenCounter';

const versionControlSchema = z.object({
  repository: z.string().min(1, 'Repository URL is required'),
  branch: z.string().min(1, 'Branch name is required'),
  message: z.string().min(1, 'Commit message is required'),
  features: z.object({
    branchProtection: z.boolean(),
    codeReview: z.boolean(),
    cicdIntegration: z.boolean(),
    autoMerge: z.boolean(),
  }),
});

type VersionControlForm = z.infer<typeof versionControlSchema>;

interface CommitInfo {
  hash: string;
  message: string;
  author: string;
  date: string;
  changes: {
    added: number;
    modified: number;
    deleted: number;
  };
}

interface BranchInfo {
  name: string;
  isProtected: boolean;
  lastCommit: string;
  author: string;
  status: 'active' | 'stale' | 'merged';
}

const FEATURES = [
  { id: 'branchProtection', name: 'Branch Protection', icon: <Shield className="w-5 h-5" />, description: 'Protect important branches' },
  { id: 'codeReview', name: 'Code Review', icon: <GitPullRequest className="w-5 h-5" />, description: 'Enforce code reviews' },
  { id: 'cicdIntegration', name: 'CI/CD Integration', icon: <RefreshCw className="w-5 h-5" />, description: 'Automated pipelines' },
  { id: 'autoMerge', name: 'Auto-merge', icon: <GitMerge className="w-5 h-5" />, description: 'Automatic merging' }
];

export function VersionControlPage() {
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [commitHistory, setCommitHistory] = useState<CommitInfo[]>([]);
  const [branches, setBranches] = useState<BranchInfo[]>([]);
  const [diffView, setDiffView] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { register, handleSubmit, watch, formState: { errors } } = useForm<VersionControlForm>({
    resolver: zodResolver(versionControlSchema),
    defaultValues: {
      branch: 'main',
      features: {
        branchProtection: true,
        codeReview: true,
        cicdIntegration: true,
        autoMerge: false,
      },
    },
  });

  const onSubmit = async (data: VersionControlForm) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // TODO: Implement actual version control operations
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Simulate commit history
      setCommitHistory([
        {
          hash: 'a1b2c3d',
          message: 'Update feature implementation',
          author: 'John Doe',
          date: '2024-02-20 14:30',
          changes: { added: 15, modified: 23, deleted: 5 }
        },
        {
          hash: 'e4f5g6h',
          message: 'Fix security vulnerability',
          author: 'Jane Smith',
          date: '2024-02-19 16:45',
          changes: { added: 8, modified: 12, deleted: 3 }
        }
      ]);

      // Simulate branches
      setBranches([
        {
          name: 'main',
          isProtected: true,
          lastCommit: 'a1b2c3d',
          author: 'John Doe',
          status: 'active'
        },
        {
          name: 'feature/new-ui',
          isProtected: false,
          lastCommit: 'e4f5g6h',
          author: 'Jane Smith',
          status: 'active'
        }
      ]);

    } catch (error) {
      console.error('Version control operation failed:', error);
      setError('Failed to perform version control operation. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getBranchStatusColor = (status: BranchInfo['status']) => {
    switch (status) {
      case 'active': return 'text-green-600 bg-green-50';
      case 'stale': return 'text-yellow-600 bg-yellow-50';
      case 'merged': return 'text-blue-600 bg-blue-50';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <GitBranch className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Version Control</h1>
              <p className="mt-1 text-sm text-gray-500">
                Manage your code with integrated version control features
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <GitCommit className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Commits</div>
                <div className="text-xs text-gray-500">Track changes</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <GitMerge className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Branches</div>
                <div className="text-xs text-gray-500">Manage branches</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <GitPullRequest className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Pull Requests</div>
                <div className="text-xs text-gray-500">Review code</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <History className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">History</div>
                <div className="text-xs text-gray-500">View changes</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Repository Configuration */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Repository Settings</h2>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Repository URL</label>
                <input
                  type="text"
                  {...register('repository')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="https://github.com/username/repo"
                />
                {errors.repository && (
                  <p className="mt-1 text-sm text-red-600">{errors.repository.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Branch</label>
                <input
                  type="text"
                  {...register('branch')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
                {errors.branch && (
                  <p className="mt-1 text-sm text-red-600">{errors.branch.message}</p>
                )}
              </div>

              {/* Features */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium text-gray-700">Features</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {FEATURES.map(feature => (
                    <label key={feature.id} className="flex items-start gap-3 p-4 border rounded-lg hover:bg-gray-50">
                      <input
                        type="checkbox"
                        {...register(`features.${feature.id}`)}
                        className="mt-1 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <div className="text-indigo-600">{feature.icon}</div>
                          <div className="font-medium text-gray-900">{feature.name}</div>
                        </div>
                        <div className="text-sm text-gray-500">{feature.description}</div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Commit Section */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <GitCommit className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Commit Changes</h2>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Commit Message</label>
                <textarea
                  {...register('message')}
                  rows={3}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="Describe your changes..."
                />
                {errors.message && (
                  <p className="mt-1 text-sm text-red-600">{errors.message.message}</p>
                )}
              </div>

              {/* File Changes */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium text-gray-700">Changed Files</h3>
                  <TokenCounter code={diffView} maxTokens={8192} />
                </div>

                <div className="border rounded-lg divide-y">
                  {selectedFiles.map((file, index) => (
                    <div key={index} className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <FileCode className="w-5 h-5 text-gray-400" />
                        <span className="text-sm text-gray-900">{file}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setSelectedFiles(files => files.filter((_, i) => i !== index))}
                        className="text-gray-400 hover:text-red-500"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>

                <CodeEditor
                  value={diffView}
                  onChange={setDiffView}
                  language="diff"
                  readOnly
                />
              </div>
            </div>
          </div>

          {/* Commit Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isLoading}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Committing...
                </>
              ) : (
                <>
                  <GitCommit className="w-5 h-5 mr-2" />
                  Commit Changes
                </>
              )}
            </button>
          </div>
        </form>

        {/* History Section */}
        {commitHistory.length > 0 && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <History className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Commit History</h2>
            </div>

            <div className="space-y-4">
              {commitHistory.map((commit, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <code className="text-sm font-mono text-gray-500">{commit.hash}</code>
                        <span className="text-sm text-gray-900">{commit.message}</span>
                      </div>
                      <div className="mt-1 text-sm text-gray-500">
                        {commit.author} committed on {commit.date}
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-green-600">+{commit.changes.added}</span>
                      <span className="text-blue-600">~{commit.changes.modified}</span>
                      <span className="text-red-600">-{commit.changes.deleted}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Branches Section */}
        {branches.length > 0 && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <GitBranch className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Branches</h2>
            </div>

            <div className="space-y-4">
              {branches.map((branch, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <GitFork className="w-5 h-5 text-gray-400" />
                        <span className="font-medium text-gray-900">{branch.name}</span>
                        {branch.isProtected && (
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">
                            Protected
                          </span>
                        )}
                      </div>
                      <div className="mt-1 text-sm text-gray-500">
                        Last commit {branch.lastCommit} by {branch.author}
                      </div>
                    </div>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full capitalize ${
                      getBranchStatusColor(branch.status)
                    }`}>
                      {branch.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}