import React, { useState } from 'react';
import { Bot, Loader2, Code2 } from 'lucide-react';
import { AIMLModelSelector } from '../components/AIML/AIMLModelSelector';
import { AIMLLanguageSelector } from '../components/AIML/AIMLLanguageSelector';
import { AIMLTaskSelector } from '../components/AIML/AIMLTaskSelector';
import { AIMLOutput } from '../components/AIML/AIMLOutput';
import { ComplexitySelector } from '../components/AIML/ComplexitySelector';
import { generateAIML } from '../lib/api/aiml';
import { AIML_MODELS } from '../config/aiml';
import { AIMLExamples } from '../components/AIML/AIMLExamples';
import type { AIMLProgress } from '../lib/api/aiml';
import type { AIMLLanguage, ComplexityLevel, AIMLModel, AIMLTask } from '../types/aiml';

export function AimlGeneration() {
  const [state, setState] = useState({
    isGenerating: false,
    result: '',
    error: null as Error | null,
    progress: { status: '', progress: 0 } as AIMLProgress,
    selectedModel: Object.keys(AIML_MODELS)[0] as AIMLModel,
    selectedLanguage: 'python' as AIMLLanguage,
    selectedTask: 'modelTraining' as AIMLTask,
    complexity: 'intermediate' as ComplexityLevel,
    prompt: ''
  });

  const updateState = (updates: Partial<typeof state>) => {
    setState(prev => ({ ...prev, ...updates }));
  };

  const handleGenerate = async () => {
    try {
      updateState({ isGenerating: true, error: null });

      const result = await generateAIML({
        model: state.selectedModel,
        language: state.selectedLanguage,
        task: state.selectedTask,
        complexity: state.complexity,
        prompt: state.prompt,
        parameters: {
          temperature: 0.7,
          topP: 0.9,
          maxTokens: 2048
        }
      }, (progress) => {
        updateState({ progress });
      });

      updateState({ result, isGenerating: false });
    } catch (error) {
      updateState({ 
        error: error as Error, 
        isGenerating: false,
        progress: { status: '', progress: 0 }
      });
    }
  };

  const handleExampleSelect = (example: {
    language: AIMLLanguage;
    task: AIMLTask;
    prompt: string;
  }) => {
    updateState({
      selectedLanguage: example.language,
      selectedTask: example.task,
      prompt: example.prompt
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-100 rounded-lg">
              <Bot className="w-8 h-8 text-blue-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">AI/ML Code Generation</h1>
          </div>
        </div>

        {/* Examples Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <AIMLExamples onSelect={handleExampleSelect} />
        </div>

        {/* Configuration Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="space-y-6">
            <AIMLModelSelector 
              selectedModel={state.selectedModel}
              onChange={(model) => updateState({ selectedModel: model as AIMLModel })}
            />
            
            <AIMLLanguageSelector
              selectedLanguage={state.selectedLanguage}
              onChange={(language) => updateState({ selectedLanguage: language })}
            />
            
            <AIMLTaskSelector
              selectedTask={state.selectedTask}
              onChange={(task) => updateState({ selectedTask: task as AIMLTask })}
            />

            <ComplexitySelector
              value={state.complexity}
              onChange={(level) => updateState({ complexity: level })}
            />

            {/* Prompt Input */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                value={state.prompt}
                onChange={(e) => updateState({ prompt: e.target.value })}
                rows={6}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Describe your AI/ML requirements in detail..."
              />
            </div>

            {/* Generate Button */}
            <div className="flex justify-end">
              <button
                onClick={handleGenerate}
                disabled={state.isGenerating}
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
              >
                {state.isGenerating ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Code2 className="w-5 h-5 mr-2" />
                    Generate Code
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Output Section */}
        <AIMLOutput
          result={state.result}
          error={state.error}
          isGenerating={state.isGenerating}
          progress={state.progress}
          language={state.selectedLanguage} // Pass the language prop
        />
      </div>
    </div>
  );
}
