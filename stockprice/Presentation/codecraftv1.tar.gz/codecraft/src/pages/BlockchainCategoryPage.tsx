import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Blocks,
  Settings2,
  Loader2,
  AlertTriangle,
  Link,
  Code2,
  Shield,
  Wallet,
  Coins,
  Network,
  GitBranch,
  CheckCircle2
} from 'lucide-react';
import { ModelSelector } from '../components/ModelSelector';
import { TokenCounter } from '../components/TokenCounter';

const blockchainSchema = z.object({
  projectName: z.string().min(3, 'Project name must be at least 3 characters'),
  network: z.object({
    type: z.enum(['ethereum', 'polygon', 'binance', 'solana', 'avalanche']),
    environment: z.enum(['mainnet', 'testnet', 'local']),
  }),
  contract: z.object({
    language: z.enum(['solidity', 'rust', 'move']),
    version: z.string().min(1, 'Version is required'),
    framework: z.string().min(1, 'Framework is required'),
  }),
  deployment: z.object({
    provider: z.enum(['hardhat', 'truffle', 'foundry', 'anchor']),
    autoVerify: z.boolean(),
  }),
  features: z.object({
    erc20: z.boolean(),
    erc721: z.boolean(),
    erc1155: z.boolean(),
    defi: z.boolean(),
    governance: z.boolean(),
  }),
  security: z.object({
    audit: z.boolean(),
    multisig: z.boolean(),
    upgradeability: z.boolean(),
  }),
  modelIds: z.array(z.string()).min(1, 'Select at least one model'),
});

type BlockchainForm = z.infer<typeof blockchainSchema>;

const NETWORKS = {
  ethereum: { name: 'Ethereum', environments: ['mainnet', 'goerli', 'sepolia'] },
  polygon: { name: 'Polygon', environments: ['mainnet', 'mumbai'] },
  binance: { name: 'BNB Chain', environments: ['mainnet', 'testnet'] },
  solana: { name: 'Solana', environments: ['mainnet', 'devnet'] },
  avalanche: { name: 'Avalanche', environments: ['mainnet', 'fuji'] },
};

const FRAMEWORKS = {
  solidity: {
    versions: ['0.8.19', '0.8.20', '0.8.21'],
    frameworks: ['OpenZeppelin', 'Chainlink', 'Aave'],
  },
  rust: {
    versions: ['1.69', '1.70', '1.71'],
    frameworks: ['Anchor', 'Seahorse', 'Solana Program Library'],
  },
  move: {
    versions: ['1.5', '1.6', '1.7'],
    frameworks: ['Aptos Framework', 'Sui Framework'],
  },
};

export function BlockchainCategoryPage() {
  const [isDeploying, setIsDeploying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [deploymentUrl, setDeploymentUrl] = useState<string | null>(null);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<BlockchainForm>({
    resolver: zodResolver(blockchainSchema),
    defaultValues: {
      network: {
        type: 'ethereum',
        environment: 'testnet',
      },
      contract: {
        language: 'solidity',
        version: '0.8.19',
        framework: 'OpenZeppelin',
      },
      deployment: {
        provider: 'hardhat',
        autoVerify: true,
      },
      features: {
        erc20: false,
        erc721: false,
        erc1155: false,
        defi: false,
        governance: false,
      },
      security: {
        audit: true,
        multisig: true,
        upgradeability: true,
      },
      modelIds: ['gemini-pro-code'],
    },
  });

  const selectedModels = watch('modelIds');
  const selectedLanguage = watch('contract.language');
  const selectedNetwork = watch('network.type');

  const onSubmit = async (data: BlockchainForm) => {
    setIsDeploying(true);
    setProgress(0);
    
    try {
      // Simulate deployment progress
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(interval);
            return 90;
          }
          return prev + 10;
        });
      }, 1000);

      // TODO: Implement actual deployment
      await new Promise(resolve => setTimeout(resolve, 5000));
      
      setDeploymentUrl('https://etherscan.io/address/0x...');
      setProgress(100);
    } catch (error) {
      console.error('Deployment failed:', error);
    } finally {
      setIsDeploying(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-8">
        {/* Header Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Blocks className="w-8 h-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Blockchain Technology</h1>
              <p className="mt-1 text-sm text-gray-500">
                Build and deploy secure blockchain applications with smart contracts
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Code2 className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Smart Contracts</div>
                <div className="text-xs text-gray-500">Multi-chain</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Shield className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Security</div>
                <div className="text-xs text-gray-500">Audited code</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Wallet className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Web3</div>
                <div className="text-xs text-gray-500">DApp ready</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <Coins className="w-5 h-5 text-indigo-600" />
              <div>
                <div className="text-sm font-medium text-gray-900">Tokens</div>
                <div className="text-xs text-gray-500">ERC standards</div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Project Configuration */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg font-medium text-gray-900">Project Configuration</h2>
            </div>

            <div className="space-y-6">
              <ModelSelector 
                selectedModels={selectedModels} 
                onChange={(models) => setValue('modelIds', models)} 
              />

              <div>
                <label className="block text-sm font-medium text-gray-700">Project Name</label>
                <input
                  type="text"
                  {...register('projectName')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
                {errors.projectName && (
                  <p className="mt-1 text-sm text-red-600">{errors.projectName.message}</p>
                )}
              </div>

              {/* Network Configuration */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Network</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Blockchain</label>
                    <select
                      {...register('network.type')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      {Object.entries(NETWORKS).map(([key, network]) => (
                        <option key={key} value={key}>
                          {network.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Environment</label>
                    <select
                      {...register('network.environment')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      {NETWORKS[selectedNetwork as keyof typeof NETWORKS].environments.map(env => (
                        <option key={env} value={env}>
                          {env.charAt(0).toUpperCase() + env.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Smart Contract Configuration */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Smart Contract</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Language</label>
                    <select
                      {...register('contract.language')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      {Object.keys(FRAMEWORKS).map(lang => (
                        <option key={lang} value={lang}>
                          {lang.charAt(0).toUpperCase() + lang.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Version</label>
                    <select
                      {...register('contract.version')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      {FRAMEWORKS[selectedLanguage as keyof typeof FRAMEWORKS].versions.map(version => (
                        <option key={version} value={version}>
                          {version}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Framework</label>
                    <select
                      {...register('contract.framework')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      {FRAMEWORKS[selectedLanguage as keyof typeof FRAMEWORKS].frameworks.map(framework => (
                        <option key={framework} value={framework}>
                          {framework}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Features */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Features</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('features.erc20')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">ERC-20 Token</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('features.erc721')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">ERC-721 NFT</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('features.erc1155')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">ERC-1155 Multi-Token</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('features.defi')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">DeFi Features</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('features.governance')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">Governance</span>
                  </label>
                </div>
              </div>

              {/* Security Features */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Security</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('security.audit')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">Security Audit</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('security.multisig')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">Multi-Signature</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('security.upgradeability')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">Upgradeability</span>
                  </label>
                </div>
              </div>

              {/* Deployment Configuration */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Deployment</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Provider</label>
                    <select
                      {...register('deployment.provider')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                      <option value="hardhat">Hardhat</option>
                      <option value="truffle">Truffle</option>
                      <option value="foundry">Foundry</option>
                      <option value="anchor">Anchor</option>
                    </select>
                  </div>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      {...register('deployment.autoVerify')}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">Auto-verify on Explorer</span>
                  </label>
                </div>
              </div>
            </div>
          </div>

          {/* Deploy Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isDeploying}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isDeploying ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Deploying...
                </>
              ) : (
                <>
                  <GitBranch className="w-5 h-5 mr-2" />
                  Deploy Contract
                </>
              )}
            </button>
          </div>
        </form>

        {/* Deployment Progress */}
        {isDeploying && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="space-y-4">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Deployment Progress</span>
                <span>{progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>
        )}

        {/* Deployment Result */}
        {deploymentUrl && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              <div>
                <h3 className="text-lg font-medium text-gray-900">Contract Deployed Successfully</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Your smart contract is now deployed at{' '}
                  <a
                    href={deploymentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-indigo-600 hover:text-indigo-500"
                  >
                    {deploymentUrl}
                  </a>
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}