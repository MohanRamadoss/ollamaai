import { TerraformRegistryScraper } from '../src/lib/rag/scraper.js';
import { ChromaDBClient } from '../src/lib/rag/chromadb.js';

async function main() {
  const scraper = new TerraformRegistryScraper();
  const chromaDB = new ChromaDBClient();

  // Initialize ChromaDB
  await chromaDB.initialize();

  // Providers to scrape
  const providers = ['aws', 'azurerm', 'google'];

  for (const provider of providers) {
    console.log(`Scraping provider: ${provider}`);
    
    // Scrape provider documentation
    const results = await scraper.scrapeProvider(provider);
    
    // Prepare documents for ChromaDB
    const documents = results.map((result, index) => ({
      id: `${provider}_${index}`,
      content: `${result.title}\n\n${result.description}\n\n${result.code}`,
      metadata: {
        provider: result.provider,
        resourceType: result.resourceType,
        source: result.source,
        lastUpdated: result.lastUpdated,
      },
    }));

    // Add to ChromaDB
    await chromaDB.addDocuments(documents);
    
    console.log(`Added ${documents.length} documents for ${provider}`);
  }

  console.log('Scraping and indexing complete!');
}

main().catch(console.error);